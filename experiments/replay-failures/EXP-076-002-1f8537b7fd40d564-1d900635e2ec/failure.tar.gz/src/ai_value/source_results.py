r"""Locate labelled TeX results without losing nested citation titles.

This is a bounded source index, not a TeX interpreter or proof checker.
Only an immediate label following the optional title identifies a result.
Cleveref's optional label type is permitted, e.g. ``\label[lemma]{key}``.
"""

from __future__ import annotations

import re


def named_results(text: str) -> list[dict]:
    # Ignore comments, retaining offsets for source locators.
    visible = re.sub(r"(?<!\\)%[^\n]*", lambda m: " " * len(m[0]), text)
    results = []
    for match in re.finditer(r"\\begin\{(theorem|lemma|proposition|corollary)\}", visible):
        pos = match.end()
        while pos < len(visible) and visible[pos].isspace():
            pos += 1
        title = None
        if pos < len(visible) and visible[pos] == "[":
            start, depth = pos + 1, 1
            pos += 1
            while pos < len(visible) and depth:
                if visible[pos] == "\\":
                    # Escaped brackets do not close an optional argument.
                    pos += 2
                    continue
                if visible[pos] == "[":
                    depth += 1
                elif visible[pos] == "]":
                    depth -= 1
                pos += 1
            if depth:
                raise ValueError("Unclosed result title at source offset " + str(match.start()))
            title = text[start:pos-1]
        label = re.match(r"\s*\\label(?:\[[^\]\n]*\])?\{([^}]+)\}", visible[pos:])
        if label is None:
            continue
        body_start = pos + label.end()
        end = visible.find(r"\end{" + match[1] + "}", body_start)
        if end < 0:
            raise ValueError("Unclosed result " + label[1])
        results.append({"kind": match[1], "label": label[1], "title_tex": title,
                        "start": match.start(), "statement_start": body_start,
                        "statement_end": end})
    return results
