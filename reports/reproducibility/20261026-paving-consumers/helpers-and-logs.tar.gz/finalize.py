from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,subprocess,tarfile
R=Path('/Users/smzdm/projects/ai_paper');W=Path(__file__).resolve().parent
O=R/'reports/reproducibility/20261026-paving-consumers';NOW=datetime.now(timezone.utc).isoformat()
def load(p):return json.loads((R/p).read_text())
def save(p,d):(R/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
core=(W/'core.log').read_text();assert 'Ran 69 tests' in core and '\nOK\n' in core
clean=json.loads(gzip.decompress((W/'clean-check.json.gz').read_bytes()));assert clean['core_exit_code']==0 and not (W/'clean').exists()
quality=json.loads(gzip.decompress((W/'quality.json.gz').read_bytes()));assert len(quality['impact_cases'])==26
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=R)
assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=R).decode().strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
for p in ['quality.json.gz','clean-check.json.gz']:shutil.copyfile(W/p,O/p)
# Check every third-party temporary source against its pinned whole-file hash.
download=json.loads((W/'downloads.json').read_text());sources=[]
for f in download['files']:
 p=Path(f['temporary_path']);b=p.read_bytes()
 assert hashlib.sha256(b).hexdigest()==f['sha256'] and len(b)==f['bytes']
 sources.append({'project':f['project'],'path':f['path'],'bytes':len(b),'sha256':f['sha256'],'removed':True})
assert len(sources)==11 and sum(x['bytes'] for x in sources)==202494
assert {p.resolve() for p in (W/'sources').rglob('*') if p.is_file()}=={Path(f['temporary_path']).resolve() for f in download['files']}
# Archive all our scripts, metadata, successes and failed QA attempts before removal.
members=sorted(p for p in W.iterdir() if p.is_file())
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in members:
  raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for p in members:assert t.extractfile(p.name).read()==p.read_bytes()
(O/'helpers-and-logs.tar.gz').write_bytes(packed)
storage={'at':NOW,'work_package':'WP-112','third_party_temporary_sources_hash_verified':sources,'third_party_body_bytes_removed':202494,'third_party_bodies_republished':False,'own_helper_members_verified':len(members),'helper_compressed_sha256':hashlib.sha256(packed).hexdigest(),'helper_decompressed_sha256':hashlib.sha256(raw).hexdigest(),'helper_archive_bytes':len(packed),'clean_core_exit_code':0,'clean_directory_removed':True,'clean_files':clean['files'],'clean_bytes':clean['bytes'],'clean_copy_hashes_verified':True,'source_and_failure_evidence_not_deleted':True,'new_scientific_experiments':0,'scope':'No numerical experiment. Selected external source metadata/ranges/hashes retained;third-party full bodies removed afterhashverification. Our outputs,source helpers andfailedQA preserved compressed beforecleanup.','work_root_removed':False}
save(str((O/'storage.json').relative_to(R)),storage)
j=load('state/reading-progress/WP-112.json');j.update({'status':'completed_bounded_source_qualification','completed_at':NOW,'generation_id':'GEN-20261026-109','canonical_ledger':'data/provenance/demand/F-300-paving-consumers.json','new_canonical_records':24,'new_explicit_edges':83,'new_candidates':0,'new_application_check_credit':0,'source_download_cleanup':'reports/reproducibility/20261026-paving-consumers/storage.json','next_action':'WP113 actualF020source reading;no morepavingconsumerprojects underthiscompletedbounded package.'});save('state/reading-progress/WP-112.json',j)
b=load('state/backlog.json');task=next(t for t in b['tasks'] if t['id']=='WP-112');assert task['status']=='in_progress'
task.update({'status':'completed','completed_at':NOW,'evidence':['GEN-20261026-109','data/provenance/demand/F-300-paving-consumers.json','reports/F300-paving-consumer-audit.md','reports/reproducibility/20261026-paving-consumers'],'result':'3pinnedprojects11source/licensefiles202494bytes2588actuallyreadlines. 24newcanonical83explicitrelations;5052oldcanonicalandalledges/code/tests/experiments/corpus/54familyreports/coveragepreserved. FullJSONGraphML/26impact/15archives267members/69core/no-mathclean passed. No newcandidate/check/experiment/formaldenial. Actualrelatedconsumers qualified,but no identical-output F300benefitbenchmark. Stop atprojectcap;WP113rotateF020 beforemandatory040.','next_action':'WP113 readactualF020 fullsource,formal/historicalscopes;15TeX3967+345Bib currentlyunread.'})
b['updated_at']=NOW;save('state/backlog.json',b)
nexttask=next(t for t in b['tasks'] if t['id']=='WP-113')
c=load('state/checkpoint.json');assert c['work_packages_since_last_retrospective']==1
c['saved_at']=NOW;c['overall_status']='active_incomplete';c['completed_work_packages'].append('WP-112');c['last_completed_work_package']='WP-112';c['work_packages_since_last_retrospective']=2
c['active_work_package']=nexttask;c['next_work_package']=nexttask;c['metrics']=load('reports/metrics.json');c['last_quality_evidence']='reports/reproducibility/20261026-paving-consumers/quality.json.gz';c['storage_receipt']='reports/reproducibility/20261026-paving-consumers/storage.json'
c['running_research_experiments']=[];c['retrospective_due_after']='Mandatoryglobal040 afterWP113,thirdsubstantivepackage since039;or earliermajorevidence/dataissue.'
c['recovery_commands']=['Readobjective/AGENTS/charter/roadmap/status/checkpoint/backlog/latestglobal039;verifydisk/processes andWP112storage beforecontinuing.','WP112 completedGEN109,3projectcap reached;do notrerunone-shotcurator,reacquire11softwarefiles orrepeatunchangedscientificexperiments merelyforfingerprint.',nexttask['next_action'],'WP113 source inventory15TeX3967lines+345Bib,README18linesonly;zero bodycredit. Actualfullsource/formal/selectedhistoricalscope andthenapplicationmapping,notnewtheoremproof.','Public21ce7dc coversWP111andolder983lineWP112journal. CurrentGEN109localonly;no routinepush.','No scientificoutput beforeindependent executablepreregistration;compress outputs/source snapshots andverifyroundtrip;officialmathreadonly.','WP113 musttrigger global040 comparingdifferent routes andold-method-null;counter2since039.']
c['recovery_observation']['WP112_close']={'at':NOW,'new_scientific_experiments':0,'running_project_processes':[],'upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','upstream_clean':True,'clean_copy_removed':True,'next_work_package':'WP-113','body_credit_for_next':0}
save('state/checkpoint.json',c)
text='WP112最终闭包（'+NOW+'）：69核心与无math干净副本均退出0；副本'+str(clean['files'])+'文件／'+str(clean['bytes'])+'字节逐项散列一致，副本已删除。26正负传播、完整JSON/GraphML对象、15归档267源码成员及全部5052旧规范行保持通过。11第三方源码202494字节逐项核散列后清理，不公开全文；自有'+str(len(members))+'成员及失败QA压缩回解验证。WP112完成，复盘039后计数2；下一WP113为F020，README18行与清单已读、正文0，完成后强制040。无新科学实验、安装、人审／第二供应商或GitHub写入，整体active_incomplete。'
for p in ['state/status.md','docs/roadmap.md']:
 with (R/p).open('a') as f:f.write('\n\n'+text+'\n')
# Recheck archived helpers immediately before deleting the temporary tree.
with tarfile.open(O/'helpers-and-logs.tar.gz') as t:
 for p in members:assert t.extractfile(p.name).read()==p.read_bytes()
shutil.rmtree(W);assert not W.exists()
storage['work_root_removed']=True;storage['removed_at']=datetime.now(timezone.utc).isoformat();save(str((O/'storage.json').relative_to(R)),storage)
print(json.dumps({'WP112':'completed','new_records':24,'new_edges':83,'core':69,'clean_exit':0,'clean_files':clean['files'],'helper_members':len(members),'work_root_removed':True,'counter':2,'next':'WP113 F020','overall':'active_incomplete','github_push':False}))
