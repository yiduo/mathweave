from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess

R=Path('/Users/smzdm/projects/ai_paper');W=Path(__file__).resolve().parent
O=R/'reports/reproducibility/20261026-paving-consumers';O.mkdir(exist_ok=True)
BASE='e1bd3d2';G='GEN-20261026-109';F='F-300';NOW=datetime.now(timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(path,data):
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def cite(path,locator):return {'path':path,'sha256':sha((R/path).read_bytes()),'commit':None,'locator':locator}
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],cwd=R).decode().strip()==BASE
nr=(R/'data/graph/nodes.jsonl').read_bytes();er=(R/'data/graph/edges.jsonl').read_bytes()
old=[json.loads(l) for l in nr.splitlines()];oldids={n['id'] for n in old}
assert len(old)==5052 and G not in oldids
j=json.loads((R/'state/reading-progress/WP-112.json').read_text());download=json.loads((W/'downloads.json').read_text())
assert j['actual_lines_read']==2588 and len(j['source_files'])==11
file_ids={
 ('petsc','LICENSE'):'LIT-300-PETSC-LICENSE',
 ('petsc','src/ksp/pc/impls/deflation/deflation.c'):'LIT-300-PETSC-DEFLATION',
 ('petsc','src/ksp/ksp/tutorials/ex11.c'):'LIT-300-PETSC-HELMHOLTZ',
 ('ginkgo','LICENSE'):'LIT-300-GINKGO-LICENSE',
 ('ginkgo','include/ginkgo/core/preconditioner/jacobi.hpp'):'LIT-300-GINKGO-JACOBI-API',
 ('ginkgo','core/preconditioner/jacobi.cpp'):'LIT-300-GINKGO-JACOBI-CORE',
 ('ginkgo','examples/preconditioned-solver/preconditioned-solver.cpp'):'LIT-300-GINKGO-SOLVER',
 ('tenpy','LICENSE'):'LIT-300-TENPY-LICENSE',
 ('tenpy','tenpy/linalg/truncation.py'):'LIT-300-TENPY-TRUNCATION',
 ('tenpy','tenpy/algorithms/tebd.py'):'LIT-300-TENPY-TEBD',
 ('tenpy','tenpy/algorithms/algorithm.py'):'LIT-300-TENPY-PARENT'}
files=[]
for f in j['source_files']:
 f=dict(f);match=next(x for x in download['files'] if x['project']==f['project'] and x['path']==f['path'])
 raw=Path(match['temporary_path']).read_bytes()
 assert sha(raw)==f['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==f['git_blob_sha1']
 covered=set()
 for a,b in f['actual_read_ranges']:assert 1<=a<=b<=f['lines'];covered.update(range(a,b+1))
 assert len(covered)==f['actual_lines_read']
 f.update(node_id=file_ids[f['project'],f['path']],code_executed=False)
 files.append(f)
assert len(files)==11 and sum(f['bytes'] for f in files)==202494
contracts=[
 {'id':'PART-300-PETSC-DEFLATION','title':'PETSc coarse correction and deflated preconditioner',
  'input':'A,W,coarseKSP andadditionalpreconditioner;coarse matrix W* A W must be solvable,not guaranteed byfullcolumnrankW for arbitraryA.',
  'output':'Presolve r=b-Ax,x+=W(W*AW)^-1W*r;application P M^-1+factor Q withQ=W(W*AW)^-1W*,P=I-QA,subjecttoinit/correctionoptions.',
  'conditions':'Pinned selectedSetup/PreSolve/Apply/API andmodulemanual;coarseFCG onlywhenSPDknown,otherwiseFGMRES in multilevelbranch,bottomdirectsolve;notexecuted.',
  'cannot_transfer':'CodeQ/P are notautomatically selfadjointorthogonalF300q;small compressedresidual doesnotcertifyfullsystem residual,coarseinvertibility orconditioning.',
  'refs':['LIT-300-PETSC-DEFLATION']},
 {'id':'PART-300-PETSC-HELMHOLTZ','title':'Actual PETSc complex Helmholtz full-vector consumer',
  'input':'Complexfivepointunit-squareHelmholtzA,knownu,b=Au;runtimeKSP;selecteddeflation testset.',
  'output':'SolvefullAx=b andprint2-normx-u/iterationcount;deflation testsrequirecomplexbuild andSuperLU_DIST.',
  'conditions':'Actualselectedcaller sourcefullyread;imaginarydiagonal generallynonHermitian,notexecuted.',
  'cannot_transfer':'No state-weighted discardedsubspacebudget orselfadjointinputqualification;genericSPD branchdoesnotmake thiscallerSPD.',
  'refs':['LIT-300-PETSC-HELMHOLTZ','LIT-300-PETSC-DEFLATION']},
 {'id':'PART-300-GINKGO-JACOBI','title':'Ginkgo inverse diagonal blocks and adaptive storage interface',
  'input':'SquarematrixconvertedtosortedCSR,contiguousblockstarts0..n orheuristicblockdetection;blocksize/executorstrideconstraints.',
  'output':'Storedinverse diagonalblocks;optionalL1 diagonalaugmentation andperblockreducedprecision;applydispatch.',
  'conditions':'Defaultmaxblock32,parametersallowNVIDIA32/AMD64 subjectactualexecutorstride;docs32isnotuniversal. Defaultfullprecision;accuracy0.1onlyusedforadaptiveautodetection.',
  'cannot_transfer':'Adaptiveaccuracy/dropoutdocumentationisnot uniformF300operatornormtheorem. F300partitiondoesnotitself supplycontiguoussmallinvertibleblocks,conditioning,permutationcost orsolverrate;backendkernelbodiesunread.',
  'refs':['LIT-300-GINKGO-JACOBI-API','LIT-300-GINKGO-JACOBI-CORE']},
 {'id':'PART-300-GINKGO-CG-CALL','title':'Actual Ginkgo CG solve and full residual consumer',
  'input':'DoubleCSR A andb/x0 readfromdata/*.mtx;CG withJacobi maxblock8,iterationcap20,residualreduction1e-7.',
  'output':'Solutionx andfull2-normAx-b;actualexampledoesnotenableadaptivestorage.',
  'conditions':'Caller94linesfullyread;matrix/RHSfixturebodiesnotdownloadedorvalidated,soSPD/conditioningscale notcertifiedfromcallsite.',
  'cannot_transfer':'Fullresidualcriterionisnotstateweightedcompression;CGusealone doesnotestablishunreadinputproperties orF300constructor/benefit.',
  'refs':['LIT-300-GINKGO-SOLVER','LIT-300-GINKGO-JACOBI-API']},
 {'id':'PART-300-TENPY-SCHMIDT','title':'TeNPy normalized Schmidt truncation and factor output',
  'input':'NormalizedSchmidtspectrumfromactualSVD;chi_max/chimin/degeneracy/svd_min/trunc_cut constraints.',
  'output':'Keptmask,renormalizedS,U/Vfactorprojections,renormalization andeps=sumdiscardedS^2;trunc_cut targets eps<=trunc_cut^2 onlywhencompatible.',
  'conditions':'Actual_combine_constraintswarnsandkeepspreviousgoodmaskwhenintersectionempty;no unconditionalallthresholds guarantee. eigh_rho normalizespositiveeigenweights andpassessqrt totruncate.',
  'cannot_transfer':'ArbitrarynearidentityF300q doesnotprovide a bondrankchi/charge-compatible Schmidtcut,lowrank factors,orcheaperSVD. Imaginary-timeerrorisnotgroundstatequality;Trottererrordistinct.',
  'refs':['LIT-300-TENPY-TRUNCATION']},
 {'id':'PART-300-TENPY-TEBD-CALL','title':'Actual TEBD tensor update and truncation accumulation',
  'input':'Two-siteMPS theta,U_bond,labeledlegs/charges,canonicalform andtrunc_params.',
  'output':'svd_theta factors rebuildA/B tensors andSchmidtbond;renormalization andperbond/sequenceTruncationError accumulated. ImaginaryGS usesenergychange.',
  'conditions':'Selectedreal/imaginaryupdate bodiesandGSloopread,notexecuted;alllibrary/dependencyclosure notread.',
  'cannot_transfer':'Smallstateweightlossdoesnotbyitselfretainlocaltensorstructure,bondrank/charge/canonicalform,Trotteraccuracy orgroundstatefidelity.',
  'refs':['LIT-300-TENPY-TEBD','LIT-300-TENPY-TRUNCATION']},
 {'id':'PART-300-TENPY-ERROR-DISPATCH','title':'Selected TEBD override versus parent truncation-check path',
  'input':'TimeEvolutionAlgorithm.evolve defaultloop versusTEBDEngine.evolve override.',
  'output':'Parentdefault callsconsistency_check(trunc_err.eps,options,max_trunc_err,0.01);selectedTEBDoverride accumulatesandreturns errorwithoutcallingparentmethod. TEBDcalc_U insteadcallsmax_delta_t check.',
  'conditions':'Staticselecteddispatchqualification only;consistency_checkbodyunread. Parentrun_evolution andTEBDevolve eachaddcounter,so runtimeaccountingnotcertified;no bugreportorapplication claim.',
  'cannot_transfer':'Do notattributeparent0.01truncationgatetoactualTEBDoverrideorusecounteras independentlyvalidatedfullphysicalerror.',
  'refs':['LIT-300-TENPY-PARENT','LIT-300-TENPY-TEBD']}
]
problems=[
 ('PROB-300-SOLVER-CONSUMER','Full linear-solve output remains outside the admitted compressed interface','PETScselectedcaller isgenerallynonHermitian;Ginkgo fixturepropertiesunread. Bothdemandfullvectoroutput/residual,not arbitraryq-compressedoperatorerror. Needactualselfadjointproblem,allowedloss,constructor andindependentfull-outputjudge.', ['PART-300-PETSC-HELMHOLTZ','PART-300-PETSC-DEFLATION','PART-300-GINKGO-CG-CALL'],'PROB-300-OUTPUT-SEMANTICS'),
 ('PROB-300-INVERSE-BLOCK-COST','Bounded inverse-block structure and full costs unestablished','F300blockcount doesnotboundmaximumblocksize orproveeachdiagonalblockinvertible/wellconditioned. Needreordering,fill,assembly/inversion/storage,iterations,fullresidual andoldstrongbaselines costed.', ['PART-300-GINKGO-JACOBI','PART-300-PETSC-DEFLATION'],'PROB-300-FINITE-COST'),
 ('PROB-300-TENSOR-COMPRESSION','Actual discarded-weight consumer lacks a compatible F300 constructor','TeNPyisarealstate-lossconsumer,butgeneralqdoesnotprovidecharge-compatible boundedSchmidtrank orlabeledU/S/Vfactors;no identical-output cheaperconstructor/baselinebatchorindependentphysicalerrorjudge admitted.', ['PART-300-TENPY-SCHMIDT','PART-300-TENPY-TEBD-CALL','PART-300-TENPY-ERROR-DISPATCH'],'PROB-300-STATE-INTERFACE'),
 ('PROB-300-CONSUMER-ADMISSION','No identical-output finite application benchmark admitted in this bounded audit','Threeprojectsreachedbudget. FiniteMSS/RSexistencebounds,olddeflation/JacobiandSVDmayalreadymeetactualneeds;oldexistenceboundalsoisnotprovenpracticalconstructor. Retainclueswithoutformaldenialorforcedexperiment.', ['PART-300-PETSC-DEFLATION','PART-300-GINKGO-JACOBI','PART-300-TENPY-SCHMIDT'],'PROB-300-FINITE-COST')]
ledger={'work_package':'WP-112','family_id':F,'generation_id':G,'at':NOW,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'upstream_commit':j['upstream_commit'],'selected_projects':download['pins'],'project_count':3,'source_file_count':11,'new_source_body_bytes':202494,'actually_read_lines':2588,'selected_source_files':files,'reading_notes':j['qualified_notes'],'source_acquisition_failures':j['source_acquisition_failures'],'contracts':contracts,'premise_gaps':[{'id':i,'title':t,'statement':s,'contracts':refs,'prior_gap':prior} for i,t,s,refs,prior in problems],'baseline_comparison':['OldPETScdeflation/coarsesolve/Jacobipreconditionerscompeteonfullsolvecorrectness+setup/inversion+storage+iterations,notpartitioncountalone.','OldSchmidtSVD/tensorstructuredtruncation alreadyreturnsactualneededfactorsandweightledger. Comparefactorization+reconstruction+physicalaccuracy,notjustepsbookkeeping.','OldfiniteMSS/RSboundsfromWP111selectedoriginalscopesmayalreadygivefiniteexistenceparameters;neitheroldnornewexistenceboundisbyitselfaefficientconstructor.'],'new_candidates':0,'new_scientific_experiments':0,'new_application_checks':0,'formal_denials':0,'human_reviews':0,'independent_second_provider_reviews':0,'decision':'Boundedauditcomplete;retainconditionaloutput/state/costclues,stopat3projectsand11files. No admittedidentical-outputF300benchmark,nonewtestgainhypothesis. RotateWP113todifferentlowcoveragearea.','scope_limits':'11selectedfiles/ranges,notwholeprojectproof/performance/securityaudit. Runtimefixtures,kernels,fulltensordependencyclosureunread;noinstall,build,solverexecutionorbenchmark.'}
lp='data/provenance/demand/F-300-paving-consumers.json';write(lp,ledger)
cfg='data/provenance/research-at-generation-109.json';(R/cfg).write_bytes((R/'configs/research.json').read_bytes())
ls=cite(lp,'WP112 pinnedactualsource/ranges,consumerinterfaces,errorsemantics,oldbaselines andstopdecision;notapplicationvalidation')
ss=cite('data/provenance/readings/F-300.json','WP111 source-qualifiedF300contracts;sourceC/fullchainunknown,notprooforapplicationacceptance')
new=[];edges=[]
def node(i,k,p,sources=None):
 assert i not in oldids and all(x['id']!=i for x in new)
 new.append({'id':i,'kind':k,'created_at':NOW,'version':1,'evidence_status':'source_content_checked','sources':sources or [ls,ss],'properties':{'family_ids':[F],'model_generation_id':G,'credibility':'unknown','dependency_closure_complete':False,**p}})
def edge(s,r,t,loc):
 edges.append({'id':'E-'+sha(('WP112|'+s+'|'+r+'|'+t+'|'+loc).encode())[:16].upper(),'source':s,'relation':r,'target':t,'source_locator':loc,'source_commit':None,'created_at':NOW,'version':1,'evidence_status':'source_content_checked'})
node(G,'generation',{'title':'F300 bounded real-consumer output/error/cost qualification','provider':'OpenAI','model':'Current user-selected session;exact backend unknown','project_base_commit':ledger['base_commit'],'independent_second_provider':None,'human_review':None},[ls,cite(cfg,'Researchexecutionpolicy snapshot atgeneration109')])
for f in files:
 ext={'url':f['url'],'sha256':f['sha256'],'commit':f['commit'],'content_checked':True,'locator':f['commit']+';'+f['path']+';actuallyreadranges '+str(f['actual_read_ranges'])+';hashcoverswholefile,butreadingonlydeclaredranges;notexecuted'}
 node(f['node_id'],'literature',{'title':f['repo']+' '+f['path'],'source_type':'pinned_software_license' if f['path']=='LICENSE' else 'pinned_software_source','source_commit':f['commit'],'actually_read_ranges':f['actual_read_ranges'],'actually_read_lines':f['actual_lines_read'],'whole_file_read':f['full_file_read'],'code_executed':False},[ls,ext])
for c in contracts:
 node(c['id'],'method',{k:v for k,v in c.items() if k not in ['id','refs']}|{'application_gain_tested':False})
 for ref in c['refs']:edge(c['id'],'depends_on',ref,'Pinnedactuallyreadimplementation/callerstatement;sourcechangerequiresqualificationreview')
for i,title,statement,refs,prior in problems:
 node(i,'problem',{'title':title,'statement':statement,'prerequisite_status':'unestablished_for_real_application','actual_related_consumer_identified':True,'identical_output_benchmark_admitted':False,'formal_denial':False,'revisit_when':'Actualinput/output/error/structurecertificate,constructivewitness,independentjudge andfullsame-outputbaselinecostbecomeavailable.'})
 for ref in refs:edge(i,'depends_on',ref,'Interfacecomparisonrequiresactualselectedconsumercontract,notmathematicalproofdependence')
 edge(i,'references',prior,'SpecificsoftwarequalificationelaboratesexistingunestablishedF300premise')
node('EXPLORE-F-300-CONSUMERS','exploration',{'title':'Three distinct actual consumer routes and bounded stop','family_ids':[F],'routes':['PETScfullsystemcoarsecorrection','Ginkgoboundedinverseblocks/fullresidual','TeNPytensorstructuredstate-losscompression'],'new_connection_count':0,'admitted_identical_output_benchmark':False,'old_methods_may_suffice':True,'new_experiment_count':0,'stop_reason':'Threeprojectcapreached;newsourceidentifiedtypedmismatchbutno independenttestgainprediction. Retainconditionalclues androtatecoverage.','formal_denial':False})
for i,_,_,_,_ in problems:edge('EXPLORE-F-300-CONSUMERS','depends_on',i,'Boundedstopdecisionretainsexactconsumerpremisegaps')
for part in ['PART-300-STATE-TO-STRONG-CORNERS','PART-300-SPECTRAL-CUT-CERTIFICATE','PART-300-SAME-PARTITION-CONTROL']:
 edge('EXPLORE-F-300-CONSUMERS','depends_on',part,'Mathematicalinterfacecomparison,notaninferredpracticalconstructorornewproof')
for i in ['LIT-300-RS21','LIT-300-MSS15']:
 assert i in oldids
 edge('PROB-300-CONSUMER-ADMISSION','compared_with',i,'WP111selectedoldscope;finiteexistencebaseline,notknownruntimealgorithm')
for n in new:
 if n['id']!=G:edge(n['id'],'generated_by',G,'CurrentselectedOpenAIsession;unknownexactbackend,nohumanorsecondprovidercredit')
 edge(n['id'],'about_family',F,'Boundedconsumerqualification;noadditionalfamilycompletioncredit')
assert len(new)==24
known=oldids|{x['id'] for x in new}|{F};oldedgeids={json.loads(l)['id'] for l in er.splitlines()}
assert all(x['source'] in known and x['target'] in known for x in edges)
assert len({e['id'] for e in edges})==len(edges) and all(e['id'] not in oldedgeids for e in edges)
(R/'data/graph/nodes.jsonl').write_bytes(nr+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in new))
(R/'data/graph/edges.jsonl').write_bytes(er+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in edges))
write(str((O/'curation.json').relative_to(R)),{'at':NOW,'generation_id':G,'base_commit':ledger['base_commit'],'new_canonical_records':len(new),'new_explicit_edges':len(edges),'all_5052_old_canonical_lines_preserved':True,'all_old_edge_bytes_preserved':True,'selected_files':11,'actual_lines':2588,'downloaded_bytes':202494,'new_candidates':0,'new_application_checks':0,'new_scientific_experiments':0,'node_ids':[n['id'] for n in new]})
print(json.dumps({'new_records':len(new),'new_explicit_edges':len(edges),'old_records_preserved':len(old),'ledger':lp}))
