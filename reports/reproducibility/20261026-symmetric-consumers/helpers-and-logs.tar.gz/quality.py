from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime,xml.etree.ElementTree as ET,collections
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP109');O=R/'reports/reproducibility/20261026-symmetric-consumers';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,validate,impact_report,read_jsonl
from ai_value.knowledge import export
sha=lambda b:hashlib.sha256(b).hexdigest();BASE='ab9f4f1869d72591e39d0d5543283fab4be2b59a'
def old(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def put(p,x):
 b=(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.write_bytes(z)
for p in ['data/graph/nodes.jsonl','data/graph/edges.jsonl']:
 assert (R/p).read_bytes().startswith(old(p)),p
for folder in ['experiments','src','tests','data/corpus','reports/families']:
 tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,folder],cwd=R).decode().splitlines()
 for p in tracked:assert (R/p).read_bytes()==old(p),p
for p in ['data/graph/reading_coverage.json','data/provenance/readings/F-239.json']:
 assert (R/p).read_bytes()==old(p),p
metrics=validate(R);nodes,edges=load(R);result=export(R)
assert metrics['candidate_connections']==45 and metrics['externally_checked_cards']==13 and metrics['effective_leads']==5
assert nodes['APP-239-01']['properties']['run_ids']==[] and nodes['APP-239-01']['properties']['theoretical_grade']=='unknown'
actual=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in actual['nodes']}==nodes and actual['edges']==edges
x=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};graph=x.find('g:graph',ns)
gn={n.attrib['id']:json.loads(next(d for d in n if d.attrib.get('key')=='properties').text) for n in graph.findall('g:node',ns)}
ge=[json.loads(next(d for d in e if d.attrib.get('key')=='evidence').text) for e in graph.findall('g:edge',ns)];assert gn==nodes and ge==edges
cases=[]
for seed,target,expect in [('PROB-239-RANK-CONSUMER-GATE','APP-239-01',True),('CLM-239-U-THM-MAIN','APP-239-01',True),('CLM-239-B-THM-MAIN','APP-239-01',False),('LIT-239-TALAGRAND1988','APP-239-01',True),('LIT-239-TALAGRAND1995','APP-239-01',False),('LIT-239-QUIMB-BUILDER','APP-239-01',True),('LIT-239-QUIMB-RAND','APP-239-01',True),('LIT-239-QUIMB-TEST','APP-239-01',True),('LIT-239-JULIA-GAUSSIAN','APP-239-01',False),('LIT-239-RESERVOIR-MATGEN','APP-239-01',False),('CLM-174-LEM-RATIONAL-PSD','APP-239-01',False),('APP-239-01','APP-332-01',False),('LIT-239-TALAGRAND1988','CLM-239-B-THM-MAIN',False)]:
 r=impact_report(nodes,edges,{seed});assert (target in r['affected'])==expect,(seed,target,expect);cases.append({'seed':seed,'target':target,'expected':expect,'actual':target in r['affected'],'affected':r['affected']})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_bytes());folder=p.parent
 for name,h in m['outputs'].items():assert sha((folder/name).read_bytes())==h,(p,name)
 for name,record in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((folder/name).read_bytes()))==record['uncompressed_sha256'],(p,name)
 snapshot=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
 for name,body in snapshot.items():assert sha(body.encode())==m['inputs'][name],(p,name)
 members+=len(snapshot);archives.append({'run_id':m['run_id'],'source_members':len(snapshot),'compressed_and_decompressed_hashes_verified':True})
assert len(archives)==15 and members==267
sources=[s for n in read_jsonl(R/'data/graph/nodes.jsonl') for s in n['sources']];counts=collections.Counter('local_hashed' if 'path'in s else 'external_hashed' if s.get('sha256') else 'external_no_byte_hash' for s in sources)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metrics':metrics,'canonical_records':len(read_jsonl(R/'data/graph/nodes.jsonl')),'canonical_citations':len(sources),'citation_kinds':dict(counts),'old4741canonical_lines_and_alloldedges_byte_exact':True,'old_experiment_source_specs_data_tests_corpus_byte_exact':True,'all53oldfamily_reports_byte_exact':True,'old_coverage_and_F239reading_ledger_byte_exact':True,'full_json_and_graphml_object_equality':True,'export':result,'impact_cases':cases,'archive_count':len(archives),'archived_source_members':members,'archive_integrity':archives,'scientific_replay_scope':'Archive hash integrity only;unchanged experiment code/spec/data,no new efficacy evidence. Current public snapshot already actually replayed13archives in CI40266152023;new conditional card has no run.'}
put(O/'source-contracts.json.gz',receipt);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','archive_integrity','export']},ensure_ascii=False))
