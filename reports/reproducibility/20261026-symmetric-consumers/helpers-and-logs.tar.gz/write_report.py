from pathlib import Path
import json
R=Path('/Users/smzdm/projects/ai_paper')
L=json.loads((R/'data/provenance/demand/F-239-symmetric-sign-contracts.json').read_text())
N={n['id']:n for n in map(json.loads,(R/'data/graph/nodes.jsonl').read_text().splitlines())}
C=N['APP-239-01']['properties']
lines=['# F239：真实软件分布、输出需求与条件性秩风险接口','',
 '2026-10-26 · WP109。由规范图谱节点与其散列绑定的需求台账导出；不是完整成果族研究、应用初检或人审。','',
 f"三个固定原始项目、17份源码／文档／许可文件，下载 {L['new_body_bytes']} 字节，实际选读 {L['actually_read_lines']} 行；完整下载不等于完整阅读，没有执行这些软件。恢复时沿用已获取的散列一致来源，没有新增下载或数值实验。",'',
 '## 已核对的输入与实际调用','',
 '| 项目 | 固定版本 | 实际输入／输出 | 本包结论 |','| --- | --- | --- | --- |']
for p,c in zip(L['projects'],L['actual_contract_comparisons']):
 lines.append('| '+p['repository']+' | `'+p['commit']+'` | '+c['actual_output']+' | '+c['decision']+' |')
lines+=['','quimb 每个坐标多重集调用一次标量填充。只有明确指定的实数两索引、Rademacher、loc=0、scale=1、标准填充、保留随机对角时，才对应 F239 无偏模型；概率仍以理想 IID 抽样为前提，不是对有限 PRNG 的独立性认证。普通开边界二维格点的角张量有两个索引，其他边／内部通常为三／四索引。实际已读测试使用 normal 默认值，只检查收缩与置换不变性，没有可逆性请求。','',
 '均值平移、自定义填充、复数四相位、固定图对角与高阶展平分别改变前提。MPO 的 Hermitian 加法对称化也不是同一上三角符号分布。偏置接口没有在所选 quimb 标准 Rademacher 工厂中建立；不能把 F239 固定偏置主定理直接套入。','',
 '## 保留的候选与尚缺的价值检验','',
 '[APP-239-01](cards/APP-239-01.md) 保留为近类比、候选、待定：若消费者必须保持该离散初始化律并要求所选两索引映射可逆，可探索锐渐近精确秩风险作为决策元数据。具体消费者尚未建立。源定理给出 `2^(-D+o(D))`，没有有效有限 D 阈值、条件数、收缩精度或运行收益。','',
 C['prediction'],'',
 '两位隔离 OpenAI 角色都支持窄条件保留。辩护者重视已实现的分布映射；怀疑者强调实际可逆性需求和增量决策价值仍缺，高阶展平可能因重复行退化。完整输出与冻结输入位于 `data/provenance/reviews/APP-239-01-isolated-roles.json.gz`。这是同供应商辅助自查，精确后端未知，不是外部检验或真实人审。','',
 '源码中的 sign-to-bit Schur／合同变换属于证明接口，维度 D→D−1；不作为已实现的初始化优化，也不从此导出更快的拒绝采样。','',
 '## 强旧基线与零假设','']+['- '+s for s in L['baselines']]
lines+=['','零假设仍是旧方法已满足实际输出，锐渐近指数没有改变有用决策。先确定精确秩、数值稳定性或谱半径中实际要哪种输出，再比较同输出的完整成本。没有实际任务、独立裁判与预先冻结的有限维阈值，不运行小矩阵频率作为渐近定理或应用有效性的证明。','',
 '## 未完成项与停止决定','']+['- '+s for s in L['gaps']]
lines+=['',L['stop_decision'],'',
 '本包新增一条条件候选，初检仍13项，五项限定支持／八项不利；没有新增有效线索、独立假设验证、人审、第二供应商复核或试点。58阅读／53源码草稿与 F238 的4/12篇范围保持。GitHub 本批之后不例行推送；公开8700f8b仅包含当时未完成日志，当前规范增量本地保存。','',
 '## 实际阅读定位','', '| 来源节点 | 文件 | 实际范围 | 文件 SHA256 |','| --- | --- | --- | --- |']
for f in L['selected_source_files']:
 ranges=', '.join(f'{a}–{b}' for a,b in f['actually_read_ranges'])
 lines.append(f"| `{f['node_id']}` | [{f['repository']} / {f['source_path']}]({f['url']}) | {ranges} | `{f['sha256']}` |")
lines+=['','全量约束、外键、依赖失效、完整导出、归档回解及干净目录检查另见 `reports/reproducibility/20261026-symmetric-consumers/`。检查成功只表明记录和软件约束通过，不能替代应用或数学审核。','']
(R/'reports/F239-symmetric-sign-interface-audit.md').write_text('\n'.join(lines))
print('Rendered F239 report from canonical candidate and hashed demand ledger')
