from pathlib import Path
import json,gzip,tarfile,io,hashlib,datetime,shutil
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP109');O=R/'reports/reproducibility/20261026-symmetric-consumers';sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
ledger=json.loads((R/'data/provenance/demand/F-239-symmetric-sign-contracts.json').read_bytes())
clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()))
assert clean['exit_code']==0 and not(T/'no-math-clean').exists()
assert next(x for x in clean['manifest']if x['path']=='data/graph/nodes.jsonl')['sha256']==sha((R/'data/graph/nodes.jsonl').read_bytes())
assert json.loads((R/'state/backlog.json').read_bytes())['tasks'][-1]['id']=='WP-110'
third=[]
for row in ledger['selected_source_files']:
 p=T/'sources'/row['repository'].replace('/','--')/row['source_path'];b=p.read_bytes();assert not p.is_symlink() and sha(b)==row['sha256'] and len(b)==row['bytes'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'url':row['url']})
assert len(third)==17 and sum(x['bytes']for x in third)==394010
assert {str(p)for p in (T/'sources').rglob('*')if p.is_file()}=={x['path']for x in third}
for row in third:Path(row['path']).unlink()
shutil.rmtree(T/'sources')
reused=[]
with tarfile.open(R/'reports/reproducibility/20261026-symmetric-sign/helpers-and-logs.tar.gz','r:gz')as old:
 for p in sorted(T.glob('WP108-*')):
  member=p.name.removeprefix('WP108-');b=p.read_bytes();assert old.extractfile(member).read()==b;reused.append({'member':member,'sha256':sha(b),'source_archive':'reports/reproducibility/20261026-symmetric-sign/helpers-and-logs.tar.gz','duplicate_plaintext_removed':True});p.unlink()
(T/'cleanup-sources.json').write_text(json.dumps({'at':now,'third_party_files_hash_verified_removed':third,'third_party_bytes_removed':394010,'reused_helper_references':reused},indent=2)+'\n')
assert all(p.is_file()for p in T.iterdir())
own=sorted(T.iterdir());members=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w')as archive:
 for p in own:
  b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(b));members.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);dest=O/'helpers-and-logs.tar.gz';dest.write_bytes(z);assert gzip.decompress(dest.read_bytes())==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(dest.read_bytes())))as archive:
 assert archive.getnames()==[m['name']for m in members]
 for m in members:assert sha(archive.extractfile(m['name']).read())==m['sha256']
for p in own:p.unlink()
assert not list(T.iterdir());T.rmdir()
receipt={'at':now,'archive':'reports/reproducibility/20261026-symmetric-consumers/helpers-and-logs.tar.gz','compressed_bytes':len(z),'uncompressed_tar_bytes':len(raw),'archive_sha256':sha(z),'decompressed_tar_sha256':sha(raw),'members':members,'all_member_roundtrip_hashes_verified':True,'own_plaintext_bytes_removed':sum(x['bytes']for x in members),'third_party_files_verified_removed':third,'third_party_temporary_bytes_removed':394010,'reused_helper_copies_replaced_by_archive_references':reused,'temporary_root_removed':not T.exists(),'scientific_archive_integrity':{'archives':15,'source_members':267},'new_scientific_experiment':False,'scientific_replays_this_package':[],'new_numerical_data':'None;new data is software-source contract/provenance,not a numeric experiment. Original raw/summary/source payloads stay compressed.','all_quality_handles_terminal':True,'upstream_math_written':False,'github_write_this_research_package':False,'last_verified_public_commit':'8700f8b7dbb6e9ecd1f62e7d5e5794e81d99b30f','overall_goal':'active_incomplete'}
(O/'storage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k not in ['members','third_party_files_verified_removed','reused_helper_copies_replaced_by_archive_references']},ensure_ascii=False))
