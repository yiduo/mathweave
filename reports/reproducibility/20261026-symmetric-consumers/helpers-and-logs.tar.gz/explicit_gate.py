from pathlib import Path
import datetime,json,hashlib,gzip
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP109');O=R/'reports/reproducibility/20261026-symmetric-consumers'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['no-math-clean-directory.json.gz','source-contracts.json.gz']:
 p=O/name;target=O/name.replace('.json.gz','-before-explicit-gate.json.gz');assert not target.exists();target.write_bytes(p.read_bytes())
for name in ['core.log','quality.log','no-math-clean.log','clean-helper.log']:
 (T/('before-explicit-gate-'+name)).write_bytes((T/name).read_bytes())
node={'id':'PROB-239-RANK-CONSUMER-GATE','kind':'problem','version':1,'created_at':now,'evidence_status':'hypothesis','properties':{'title':'Unestablished rank-sensitive law-preserving consumer and finite decision gate','family_ids':['F-239'],'model_generation_id':'GEN-20261026-106','credibility':'unknown','dependency_closure_complete':False,'prerequisite_status':'unestablished','actual_consumer_identified':False,'input':'Real consumer/domain specification requiring exact invertibility of the raw two-index ensemble,law constraints,D range,selection count,decision/loss and independent finite-D judge','output':'Qualification evidence permitting a separately preregistered application-value test;not theorem validity or automatic acceptance','reason':'Inspected actual quimb caller only contracts normal-default tensors;no nonsingularity decision or finite-D utility requirement established.'},'sources':[{'path':'data/provenance/demand/F-239-symmetric-sign-contracts.json','sha256':sha((R/'data/provenance/demand/F-239-symmetric-sign-contracts.json').read_bytes()),'commit':None,'locator':'Actual caller comparison andgaps1-3;explicit unmet application admission prerequisite,not a mathematical refutation'}]}
p=R/'data/graph/nodes.jsonl';rows=[json.loads(s)for s in p.read_text().splitlines()];assert all(x['id']!=node['id']for x in rows)
with p.open('a')as f:f.write(json.dumps(node,ensure_ascii=False,sort_keys=True)+'\n')
edges=[]
for s,r,t in [('APP-239-01','depends_on',node['id']),(node['id'],'generated_by','GEN-20261026-106'),(node['id'],'about_family','F-239')]:
 loc='Explicit unmet consumer/finite-decision admission gate;source/code matching alone is not application value'
 edges.append({'id':'E-'+hashlib.sha256(('WP109-gate|'+s+'|'+r+'|'+t).encode()).hexdigest()[:16].upper(),'source':s,'relation':r,'target':t,'source_locator':loc,'source_commit':None,'created_at':now,'version':1,'evidence_status':'hypothesis'})
with (R/'data/graph/edges.jsonl').open('a')as f:
 for e in edges:f.write(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n')
p=O/'curation.json';d=json.loads(p.read_text());d['added_canonical_records']=25;d['added_explicit_edges']=72;d['node_ids'].append(node['id']);d['explicit_gate_addendum']={'at':now,'reason':'Expose already-recorded missing consumer/finite decision as a searchable first-class prerequisite and dependency route. No old canonical record changed,no additional candidate/evidence claim.','prior_24node_69edge_curation_log_retained':True};p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=T/'quality.py';s=p.read_text().replace("('CLM-239-U-THM-MAIN','APP-239-01',True)","('PROB-239-RANK-CONSUMER-GATE','APP-239-01',True),('CLM-239-U-THM-MAIN','APP-239-01',True)");p.write_text(s)
for name in ['README.md','README.en.md','PROGRESS.en.md']:
 p=R/name;s=p.read_text().replace('7734节点、21813关系、8403条','7735节点、21817关系、8404条').replace('8393条属于','8394条属于').replace('7,734 graph nodes and 21,813 relations','7,735 graph nodes and 21,817 relations').replace('7,734 nodes; 21,813 relations; 8,403 canonical citation annotations (8,393','7,735 nodes; 21,817 relations; 8,404 canonical citation annotations (8,394').replace('Twenty-four new canonical records and69 explicit relations','Twenty-five new canonical records and72 explicit relations').replace('当前18条直接基线关系缺口','当前19条直接基线关系缺口');p.write_text(s)
print(json.dumps({'added_gate':node['id'],'total_new_records':25,'total_new_explicit_edges':72,'prior_qa_preserved':True}))
