from pathlib import Path
from datetime import datetime, timezone
import copy, gzip, hashlib, json, re, subprocess

R=Path('/Users/smzdm/projects/ai_paper'); T=Path('/private/tmp/ai-paper-WP109')
O=R/'reports/reproducibility/20261026-symmetric-consumers'; O.mkdir(parents=True,exist_ok=True)
BASE='ab9f4f1869d72591e39d0d5543283fab4be2b59a'; G='GEN-20261026-106'; F='F-239'
UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'; NOW=datetime.now(timezone.utc).isoformat()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==BASE
sha=lambda b:hashlib.sha256(b).hexdigest()
def enc(d): return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
def write(name,d):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(d))
def pack(name,d):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);raw=enc(d);z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;p.write_bytes(z)
def cite(name,loc):return {'path':name,'sha256':sha((R/name).read_bytes()),'commit':None,'locator':loc}
def external(f):return {'url':f['url'],'sha256':f['sha256'],'commit':f['commit'],'content_checked':True,'locator':f['commit']+';'+f['source_path']+';actually read ranges '+str(f['actually_read_ranges'])+';file hash covers all bytes,not full-file reading or execution'}

raw=(R/'data/graph/nodes.jsonl').read_bytes(); eraw=(R/'data/graph/edges.jsonl').read_bytes()
old=[json.loads(x) for x in raw.splitlines()]; oldids={x['id'] for x in old}
assert len(old)==4741 and G not in oldids and 'APP-239-01' not in oldids
J=json.loads((R/'state/reading-progress/WP-109.json').read_bytes())
assert len(J['projects'])==3 and len(J['actually_read_files'])==17 and J['downloaded_bytes']==394010
pack('state/reading-progress/history/WP109-before-canonical-curation.json.gz',J)
ids=['LIT-239-QUIMB-LICENSE','LIT-239-QUIMB-BUILDER','LIT-239-QUIMB-RAND','LIT-239-QUIMB-ARRAYOPS','LIT-239-QUIMB-TEST','LIT-239-JULIA-LICENSE','LIT-239-JULIA-README','LIT-239-JULIA-PROJECT','LIT-239-JULIA-MODULE','LIT-239-JULIA-GAUSSIAN','LIT-239-JULIA-TEST','LIT-239-RESERVOIR-LICENSE','LIT-239-RESERVOIR-MATGEN','LIT-239-RESERVOIR-NODE','LIT-239-RESERVOIR-OBSERVABLES','LIT-239-RESERVOIR-MATGEN-TEST','LIT-239-RESERVOIR-NODE-TEST']
notes=[
 'Apache-2.0 license selected in full;no third-party full source republished.',
 'Permutation-orbit scalar cache creates raw symmetric arrays;two-index Rademacher qualification,open-grid corner shapes,normal default,alternative MPO Hermitian symmetrization and scaling boundaries inspected. Not all 6682 lines read.',
 'Generator handler,uniform choice,Rademacher real versus complex support,seed setup,fill factory and normal Hermitian construction inspected. Finite PRNG is abstracted by an ideal IID law,not certified independent bits.',
 'sensibly_scale norm-based scaling inspected;normalization does not restore a changed sign distribution.',
 'Actual normal-default TN2D symmetric caller tests contraction and permutation invariance;no Rademacher branch,rank requirement or rejection consumer established.',
 'MIT license selected in full;no third-party full source republished.',
 'Selected Gaussian/eigenvalue API and sampling documentation;README aliases not substituted for current code.',
 'Full Project.toml:version0.5.6 and Julia1.10 compatibility;no package installed.',
 'Full module imports/includes and selected exports;not a whole-library absence claim.',
 'Dense GaussianHermite/Wigner field-index sampling and eigenvalue/tridiagonal context;real branch continuous Gaussian symmetrization,not symmetric Bernoulli. Dyson beta is not Bernoulli bias.',
 'Full selected Gaussian sampling tests;shape/type/eigenvalue interfaces inspected,not executed.',
 'MIT license selected in full;no third-party full source republished.',
 'Initializer scaling,independent Bernoulli scalar choice,sparse/fixed-degree/dense shapes and Bernoulli factory inspected. No mirroring in selected generator;actual spectral-radius scaling is not exact-rank rejection.',
 'Reservoir init and recurrent step selected ranges:default normal W,sparse connectivity,rectangular Bernoulli Win;callable W can be square but not thereby symmetric;matrix-vector recurrence requires no inverse.',
 'spectral_radius computes max absolute eigenvalue;effective variant returns spectral_radius(lr*W+(1-lr)I),not a least singular value or condition number. Actual code used where doc wording differs.',
 'Selected generation/scaling/type/connectivity/seed tests;not executed and not a proof of rank demand.',
 'Selected reservoir setup/activation/shape/matrix-input checks;not executed;no claim of reading remainder.'
]
files=copy.deepcopy(J['actually_read_files'])
assert len(ids)==len(files)==len(notes)
for f,i,note in zip(files,ids,notes):
 p=T/'sources'/f['repository'].replace('/','--')/f['source_path']; b=p.read_bytes()
 assert sha(b)==f['sha256'] and len(b)==f['bytes']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_blob']
 assert all(1<=a<=z<=f['lines'] for a,z in f['actually_read_ranges'])
 f.update(node_id=i,actual_scope=note,code_executed=False,whole_file_read=f['actually_read_lines']==f['lines'])

packet=json.loads((T/'candidate-packet.json').read_bytes())
reviews={'retrieved_at':NOW,'completion_timestamps':'not exposed by completed-agent inventory;not invented','input_packet':packet,'input_packet_archive':'state/reading-progress/history/WP109-neutral-review-packet.json.gz','input_packet_archive_sha256':sha((R/'state/reading-progress/history/WP109-neutral-review-packet.json.gz').read_bytes()),'provider':'OpenAI','model':'Current user-selected session;exact backend unknown','context_isolation':'Fresh role contexts with the same frozen neutral packet;neither saw the other output before completion. Existing completed outputs retrieved;no new role invocation this continuation.','independent_second_provider':False,'human_review':False,'external_application_check':False,'outputs':[],'scope':'Opinions concern original frozen packet;future utility metric and quantitative preregistration not reviewed or approved.'}
for role in ['defender','skeptic']:
 b=(T/(role+'.md')).read_bytes();reviews['outputs'].append({'agent':'/root/f239_'+role,'role':role,'text':b.decode(),'transcribed_completed_tool_output_sha256':sha(b),'status':'completed'})
reviewpath='data/provenance/reviews/APP-239-01-isolated-roles.json.gz';pack(reviewpath,reviews)

conditions=[
 'Exactly two raw equal-size indices (D,D);real floating dtype;dist=rademacher,loc=0,scale=1;standard fill function;random diagonal retained.',
 'Probability is under the ideal independent-uniform RNG model before value-dependent selection/rejection. A fixed seed is deterministic;no finite-PRNG independence certification.',
 'For TN2D only selected raw two-index corner tensors of an ordinary open lattice Lx,Ly>=2;not a full contracted network or arbitrary higher-order flattening.',
 'Theorem supplies asymptotic exact singularity 2^(-D+o(D));no effective finite threshold,conditioning,runtime or contraction-quality statement.',
 'Actual invertibility demand,law-preservation requirement,finite risk decision and incremental value remain unestablished.'
]
baselines=[
 'Exact algebraic rank screening/rejection answers invertibility for each realized integer sign matrix;charge generation and rejected attempts,not only accepted draws.',
 'Tolerance-aware SVD/QR and least-singular-value criteria address numerical stability if that is the actual request;exact nonsingularity is not an equivalent output.',
 'Old CJMS exp(-cD) already gives exponential decay for the same uniform symmetric law;source-selected2021v2 scope retained separately from2025 publication bytes.',
 'Guaranteed-invertible orthogonal/unitary or structured choices only when a changed initializer law and its different symmetry are permitted by the consumer.'
]
gaps=[
 'No inspected caller requires invertibility of the qualified raw two-index matrices;quimb actual selected test uses normal law and contracts tensors.',
 'No fixed operational D range,number/selection of matrices,allowed failure probability,loss/cost,seed policy or law-preservation requirement supplied.',
 'No independent finite-D bound/calibration,domain judge or same-output costed benchmark admitted. Asymptotic rate cannot select a finite rejection budget.',
 'Higher-order permutation-symmetric tensor flattening need not have independent upper-triangle entries;duplicate-row flattenings can be singular. No blanket TN-network guarantee.',
 'Julia selected Wigner implementation is continuous Gaussian. ReservoirPy selected Bernoulli shape/sparsity/recurrent output is not a mirrored symmetric sign model;changes cannot be hidden under the same name.',
 'Source C/full dependency chain unknown;both isolated roles are same-provider auxiliaries. Human classification/specification and independent provider remain pending.',
 'Small-matrix frequencies or successful metadata parsing would not count as application-value evidence. No numerical/symbolic experiment was run.'
]
ledger={'work_package':'WP-109','family_id':F,'generation_id':G,'at':NOW,'base_commit':BASE,'upstream_commit':UP,'projects':J['projects'],'project_cap':3,'download_budget_bytes':6291456,'new_body_bytes':394010,'selected_source_files':files,'actually_read_lines':sum(f['actually_read_lines'] for f in files),'reading_note':'Whole download hashes and selected reading ranges are distinct. No project installation/clone or source-code execution. External full source excluded from archives.','qualified_ensemble_conditions':conditions,'actual_contract_comparisons':[
 {'project':'quimb','producer_qualified':True,'scope':'Only explicitly parameterized real raw two-index Rademacher branch;not normal-default actual test','actual_output':'Tensor contraction/permutation invariance in inspected caller','invertibility_demand_identified':False,'decision':'Retain conditional rank-risk metadata mapping;consumer and incremental benefit unqualified'},
 {'project':'RandomMatrices.jl','producer_qualified':False,'scope':'Selected GaussianHermite/Wigner and eigenvalue/tridiagonal APIs','actual_output':'Continuous Gaussian random matrices/eigenvalues','decision':'Does not match selected discrete ensemble;no universal library absence claim'},
 {'project':'ReservoirPy','producer_qualified':False,'scope':'Selected Bernoulli generator,sparse/dense arrays,reservoir init/recurrent step and observables','actual_output':'Recurrent matrix-vector dynamics with optional eigenvalue-radius scaling','decision':'No mirrored symmetry or inverse demand established;rectangular input and conditioning/eigenvalue targets kept separate'}],
 'baselines':baselines,'gaps':gaps,'reviews':reviewpath,'candidate_id':'APP-239-01','candidate_decision':'Admit one narrow conditional near analogy;implemented law exists and exact failure event is typed. Real rank-sensitive consumer and utility test not yet admitted.','initial_checks_added':0,'scientific_experiments_added':0,'claim_of_new_mathematics':False,'stop_decision':'Three-project cap reached;stop expanding similar libraries. Finish package QA then rotate towardF238 unread companions/other lowcoverage before retro039.','prior_weekly_human_sample':'Existing W44 sample remains pending;adding candidate updates pending grading population,not completed reviews.'}
ledgerpath='data/provenance/demand/F-239-symmetric-sign-contracts.json';write(ledgerpath,ledger)
cfgpath='data/provenance/research-at-generation-106.json';(R/cfgpath).write_bytes((R/'configs/research.json').read_bytes())
prediction='For a consumer that must preserve this raw symmetric-sign law and requires invertible two-index maps,sharp asymptotic rank-loss metadata could improve a predeclared initialization/risk decision beyond old exponential metadata or direct screening. No magnitude or finite-D benefit is established;the actual decision,utility metric,finite-D validity and threshold must be independently frozen before any run. The source-only prediction is -log2(P[exact rank<D])/D ->1,which is not itself an application-value test.'
plan={'connection_id':'APP-239-01','version':1,'created_at':NOW,'status':'conditional_plan_not_preregistered','scientific_run':False,'actual_consumer_identified':False,'input':'Explicit selected raw real symmetric D-by-D Rademacher initializers with random diagonal,standard fill,unshifted unit scale and ideal IID law;independent operational workload and non-value-dependent selection policy still missing.','output':'Asymptotic exact-rank risk annotation only until independently justified finite-D decision evidence exists. No condition-number or performance output.','falsifiable_prediction':prediction,'source_asymptotic_statement':'2^(-D+o(D));not an effective finite-D risk budget','ensemble_conditions':conditions,'entry_gates':['An inspectable consumer/domain specification that actually requires exact invertibility and states whether this initializer law must be preserved','Freeze D range,number and selection of tested matrices,seed policy,decision and meaningful loss/cost','Obtain independently justified finite-D validity/calibration and an external judge;no universal finite threshold inferred from o(D)','Freeze strongest same-output old baselines,full costs,holdout,success/failure thresholds and resource limit before outputs'],'baselines':baselines,'full_cost':['RNG generation and its law qualification','Exact rank or numerical tolerance verification according to the actual output','Rejected matrices,selection-induced law changes and fallback','Finite-D calibration,metadata construction,serialization,wall time and peak process memory','Downstream decision loss and numerical effects,including alternate-law costs'],'controls':['Normal-default,shifted,zero-scale,complex,fixed-diagonal and higher-order-flattened arrays are different models','Exact rank versus conditioning output audited separately','Old exponential versus sharp-asymptotic metadata;no-metadata/direct-screening null','One matrix versus explicitly selected batch;fixed seeds versus random-law probability'],'success_threshold':None,'failure_threshold':None,'reason_thresholds_unset':'Real consumer,independent judge and finite-D task absent;this is not an executable preregistration','stop_rule':'Do not run small-matrix frequency reproduction or metadata checker as application efficacy. Stop software search after3projects;retain pending conditional mapping and rotate.','reproducibility':'Future admitted run requires a new immutable executable spec before outputs;gzip numerical/raw/source payloads and verify decompressed SHA256 before cleanup.','model_roles':reviewpath,'human_and_second_provider':'missing,deferred not waived'}
planpath='experiments/plans/APP-239-01-conditional.json';write(planpath,plan)

new=[];edges=[]
ls=cite(ledgerpath,'WP109 actual selected software source/ranges,ensemble and caller qualification,old baselines,gaps and bounded stop decision')
rs=cite(reviewpath,'Completed isolated same-provider raw opinions on frozen packet;no human/second-provider/external-check credit')
ss=cite('data/provenance/readings/F-239.json','WP108 source-qualified main and selected CJMS original scope;not full proof audit')
def node(i,k,p,sources=None,e='source_content_checked'):
 assert i not in oldids and all(n['id']!=i for n in new)
 p={'family_ids':[F],'model_generation_id':G,'credibility':'unknown','dependency_closure_complete':False,**p}
 new.append({'id':i,'kind':k,'version':1,'created_at':NOW,'evidence_status':e,'properties':p,'sources':sources or [ls]})
def edge(s,r,t,loc,e='source_content_checked',commit=None):
 i='E-'+hashlib.sha256(('WP109|'+s+'|'+r+'|'+t+'|'+loc).encode()).hexdigest()[:16].upper()
 edges.append({'id':i,'source':s,'relation':r,'target':t,'source_locator':loc,'source_commit':commit,'created_at':NOW,'version':1,'evidence_status':e})
node(G,'generation',{'title':'F239 symmetric-discrete software consumer qualification and conditional tensor-initializer mapping','provider':'OpenAI','model':'Current user-selected session;exact backend unknown','human_review':None,'independent_second_provider':None,'project_base_commit':BASE},[ls,cite(cfgpath,'Research execution policy snapshot atgeneration106')])
for f in files:
 node(f['node_id'],'literature',{'title':f['repository']+' '+f['source_path'],'source_type':'pinned_software_source' if 'LICENSE' not in f['source_path'] else 'pinned_software_license','source_commit':f['commit'],'actually_read_ranges':f['actually_read_ranges'],'actual_scope':f['actual_scope'],'code_executed':False,'whole_file_read':f['whole_file_read']},[ls,external(f)])
method_specs=[
 ('PART-239-QUIMB-TWO-INDEX','Raw two-index real symmetric Rademacher ensemble','D,ndim2,standardfill,realfloat,distRademacher,loc0,scale1;ideal IID scalar choice','One draw per unordered pair including diagonal;raw symmetric +/-1 matrix','No arbitrary customfill,complexsupport,shift,zero-scale,after-selection or higher-order flattening guarantee',['LIT-239-QUIMB-BUILDER','LIT-239-QUIMB-RAND']),
 ('PART-239-QUIMB-CORNER-CALL','Open tensor-grid corner construction and actual contraction test','Open Lx,Ly>=2,D;selected rawcorner tensor;parameterized symmetric initializer','Two indices at corners;inspected test uses normal law and contraction/permutation invariance','No actual nonsingularity requirement or contraction/runtime benefit;MPO hermitian addition gives another law',['LIT-239-QUIMB-BUILDER','LIT-239-QUIMB-TEST','LIT-239-QUIMB-ARRAYOPS']),
 ('PART-239-JULIA-GAUSSIAN','Selected Gaussian Wigner sampling contract','GaussianHermite/Wigner beta1,real n-by-n normal draws','Symmetrized scaled continuous Gaussian sample;other selected API returns eigenvalues/tridiagonal samples','Not Bernoulli signs;Dyson beta not sign bias;no whole-library nonexistence claim',['LIT-239-JULIA-GAUSSIAN','LIT-239-JULIA-MODULE','LIT-239-JULIA-README','LIT-239-JULIA-PROJECT','LIT-239-JULIA-TEST']),
 ('PART-239-RESERVOIR-RECURRENCE','Selected Bernoulli and recurrent spectral-radius contract','Independent Bernoulli/sparse arbitraryshape generation;W(units,units),Win(units,inputdim);lr/sr','Recurrent W@state+Win@input update,optional max-absolute-eigenvalue radius scaling','No mirrored symmetric law from square shape;no inverse requirement,least-singular-value or condition-number output',['LIT-239-RESERVOIR-MATGEN','LIT-239-RESERVOIR-NODE','LIT-239-RESERVOIR-OBSERVABLES','LIT-239-RESERVOIR-MATGEN-TEST','LIT-239-RESERVOIR-NODE-TEST'])]
for i,title,inp,output,lim,refs in method_specs:
 node(i,'method',{'title':title,'input':inp,'output':output,'conditions':conditions if 'TWO-INDEX'in i else 'Only selected pinned code ranges;not executed','cannot_transfer':lim,'application_gain_tested':False})
 for ref in refs:edge(i,'depends_on',ref,'Actually read pinned implementation/test/doc contract;source change requires qualification review')
node('PROB-239-TENSOR-RANK-RISK','problem',{'title':'Law-preserving invertible two-index tensor initialization risk;real consumer not established','input':plan['input'],'desired_output':plan['output'],'actual_consumer_identified':False,'full_cost':plan['full_cost'],'qualifying_implementation_identified':True},[ls,cite(planpath,'Conditional plan and missing admission gates;not registered numerical experiment')],e='hypothesis')
node('APP-239-01','connection',{'title':'对称Rademacher两索引张量初始化的条件性精确秩风险元数据','source_ids':['CLM-239-U-THM-MAIN'],'history_ids':['LIT-239-SYMMETRICEXPONENTIAL'],'part_ids':['PART-239-QUIMB-TWO-INDEX'],'problem_id':'PROB-239-TENSOR-RANK-RISK','mechanism':plan['input']+' Output:'+plan['output'],'prediction':prediction,'test_spec':planpath,'run_ids':[],'opposition':{'text':'Concrete law matches only raw real two-index parameters;observed normal-default contraction caller needs no inverse. Higher-order flattenings may be singular. Sharp asymptotics provide no finite risk budget,and old rank/SVD/CJMS methods may suffice.','independent':False,'isolated_same_provider_agent':True,'type':'auxiliary self-check;not provider/human review','timing':'pre-experiment;fresh isolated same-provider agent on frozen packet'},'defense':{'text':'Implemented orbit-wise generation identifies an exact ensemble and failure event beyond an unnamed analogy. Retain low-priority mapping conditional on a genuine law-preserving invertibility consumer;no efficacy claim.','independent':False,'isolated_same_provider_agent':True,'type':'auxiliary self-check;not provider/human review','timing':'pre-experiment;fresh isolated same-provider agent on frozen packet'},'isolated_review_evidence':reviewpath,'theoretical_grade':'unknown','source_claim_grade':'C','sensitive':False,'resources':'No numerical allocation,no install/clone. Three-project qualification complete;future run needs independent executable preregistration and compressed raw/source outputs.','owner':'Current selected OpenAI session;human owner unassigned','workflow':'候选','application_result':'待定','limitations':'; '.join(gaps),'revisit_when':'Actual raw two-index invertibility demand,law constraints,finite-D decision,independent judge and strongest same-output old baseline with full costs become available.','analogy':'near','dedup_key':'F-239|PROB-239-TENSOR-RANK-RISK|raw-two-index-symmetric-rademacher-exact-rank-metadata','priority_reason':'Low numerical priority:concrete law interface established,but no actual rank-sensitive consumer or incremental decision value. Retain conditionally and rotate after bounded search.','external_check_type':'conditional_plan_not_run','baseline':baselines,'summary':{'status':'not_run','actual_consumer_identified':False,'qualified_producer_identified':True,'initial_check_eligible':False,'supported':None,'observations':None,'old_methods_may_suffice':True}},[ls,ss,rs,cite(planpath,'Conditional plan;no executable preregistration or scientific outputs')],e='hypothesis')
for ref in ['CLM-239-U-THM-MAIN','PART-239-QUIMB-TWO-INDEX']:
 edge('APP-239-01','depends_on',ref,'Conditional mapping requires exact source theorem and qualified raw initializer law',e='hypothesis')
edge('APP-239-01','uses','PART-239-QUIMB-CORNER-CALL','Application context and explicit missing invertibility demand;not actual production need',e='hypothesis')
edge('APP-239-01','addresses','PROB-239-TENSOR-RANK-RISK','Hypothetical law-preserving rank-risk decision,real consumer not admitted',e='hypothesis')
edge('APP-239-01','compared_with','LIT-239-SYMMETRICEXPONENTIAL','Old exponential baseline already sufficient for some decisions;not a new source claim')
edge('APP-239-01','compared_with','PART-239-JULIA-GAUSSIAN','Continuous Gaussian law differs;not a substitute under exact-sign constraints')
edge('APP-239-01','compared_with','PART-239-RESERVOIR-RECURRENCE','Nonsymmetric recurrence/condition targets differ;not evidence of consumer demand')
for n in new:
 if n['id']!=G:edge(n['id'],'generated_by',G,'Current selected OpenAI session;exactbackendunknown,nohuman/provider approval')
 for fid in n['properties'].get('family_ids',[]):edge(n['id'],'about_family',fid,'F239 bounded source/consumer qualification;no complete-family credit')
assert len(new)==24
existing_edges={json.loads(l)['id'] for l in eraw.splitlines()};assert all(e['id']not in existing_edges for e in edges) and len({e['id'] for e in edges})==len(edges)
known=oldids|{n['id']for n in new}|{F};assert all(e['source']in known and e['target']in known for e in edges)
nr=b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode()for n in new); ee=b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode()for e in edges)
(R/'data/graph/nodes.jsonl').write_bytes(raw+nr);(R/'data/graph/edges.jsonl').write_bytes(eraw+ee)
receipt={'at':NOW,'generation_id':G,'base_commit':BASE,'added_canonical_records':len(new),'added_explicit_edges':len(edges),'old_canonical_records_preserved':len(old),'source_files':17,'actually_read_lines':ledger['actually_read_lines'],'new_download_bytes_this_continuation':0,'prior_bounded_download_bytes':394010,'candidate_added':'APP-239-01','new_scientific_experiment':False,'new_external_application_checks':0,'source_reading_coverage_unchanged':True,'all_old_canonical_lines_and_edges_prefix_preserved':True,'ledger':ledgerpath,'review':reviewpath,'plan':planpath,'node_ids':[n['id']for n in new]}
write('reports/reproducibility/20261026-symmetric-consumers/curation.json',receipt)
print(json.dumps({k:v for k,v in receipt.items()if k!='node_ids'},ensure_ascii=False))
