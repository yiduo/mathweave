from pathlib import Path
import json,hashlib,urllib.request,datetime,urllib.parse
T=Path('/private/tmp/ai-paper-WP109');M=json.loads((T/'manifest.json').read_bytes());P=T/'acquisition.json';A=json.loads(P.read_bytes()) if P.exists() else {'download_limit_bytes':6291456,'total_downloaded_bytes':0,'files':[],'failures':[{'stage':'GitHub repository metadata','repository':'reservoirpy/reservoirpy','failure':'Transient connector transport failure; subsequent exact public branch GET succeeded,not treated as project absence.'}]}
for project in M['projects']:
 for file in project['files']:
  key=project['repository']+':'+file['path']
  if any(x['key']==key for x in A['files']):continue
  url='https://raw.githubusercontent.com/'+project['repository']+'/'+project['commit']+'/'+urllib.parse.quote(file['path'])
  try:
   request=urllib.request.Request(url,headers={'User-Agent':'MathWeave-bounded-consumer-qualification'})
   with urllib.request.urlopen(request,timeout=35) as r:
    raw=r.read(A['download_limit_bytes']-A['total_downloaded_bytes']+1);A['total_downloaded_bytes']+=len(raw);assert A['total_downloaded_bytes']<=A['download_limit_bytes'];assert len(raw)==file['bytes'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==file['git_blob'];raw.decode('utf8')
   p=T/'sources'/project['repository'].replace('/','--')/file['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);row={'key':key,'repository':project['repository'],'commit':project['commit'],'source_path':file['path'],'url':url,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'git_blob':file['git_blob'],'git_blob_sha1_verified':True,'sha256':hashlib.sha256(raw).hexdigest(),'path':str(p),'lines':len(raw.decode().splitlines())};A['files'].append(row);print(json.dumps({'path':file['path'],'bytes':len(raw),'blob_match':True}),flush=True)
  except Exception as e:
   row={'key':key,'url':url,'type':type(e).__name__,'error':str(e)};A['failures'].append(row);print(json.dumps(row),flush=True)
  P.write_text(json.dumps(A,indent=2)+'\n')
print('successful bytes',A['total_downloaded_bytes'])
