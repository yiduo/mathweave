from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;base='c0f46d8';s=json.loads((w/'curation-summary.json').read_text())
def old(p):return subprocess.check_output(['git','show',base+':'+p])
oldrows={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};newrows={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)}
changed={'APP-124-01','PROB-124-WORKFLOW','ANALYSIS-F-124'};assert len(oldrows)==5452 and len(newrows)==5457
for id,raw in oldrows.items():
 if id not in changed:assert newrows[id]==raw,id
prior=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-120-before.json.gz').read_bytes()))['records'];assert {x['id']:x for x in prior}=={id:json.loads(oldrows[id]) for id in changed}
for id in changed:
 n=json.loads(newrows[id]);assert n['version']==json.loads(oldrows[id])['version']+1 and n['updated_by_generation_id']=='GEN-20261027-120'
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')) and name not in ['reports/families/F-124.md','reports/cards/APP-124-01.md']:
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==63 and generated['source_decomposition_drafts']==58 and generated['candidate_connections']==47
assert generated['externally_checked_cards']==14 and generated['distinct_validation_hypotheses']==14 and generated['effective_leads']==6 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
before=json.loads(oldrows['APP-124-01'])['properties'];card=nodes['APP-124-01']['properties']
for key in ['prediction','dedup_key','test_spec','run_ids','source_ids','history_ids','part_ids','application_result','workflow','theoretical_grade']:
 assert card[key]==before[key],key
assert card['summary']['observations'] is None and card['summary']['supported'] is None and not card['summary']['initial_check_eligible']
assert (r/'experiments/plans/MAP-124-001.json').read_bytes()==old('experiments/plans/MAP-124-001.json')
oldanalysis=json.loads(oldrows['ANALYSIS-F-124'])['properties'];a=nodes['ANALYSIS-F-124']['properties']
for key in ['formal_status','formal_statement_comparison','result_ids_by_label','result_ids_by_source','source_sections','source_decomposition_draft_complete','historical_references_by_key','historical_verified_keys']:
 assert a[key]==oldanalysis[key],key
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F181-source-scope/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 key='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[key] in impact_report(nodes,edges,{v['seed']})['affected'])==(key=='required_affected');impacts.append(v)
for seed,target,positive in [('CLM-124-PROP-ALGORITHM','PART-124-ENUMERATED-SET-DP',True),('PART-124-WITNESS-DP','PART-124-ENUMERATED-SET-DP',False),('AUDIT-124-GENERATOR-ADMISSION','CLM-124-THM-MAIN',False),('REVIEW-124-GENERATOR-SKEPTIC','CLM-124-THM-MAIN',False),('PART-124-ENUMERATED-SET-DP','CLM-124-THM-MAIN',False),('APP-124-01','APP-337-01',False)]:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive,(seed,target)
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'F124 actualalgorithm/witness/staticauxiliary opinion keptdistinct;noaudit-to-mathproofdependency'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==17 and members==337
ledger=json.loads((r/'data/provenance/readings/F-124-generator-admission.json').read_text());assert not ledger['original_plan_modified'] and ledger['admission_decision']['new_initial_checks']==0
for row in ledger['source_ranges']:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
reviews=json.loads(gzip.decompress((r/ledger['actual_auxiliary_reviews']).read_bytes()));assert len(reviews['roles'])==2
for row in reviews['roles']:
 assert hashlib.sha256(row['raw_response_text'].encode()).hexdigest()==row['raw_response_sha256']
 assert json.loads(row['raw_response_text'])==row['parsed_response']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':5449,'versioned_old_records':3,'new_records':5,'new_edges':s['new_edges'],'prior_versions_archived_exactly':True,'reading_coverage_byte_equal':True,'protected_files':len(preserved),'canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'isolated_same_provider_actual_reviews':2,'original_plan_prediction_and_credit_unchanged':True,'source_results_and_formal_grades_unchanged':True,'target_outputs_observed':False,'new_scientific_runs':0,'new_initial_checks':0,'new_family_read_credit':0,'scope':'Source/resourceadmissiononly.No semantic-saturation ormaterialization argumentusedasall-implementationimpossibility,actualbenchmarkfailure,formalnegative,orapplicationcredit. Scientificcodeunchanged;noexpensivereplayrepeatedafterglobal043.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics']},ensure_ascii=False))
