from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;base='c28ccb840fbacc3cbc6615952d756be5a72208ec'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
s=json.loads((w/'curation-summary.json').read_text());assert s['old_records']==5408 and s['new_records']==44
assert (r/'data/graph/nodes.jsonl').read_bytes().startswith(old('data/graph/nodes.jsonl'))
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert len((r/'data/graph/nodes.jsonl').read_bytes().splitlines())==5408+s['new_records']
assert gzip.decompress((r/'data/graph/history/GEN-20261027-119-reading-coverage-before.json.gz').read_bytes())==old('data/graph/reading_coverage.json')
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')):
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==63 and generated['source_decomposition_drafts']==58
assert generated['candidate_connections']==47 and generated['externally_checked_cards']==14 and generated['effective_leads']==6 and generated['distinct_validation_hypotheses']==14 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
a=nodes['ANALYSIS-F-181']['properties'];refs=list(a['result_ids_by_label'].values())
assert len(refs)==16 and len(a['method_ids'])==12 and len(a['historical_references_by_key'])==11
assert sum(nodes[x]['properties']['source_claim_grade']=='B' for x in refs)==1
assert nodes['CLM-181-THM-MAIN']['properties']['source_claim_grade']=='B' and nodes['CLM-181-COR-EULERIAN-CYCLES']['properties']['source_claim_grade']=='C'
assert all(nodes[x]['properties']['dependency_chain_grade']=='unknown' for x in refs)
assert not a['full_family_complete'] and not a['historical_lineage_complete'] and not a['formal_status']['local_lean_build']
assert all(not x['accepted_connection'] for x in nodes['EXPLORE-F-181']['properties']['attempts'])
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)}
xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F337-AD-execution/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
for seed,target,positive in [
 ('CLM-181-LEM-PAIR-FOLDING','CLM-181-THM-MAIN',True),
 ('CLM-181-LEM-ROUTING','PART-181-SIMPLE-CYCLE-LIFT',True),
 ('CLM-181-THM-LOVASZ','CLM-181-THM-MAIN',True),
 ('CLM-181-THM-AHARONI-HAXELL','CLM-181-THM-MAIN',True),
 ('CLM-181-LEM-VERTEX-SAMPLING','PART-181-THREE-RESERVOIRS',True),
 ('CLM-181-THM-MAIN','CLM-181-COR-EULERIAN-CYCLES',True),
 ('LIT-181-GGKO2021','CLM-181-COR-EULERIAN-CYCLES',True),
 ('LIT-181-GGKO2021','CLM-181-THM-MAIN',False),
 ('LIT-181-BM2024','CLM-181-LEM-PAIR-FOLDING',False),
 ('CLM-181-COR-EULERIAN-CYCLES','CLM-181-THM-MAIN',False),
 ('CLM-181-THM-MAIN','APP-178-01',False),
 ('PART-181-SIMPLE-CYCLE-LIFT','CLM-337-CAT0-THM-MAIN',False)]:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive,(seed,target)
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'F181 exact source proof inputs;historicalcontext/crossfamily analogy not mandatory dependency'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==17 and members==337
ledger=json.loads((r/'data/provenance/readings/F-181.json').read_text());assert ledger['source_tex_lines']==2566 and len(ledger['results'])==16 and ledger['third_party_acquired_bytes']==3088053
for f in ledger['read_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_rows_byte_equal':5408,'new_records':s['new_records'],'new_explicit_edges':s['new_explicit_edges'],'old_explicit_edge_prefix_equal':True,'preserved_science_code_tests_corpus_other_family_reports_and_prior_reading_ledgers':len(preserved),'prior_reading_coverage_archived_exactly':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'experiment_archives':archives,'source_archive_members':members,'new_candidates':0,'application_checks_added':0,'new_scientific_runs':0,'primary_original_selected_scopes':4,'source_bytes':3088053,'source_B':1,'source_C':15,'limitations':'Current single-manuscript source draft andselected original/formal scope only;full family/history/proof/build/human/provider/application acceptance incomplete. Scientific code unchanged;no new research experiment.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','experiment_archives','generated_metrics']},ensure_ascii=False))
