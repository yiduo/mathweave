from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export

root=Path.cwd();work=Path(__file__).resolve().parent;base='07b52a1'
def show(path):return subprocess.check_output(['git','show',base+':'+path])
old=show('data/graph/nodes.jsonl').splitlines();new=Path('data/graph/nodes.jsonl').read_bytes().splitlines()
assert new[:len(old)]==old and len(new)-len(old)==24
assert Path('data/graph/edges.jsonl').read_bytes().startswith(show('data/graph/edges.jsonl'))
kept=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
    if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/')):
        assert Path(name).read_bytes()==show(name),name;kept.append(name)
current=json.loads(Path('data/graph/reading_coverage.json').read_text())
assert Path('data/graph/reading_coverage.json').read_bytes()==show('data/graph/reading_coverage.json')
metrics=validate(root);generated=render(root);exported=export(root);nodes,edges=load(root)
expected={n['properties']['family_id'] for n in nodes.values() if n['kind']=='family_analysis' and n['properties'].get('source_decomposition_draft_complete')}
assert set(current['source_decomposition_drafts'])==expected and len(expected)==55
assert generated['partial_reading_families']==60 and generated['source_decomposition_drafts']==55
assert generated['candidate_connections']==46 and generated['externally_checked_cards']==13 and generated['effective_leads']==5
assert all(n['properties']['credibility']=='C' and n['properties']['dependency_chain_grade']=='unknown' for n in nodes.values() if n['kind']=='claim' and n['id'].startswith('CLM-300-'))
js=json.loads(gzip.decompress(Path('reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress(Path('reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={n.attrib['id']:json.loads(next(d.text for d in n.findall('g:data',ns) if d.attrib['key']=='properties')) for n in g.findall('g:node',ns)}
xe=[json.loads(next(d.text for d in n.findall('g:data',ns) if d.attrib['key']=='evidence')) for n in g.findall('g:edge',ns)]
assert xn==nodes and xe==edges
cases=[('CLM-300-Q-LEM-ASSIGNMENT','CLM-300-Q-THM-MAIN'),('CLM-300-Q-LEM-RANK-COMPARISON','CLM-300-Q-THM-MAIN'),('CLM-300-Q-PROP-ATOMLESS-KERNELS','CLM-300-Q-PROP-MOMENT-TRANSFER'),('CLM-300-Q-PROP-MOMENT-TRANSFER','CLM-300-Q-THM-MAIN'),('CLM-300-A-LEM-ATOMLESS','CLM-300-A-THM-MAIN'),('CLM-300-A-THM-MAIN','CLM-300-A-COR-SO-PAVING'),('CLM-300-Q-THM-MAIN','CLM-300-A-COR-QUADRATIC-EXPECTED-APPROXIMATION'),('LIT-300-AS12','CLM-300-A-THM-MAIN'),('LIT-300-RS21','CLM-300-Q-THM-MAIN'),('CLM-238-FRAMES-CHAR-REPAIR','PART-238-COMP-DEPENDENT-HALF-REPAIR')]
cases += [('LIT-300-PETSC-DEFLATION','PROB-300-SOLVER-CONSUMER'),('LIT-300-GINKGO-JACOBI-API','PROB-300-INVERSE-BLOCK-COST'),('LIT-300-TENPY-PARENT','PART-300-TENPY-ERROR-DISPATCH'),('LIT-300-TENPY-TRUNCATION','PROB-300-TENSOR-COMPRESSION'),('LIT-300-TENPY-TEBD','EXPLORE-F-300-CONSUMERS'),('PART-300-SPECTRAL-CUT-CERTIFICATE','EXPLORE-F-300-CONSUMERS')]
cases += [('CLM-020-LEM-AFFINE-PATCHES','APP-020-01'),('CLM-020-LEM-AFFINE-DELETION','CLM-020-THM-DENSITY'),('CLM-020-PROP-SIEVE-TRANSFER','CLM-020-THM-DENSITY'),('CLM-020-PROP-PARAMETER-CERTIFICATE','CLM-020-THM-DENSITY'),('CLM-020-LEM-RATIONAL-VALUES','CLM-020-THM-DENSITY'),('CLM-020-PROP-QUINTIC-DISCARD','CLM-020-PROP-CURVE-ALTERNATIVES'),('CLM-020-PROP-WEIGHTED-HILBERT','CLM-020-PROP-QUARTIC-SURFACE'),('LIT-020-XIAO2017POWERFREE','CLM-020-COR-ALL-DEGREES'),('LIT-020-REUSS2015POWERFREE','CLM-020-COR-SEPARABLE-PRODUCTS'),('LIT-020-EISENBUDGREENHULEKPOPESCU2006','CLM-020-THM-DENSITY'),('CLM-020-UNLABELLED-ANALYTIC-RELATION','PART-020-COMMON-ANALYTIC-GERM'),('PROB-020-ADAPTIVE-PRIME-GATE','APP-020-01')]
cases += [('LIT-020-SAGE-IDEAL','PROB-020-MODULAR-STATE'),('LIT-020-SAGE-FUNCTION','PART-020-SAGE-NATIVE-DISPATCH'),('LIT-020-SINGULAR-MODULAR','PROB-020-MODULAR-PRIME-LAW'),('LIT-020-SINGULAR-MODSTD','PROB-020-MODULAR-VALIDATION'),('LIT-020-SINGULAR-MODDIQ','PART-020-SINGULAR-IDEAL-CALLER'),('LIT-020-SYMPY-MODGCD','PROB-020-MODULAR-STATE'),('LIT-020-SYMPY-RINGS','PART-020-SYMPY-DEFAULT-GCD-DISPATCH'),('PART-020-SINGULAR-CERT-SCOPE','EXPLORE-F-020-MODULAR-CONSUMERS')]
impacts=[]
for seed,target in cases:
    report=impact_report(nodes,edges,{seed});assert target in report['affected'],(seed,target)
    impacts.append({'seed':seed,'required_affected':target,'confirmed':True})
for seed,target in [('CLM-300-A-THM-MAIN','CLM-300-Q-THM-MAIN'),('CLM-300-Q-THM-MAIN','CLM-300-A-THM-MAIN'),('LIT-300-PV15','CLM-300-Q-THM-MAIN'),('LIT-300-PV15','CLM-300-A-THM-MAIN'),('LIT-300-RS21','PART-300-SINGLE-COLOR-COST')]:
    report=impact_report(nodes,edges,{seed});assert target not in report['affected'],(seed,target)
    impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Background/context references are not mandatory proof edges;main proofs do not depend on conversion corollaries.'})
for seed,target in [('LIT-300-TENPY-PARENT','PART-300-TENPY-SCHMIDT'),('CLM-300-Q-THM-MAIN','PART-300-GINKGO-JACOBI'),('LIT-300-GINKGO-JACOBI-API','CLM-300-Q-THM-MAIN'),('LIT-300-PETSC-DEFLATION','CLM-300-A-THM-MAIN'),('LIT-300-TENPY-TRUNCATION','APP-239-01')]:
    report=impact_report(nodes,edges,{seed});assert target not in report['affected'],(seed,target)
    impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Software interfaces do not become mathematical proof prerequisites or unrelated candidate evidence.'})
for seed,target in [('CLM-020-THM-DENSITY','APP-020-01'),('CLM-020-PROP-PARAMETER-CERTIFICATE','APP-020-01'),('CLM-020-UNLABELLED-ANALYTIC-RELATION','CLM-020-THM-DENSITY'),('CLM-020-UNLABELLED-LEVEL-SAVING','CLM-020-THM-DENSITY'),('LIT-020-CARELLA2023SQUAREFREE','CLM-020-THM-DENSITY'),('LIT-020-ZAPATACEBALLOSJALALVAND2026SQUAREFREE','CLM-020-THM-DENSITY'),('LIT-020-HEATHBROWN2013POWERFREE','CLM-020-THM-DENSITY'),('LIT-020-REUSS2015POWERFREE','APP-020-01'),('CLM-020-LEM-CYCLOTOMIC-PELL','CLM-020-THM-DENSITY'),('CLM-020-LEM-AFFINE-DELETION','APP-239-01')]:
    report=impact_report(nodes,edges,{seed});assert target not in report['affected'],(seed,target)
    impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Additional variants/context/old special baselines are not mandatory main proof or unrelated application inputs.'})
f020=[n for n in nodes.values() if n['kind']=='claim' and n['id'].startswith('CLM-020-')]
assert len(f020)==28 and sum(n['properties']['credibility']=='B' for n in f020)==2
assert all(n['properties']['dependency_chain_grade']=='unknown' for n in f020)
formal=json.loads(Path('data/provenance/readings/F-020-formal.json').read_text());index=Path(formal['static_index'])
assert hashlib.sha256(index.read_bytes()).hexdigest()==formal['static_index_sha256']
idx=json.loads(gzip.decompress(index.read_bytes()));assert len(idx['files'])==63
for f in idx['files']:assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256']
card=nodes['APP-020-01']['properties'];assert card['run_ids']==[] and card['theoretical_grade']=='unknown' and card['application_result']=='待定'
plan=json.loads(Path(card['test_spec']).read_text());assert plan['status']=='conditional_plan_not_preregistered' and plan['success_threshold'] is None and plan['failure_threshold'] is None
roles=json.loads(gzip.decompress(Path(card['isolated_review_evidence']).read_bytes()));assert not roles['independent_second_provider'] and not roles['human_review'] and roles['exact_backend_model']=='unknown'
for opinion in roles['opinions']:assert hashlib.sha256(opinion['raw_text'].encode()).hexdigest()==opinion['raw_sha256']
for seed,target in [('LIT-020-SINGULAR-MODULAR','CLM-020-THM-DENSITY'),('LIT-020-SYMPY-MODGCD','CLM-020-LEM-AFFINE-DELETION'),('LIT-020-SAGE-IDEAL','APP-020-01'),('LIT-020-SINGULAR-MODSTD','APP-020-01'),('LIT-020-SYMPY-RINGS','PART-020-SYMPY-MODGCD-STATE'),('CLM-020-THM-DENSITY','PART-020-SINGULAR-PRIME-LAW'),('LIT-020-SAGE-IDEAL','APP-239-01')]:
    report=impact_report(nodes,edges,{seed});assert target not in report['affected'],(seed,target)
    impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Selectednonadmittedsoftwaredoesnotbecomeoriginalmathematicalprooforgenericconditionalhypothesisprerequisite;caller/producerpathsremain distinct.'})
archives=[];members=0
for mp in sorted(Path('experiments/runs').glob('*/manifest.json')):
    m=json.loads(mp.read_text());folder=mp.parent
    for name,digest in m['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,(folder,name)
    for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
    snapshot=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
    for name,body in snapshot.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name],(folder,name)
    members+=len(snapshot);archives.append({'run_id':folder.name,'output_hashes':True,'gzip_payload_hashes':True,'source_members':len(snapshot)})
assert len(archives)==15 and members==267
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_records_byte_equal':len(old),'new_records':24,'old_explicit_edges_prefix_equal':True,'preserved_science_code_tests_corpus_and_family_report_files':len(kept),'old_reading_coverage_members_equal':True,'reading_coverage_unchanged':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'experiment_archives':archives,'source_archive_members':members,'scientific_runs_added':0,'application_checks_added':0,'F020_full_dependency_unknown':True,'new_candidates':0,'source_license_files':10,'actually_read_selected_lines':3863,'F020_old_claims':28,'source_B':2,'source_C':26,'F020_static_index_files_hashed':63,'new_interface_methods':8,'conditional_candidate_unchanged_without_experiment':True,'all56_source_C_fullchain_unknown':True,'limitations':'Software/graph/traceability/archive integrity,not proof validation,independent provider,humanreview orapplication support. Archive hashes are not fresh scientific replays;unchanged experiment source requires no rerun merely fornewfingerprint.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(work/'quality.json.gz').write_bytes(packed)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['experiment_archives','impact_cases','generated_metrics']},ensure_ascii=False))
