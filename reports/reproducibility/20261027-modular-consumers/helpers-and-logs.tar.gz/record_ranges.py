from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
batch=json.loads((work/sys.argv[1]).read_text());p=root/'state/reading-progress/WP-114.json';j=json.loads(p.read_text())
def merge(ranges):
    result=[]
    for a,b in sorted(ranges):
        if result and a<=result[-1][1]+1:result[-1][1]=max(result[-1][1],b)
        else:result.append([a,b])
    return result
for item in batch['reads']:
    f=next(f for f in j['source_files'] if f['project']==item['project'] and f['path']==item['path'])
    source=work/'sources'/f['project']/f['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==f['sha256']
    assert all(1<=a<=b<=f['lines'] for a,b in item['ranges'])
    f['actually_read_ranges']=merge(f['actually_read_ranges']+item['ranges']);f['actual_lines_read']=sum(b-a+1 for a,b in f['actually_read_ranges']);f['whole_file_actually_read']=f['actual_lines_read']==f['lines']
now=datetime.now(timezone.utc).isoformat();j['updated_at']=now;j['actual_lines_read']=sum(f['actual_lines_read'] for f in j['source_files']);j.setdefault('reading_batches',[]).append({'at':now,'input':sys.argv[1],**batch});j.setdefault('provisional_qualification_notes',[]).extend(batch['notes']);j['next_action']=batch['next_action'];j['status']='selected_source_reading_in_progress_no_canonical_credit';p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
b=json.loads((root/'state/backlog.json').read_text());task=next(t for t in b['tasks'] if t['id']=='WP-114');task['next_action']=j['next_action'];task['execution_progress'].update({'source_body_files_acquired':len(j['source_files']),'body_bytes':j['body_bytes'],'actually_read_lines':j['actual_lines_read'],'canonical_credit_added':False});b['updated_at']=now;(root/'state/backlog.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
c=json.loads((root/'state/checkpoint.json').read_text());c['saved_at']=now;c['active_work_package']=task;c['next_work_package']=task;c['recovery_commands'][3]=j['next_action'];(root/'state/checkpoint.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
with (root/'state/status.md').open('a') as out:out.write('\n\nWP114源码阅读检查点（'+now+'）：三项目10文件572605字节已固定获取，实际选读累计'+str(j['actual_lines_read'])+'行；本批仅临时资格笔记，无规范／候选／初检增量。'+batch['summary_zh']+' 下一：'+j['next_action']+'\n')
print(json.dumps({'actual_lines_read':j['actual_lines_read'],'files_acquired':len(j['source_files']),'body_bytes':j['body_bytes'],'canonical_credit_added':False}))
