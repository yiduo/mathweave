from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,urllib.error
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
j=json.loads((root/'state/reading-progress/WP-114.json').read_text());assert not j['source_files']
files=[];failures=[];total=0;cap=j['resource_limits']['new_body_bytes']
for project in j['pins']:
    for name in project['selected_paths']:
        url='https://raw.githubusercontent.com/'+project['repository']+'/'+project['commit']+'/'+name
        target=work/'sources'/project['project']/name;assert not target.exists()
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-qualification'})
            with urllib.request.urlopen(req,timeout=30) as r:
                data=r.read(cap-total+1);assert total+len(data)<=cap,'Body budget exceeded'
                headers={k:r.headers.get(k) for k in ['Content-Type','ETag','Last-Modified']}
            text=data.decode('utf-8');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);total+=len(data)
            files.append({'project':project['project'],'repository':project['repository'],'commit':project['commit'],'path':name,'url':url,'bytes':len(data),'lines':len(text.splitlines()),'sha256':hashlib.sha256(data).hexdigest(),'response_headers':headers,'retrieved_at':datetime.now(timezone.utc).isoformat(),'actually_read_ranges':[],'actual_lines_read':0,'scope':'Downloaded whole file;not bodyreading orapplication qualification.'})
        except Exception as exc:
            failures.append({'url':url,'at':datetime.now(timezone.utc).isoformat(),'error_type':type(exc).__name__,'message':str(exc),'retry':'not automatically retried;no insecure TLS or guessedsourcebody'})
        (work/'downloads.json').write_text(json.dumps({'files':files,'failures':failures,'total_bytes':total,'maximum_bytes':cap},ensure_ascii=False,indent=2)+'\n')
j['updated_at']=datetime.now(timezone.utc).isoformat();j['source_files']=files;j['acquisition_failures']=failures;j['body_bytes']=total;j['status']='pinned_sources_acquired_not_body_read'
(root/'state/reading-progress/WP-114.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files_acquired':len(files),'body_bytes':total,'failures':failures,'body_reading_credit':0}))
