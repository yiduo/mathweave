from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,io,tarfile,shutil
root=Path.cwd();work=Path(__file__).resolve().parent;out=root/'reports/reproducibility/20261027-modular-consumers';now=datetime.now(timezone.utc).isoformat()
def load(p):return json.loads((root/p).read_text())
def save(p,d):(root/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=json.loads(gzip.decompress((work/'quality.json.gz').read_bytes()));clean=json.loads(gzip.decompress((work/'clean-check.json.gz').read_bytes()))
assert len(q['impact_cases'])==63 and clean['core_exit_code']==0 and clean['copy_hashes_verified'] and not (work/'clean').exists()
assert 'Ran 69 tests' in (work/'core.log').read_text() and '\nOK\n' in (work/'core.log').read_text()
d=json.loads((work/'downloads.json').read_text());assert len(d['files'])==10 and not d['failures'];removed=[]
expected=set()
for r in d['files']:
    p=work/'sources'/r['project']/r['path'];assert p.resolve().is_relative_to(work/'sources') and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];expected.add(p)
    removed.append({k:r[k] for k in ['project','path','url','commit','bytes','sha256']})
assert {p for p in (work/'sources').rglob('*') if p.is_file()}==expected
shutil.rmtree(work/'sources')
for r in removed:r['removed']=True
assert sum(r['bytes'] for r in removed)==572605
for name in ['quality.json.gz','clean-check.json.gz']:
    raw=(work/name).read_bytes();gzip.decompress(raw);(out/name).write_bytes(raw)
cur=json.loads((work/'curation-summary.json').read_text());save(str((out/'curation.json').relative_to(root)),cur)
members=sorted(p for p in work.iterdir() if p.is_file());buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for p in members:
        raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for p in members:assert t.extractfile(p.name).read()==p.read_bytes()
(out/'helpers-and-logs.tar.gz').write_bytes(packed)
storage={'at':now,'work_package':'WP-114','third_party_temporary_sources_hash_verified':removed,'third_party_body_bytes_removed':572605,'third_party_bodies_republished':False,'own_helper_members_verified':len(members),'helper_compressed_sha256':hashlib.sha256(packed).hexdigest(),'helper_decompressed_sha256':hashlib.sha256(raw).hexdigest(),'helper_archive_bytes':len(packed),'clean_core_exit_code':0,'clean_directory_removed':True,'clean_files':clean['files'],'clean_bytes':clean['bytes'],'clean_copy_hashes_verified':True,'new_scientific_experiments':0,'scope':'Ownsnapshot/log/metadata roundtripverified;actualselectedthirdpartysoftwarebodies removedafterhashcheck. No newconsumeradmission,application efficacy orformalreview.','work_root_removed':False}
save(str((out/'storage.json').relative_to(root)),storage)
j=load('state/reading-progress/WP-114.json');old=(root/'state/reading-progress/WP-114.json').read_bytes();arch='state/reading-progress/history/WP114-before-canonical-close.json.gz';assert not (root/arch).exists();p=gzip.compress(old,mtime=0);assert gzip.decompress(p)==old;(root/arch).write_bytes(p)
j.update({'updated_at':now,'status':'bounded_consumer_qualification_complete_not_admitted','canonical_credit_added':True,'prior_version_archive':arch,'qualification':{'generation':'GEN-20261027-111','canonical_new_records':24,'new_explicit_edges':44,'new_candidates':0,'new_application_checks':0,'scientific_runs':[],'source_license_files':10,'actually_read_lines':3863,'same_S_full_kernel_consumer_admitted':False,'quality_evidence':str(out.relative_to(root))},'next_action':'WP114completeat3projectcap;no newexperimentorformaldenial. RotateWP115F047;do notreruncurator/reacquire10softwarefiles.'});save('state/reading-progress/WP-114.json',j)
b=load('state/backlog.json');wp=next(t for t in b['tasks'] if t['id']=='WP-114');task=next(t for t in b['tasks'] if t['id']=='WP-115')
wp.update({'status':'completed','completed_at':now,'next_action':j['next_action'],'outputs':['data/provenance/demand/F-020-modular-consumers.json','reports/F020-modular-consumer-audit.md',str(out.relative_to(root))],'result':'3pinnedprojects10source/licensefiles572605bytes3863actualselectedlines. 24newcanonical44explicitrelations;5164oldrecords/oldedges/science/source/tests/experiments/corpus/55familyreports/readingcoverageunchanged. Fullobjects/63impact/15archives267members/69core/no-mathclean passed. No same-SfullQkernel/fullstate/prime-law/finite-risk/fullcostconsumeradmitted;APP02001predictionunchanged,candidate46/check13. Stopprojectcap,rotateWP115F047;noGithubpush.'});wp['qualification_progress'].update({'clean_check':'passed','storage':'compressed_roundtrip_verified'});b['updated_at']=now;save('state/backlog.json',b)
c=load('state/checkpoint.json');assert c['work_packages_since_last_retrospective']==0 and 'WP-114' not in c['completed_work_packages']
c['completed_work_packages'].append('WP-114');c.update({'saved_at':now,'overall_status':'active_incomplete','last_completed_work_package':'WP-114','work_packages_since_last_retrospective':1,'active_work_package':task,'next_work_package':task,'last_quality_evidence':str((out/'quality.json.gz').relative_to(root)),'storage_receipt':str((out/'storage.json').relative_to(root))})
c['recovery_commands']=['Readgoal/AGENTS/charter/roadmap/status/checkpoint/backlog/latestglobal040;verifydisk/processes andWP114storage first.','WP113GEN110 andWP114GEN111canonicalalreadyapplied;do notrerunone-shotcurators orreacquire9historicalHTML/10softwarefiles.','WP114fullJSONGraphML/63positive-negativeimpacts/15archives267members/69core/no-mathclean passed;unchanged221/325scientificreplaysalreadydone inglobal040,do notrepeatmerelyforfingerprint.',task['next_action'],'F047onlyREADME/hashinventory10TeX2281lines(172referencesincluded),body0;F05312TeX5064alternativebody0. Bothremainuncounted.','Currentpublicd48dd19/CI40300240089stillcoversWP112 andolderunfinishedWP113;GEN110/111localonly,noautomaticGitHubpush.','Counter1since040;mandatoryglobal041afterWP116,or earliermajorcounterevidence/dataissue. No newscientificoutput beforeindependent executablepreregistration;no newmathproof/Leaninstall.']
c['recovery_observation']['WP114_close']={'at':now,'running_project_processes':[],'all_local_quality_handles_terminal':True,'upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','upstream_clean':True,'clean_copy_removed':True,'source_temporaries_removed':True,'new_scientific_experiments':0,'next_package_source_body_credit':0}
save('state/checkpoint.json',c)
pub=load('state/publication.json');pub['local_progress_after_verified_snapshot']='WP113 GEN110/global040 andcompletedWP114 GEN11124newrecords44edges/10files3863lines with63impact/69core/no-mathclean/verifiedcompressedcleanup. Verifiedpublicd48dd19 remainsolderWP112/unfinishedWP113;routinepushdisabled.';save('state/publication.json',pub)
line='WP114最终闭包（'+now+'）：69核心及无math干净副本退出0；'+str(clean['files'])+'文件／'+str(clean['bytes'])+'字节逐项散列一致，副本已删除。63正负传播、完整图对象、15归档267成员与5164旧规范行及原阅读覆盖保持；十第三方文件572605字节核散列后清理，自有'+str(len(members))+'成员压缩回解验证。无新科学实验／候选／初检或正式否定；复盘040后计数1，下一WP115 F047正文仍0。整体active_incomplete，无GitHub推送。'
with (root/'state/status.md').open('a') as f:f.write('\n\n'+line+'\n')
assert str(work)=='/private/tmp/ai-paper-WP114';shutil.rmtree(work);storage['work_root_removed']=True;storage['removed_at']=datetime.now(timezone.utc).isoformat();save(str((out/'storage.json').relative_to(root)),storage)
print(json.dumps({'WP114':'completed_bounded_consumer_qualification','new_records':24,'new_edges':44,'candidate_count':46,'initial_checks':13,'next':'WP-115 F047','next_body_read':0,'counter_since_040':1,'clean_files':clean['files'],'helper_members':len(members),'temporary_root_removed':True,'github_push':False}))
