from pathlib import Path
from datetime import datetime,timezone
import json,gzip,urllib.request,urllib.error,subprocess
r=Path.cwd();w=Path('/private/tmp/ai-paper-20261027-publication');base='https://api.github.com/repos/yiduo/mathweave';fallbacks=[]
def get(path):
 headers={'User-Agent':'MathWeave-publication-CI-readback','Cache-Control':'no-cache'}
 try:
  with urllib.request.urlopen(urllib.request.Request(base+path,headers=headers),timeout=25) as resp:return json.loads(resp.read())
 except urllib.error.HTTPError as e:
  if e.code!=403:raise
  result=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,check=True,cwd=r);fields=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line);assert fields.get('password') and fields.get('host')=='github.com';headers['Authorization']='Bearer '+fields['password'];fallbacks.append({'endpoint':path,'anonymous_status':403,'retry':'configured helper, secret not logged'})
  with urllib.request.urlopen(urllib.request.Request(base+path,headers=headers),timeout=25) as resp:return json.loads(resp.read())
def save(n,d):
 raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/n).write_bytes(z)
run=get('/actions/runs/40494856629');assert run['head_sha']=='612e91b800eca969b2b496cde34e5206b3afa4d1'
selected={k:run[k] for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at']};ci={'at':datetime.now(timezone.utc).isoformat(),'commit':run['head_sha'],'runs':[selected],'api_fallbacks':fallbacks.copy(),'scope':'95 core checks,13 configured archived replays,exports and publication audit; no EXP076 strict Linux,optional NumPy,Lean,human/provider or research acceptance'};save('CI-observation.json.gz',ci)
jobs=get('/actions/runs/40494856629/jobs?per_page=100');save('CI-jobs-observation.json.gz',jobs)
print(json.dumps({'run':selected,'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'steps':[{'name':s['name'],'status':s['status'],'conclusion':s['conclusion']} for s in j['steps']]} for j in jobs['jobs']]},ensure_ascii=False))
