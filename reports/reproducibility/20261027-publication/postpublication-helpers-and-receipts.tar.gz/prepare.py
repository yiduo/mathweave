from pathlib import Path
from datetime import datetime, timezone
import json,gzip,tarfile,io,hashlib
r=Path.cwd();tmp=Path('/private/tmp/ai-paper-20261027-publication');out=r/'reports/reproducibility/20261027-publication';out.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Preserve the unpublished entry-document versions before replacing their stale snapshots.
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for n in ['README.md','README.en.md','PROGRESS.en.md']:
  b=(r/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
b=buf.getvalue();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/'entry-documents-before.tar.gz').write_bytes(z)
m=json.loads((r/'reports/metrics.json').read_text());assert (m['candidate_connections'],m['externally_checked_cards'],m['partial_reading_families'],m['source_decomposition_drafts'])==(47,15,64,59)
zh='''# MathWeave · 数学织网

[English overview](README.en.md) · [English charter](CHARTER.en.md) · [English progress](PROGRESS.en.md) · [中文纲领](722篇AI数学论文应用价值挖掘纲领.md)

**连接数学成果、历史方法与可检验应用的证据网络。**

研究单位是“成果族 + 历史谱系 + 应用问题”。项目使用固定来源、版本化知识图谱和可复现实验，保留适用条件、失败证据与审核缺口。第一阶段仍未完成。

仓库：[yiduo/mathweave](https://github.com/yiduo/mathweave)。本次为2026年10月27日用户要求的合并发布：已整理至WP128／全局复盘045，并包含尚未完成的WP129阅读检查点。实际远端提交、公开核验及CI结果分别记录在[发布状态](state/publication.json)，不继承上一版的成功状态。

| 指标 | 当前记录 | 验收边界 |
| --- | --- | --- |
| 固定语料 | 372成果族、719篇当前手稿 | 登记不等于研究完成；历史722口径逐项核对 |
| 原文阅读与草稿 | 64族实际阅读、59族当前稿全文草稿 | 完整成果族、完整历史和六阶段完成均为0 |
| 知识图谱 | 8,874节点、26,094关系 | 保留来源与版本；图谱规模不代表数学或应用有效性 |
| 候选连接 | 47／500 | 十领域尝试与命题绑定不计候选 |
| 合格初检卡片 | 15／100 | 15个不同假设：7项限定支持、8项不利观察 |
| 其他检查 | 1项诊断、2项组件检查 | 不额外计入应用假设计数 |
| 真实人工分级 | 0／150 | 第二供应商、规格人审和试点也仍为0 |

近期可核对的成果：

- [F149反应网络检验](reports/retrospectives/045-old-method-sufficiency-and-history-scope.md)：72个合成实例、401次精确更新，27例负浓度事件；旧逐坐标基线全部捕获，没有确认2026数学的额外计算收益。
- [F181历史范围](reports/F181-historical-scope-followup.md)：选定原作由4／11补至8／11；旧局部扩张准则在对应接口上更强。剩余原作、精确转录与递归证明缺口保留。
- [F337实际AD诊断](reports/F337-AD-execution.md)：192项参考有效，但16个零点后端异常使冻结主预测待定；独立列为诊断，不增加初检。
- [F271当前阅读检查点](state/reading-progress/WP-129.json)：四当前稿46源文件14,199行均已实际读完，五部历史原作仅核选定范围。命题／方法／跨域关系仍待规范入图，不增加正式阅读族、全文草稿或应用计数。

最新完成包有95项核心检查、无math干净环境检查、18个科学归档／378源码成员及代表性严格重放证据；本批发布检查另见[发布核验目录](reports/reproducibility/20261027-publication/)。软件检查不证明数学结论或业务收益。[验收矩阵](reports/acceptance.md)、[机器指标](reports/metrics.json)、[全局复盘045](reports/retrospectives/045-old-method-sufficiency-and-history-scope.md)保留完整差距。

**OpenAI官方的 `math/` 目录不包含在本仓库中，也不复制或重新部署。** 原作通过固定[上游提交](https://github.com/openai/math/tree/1581d4cbdd69a0faf34b2089614fe2a814316a6a)、标识和校验清单引用。第三方全文、缓存和批量本地历史同样排除。英文纲领已提供；详细研究账本主要为中文。

'''
p=r/'README.md';old=p.read_text();assert '## 快速开始' in old;p.write_text(zh+old[old.index('## 快速开始'):])
# Correct one remaining current navigation count in the retained instructions.
p.write_text(p.read_text().replace('覆盖372族和45候选','覆盖372族和47候选'))
en='''# MathWeave

[中文](README.md) · [English charter](CHARTER.en.md) · [Original Chinese charter](722篇AI数学论文应用价值挖掘纲领.md) · [Progress and limits](PROGRESS.en.md)

**Weaving mathematical results, historical methods, and testable applications into an evidence graph.**

The research unit is **result family + historical lineage + application problem**. Versioned records connect source propositions, transferable methods, concrete hypotheses and reproducible checks, retaining conditions and adverse evidence.

**Phase one is incomplete.** Current canonical records contain 47 candidate connections, 15 preliminary checks of distinct hypotheses, seven narrowly supported predictions and eight adverse observations. There are 64 actually read families and 59 current-source drafts. No family has completed its full lineage or all six stages. Real human classification, specification review, second-provider review and pilots remain zero.

The graph contains **8,874 nodes and 26,094 relations**. Its size measures records, not established mathematics or engineering value. A separate diagnostic and two component checks do not inflate the hypothesis count.

This October 27, 2026 owner-requested publication batch includes completed work through **WP128 / global review045** and the **unfinished WP129** journal. Four F271 manuscripts, 46 source files and 14,199 lines were read; five historical originals were checked only in selected scopes. Source bindings, methods and application mappings are still pending curation, so this journal adds no canonical coverage or application credit. See [the journal](state/reading-progress/WP-129.json).

Recent checks preserve the old-method null hypothesis. The F149 synthetic reaction-network audit found 27 negative-concentration cases among 72 fixtures and 401 exact updates; the old coordinatewise baseline caught every one. F181's historical comparison found an older local expansion criterion already stronger at the selected interface. Neither establishes incremental 2026 engineering benefit. The F337 AD run remains a separate diagnostic because backend exceptions prevent adjudicating its frozen main prediction.

Repository: [yiduo/mathweave](https://github.com/yiduo/mathweave). Exact public commit, readback and CI observations are tracked separately in [publication state](state/publication.json). Previous public CI success does not apply automatically to this batch. Routine package pushes remain disabled.

'''
p=r/'README.en.md';old=p.read_text();tail=old[old.index('## Corpus and upstream boundary'):];tail=tail[:tail.index('\nThe [bounded symbolic-demand follow-up]')] if '\nThe [bounded symbolic-demand follow-up]' in tail else tail;p.write_text(en+tail)
progress='''# MathWeave — Research progress

Snapshot: October 27, 2026. Canonical research is curated through WP128 / generation125 and global review045. WP129 is an unfinished reading and historical-scope checkpoint. This is an owner-requested publication batch; remote publication and CI are established only by their separate receipts. **Phase one remains incomplete.**

| Measure | Current result | Remaining requirement |
| --- | --- | --- |
| Fixed catalogue | 372 families; 719 current manuscripts | Registration does not establish research completion |
| Actual reading | 64 / 372 families | Includes partial reading; WP129 adds no canonical credit yet |
| Current-source decomposition drafts | 59 / 372 families | Full family and historical closure remain unachieved |
| Complete families / full lineages / all six stages | 0 / 0 / 0 | Missing proof dependencies and review gates remain explicit |
| Candidate connections | 47 / 500 | Deduplicated mappings with conditions; exploration attempts excluded |
| Real human classification | 0 / 150 | Deferred; model self-review is not a substitute |
| Preliminary application cards | 15 / 100 | Seven limited predictions supported, eight adverse observations |
| Distinct reproducible hypothesis checks | 15, target 10 | Only this numerical subtarget is met; the overall milestone is incomplete |
| Separate diagnostic / component checks | 1 / 2 | Excluded from additional application-hypothesis credit |
| Scientific archives | 18, containing 378 source members | Includes the diagnostic and component archives; not 18 distinct application hypotheses |
| Human specification review / second provider / pilots | 0 / 0 / 0 | No reviewed engineering deployment is claimed |
| Graph | 8,874 nodes; 26,094 relations | 9,845 core citation annotations; record counts are not proof acceptance |

## Evidence added since the previous public snapshot

- WP113–WP116: F020 and F047 current-source drafts, selected history and bounded real-consumer audits. Unmet input contracts and old exact methods remain explicit.
- WP117: the preregistered F276 synthetic fixed-receiver check ran 125 fixtures and 25 optimizer comparisons; 14 of 27 interior fixtures exceeded the original 0.01 bit/use threshold. Archived-source replay matched complete raw and summary outputs. Old classical probabilities already suffice; no device or new-theorem speed benefit is established. [Scope](reports/F276-receiver-preregistration.md).
- WP118–WP125: selected historical prerequisites, F337 and F181 source drafts, F238's seventh of twelve manuscripts, and both current F059 manuscripts. F337's actual AD diagnostic is kept separate from preliminary-card credit: 16 zero-point backend exceptions prevent a verdict on its frozen main prediction. [Diagnostic](reports/F337-AD-execution.md).
- WP126–WP127: F149 executable specification was frozen before the target run. All 72 synthetic fixtures / 401 exact updates were checked; 27 negative-concentration cases include 18 nonlinear multi-link cases. Exact raw/summary replay matched. The old coordinatewise check found all events, so no incremental 2026 computational benefit was demonstrated.
- WP128: four additional historical originals were checked in selected scopes, bringing F181 to 8 of 11 selected root works. An older local expansion result is stronger at the compared interface; this does not provide the whole decomposition or an implemented runtime. Unread originals, transcription problems and recursive gaps remain. [History](reports/F181-historical-scope-followup.md), [global045](reports/retrospectives/045-old-method-sufficiency-and-history-scope.md).
- WP129, unfinished: all four F271 natural-language source bodies were read, totaling 46 TeX/Bib files and 14,199 lines. Five originals were checked in selected text scopes, with an existing matching BBL scope reused. The actual selected formal endpoint concerns September spontaneous magnetization/dynamics; the October companions do not inherit that coverage. No Lean build, human specification review, new application run or canonical-family credit is claimed. [Reading checkpoint](state/reading-progress/WP-129.json), [history scopes](reports/reproducibility/20261027-F271-source/selected-history-scopes.json).

## Reproducibility and boundaries

The latest completed research package has 95 core checks, a no-upstream clean-directory check, complete JSON/GraphML comparisons, dependency propagation checks, archive integrity and representative supported/adverse archived-source replays. These are software/data and scoped replay checks, not full mathematical or application acceptance. [WP128 closure](reports/reproducibility/20261027-F181-history/closure.json) retains the exact scope; [publication QA](reports/reproducibility/20261027-publication/) records checks for this release batch.

The Linux workflow runs its configured core suite and 13 archived replays. It excludes EXP076 strict Linux portability and the separately pinned optional NumPy experiments. A green workflow does not certify Lean, cross-provider review, human review, hardware effectiveness or completion of phase one. [Platform scope](docs/publication.md#actual-first-ci-and-platform-limit).

The official OpenAI `math/` directory is excluded, as are third-party full texts, credentials, caches and bulk local Git history. The pinned upstream revision and checksum manifests identify original evidence without redeploying it. Numerical data, source snapshots and helper logs are compressed and checked by decompression hashes. Temporary external originals are removed after recording their hashes; failed evidence is retained.

## Next research work

Complete WP129 source-bound propositions, method contracts, selected historical comparisons and ten-domain/cross-family exploration, then run the required graph and provenance checks before granting canonical credit. Keep broader coverage and actual application checks in parallel. Old methods may already be sufficient; new numerical work requires a separately frozen specification. Real human and second-provider gates remain deferred, without blocking independent source work or being counted as complete.

[Acceptance matrix](reports/acceptance.md) · [Generated metrics](reports/metrics.json) · [Current state](state/status.md) · [English charter](CHARTER.en.md)
'''
(r/'PROGRESS.en.md').write_text(progress)
with (r/'CHANGELOG.md').open('a') as f:f.write('\n\n## 2026-10-27 — owner-requested publication batch\n\nPublish completed WP113–WP128 / global045 and unfinished WP129 four-manuscript reading/history checkpoint. Entry documents now agree with canonical47candidates/15checks/64reading/59drafts and8874nodes/26094edges; seven limited predictions supported, eight adverse, one separate diagnostic. No extra research credit for publication. Official math, external full texts and bulk local Git history remain excluded. Exact push/readback/CI outcomes are recorded separately after observation.\n')
with (r/'docs/publication.md').open('a') as f:f.write('\n\n## 2026-10-27 owner-requested batch\n\nThe owner requested one current progress submission. Retain MathWeave and https://github.com/yiduo/mathweave. Include curated work through WP128 / global045 and unfinished WP129 (four current F271 source bodies, 46 files / 14199 lines, five selected original scopes). No extra canonical coverage, application checks, human review or formal acceptance is granted to the unfinished package. Create a single snapshot commit parented by the current public main, retaining explicit research history artifacts but excluding bulk local commit history, official math and temporary external bodies. Synchronize the Chinese and English entry documents and progress counts. Complete local/clean checks and exact tree audit before push; verify the remote tree and CI separately afterward. Post-push receipts stay local until the next meaningful batch, avoiding an extra metadata-only push.\n')
p=r/'state/publication.json';d=json.loads(p.read_text());d['pending_batch']={'requested_at':now,'request':'提交一版','status':'preparing_not_pushed','scope':'Completed WP113-WP128 / global045 plus unfinished WP129 natural-source and selected-history checkpoint','official_math_excluded':True,'bulk_local_history_excluded':True,'parent_expected':d['verified_commit'],'qa_evidence':str(out.relative_to(r))};save(p,d)
p=r/'state/checkpoint.json';c=json.loads(p.read_text());c['saved_at']=now;c['publication_work'].update(status='preparing_current_owner_requested_batch',current_local_research_not_yet_pushed='WP113-WP128 and unfinished WP129; preparing reviewed public snapshot, not yet pushed.',pending_public_commit=None,pending_public_tree=None,active_push_exec_session=None);c['publication_qa_evidence']=str(out.relative_to(r));save(p,c)
with (r/'state/status.md').open('a') as f:f.write('\n\n用户要求“提交一版”（'+now+'）：准备一次合并公开快照，范围WP113–WP128／全局045及未完成WP129四稿阅读／五历史选段检查点。中英文入口同步47候选15初检64阅读59草稿；未推送前不改变已核验远端边界，CI另取证。官方math／第三方全文／批量本地历史排除。\n')
print(json.dumps({'prepared':True,'canonical_metrics':m,'publication_evidence':str(out.relative_to(r)),'scope':'Not yet pushed; no research credit change'},ensure_ascii=False))
