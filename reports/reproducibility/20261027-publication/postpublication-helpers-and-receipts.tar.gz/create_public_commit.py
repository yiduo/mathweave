from pathlib import Path
import json,os,subprocess
r=Path.cwd();w=Path('/private/tmp/ai-paper-20261027-publication')
def git(*a,**kw):return subprocess.check_output(['git',*a],cwd=r,**kw).decode().strip()
a=json.loads((w/'final-audit.json').read_text());assert a['failure_count']==0 and a['upstream_math_paths']==0
assert not git('status','--porcelain=v1')
parent='d48dd19a24a2c872954ab7cce35ee9c7eaf04cdd';assert git('ls-remote','origin','refs/heads/main').split()[0]==parent
tree=git('rev-parse','HEAD^{tree}');assert not git('ls-tree','-r','--name-only','HEAD','--','math')
env=dict(os.environ,GIT_AUTHOR_NAME='MathWeave contributors',GIT_AUTHOR_EMAIL='yiduo@users.noreply.github.com',GIT_COMMITTER_NAME='MathWeave contributors',GIT_COMMITTER_EMAIL='yiduo@users.noreply.github.com')
commit=git('-c','commit.gpgsign=false','commit-tree',tree,'-p',parent,'-m','Publish MathWeave progress through WP128 and F271 reading checkpoint',env=env)
assert git('rev-list','--count',commit,'^'+parent)=='1'
c={'repository':'https://github.com/yiduo/mathweave','commit':commit,'tree':tree,'parent':parent,'local_commit':git('rev-parse','HEAD'),'files':a['files'],'bytes':a['total_bytes'],'upstream_math_paths':0,'bulk_local_history_included':False,'state':'prepared_not_pushed','ci':'unobserved'}
(w/'public-candidate.json').write_text(json.dumps(c,indent=2)+'\n');print(json.dumps(c))
