from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,subprocess,tarfile
r=Path.cwd();w=Path('/private/tmp/ai-paper-20261027-publication');out=r/'reports/reproducibility/20261027-publication'
def sha(b):return hashlib.sha256(b).hexdigest()
ci=json.loads(gzip.decompress((w/'CI-observation.json.gz').read_bytes()));assert ci['runs'] and all(x['status']=='completed' and x['conclusion']=='success' for x in ci['runs'])
for n in ['CI-jobs-observation.json.gz','CI-jobs-first-observation.json.gz']:
 b=(w/n).read_bytes();gzip.decompress(b);(out/n).write_bytes(b)
assert not (w/'clean').exists()
files=sorted(p for p in w.iterdir() if p.is_file());manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in files:
  b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b));manifest.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for i in manifest:assert sha(t.extractfile(i['name']).read())==i['sha256']
archive=out/'postpublication-helpers-and-receipts.tar.gz';archive.write_bytes(z)
assert not subprocess.check_output(['git','diff','ea988eb','--name-only','--','data','experiments','src','tests','reports/families','reports/graph'],text=True).strip()
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
candidate=json.loads((w/'public-candidate.json').read_text());assert subprocess.check_output(['git','rev-parse',candidate['commit']+'^{tree}'],text=True).strip()==candidate['tree']
for p in files:p.unlink()
w.rmdir()
storage={'at':datetime.now(timezone.utc).isoformat(),'members':manifest,'compressed_sha256':sha(z),'decompressed_sha256':sha(raw),'gzip_bytes':len(z),'temporary_files_deleted_after_roundtrip':True,'temporary_directory_removed':not w.exists(),'clean_copy_removed':True,'bulk_math_copy_created':False,'postpush_receipts_local_only':True,'remote_public_commit':candidate['commit'],'CI_run':ci['runs'][0]['id'],'CI_conclusion':'success','scientific_data_and_graph_unchanged':True,'goal':'active_incomplete'};(out/'postpublication-storage.json').write_text(json.dumps(storage,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['git','diff','--check'],check=True)
print(json.dumps({k:v for k,v in storage.items() if k!='members'}))
