# MathWeave

WP120 registers one conditional source-inspired scalar C1/actual-AD calibration: 47 candidates, still 14 actual preliminary checks. The 192 inputs, strong ordinary pre-operation branch baseline, partial-independent Decimal references, resource/failure protocol and executable specification are prepared. The target backend has not yet been imported or evaluated. Software checks and same-provider auxiliary opinions do not establish a prediction, incremental 2026 application value, human review or a second provider. [Preregistration and limits](reports/F337-AD-preregistration.md).

WP119 completes both current F337 source drafts: 28 TeX/Bib files and 7,413 lines, 54 named results plus one explicitly bounded unlabelled optimality statement, and 18 method contracts. Four of 46 historical roots were checked in selected original scopes; full lineage and proof/specification review remain incomplete. Only two selected source statements are B, the other 53 are C; full chains are unknown. No new application check or target numerical run. [Source scope](reports/families/F-337.md) and [global review042](reports/retrospectives/042-source-scope-and-testable-transfer.md). Next: qualify an actual lightweight AD primitive, then freeze a scalar C1-through-zero transfer specification with a correct old branch baseline before target outputs. No new training or algorithm benefit is established.

WP118 checks the original Traverso Picard theorem and four Stacks prerequisite statements, with explicit regular/normal, finite-normalization, local-factorial and nonempty-variable scope. F047 has four of 26 historical roots checked in selected scopes; recursive proofs and full history remain incomplete. Explicit alternative routes are review routing, not certified proof independence. No new application check, numerical run or GitHub push. [Historical scope evidence](reports/F047-Picard-historical-prerequisites.md).

Current local through WP120 / GEN117: 47 candidates, 14 initially checked cards / distinct hypotheses, six limited predictions supported and eight adverse observations; 62 families actually read and 57 current-source drafts. The frozen F276 synthetic fixed-X audit completed 125 fixtures and 25 optimizer comparisons; 14 of 27 interior fixtures exceed the original 0.01 bit/use threshold. Exact archived-source replay matches complete raw and summary outputs. Honest old classical probabilities already suffice: no new 2026 computational advantage or device benefit. Full family/history closure and human/provider reviews remain incomplete. This local increment is not on GitHub. See [execution and limits](reports/F276-receiver-preregistration.md) and [generated metrics](reports/metrics.json).


[中文](README.md) · [English charter](CHARTER.en.md) · [Original Chinese charter](722篇AI数学论文应用价值挖掘纲领.md) · [Progress and limits](PROGRESS.en.md)

**Weaving mathematical results, historical methods, and testable applications into an evidence graph.**

This project connects a pinned mathematical manuscript corpus with historical literature, transferable methods, and concrete application problems. Its unit of research is **result family + historical lineage + application problem**. A versioned knowledge graph records the evidence, conditions, dependencies, experiments, and unresolved gaps.

**Phase one is incomplete.** The project has 47 candidate connections and 14 preliminary checks of distinct hypotheses. Six checks support narrowly defined predictions; eight retain adverse observations. These are not six new mathematical results or demonstrated engineering improvements. No family has completed the full research requirements or all six stages. Human review, independent checks by another model provider, and engineering pilots remain outstanding.

Earlier WP116 audited two pinned polynomial-map projects: three files, 159,523 bytes and 1,687 read lines; 15 canonical records and 20 explicit edges. Existing exact graph/source-relation checks covered the selected task, so that package added no candidate or experiment. [Global review041](reports/retrospectives/041-from-interface-screening-to-conditional-tests.md) then selected the existing APP27601 synthetic fixed-receiver audit, now executed as described above. Real-consumer prerequisites remain binding where the actual card requires them. Current totals are 62 reading families, 57 source drafts, 47 candidates and 14 checks; the graph has 8,570 nodes and 24,802 relations. Verified public d48dd19 is the older boundary; routine pushes are disabled. See [F047 consumer evidence](reports/F047-map-consumer-audit.md).

Repository: [yiduo/mathweave](https://github.com/yiduo/mathweave).

## Corpus and upstream boundary

The historical charter refers to 722 manuscripts. The pinned revision `1581d4cbdd69a0faf34b2089614fe2a814316a6a` contains 719 current manuscript records in 372 result families. Reconciliation preserves 692 unchanged paths, 27 linked version updates, and three proof withdrawals. PDF-file counts are not manuscript counts. The approximately 4,000 original questions mentioned in the charter were not fabricated into a dataset.

**OpenAI's official `math/` directory is not included, copied, hosted, or redeployed here.** Read the originals in [openai/math](https://github.com/openai/math/tree/1581d4cbdd69a0faf34b2089614fe2a814316a6a). This repository retains identifiers, source locations, version mappings, and checksums. Offline checks can use the pinned checksum manifest without downloading the upstream corpus; this is not a fresh reading of the originals.

This is an independent application-research project. It does not claim OpenAI endorsement or authorship of the upstream results.

## Run without downloading the corpus

Python 3.11+ and its standard library suffice for core checks and the historical standard-library experiment replays. JavaScript viewer tests also need an existing Node.js runtime. No model credentials or Lean installation are required. See the workflow for the actual CI environment; successful software checks do not certify the mathematics.

```sh
python3 scripts/check.py
python3 scripts/replay_run.py experiments/runs/EXP-332-001-b2607a9926c44586
PYTHONPATH=src python3 -m ai_value.cli query APP-332-01
PYTHONPATH=src python3 -m ai_value.cli export-graph
```

Open `reports/graph/index.html` locally to browse the graph. Download the repository ZIP, extract it, and open that file; GitHub's source viewer does not execute the HTML. Compressed JSON and GraphML exports are in the same directory.

The optional finite-bosonic experiment uses the separately documented, pinned Python/NumPy runtime. Do not run `experiment all` expecting a standard-library-only environment. See [runtime and scope](docs/bosonic-regression.md).

The Linux workflow covers 13 archived replays. EXP076 matched complete raw and summary payloads on its original macOS/Python 3.14.7 runtime, but failed raw equality on the first Linux run while its summary matched. It is not claimed portable. The original comparator and archive remain unchanged; [both outcomes and CI scope](docs/publication.md#actual-first-ci-and-platform-limit) are retained.

## Read the evidence

| Resource | Purpose |
| --- | --- |
| [English charter](CHARTER.en.md) | Full translated program, principles, stages, targets, and review gates |
| [Current progress](PROGRESS.en.md) | Evidence counts, adverse outcomes, remaining work, and next package |
| [Acceptance matrix](reports/acceptance.md) | Target-by-target status, generated from canonical records |
| [Machine-readable metrics](reports/metrics.json) | Current counts; registration and reading are kept separate |
| [Graph navigation](reports/graph/navigation.md) | Family and candidate index with explicit conditions and gaps |
| [Canonical graph](data/graph/) and [corpus records](data/corpus/) | Versioned source of records; exports and cards are derived |
| [Application cards](reports/cards/) | Hypotheses, dependencies, objections, and actual checks |
| [Experiment archives](experiments/runs/) | Specifications, compressed raw results, source snapshots, and manifests |
| [Retrospectives](reports/retrospectives/) | Comparisons of different routes and the possibility that old methods suffice |
| [F332 audit](reports/F332-family-acceptance-audit.md) | Actual proof reading and reasons complete-family credit remains zero |
| [F153 reading](reports/bernoulli-F153-reading.md) | Infinite classification, limited verifier scope, and the unestablished AR(1) benefit |
| [Real perturbation metadata](reports/F094-metadata-readiness.md) | Resolved decoding, actual label collisions, and remaining application prerequisites |

Most detailed research records are in Chinese. This release provides English entry documents, rather than claiming every historical record has been translated.

## Evidence and storage rules

Source assertions, selected proof statements, full dependency grades, external checks, and human decisions are separate records. A Lean catalogue entry is not a successful local build, and a model self-check is not human review or a second provider. Unknown prerequisites stay explicit. Formal rejection requires two real reviewers; pilots require complete A-grade dependencies and real authorization.

Register numerical specifications before running experiments. Retain adverse and failed results. Compress numerical payloads and source snapshots, verify decompression hashes, and remove temporary plaintext. Avoid duplicate upstream checkouts and large dependency downloads. Replays use isolated temporary directories that are cleaned afterward.

## License and publication

Original project code, documentation, and derived records are licensed under [Apache-2.0](LICENSE). Third-party items keep their own licenses and attribution in [NOTICE](NOTICE); this license does not relicense upstream manuscripts or external papers. Sensitive directions are represented only by necessary routing information in the public graph.

Publication status and its verification receipt are recorded in [state/publication.json](state/publication.json). Publication does not complete the research program, grant a mathematical credibility upgrade, or imply approval for engineering deployment. See [publication scope](docs/publication.md).

The [bounded symbolic-demand follow-up](reports/F025-demand-followup.md) distinguishes a real constrained old caller from the proposed single-marker feature. [Retrospective 032](reports/retrospectives/032-demand-constraints-and-next-counting-route.md) keeps all unmet phase-one targets. F113 is now read in full; [its scope report](reports/perfect-matching-F113-reading.md) separates relative counting, coarse deterministic counting, entropy, and sampling. The subsequent demand review qualifies actual counting consumers and strong old baselines; the next reading package covers F262 scalar/matrix spectral inequalities.

The [matching-count demand review](reports/F113-counting-demand.md) adds one conditional graph-probability calibration connection. The literal published replica schedule is not admitted for finite execution. No new preliminary check or general Gaussian-boson-sampling claim is counted.
