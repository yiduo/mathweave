from pathlib import Path
from html.parser import HTMLParser
import json,hashlib
w=Path(__file__).resolve().parent;d=w/'history'
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.o=[];self.math=0;self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style','nav','header','footer']:self.skip+=1
  if t=='math':
   if not self.math:self.o.append(dict(a).get('alttext','[math unavailable]'))
   self.math+=1
  if t in ['p','h1','h2','h3','h4','h5','h6','div','section','li']:self.o.append('\n')
 def handle_endtag(self,t):
  if t=='math':self.math-=1
  if t in ['script','style','nav','header','footer']:self.skip-=1
 def handle_data(self,s):
  if not self.skip and not self.math:self.o.append(s)
x=Extract();x.feed((d/'DuttaLahiri2019v1.html').read_text());s='\n'.join(' '.join(l.split()) for l in ''.join(x.o).splitlines() if l.strip());(d/'DuttaLahiri2019v1.txt').write_text(s+'\n')
print('DUTTA SELECTED')
for a,b in [('Theorem 2.17','3 Main Results'),('Lemma 3.3','Remark 3.5')]:
 i=s.index('\n'+a)+1;e=s.index('\n'+b,i);print(s[i:e])
print('BRION selected converted-text pages120-123')
p=(d/'Brion2015.txt').read_text().split('\f');print('\n'.join(p[7:11]))
(w/'conversion.json').write_text(json.dumps({'html':'stdlib HTMLParser,MathML alttext preserving original TeX;no bs4 dependency installed','pdf':'pdftotext -layout;converted text only,not visual page inspection','text_files':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(d.glob('*.txt'))],'failed_attempt':'Bundled Python has no bs4; original ModuleNotFoundError retained in work log and replaced by stdlib parser'},indent=2)+'\n')
