from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess,sys
sys.path.insert(0,'src')
from ai_value.graph import validate
from ai_value.source_results import named_results
root=Path.cwd();work=Path(__file__).resolve().parent;now=datetime.now(timezone.utc).isoformat()
GEN='GEN-20261027-110';UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a';FID='F-020';MID='P-b048d707c8589e15'
np=root/'data/graph/nodes.jsonl';ep=root/'data/graph/edges.jsonl';cp=root/'data/graph/reading_coverage.json'
oldnodes=np.read_bytes();oldedges=ep.read_bytes();oldcoverage=cp.read_bytes()
by={n['id']:n for n in map(json.loads,oldnodes.decode().splitlines())};assert len(by)==5076
assert GEN not in by and 'ANALYSIS-F-020' not in by and 'APP-020-01' not in by
new=[];edges=[];keys={(e['source'],e['relation'],e['target']) for e in map(json.loads,oldedges.decode().splitlines())}
spec=json.loads((work/'qualification.json').read_text());j=json.loads((root/'state/reading-progress/WP-113.json').read_text())
formal=json.loads((work/'formal-scope.json').read_text());hist=json.loads((work/'history-scope.json').read_text())
assert j['actual_source_lines_read']==3967 and j['actual_full_tex_files_read']==15 and j['full_current_source_read_complete']
assert not j['canonical_credit_added'] and hist['selected_original_works']==4
def save(path,obj):
    p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def src(path,loc):return {'path':path,'locator':loc,'commit':UP if path.startswith('math/') else None,'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()}
def add(id,kind,props,sources,status='source_claim'):
    assert id not in by,id
    n={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':status,'properties':{'model_generation_id':GEN,'dependency_closure_complete':False,**props},'sources':sources}
    by[id]=n;new.append(n);return n
def edge(a,r,b,loc):
    if (a,r,b) in keys:return
    keys.add((a,r,b));edges.append({'id':'E-'+hashlib.sha256((a+'|'+r+'|'+b).encode()).hexdigest()[:16].upper(),'source':a,'relation':r,'target':b,'version':1,'created_at':now,'evidence_status':'source_claim','source_commit':UP,'source_locator':loc})
def cid(label):return 'CLM-020-'+re.sub('[^a-zA-Z0-9]+','-',label).strip('-').upper()
formalpath='data/provenance/readings/F-020-formal.json';histpath='data/provenance/readings/F-020-history.json';ledgerpath='data/provenance/readings/F-020.json'
indexpath='data/graph/lean_indices/F-020.json.gz';(root/indexpath).parent.mkdir(parents=True,exist_ok=True)
(root/indexpath).write_bytes((work/'F020-formal-index.json.gz').read_bytes());gzip.decompress((root/indexpath).read_bytes())
formal['static_index']=indexpath;formal['static_index_sha256']=hashlib.sha256((root/indexpath).read_bytes()).hexdigest();formal['recorded_at']=now
save(formalpath,formal);save(histpath,hist)
rows=[];labels={};by_source={};closure=[]
texfiles=[r for r in j['actual_source_files_read'] if r['path'].endswith('.tex')]
assert len(texfiles)==15
main=next(r['path'] for r in texfiles if r['path'].endswith('/main.tex'));build=Path(main).parent
for f in j['actual_source_files_read']:
    assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256']
for f in texfiles:
    path=f['path'];text=(root/path).read_text();by_source[path]={}
    for m in re.finditer(r'\\(?:input|include)\s*\{([^}]+)\}',text):
        target=str(build/(m[1]+('' if Path(m[1]).suffix else '.tex')))
        assert target in {r['path'] for r in texfiles},target
        closure.append({'source':path,'target':target,'fully_read':True})
    for r in named_results(text):
        label=r['label'];summary,conditions=spec['claims'][label];id=cid(label)
        assert label not in labels;labels[label]=id;by_source[path][label]=id
        rows.append({'id':id,'label':label,'kind':r['kind'],'manuscript_id':MID,'path':path,'sha256':f['sha256'],'statement_lines':[text.count('\n',0,r['statement_start'])+1,text.count('\n',0,r['statement_end'])+1],'statement_tex':text[r['statement_start']:r['statement_end']].strip(),'summary':summary,'conditions':conditions,'aliases':r['label_aliases'],'source_claim_grade':'B' if label in {'thm:density','cor:all-degrees'} else 'C','unlabelled':False})
assert len(rows)==26 and set(labels)==set(spec['claims']) and not any(r['aliases'] for r in rows)
cyclo=next(r['path'] for r in texfiles if r['path'].endswith('13-cyclotomic.tex'));text=(root/cyclo).read_text()
unlabelled=[('unlabelled:level-saving','There is also a determinant saving obtained directly',r'\subsection{Analytic relations and box incidence}','特殊四次分圆level方程的嵌套列节省','特定方向簇D∩{S≠0}、真实整数代表S=−1及正体积多项式v0的各固定正ray下界；固定mesh、T后N→∞。平均列指数节省后，局部相对维r光滑好素数及严格rho阈值给真cut。不能从projective零集合单独恢复S=−1；附加方法不是密度主证明的必要输入。'),('unlabelled:analytic-relation',r'\paragraph{Approximate rank from an actual analytic relation.}',r'\paragraph{The quintic equality case.}','非零拉回解析关系的近似秩及行列式界','一个共同复多圆盘上统一有界holomorphic f_lambda且Taylor系数连续，极限拉回germ非零、正最低权D；每个评价矩阵的全部点用同一lambda。固定Z和矩阵规模先于N。截断乘法injective及持久子式给近似矩阵rank≤q_Z、奇异值／行列式界，不是原解析评价精确秩。原sections归一化不能替代拉回germ非零；附加条件方法不参与主密度依赖。')]
for label,start,end,summary,conditions in unlabelled:
    a=text.index(start);b=text.index(end,a);id=cid(label)
    rows.append({'id':id,'label':label,'kind':'unlabelled_source_consequence','manuscript_id':MID,'path':cyclo,'sha256':hashlib.sha256(text.encode()).hexdigest(),'statement_lines':[text.count('\n',0,a)+1,text.count('\n',0,b)],'statement_tex':None,'summary':summary,'conditions':conditions,'aliases':[],'source_claim_grade':'C','unlabelled':True})
claim_ids={r['label']:r['id'] for r in rows}

bib=next(r for r in j['actual_source_files_read'] if r['path'].endswith('references.bib'));bt=(root/bib['path']).read_text()
matches=list(re.finditer(r'@\w+\s*\{([^,\s]+),',bt));bibmap={};litnodes={}
def field(entry,name):
    m=re.search(r'\b'+name+r'\s*=\s*\{',entry,re.I)
    if not m:return None
    start=m.end();pos=start;depth=1
    while depth and pos<len(entry):
        if entry[pos]=='{':depth+=1
        elif entry[pos]=='}':depth-=1
        pos+=1
    assert depth==0;return ' '.join(entry[start:pos-1].split())
for i,m in enumerate(matches):
    key=m[1];entry=bt[m.start():matches[i+1].start() if i+1<len(matches) else len(bt)].strip()
    id='LIT-020-'+re.sub('[^a-zA-Z0-9]+','-',key).strip('-').upper();bibmap[key]=id
    props={'title':field(entry,'title') or key,'bibliography_key':key,'bibliography_entry':entry,'retrieval_status':'upstream_bibliography_only','verified_scope':'Complete bibliography entry read; original body not read.','full_original_proof_review':False}
    sources=[src(bib['path'],'Complete bibliography entry '+key)];status='source_claim'
    if key in hist['verified_scopes']:
        h=hist['verified_scopes'][key];bodies=[x for x in hist['selected_bodies'] if x['work']==key or (key=='stacks-project' and x['work'].startswith('stacks-project-'))]
        assert bodies
        props.update({'retrieval_status':'selected_original_scope_checked','verified_scope':h['summary'],'selected_scope_locator':h['scope'],'original_version':h['version'],'unverified_scope':'No full historical proof review, recursive lineage or unselected root body qualification.'})
        for x in bodies:sources.append({'url':x['url'],'sha256':x['sha256'],'source_file_sha256':x['sha256'],'locator':h['scope']+'; '+x['work']+'; selected scope only','content_checked':True,'checked_at':x['retrieved_at']})
        status='source_content_checked'
    litnodes[key]=add(id,'literature',props,sources,status)
assert len(litnodes)==28
reviewpath='data/provenance/reviews/APP-020-01-isolated-roles.json.gz'
packet=(work/'neutral-mapping-packet.json').read_bytes()
review={'recorded_at':now,'packet_sha256':hashlib.sha256(packet).hexdigest(),'frozen_packet':json.loads(packet),'provider':'OpenAI','exact_backend_model':'unknown','independent_second_provider':False,'human_review':False,'contexts_isolated':True,'roles_did_not_read_each_other':True,'source':'Completed earlier isolated roles; recovered raw files and publication archive, not fresh calls this turn.','opinions':[],'disagreement':'Defender recommends one pending conditional candidate; skeptic prefers method/gap until a consumer passes admission, allowing one card only if pending admission is explicit. No consensus or approval inferred.','decision':'Retain exactly one low-priority pending conditional candidate under charter wide-entry policy, with no admitted consumer, executable preregistration or external-check credit.','auxiliary_finite_bound':'Both roles suggest a possible finite bad-fraction bound. It remains an unproved application-side derivation, not an accepted source theorem, risk certificate or research contribution; no numerical use is authorized by this note.'}
for role in ['defender','skeptic']:
    p=work/(role+'.md');raw=p.read_bytes();review['opinions'].append({'role':role,'agent':'/root/f020_'+role,'raw_text':raw.decode(),'raw_sha256':hashlib.sha256(raw).hexdigest(),'file_mtime_observed_not_call_time':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat(),'independent':False,'isolated_same_provider_agent':True})
raw=json.dumps(review,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
(root/reviewpath).parent.mkdir(parents=True,exist_ok=True);(root/reviewpath).write_bytes(packed)
planpath='experiments/plans/APP-020-01-conditional.json'
plan={'connection_id':'APP-020-01','version':1,'created_at':now,'status':'conditional_plan_not_preregistered','scientific_run':False,'actual_consumer_identified':False,'input':review['frozen_packet']['conditional_input_contract'],'output':review['frozen_packet']['possible_output'],'falsifiable_prediction':review['frozen_packet']['application_value_hypothesis'],'baselines':review['frozen_packet']['null_and_baselines'],'entry_gates':['An inspected nontrivial consumer exposing the same fixed S and nested complete Q-evaluation kernels; ordinary Fp nullspaces do not qualify','Prove full-record equality implies every subsequent state/patch/minor agrees, with deterministic choices and all fixed-depth failure paths','Effective finite B0,T0,prime-pool law,nonzero-minor height bounds and bridge from bad fraction to the actual failure/cost event','Independent exact output judge;freeze strongest old policies,full information and construction costs,holdout,resource cap and meaningful thresholds before numerical outputs'],'full_cost':['Representation/acquisition of S','Complete rational kernels and coefficient growth','Patch/component and nonzero-minor construction','Finite certificate and relevant full paths','Prime generation,modular arithmetic,CRT,reconstruction,restarts and exact output verification','Wall time,peak memory,storage and all certificate generation/checking'],'success_threshold':None,'failure_threshold':None,'reason_thresholds_unset':'No actual workload,consumer,finite certificate or independent judge admitted; this is not an executable preregistration.','controls':['Fixed minors and independent resampling','Lucky-prime/modular-rank checks with exact final verification','Deterministically large primes if feasible','Same complete-kernel information and equal full-cost allocation for old policies','All paths rather than success-only conditioning; whole-algorithm failure distinct from expected bad fraction'],'stop_rule':'Stop before benefit experiments if same-S kernels,stable-state contract,finite nonvacuous risk or full-cost feasibility cannot be established. Retain evidence;no new theorem research or known-formula prime-grid demo.','revisit_when':'A pinned inspectable workload and finite admission evidence or a lower-cost constructive interface becomes available.','model_roles':reviewpath,'human_and_second_provider':'missing,deferred not waived','numerical_data':None}
save(planpath,plan)
gaps=['Full current natural source read andsource-qualified; no independent proof validation or complete historical family acceptance.','28 external roots:four selected original scopes,nine HTML bodies hashed;24 roots and recursive lineage remain unread. Browning direct publication,Milne class/unit construction andEGHP minimal-degree originals remain gaps.','Only thm:density/cor:all-degrees selected formal endpoints retain local B;26 other bindings C;full dependency grade unknown,no local Lean/Comparator or human specification review. Static63-file/23269-line import index is not proof reading or axiom audit.','Fixed-polynomial asymptotics and existential patches do not provide effective uniform finite N0,constructive input costs or practical generator. Source parameter certificate read,not executed.','Adaptive modular consumer,complete same-S Q-kernels,full-state stability,finite risk certificate andfull costs unestablished. Roles disagree on admission;one pending conditional card,not an actual check.','Analytic variant needs nonzero pulled-back limiting germ,common polydisc andsame parameter per matrix;only approximate rank. Level-saving andanalytic variants are not main density proof dependencies.']
versions=[json.loads(l) for l in (root/'data/corpus/reconciliation.jsonl').read_text().splitlines() if json.loads(l).get('family_id')==FID]
ledger={'family_id':FID,'work_package':'WP-113','generation_id':GEN,'at':now,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream_commit':UP,'manuscript_ids':[MID],'read_files':j['actual_source_files_read'],'readmes':[r for r in j['source_files'] if r['path'].endswith('README.md')],'actual_read_ranges':'All15TeX3967lines plus345Bib andREADME; earlier batches and incomplete journals retained without extra credit.','manual_file_reading_notes':j['provisional_reading_notes'],'source_sections':list(by_source),'source_tex_lines':3967,'bibliography_lines':345,'include_links_checked':closure,'results':rows,'methods':spec['methods'],'domain_attempts':spec['domains'],'cross_family_attempts':spec['cross_family'],'historical_references_by_key':bibmap,'historical_external_work_count':28,'historical_selected_originals':histpath,'unread_root_work_ids':[n['id'] for k,n in litnodes.items() if k not in hist['verified_scopes']],'historical_versions_in_corpus':versions,'version_history_scope':'Current source at fixed upstream only; reconciliation mapping is catalogue evidence, not actual reading of all historical proof versions. No withdrawn source silently substituted.','formal_status':formalpath,'formal_index':indexpath,'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':1,'new_initial_checks':0,'numeric_or_symbolic_run':False,'isolated_reviews':reviewpath,'gaps':gaps,'source_reuse_policy':'Official math read-only; qualified result statement excerpts and metadata only, no full upstream tree or third-party body copies in publication.','github_push':False,'acquisition':{'prior_turn_body_bytes':hist['new_body_bytes'],'new_body_bytes_this_continuation':0,'no_dependencies_installed':True},'method_count_note':'24 contracts include the actually read final elementary box-incidence estimate; this is a method scope, not an additional labelled theorem or application.'}
save(ledgerpath,ledger);ledger_source=src(ledgerpath,'Full actual F020 source-reading ledger,28source bindings,24method contracts andexplicit formal/history/application limits')
for r in rows:
    props={'title':r['summary'],'statement':r['summary'],'conditions':[r['conditions']],'family_ids':[FID],'manuscript_id':MID,'source_label':r['label'],'source_statement_lines':r['statement_lines'],'credibility':r['source_claim_grade'],'source_claim_grade':r['source_claim_grade'],'dependency_chain_grade':'unknown','unlabelled_source_consequence':r['unlabelled'],'constants_and_constructions':['Exact formula/quantifiers in source statement and source locator;section hypotheses and transfer exclusions in conditions;parameter table is source claim,not local numerical observation.']}
    if r['statement_tex'] is not None:props['statement_tex']=r['statement_tex']
    sources=[copy.deepcopy(ledger_source),src(r['path'],r['label']+';lines'+str(r['statement_lines'])+';full containing source actually read;not accepted proof review')]
    if r['source_claim_grade']=='B':sources.append(src(formalpath,'Actual Model/Main selected input/output comparison;no Lean build or human review'))
    add(r['id'],'claim',props,sources);edge(r['id'],'member_of',FID,'Source-qualified result in the one current manuscript');edge(r['id'],'derived_from',MID,'Pinned current source;complete dependency closure unknown')
deps={
'thm:density':['prop:large-prime-tail','prop:sieve-transfer'],
'cor:all-degrees':['thm:density','lem:density-content'],
'cor:separable-products':['prop:large-prime-tail','prop:sieve-transfer'],
'thm:affine-counting':['lem:affine-patches','lem:affine-residue-cut','lem:affine-deletion'],
'lem:affine-deletion':['lem:affine-patches'],
'lem:paired-boxes':['lem:balanced-factorization'],
'prop:archimedean-cuts':['lem:bicone','lem:paired-boxes'],
'prop:lattice-boxes':['lem:lattice-basis','lem:paired-boxes'],
'lem:quartic-fibers':['prop:archimedean-cuts','lem:balanced-factorization'],
'prop:quartic-surface':['prop:weighted-hilbert'],
'prop:curve-alternatives':['lem:rational-values','prop:quintic-discard','lem:balanced-factorization'],
'prop:parameter-certificate':['lem:bicone','prop:quartic-surface','prop:curve-alternatives'],
'prop:large-prime-tail':['thm:affine-counting','lem:balanced-factorization','lem:paired-boxes','prop:archimedean-cuts','prop:lattice-boxes','lem:quartic-fibers','prop:weighted-hilbert','prop:quartic-surface','prop:quintic-discard','prop:curve-alternatives','prop:parameter-certificate'],
'cor:cyclotomic-density':['thm:density'],
'prop:cyclotomic-central':['prop:large-prime-tail','prop:parameter-certificate','lem:balanced-factorization','lem:quartic-fibers'],
'unlabelled:level-saving':['lem:bicone']}
for child,parents in deps.items():
    for parent in parents:edge(claim_ids[child],'depends_on',claim_ids[parent],'Confirmed supporting result;scope/section assumptions retained. Not all lexical references are mandatory premises.')
for label,key in [('cor:all-degrees','Xiao2017PowerFree'),('cor:separable-products','Xiao2017PowerFree'),('cor:separable-products','Reuss2015PowerFree'),('lem:bicone','stacks-project'),('prop:weighted-hilbert','stacks-project'),('prop:quartic-surface','EisenbudGreenHulekPopescu2006')]:edge(claim_ids[label],'depends_on',bibmap[key],'Specific historical proof input; selected scope ifdeclared,otherwise original unread and full chain unknown')
for r in rows:
    for m in re.finditer(r'\\cite\w*\s*(?:\[[^\]]*\])?\{([^}]+)\}',(root/r['path']).read_text()):
        for key in m[1].split(','):
            if key.strip() in bibmap:edge(r['id'],'historical_context',bibmap[key.strip()],'File-level bibliography context;not per-result mandatory proof input. Carella/Zapata context does not become theorem dependency.')
method_ids=[]
for key,label,inp,out,cond,lim in spec['methods']:
    id='PART-020-'+key;method_ids.append(id);r=next(r for r in rows if r['label']==label)
    sources=[src(r['path'],label+';full section read;scoped input/output method,not empirical value')]
    if key=='GRID-INCIDENCE-MULTIPLICITY':sources.append(src(cyclo,'Final unlabelled box-incidence paragraph;original witness vector distinct from lattice residual vector'))
    add(id,'method',{'title':key,'family_ids':[FID],'input':inp,'output':out,'conditions':cond,'cannot_transfer':lim,'credibility':'C','source_claim_grade':'C','dependency_chain_grade':'unknown'},sources)
    edge(id,'depends_on',claim_ids[label],'Source method contract,not effective algorithm or accepted theorem')
problems=[('FINITE-DENSITY','固定多项式密度的有限误差缺口','无系数一致常数／有效N0／可操作采样复杂度，旧逐值整除检查可能已足够。'),('ADAPTIVE-PRIME-GATE','自适应模重构完整核准入缺口','尚无真实消费者提供同一S上的嵌套完整Q核、确定性状态、所有失败路径、非零子式高度和有限非空风险／全成本证书。'),('CONSTRUCTION-COST','全核与算术构造全成本缺口','S、求值核、分量／补丁、类群／单位基及证书构造成本必须收费，不能先解原问题后宣称选素数收益。'),('ANALYTIC-GERM','拉回解析关系非零与有限参数缺口','共同复多圆盘／统一解析界、每矩阵同一lambda与非零极限拉回germ未由现实数据提供，近似秩不能提升为精确。')]
for suffix,title,statement in problems:add('PROB-020-'+suffix,'problem',{'title':title,'statement':statement,'family_ids':[FID],'credibility':'unknown','prerequisite_status':'unestablished_for_real_application'},[copy.deepcopy(ledger_source)],'source_content_checked')
app=add('APP-020-01','connection',{'title':'完整核稳定性条件下的自适应模重构选素数政策','family_ids':[FID],'source_ids':[claim_ids['lem:affine-deletion']],'history_ids':[bibmap['Reuss2015PowerFree']],'part_ids':['PART-020-RANK-STABILITY-DELETE','PART-020-VARIABLE-BLOCK-SAMPLING'],'problem_id':'PROB-020-ADAPTIVE-PRIME-GATE','mechanism':plan['input']+' Output: '+plan['output'],'prediction':plan['falsifiable_prediction'],'test_spec':planpath,'run_ids':[],'baseline':plan['baselines'],'opposition':{'type':'auxiliary self-check,not provider/human review','independent':False,'isolated_same_provider_agent':True,'text':'Skeptic prefers method/gap until actual consumer admission: ordinary Fp kernels do not nest in one Q-space,rank alone is insufficient,all fixed-depth paths and effective constants/costs are essential. Allows one card only with pending admission explicit.'},'defense':{'type':'auxiliary self-check,not provider/human review','independent':False,'isolated_same_provider_agent':True,'text':'Defender supports one narrow pending hypothesis because deletion/full-record stability decouples adaptive bad-prime objects. Requires real consumer,finite certificate and full costs;no efficacy established.'},'theoretical_grade':'unknown','source_claim_grade':'C','credibility':'unknown','sensitive':False,'resources':'No numerical allocation or installations. Future admitted run requires independent executable preregistration;all raw/data/source snapshots compressed with verified roundtrip.','owner':'Current selected OpenAI session;human owner unassigned','workflow':'候选','application_result':'待定','limitations':'; '.join(gaps),'revisit_when':plan['revisit_when'],'analogy':'far','dedup_key':'F-020|PROB-020-ADAPTIVE-PRIME-GATE|same-S-complete-Q-kernel-variable-prime-batch-policy','priority_reason':'Low priority until a nontrivial actual modular consumer proves the complete-kernel stability contract and useful finite risk at full cost. Ordinary resampling/lucky-prime checks/exact verification may already suffice.','isolated_review_evidence':reviewpath,'external_check_type':'conditional_plan_not_run','summary':{'actual_consumer_identified':False,'initial_check_eligible':False,'status':'not_run','supported':None,'observations':None,'old_methods_may_suffice':True,'canonical_candidate_admission':'One pending conditional hypothesis,not admitted application efficacy;role disagreement retained.'}},[copy.deepcopy(ledger_source),src(reviewpath,'Frozen identical packet andraw isolated same-provider opinions;not external validation'),src(planpath,'Conditional plan only;no executable preregistration or outputs')],'hypothesis')
for ref in app['properties']['source_ids']+app['properties']['part_ids']+['PROB-020-ADAPTIVE-PRIME-GATE','PROB-020-CONSTRUCTION-COST']:edge(app['id'],'depends_on',ref,'Conditional application premise;no actual consumer or benefit acceptance')
edge(app['id'],'references',bibmap['Reuss2015PowerFree'],'Historical technique context,not an admitted modular algorithm')
expl=add('EXPLORE-F-020','exploration',{'title':'F020十领域与三跨族条件探索','family_ids':[FID],'attempts':[{'domain':d,'analogy':a,'assessment':s,'accepted_connection':accept,'connection_id':'APP-020-01' if accept else None} for d,a,s,accept in spec['domains']],'cross_family_attempts':spec['cross_family'],'new_connection_ids':['APP-020-01'],'interpretation':'Only one concrete conditional mapping retained;ten attempts/three combinations are not ten/thirteen applications or external checks. No formal negative archive.','credibility':'unknown'},[copy.deepcopy(ledger_source)],'hypothesis')
for id in method_ids:edge(expl['id'],'uses',id,'Conditional structural exploration,not measured value')
for item in spec['cross_family']:
    assert item['existing_method'] in by;edge(expl['id'],'references',item['existing_method'],'Cross-family structural comparison;not a combined proof orapplication dependency')
analysis=add('ANALYSIS-F-020','family_analysis',{'title':'F020固定多项式幂自由值的当前源码拆解草稿','family_id':FID,'family_ids':[FID],'manuscript_ids':[MID],'manuscript_source_drafts_complete_ids':[MID],'source_sections':list(by_source),'source_line_count':3967,'result_ids_by_label':labels,'result_ids_by_source':by_source,'unlabelled_result_ids':[r['id'] for r in rows if r['unlabelled']],'method_ids':method_ids,'formal_statement_comparison':[{'item':'thm:density andcor:all-degrees only','natural':'Fixed Q-irreducible Z polynomial,degree4..8 orall>=4,k=d−2,local admissibility,positive convergent Euler density and little-o per fixed polynomial','Lean':'Actual PowerFree Model/Main andselected endpoint dependencies read;source quartic route uses3/1000 and100bins,not exactnatural grid proof','assessment':'Only two selected result statements local B,26otherbindings C;wholeproof/route/constants correspondence unknown,no build/Comparator/human.'},{'item':'Simultaneous products,cyclotomic support andunlabelled analytic/level variants','natural':'Additional separability/local-union/arithmetic/germ hypotheses remain explicit','Lean':'Not automatically supplied by selected allDegrees endpoint','assessment':'No inherited full-family B orlocal formal acceptance.'}],'formal_status':{'evidence':formalpath,'static_index':indexpath,'indexed_OAI_files':63,'indexed_lines':23269,'lexical_declarations':1165,'local_lean_build':False,'comparator_run':False,'human_spec_review':False,'complete_proof_or_axiom_audit':False},'historical_references_by_key':bibmap,'historical_verified_keys':list(hist['verified_scopes']),'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'gaps':gaps,'credibility':'unknown','completion_basis':'15TeX3967lines+345Bib+README actually read;26named and2unlabelled sourcebindings,24methodcontracts. Not full lineage,proof review,human/provider orapplication acceptance.'},[copy.deepcopy(ledger_source)],'source_content_checked')
config='data/provenance/research-at-generation-110.json';(root/config).write_bytes((root/'configs/research.json').read_bytes())
add(GEN,'generation',{'title':'F020current fullsource qualification,selected formal/history andone conditional adaptive-prime hypothesis','family_ids':[FID],'project_base_commit':ledger['base_commit'],'provider':'OpenAI','model':'Current user-selected session;exact backend unknown','human_review':None,'independent_second_provider':None,'credibility':'unknown','seed_list_exposed':True},[copy.deepcopy(ledger_source),src(config,'Research policy snapshot'),src(formalpath,'Selected actual endpoints andbounded static index;not proof acceptance'),src(histpath,'Four selected historical works;not recursive closure')],'source_content_checked')
coverage=json.loads(oldcoverage);assert FID not in coverage['partially_read_families']
archive='data/graph/history/'+GEN+'-reading-coverage-before.json.gz';packed=gzip.compress(oldcoverage,mtime=0);assert gzip.decompress(packed)==oldcoverage;(root/archive).write_bytes(packed)
coverage['partially_read_families'][FID]=['Full current15TeX3967lines+345Bib/README actual reading/source draft;26named+2unlabelled bindings and24contracts,notfullfamily.','Four selected historical works:nine HTML bodies1993868bytes acquired earlier;24rootbodies andrecursivehistory remainunread.','Actual selected formal Model/Main onlytwo endpoints localB;26otherbindings C/fullchainsunknown;63-file index notfullproofreading/build/axiomaudit.','Ten domains/three crossfamily attempts;one low-priority conditional APP02001,role disagreement preserved;no actualconsumer/externalcheck/experiment.']
expected={n['properties']['family_id'] for n in by.values() if n['kind']=='family_analysis' and n['properties'].get('source_decomposition_draft_complete')}
coverage['source_decomposition_drafts']+=sorted(expected-set(coverage['source_decomposition_drafts']));assert len(expected)==55
coverage.update({'updated_at':now,'update_reason':'WP113 actual full-current-source qualification andselected history/formal scope;one conditional candidate,notcompletefamily/application validation','prior_version_archive':archive})
summary={'generation':GEN,'base_commit':ledger['base_commit'],'old_records':len(by)-len(new),'new_records':len(new),'modified_old_record_ids':[],'new_explicit_edges':len(edges),'named_bindings':26,'unlabelled_bindings':2,'method_contracts':24,'new_literature_nodes':28,'historical_selected_original_works':4,'source_B':2,'source_C':26,'new_candidates':1,'new_application_checks':0,'new_scientific_experiments':0,'new_record_ids':[n['id'] for n in new]}
try:
    np.write_bytes(oldnodes+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new).encode());ep.write_bytes(oldedges+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges).encode());save('data/graph/reading_coverage.json',coverage)
    metrics=validate(root)
except Exception as exc:
    (work/'unaccepted-curation-failure.json').write_text(json.dumps({'error_type':type(exc).__name__,'error':str(exc),'summary':summary,'state':'Canonical nodes/edges/coverage restored;new evidence files retained for repair'},ensure_ascii=False,indent=2)+'\n')
    np.write_bytes(oldnodes);ep.write_bytes(oldedges);cp.write_bytes(oldcoverage);raise
assert np.read_bytes().startswith(oldnodes) and ep.read_bytes().startswith(oldedges)
summary['initial_graph_validation']=metrics;(work/'curation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='new_record_ids'},ensure_ascii=False))
