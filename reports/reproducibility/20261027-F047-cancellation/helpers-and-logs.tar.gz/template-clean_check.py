from pathlib import Path
from datetime import datetime,timezone
import sys,os,subprocess,hashlib,json,gzip,shutil
root=Path.cwd();work=Path('/private/tmp/ai-paper-WP113');clean=work/'clean';assert not clean.exists();clean.mkdir();manifest=[]
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
for name in sorted(set(filter(None,paths))):
 assert name.split('/')[0] not in {'math','.git','.venv','tmp','.cache'};p=root/name;assert p.is_file() and not p.is_symlink();data=p.read_bytes();q=clean/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);q.chmod(p.stat().st_mode&0o777);h=hashlib.sha256(data).hexdigest();assert hashlib.sha256(q.read_bytes()).hexdigest()==h;manifest.append({'path':name,'bytes':len(data),'sha256':h})
assert not (clean/'math').exists()
with (work/'clean-core.log').open('wb') as out:r=subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=out,stderr=subprocess.STDOUT)
d={'at':datetime.now(timezone.utc).isoformat(),'core_exit_code':r.returncode,'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest),'manifest':manifest,'copy_hashes_verified':True,'math_included':False,'runtime':sys.version,'scope':'Current selected tree in fresh directory,including untracked newcanonical records;no upstream or installed projectdependencies. Later closuremetadata separately identified.'};raw=json.dumps(d,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(work/'clean-check.json.gz').write_bytes(packed)
if r.returncode==0:shutil.rmtree(clean)
print(json.dumps({k:v for k,v in d.items() if k!='manifest'}));raise SystemExit(r.returncode)
