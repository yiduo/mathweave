from pathlib import Path
import json
w=Path(__file__).resolve().parent
C={
'thm:main':['复四维整代数的多项式柱与非多项式底空间','固定k=C、P=k[p,s,u,F,J]及x=s²+u³+p²F、H=x²F−(1+2sx)J−p²J²−pu、A=P/(H)；所有同构保持k。dimA=4,A[w]≅k^[5],A非k^[4]。是这一个对象的原稿主张，不是任意域、拓扑、有效识别算法或局部验证定理。'],
'cor:stable-coordinate':['固定H加一个变量后成为环境坐标而原来不是坐标','环境P与P[w]中的坐标概念；H非坐标来自A非多项式。稳定坐标另用k[p]上残余坐标和Dutta–Lahiri3.4，不能仅由商环A[w]多项式推出；未在选定Lean主结论覆盖。'],
'con:domain':['整性、维数与p倒置的具体Laurent坐标','p不整除H，倒置p后H对u线性且系数单位；UFD中因子下降。p在A中非零，A[p^-1]=C[p,p^-1,x,y,z]；倒置p的局部坐标不能延伸为全局多项式坐标。'],
'prop:stabilization':['一个额外变量的显式多项式柱同构','固定H和特定LND Delta、DeltaH=p³。有限exp(wDelta)后用行列式1的(F,J)变换、模p³根L*及多项式e0证书；p非零取消p³。给出固定例子的互逆映射，无一般多项式自动同构求解复杂度界，未由本项目执行符号计算。'],
'deg:valuation':['固定p素理想给离散赋值和全局p整除','S=C[p,x,y,z,u]/(xy−z(z+1)−p³u)嵌入A、共同p倒置；R=S/pS光滑整。S_(pS)为DVR且对b∈S，ordp b≥i等价b∈p^iS，用素性证明全局整除，i≥0。不能套用到任意局部赋值。'],
'prop:graded':['保留系数嵌入的精确关联分次代数','负赋值次数、权重(-1,0,0,2,2)，grA确为R[tau,I/tau²]⊂R[tau,tau^-1]；每元素有最大权恰为deg的代表。Htop=presentation主部，权重下降有固定deg下界；抽象同构不替代实际R嵌入。'],
'lem:induced-lnd':['非零局部幂零导子的齐次初始导子','对固定A的任意非零LND，生成元最大次数差j可为负，精确代表给全局界。非零齐次D0且不变量初始形式仍不变；不保证D0保持R。'],
'prop:positive-invariant':['假定A多项式强制正赋值次数不变量','只是假设A≅C^[4]下的必要条件；至少一个坐标正次数，在另一坐标求导固定它，再取初始导子。不能把必要条件当多项式性充分判据。'],
'prop:principalization':['两Laurent图主丛上理想主化并保持两套分次','Rt=C[a,d,b,c,u]/(ac−bd−1),x=ab,y=dc,z=db,v=a³b−a²u³−d²。两开图保证R→Rt忠实平坦；I Rt=(v)有f=C1v,g=b²v,v=alpha f+beta g证书。Gt=Rt[tau,V]/(tau²V−v)整，赋值次数与纤维权重分开；不假设Ga作用保持Rt。'],
'prop:linearization':['光滑仿射复簇上加法作用的唯一规范线丛提升','X光滑整仿射复簇，Pic(A1×X)≅PicX，任意线丛的提升在0处恒等且满足cocycle。单位C[t]^*=C^*不等于全单位均为常数域标量。L×仿射时才把作用写成坐标环LND，char0用于导子与指数对应；选定Lean不覆盖此一般命题。'],
'prop:homogeneous-lift':['自然证明中保持纤维权和赋值次数的原导子提升','G上齐次LND D0次数j，可在Gt提升原D0，纤维权0且同j；D0非零则提升非零。使用前一一般线丛命题及规范提升唯一性；与实际Lean的cD后取最高分量不同，不互相冒充。'],
'lem:lnd-order':['局部幂零阶的乘法相加与核乘法封闭','char0整环T，非零f,g的nu(fg)=nu f+nu g。导子非零值降阶1，核乘法封闭，delta h非零不能整除于hT。无UFD假设；charp二项式消失情形不可沿用。'],
'prop:extracted-lnd':['多项式性假设强制非正纤维权的二阶零导子','固定Gt双分次，正次数不变量强制V不变；按Dt(tau)=0或不等0分支抽取Rt上E，E非零LND、固定q≤0,E²v=0。q≤0本质；原稿正权E+(b)=a,E+(c)=d满足E+²v=0不能省此条件。'],
'rig:abc':['char0域上一变量Mason–Stothers不同根界','F特征0，X,Y,Z∈F[q]均非零两两互素、X+Y=Z且不全常数；最大次数≤代数闭包中不同根数−1。闭包只用于数根，不得把后续原系数域中的非平方变为可平方。'],
'rig:one-variable':['一变量多项式环的LND只能常数速度','F特征0，F线性局部幂零导子作用于F[t]，delta t∈F；必须固定F且实际局部幂零，非任意多项式向量场。'],
'prop:rigidity':['固定Rt中非正纤维权的二阶零导子障碍','固定v和Rt、E是k线性非零LND、固定纤维位移e≤0。辅助最高分量保持e，orbit abc后用原K=C(a,d,b)(u)中−u³的u阶奇数排除平方；再用Rt∩C(a,d,u)=C[a,d,u]与非负权。正纤维权反例保留，不扩称所有导子都不存在。'],
'cor:affine-fibrations':['仿射直线与平面基上的非局部平凡光滑三维仿射纤维','固定pi:SpecA→A1_p及rho=(p,H):A5→A2_pq；所有点的剩余域纤维均为A3，光滑满射相对维3。Jacobian单位理想单独证明光滑，pi为q0基变。非Zariski局部平凡用有限呈示、BCW与rank3有限生成投射模在C多项式基上自由；不涉及相对维1或2。']}
M=[
('STABLE-CYLINDER','显式稳定化坐标证书','固定H和一个额外变量w','五个全局多项式坐标及反向代换','prop:stabilization','必须保存p=0分支、整性和p非零；不是一般坐标算法或降维规则'),
('RESIDUAL-COORDINATE','倒置参数及特殊纤维分开核对残余坐标','C[p]上固定多项式H','每个剩余域上以H为首坐标','cor:affine-fibrations','p^-1局部与p0行列式1变换齐全；残余坐标不直接推出未稳定全局坐标'),
('VALUATION-DIVISIBILITY','素参数的局部阶与全局整除桥梁','S、素理想pS及p倒置共同域','ordp与全局p幂整除的精确等价','deg:valuation','特定素性与DVR条件，不能给任意局部观测推全局整除'),
('EXACT-GRADED','带系数嵌入和终止证书的初始模型','固定Htop、负权赋值和实际R嵌入','grA的精确子代数表示和最小权代表','prop:graded','不只登记抽象Hilbert或同构；下降要保留实际次数下界'),
('INITIAL-LND','保留不变量的最高次数导子','固定A的非零LND及生成元次数','非零齐次LND和不变量初始形式','lem:induced-lnd','次数位移任意符号，导子不必保持系数R；原稿Delta(u)=−tau²反例'),
('TORSOR-PRINCIPALIZE','两图忠实平坦主化','R中理想I和指定SL2型主丛','I Rt=(v)、双分次Gt及显式组合证书','prop:principalization','图覆盖、过渡单位、平坦性和tau非零不能省；不是原空间上I已主'),
('NORMALIZED-LIFT','规范线丛提升的cocycle判据','光滑整仿射复簇、Ga作用、线丛','唯一0处恒等提升及纤维权0的LND','prop:linearization','L×需仿射，char0；不由所选Lean主结论自动覆盖'),
('SIGNED-EXTRACTION','通过两套权重分支抽取障碍','Gt中齐次LND和正赋值次数不变量','Rt上非正纤维权E且E²v=0','prop:extracted-lnd','必须保存正权可行反例，不能删q≤0变成更强结论'),
('LND-ORDER','用局部幂零阶限制可除性','char0整环中实际LND及非零乘积','阶相加、核乘法封闭和非整除障碍','lem:lnd-order','是旧一般引理在本构造使用，不作新数学或速度收益'),
('ORBIT-ABC','轨道多项式的根重数与系数域双重障碍','char0轨道多项式和次数≤1的d²+a²u³','abc次数限制后检查原系数域非平方','prop:rigidity','原K中u阶奇数是关键；代数闭包仅数根，不全程换域'),
('COEFFICIENT-INTERSECTION','两张图求系数域交集','Rt的a,d局部化及不变系数Q','Rt∩Q=C[a,d,u]，再读非负纤维权','prop:rigidity','a,d在系数UFD互素，b/c超越性与固定系数条件明确'),
('FIBER-LOCAL-GLOBAL','分别检查纤维、光滑及全局平凡性','固定残余坐标映射及有限呈示代数','全部剩余域A3纤维与光滑，独立全局障碍','cor:affine-fibrations','不能以纤维采样或局部Jacobian通过代替Zariski局部平凡；BCW原作取证缺口保留')]
D=[
('符号代数／坐标识别','near','具体输入H与A可用作区分稳定商环、环境坐标和未稳定识别的回归对象；尚未识别真实算法的错误分支或独立裁判，保留方法和消费者缺口，不先跑已知多项式恒等式算新收益。'),
('程序验证／编译器优化','far','添加辅助变量后的等价不能自动取消辅助状态；需实际多项式状态语义、保持标量的同构以及错误消去规则。普通SSA临时变量删除不等于仿射坐标取消，暂无具体工作负载。'),
('机器学习／潜变量可识别性','far','X×A1与X不同提供稳定表征丢失结构的类比；真实潜变量模型通常统计可识别或实光滑同胚，尚无复代数同构损失函数接口，不可称识别性反例。'),
('机器人／配置空间','far','局部坐标和全局平凡化分离可能帮助配置图谱测试；实际配置空间有实不等式、碰撞和度量，固定复四维例子未与可执行运动规划实例对接。'),
('生物反应网络','far','稳态代数多样体的辅助物种消去需保留结构；正浓度、守恒律和动力学不在来源范围，不能由C代数例子推出生物多稳态。'),
('金融／因子模型','bold','边际／纤维相同未必总体模型可分解是一条结构直觉；概率分布、套利和可估计性与Zariski局部平凡不同，尚无可证伪金融机制。'),
('交通／分区路网','bold','每个局部路段同型仍需全局拼接信息；离散图及路径代价不满足复仿射纤维接口，没有运行收益指标，不强行入应用卡。'),
('能源／潮流方程','far','参数化多项式可行集合或有特殊纤维和全局障碍；实可行域、Jacobian奇点和物理约束需另证，原稿光滑复例子不等于潮流求解改进。'),
('语言／组合语义','bold','加上下文变量后表示相同不保证原表示相同是信息丢失类比；无语言语义到复代数保持同构的映射，不作语言模型性能主张。'),
('艺术／参数化造型','bold','局部相同纤维而整体不可统一参数化可作为造型直觉；实际目标为实可渲染几何与连续参数，不由复代数非平凡直接给出新形状或压缩。')]
X=[{'family_id':'F-200','existing_method':'PART-200-FILTERED','assessment':'同为filtered→graded，F200的Hilbert／秩比较不提供F047实际R系数嵌入或LND保持性；组合前需共同环、过滤及核结构，不自动给识别算法。'}, {'family_id':'F-333','existing_method':'PART-333-POLYNOMIAL-LOCALIZATION','assessment':'F333连续局部多项式化／等距修正与F047代数全局平凡性属不同范畴；平滑或等距浸入不保持仿射代数同构，不能用局部图替代全局坐标。'}, {'family_id':'F-124','existing_method':'PART-124-FLATTEN','assessment':'辅助变量／展平后对象易表示的共同形式不等于允许删除变量；F124有限自动机与整数表示的状态语义不满足复有限型环同构。保留规格反例类比，无组合应用通过。'}]
(w/'qualification.json').write_text(json.dumps({'claims':C,'methods':M,'domains':D,'cross_family':X,'new_candidates':0,'reason_no_candidate':'No admitted concrete consumer/workload and executable falsifiable benefit beyond methodological regression boundaries. Exploration remains revisitable, not formally denied.'},ensure_ascii=False,indent=2)+'\n')
print(len(C),len(M),len(D),len(X))
