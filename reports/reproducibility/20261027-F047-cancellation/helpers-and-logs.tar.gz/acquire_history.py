from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json,concurrent.futures
w=Path(__file__).resolve().parent;d=w/'history';d.mkdir(exist_ok=True)
rows=[('DuttaLahiri2019v1','https://arxiv.org/html/1908.03549v1','html'),('Brion2015','https://www.ms.u-tokyo.ac.jp/journal/pdf/jms220104.pdf','pdf'),('Suslin1976','https://www.mathnet.ru/php/getFT.phtml?jrnid=dan&option_lang=eng&paperid=40545&what=fullt','pdf'),('BassConnellWright1976','https://www.ams.org/journals/bull/1976-82-05/S0002-9904-1976-14128-6/S0002-9904-1976-14128-6.pdf','pdf')]
def one(row):
 name,url,ext=row;out={'work':name,'url':url,'retrieved_at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave bounded original-scope inspection'}),timeout=40) as r:
   raw=r.read(2*1024*1024+1);assert len(raw)<=2*1024*1024
   out['content_type']=r.headers.get('Content-Type');out['final_url']=r.url
  if ext=='pdf':assert raw.startswith(b'%PDF'), 'Expected PDF body'
  p=d/(name+'.'+ext);p.write_bytes(raw);out.update(status='retrieved_not_yet_locally_read',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),temporary_path=str(p))
 except Exception as e:out.update(status='failed_preserved_no_content_credit',error=type(e).__name__+': '+str(e))
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:records=list(ex.map(one,rows))
assert sum(r.get('bytes',0) for r in records)<=8*1024*1024
(w/'history-acquisition.json').write_text(json.dumps({'selected_works':4,'budget_bytes':8*1024*1024,'files':records,'full_bodies_republished':False},ensure_ascii=False,indent=2)+'\n')
for r in records:print(json.dumps(r,ensure_ascii=False))
