from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).resolve().parent;base='9662113'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
on=old('data/graph/nodes.jsonl');oe=old('data/graph/edges.jsonl');n=(r/'data/graph/nodes.jsonl').read_bytes();e=(r/'data/graph/edges.jsonl').read_bytes();assert n.startswith(on) and e.startswith(oe) and len(n.splitlines())-len(on.splitlines())==60
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/')):assert (r/name).read_bytes()==old(name),name;preserved.append(name)
cov=json.loads((r/'data/graph/reading_coverage.json').read_text());prev=json.loads(old('data/graph/reading_coverage.json'));assert all(cov['partially_read_families'][k]==v for k,v in prev['partially_read_families'].items());assert cov['full_family_decompositions_complete']==prev['full_family_decompositions_complete']==[]
metrics=validate(r);generated=render(r);exported=export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==61 and generated['source_decomposition_drafts']==56
assert generated['candidate_connections']==46 and generated['externally_checked_cards']==13 and generated['effective_leads']==5 and generated['distinct_validation_hypotheses']==13
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-modular-consumers/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 rep=impact_report(nodes,edges,{v['seed']});k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in rep['affected'])==(k=='required_affected'),v;impacts.append(v)
def c(l):return 'CLM-047-'+l.upper().replace(':','-')
for a,b in [(c('deg:valuation'),c('thm:main')),(c('prop:linearization'),c('thm:main')),(c('prop:rigidity'),c('thm:main')),('LIT-047-DUTTALAHIRI',c('cor:stable-coordinate')),('LIT-047-BASSCONNELLWRIGHT',c('cor:affine-fibrations')),('LIT-047-SUSLIN',c('cor:affine-fibrations')),(c('prop:stabilization'),'PART-047-STABLE-CYLINDER')]:
 assert b in impact_report(nodes,edges,{a})['affected'],(a,b);impacts.append({'seed':a,'required_affected':b,'confirmed':True})
for a,b in [('LIT-047-DUTTALAHIRI',c('thm:main')),('LIT-047-BASSCONNELLWRIGHT',c('thm:main')),('LIT-047-GUPTAPOSITIVE',c('thm:main')),('LIT-047-BRION',c('thm:main')),('PART-200-FILTERED',c('prop:graded')),(c('cor:affine-fibrations'),c('thm:main')),(c('prop:rigidity'),'APP-020-01')]:
 assert b not in impact_report(nodes,edges,{a})['affected'],(a,b);impacts.append({'seed':a,'must_not_propagate_to':b,'confirmed':True,'scope':'Context and mapping references do not become mandatory proofs;fibration/stable-coordinate consequences are not prerequisites for cancellation main.'})
claims=[x for x in nodes.values() if x['kind']=='claim' and x['id'].startswith('CLM-047-')];assert len(claims)==17 and sum(x['properties']['source_claim_grade']=='B' for x in claims)==2;assert all(x['properties']['dependency_chain_grade']=='unknown' for x in claims)
f=json.loads((r/'data/provenance/readings/F-047-formal.json').read_text());assert not f['local_build'] and not f['comparator_run'] and not f['human_spec_review'];packed=(r/f['static_index']).read_bytes();assert hashlib.sha256(packed).hexdigest()==f['static_index_sha256'];idx=json.loads(gzip.decompress(packed));assert len(idx['local_files'])==55
for file in idx['local_files']:assert hashlib.sha256((r/file['path']).read_bytes()).hexdigest()==file['sha256']
for file in f['selected_files_actually_read']:assert hashlib.sha256((r/file['path']).read_bytes()).hexdigest()==file['sha256']
h=json.loads((r/'data/provenance/readings/F-047-history.json').read_text());assert len(h['verified_hashed_original_scopes'])==2 and len(h['selected_bodies'])==4;assert not h['full_historical_lineage_complete'];assert h['web_only_partial_original_scope']['Suslin']['original_body_sha256'] is None
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());folder=mp.parent
 for name,digest in m['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':folder.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==15 and members==267
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_records_byte_equal':len(on.splitlines()),'new_records':60,'old_explicit_edges_prefix_equal':True,'preserved_science_code_tests_corpus_and_family_report_files':len(preserved),'old_reading_coverage_members_equal':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'experiment_archives':archives,'source_archive_members':members,'new_named_claims':17,'new_methods':12,'new_literature':26,'source_B':2,'source_C':15,'static_index_files_hashed':55,'historical_hashed_original_scopes':2,'new_candidates':0,'application_checks_added':0,'scientific_runs_added':0,'limits':'Traceability/software/archive checks;not mathematical proof validation,human/provider review or efficacy. No scientific source change;archive hashes suffice without gratuitous numeric replay.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(w/'quality.json.gz').write_bytes(packed);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','experiment_archives','generated_metrics']},ensure_ascii=False))
