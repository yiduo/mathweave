from pathlib import Path
import urllib.request,json,hashlib
from datetime import datetime,timezone
w=Path(__file__).resolve().parent;p=w/'history-acquisition.json';x=json.loads(p.read_text());r=next(z for z in x['files'] if z['work']=='Suslin1976');previous=dict(r)
try:
 with urllib.request.urlopen(r['url'],timeout=50) as f:raw=f.read(2*1024*1024+1);assert raw.startswith(b'%PDF') and len(raw)<=2*1024*1024
 q=w/'history/Suslin1976.pdf';q.write_bytes(raw);r.update(status='retrieved_not_yet_locally_read',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),temporary_path=str(q),recovery_at=datetime.now(timezone.utc).isoformat())
except Exception as e:r['bounded_recovery_error']=type(e).__name__+': '+str(e)
r['prior_failure']=previous;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
