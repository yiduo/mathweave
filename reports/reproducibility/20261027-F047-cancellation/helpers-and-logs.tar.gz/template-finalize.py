from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,tarfile
root=Path.cwd();work=Path(__file__).resolve().parent;out=root/'reports/reproducibility/20261027-F020-powerfree';now=datetime.now(timezone.utc).isoformat()
def load(p):return json.loads((root/p).read_text())
def save(p,d):(root/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
clean=json.loads(gzip.decompress((work/'clean-check.json.gz').read_bytes()));assert clean['core_exit_code']==0 and clean['copy_hashes_verified'] and not (work/'clean').exists()
assert 'Ran 69 tests' in (work/'core.log').read_text() and '\nOK\n' in (work/'core.log').read_text()
q=json.loads(gzip.decompress((work/'quality.json.gz').read_bytes()));assert len(q['impact_cases'])==48
acq=json.loads((work/'history-acquisition.json').read_text());removed=[]
for r in acq['files']:
    p=Path(r['temporary_path']);assert p.is_relative_to(work/'history') and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
    removed.append({k:r[k] for k in ['work','url','bytes','sha256']})
for r in acq['files']:Path(r['temporary_path']).unlink()
assert not list((work/'history').iterdir());(work/'history').rmdir()
for r in removed:r['removed']=True
assert len(removed)==9 and sum(r['bytes'] for r in removed)==1993868
for name,target in [('quality.json.gz','quality.json.gz'),('clean-check.json.gz','clean-check.json.gz')]:
    raw=(work/name).read_bytes();gzip.decompress(raw);(out/target).write_bytes(raw)
save(str((out/'curation.json').relative_to(root)),json.loads((work/'curation-summary.json').read_text()))
replays={name:json.loads((work/name).read_text()) for name in ['replay-221.json','replay-325.json']}
for r in replays.values():assert all(r['deterministic_outputs_match'].values())
raw=json.dumps(replays,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(out/'representative-replays.json.gz').write_bytes(packed)
members=sorted(p for p in work.iterdir() if p.is_file())
assert not any(p.suffix in {'.html','.pdf','.tex','.lean'} for p in members)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for p in members:
        raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for p in members:assert t.extractfile(p.name).read()==p.read_bytes()
(out/'helpers-and-logs.tar.gz').write_bytes(packed)
storage={'at':now,'work_package':'WP-113','third_party_temporary_sources_hash_verified':removed,'third_party_body_bytes_removed':1993868,'third_party_bodies_republished':False,'own_helper_members_verified':len(members),'helper_compressed_sha256':hashlib.sha256(packed).hexdigest(),'helper_decompressed_sha256':hashlib.sha256(raw).hexdigest(),'helper_archive_bytes':len(packed),'clean_core_exit_code':0,'clean_directory_removed':True,'clean_files':clean['files'],'clean_bytes':clean['bytes'],'clean_copy_hashes_verified':True,'new_scientific_experiments':0,'actual_existing_representative_replays':2,'scope':'Own metadata,derivations,code,roles andlogs compressed withmember/decompressed hashes;upstream notduplicated,third-party fullHTML bodies removed after qualification. No new efficacy or formal/human review.','work_root_removed':False}
save(str((out/'storage.json').relative_to(root)),storage)
j=load('state/reading-progress/WP-113.json');old=(root/'state/reading-progress/WP-113.json').read_bytes();arch='state/reading-progress/history/WP113-before-canonical-close.json.gz';assert not (root/arch).exists();p=gzip.compress(old,mtime=0);assert gzip.decompress(p)==old;(root/arch).write_bytes(p)
j.update({'updated_at':now,'status':'current_source_draft_qualified_not_full_family','canonical_credit_added':True,'new_source_decomposition_credit':True,'full_current_source_read_complete':True,'qualification':{'generation':'GEN-20261027-110','named_bindings':26,'unlabelled_bindings':2,'method_contracts':24,'source_B':2,'source_C':26,'dependency_chain_grade':'unknown','historical_selected_works':4,'historical_complete':False,'new_candidate':'APP-020-01','new_application_checks':0,'scientific_runs':[],'quality_evidence':str(out.relative_to(root))},'prior_version_archive':arch,'next_action':'WP113 closed aftersource qualification/QA/storage andglobal040. ContinueWP114 boundedrealconsumer admission;do notrerun curator or221/325merelyforfingerprint.'});save('state/reading-progress/WP-113.json',j)
b=load('state/backlog.json');wp=next(t for t in b['tasks'] if t['id']=='WP-113');task=next(t for t in b['tasks'] if t['id']=='WP-114')
wp.update({'status':'completed','completed_at':now,'next_action':j['next_action'],'outputs':['data/provenance/readings/F-020.json','data/provenance/readings/F-020-formal.json','data/provenance/readings/F-020-history.json','reports/powerfree-F020-reading.md','reports/families/F-020.md','reports/cards/APP-020-01.md','reports/retrospectives/040-effective-interfaces-and-bounded-admission.md',str(out.relative_to(root))],'result':'Fullcurrent natural source15TeX3967+345Bib qualified;26named+2unlabelledbindings24contracts;2sourceB/26C/fullchainunknown. Fourselectedhistoricalworks only. 88newrecords305edges andone low-priority pendingconditionalAPP02001;no actualconsumer/check/experiment. 5076oldrecords/oldedges and246science/source/test/corpus/archive/familyfiles preserved. Fullobjects/48impact/15archives267members/69core/no-mathclean andexact221/325replayspassed. Global040 closescycle andselectsboundedWP114;noGitHubpush.'})
wp['qualification_progress']['clean_check']='passed';wp['qualification_progress']['storage']='compressed_roundtrip_verified'
b['updated_at']=now;save('state/backlog.json',b)
c=load('state/checkpoint.json');c.update({'saved_at':now,'overall_status':'active_incomplete','last_completed_work_package':'WP-113','latest_retrospective':'reports/retrospectives/040-effective-interfaces-and-bounded-admission.md','work_packages_since_last_retrospective':0,'retrospective_due_after':'AfterWP116,third substantivepackage since040,or earliermajorcounterevidence/dataissue.','active_work_package':task,'next_work_package':task,'last_quality_evidence':str((out/'quality.json.gz').relative_to(root)),'storage_receipt':str((out/'storage.json').relative_to(root))})
assert 'WP-113' not in c['completed_work_packages'];c['completed_work_packages'].append('WP-113')
c['recovery_commands']=['Readgoal/AGENTS/charter/roadmap/status/checkpoint/backlog/latestglobal040;verifydisk/processes andWP113storage beforecontinuing.','WP113 GEN11088newrecords305edges alreadyapplied;do notrerunone-shotcurator orredownload9HTML1993868bytes. Canonicalsource/currentdraft notfullfamily/history.','48impact/fullJSONGraphML/15archives267members/69core/no-mathclean passed;actualsupported221/adverse325fullpayloads matched. Do notrepeat merelyfornewfingerprint.',task['next_action'],'Publicd48dd19 andCI40300240089 remainverifiedWP112 plusolderWP113journal;currentGEN110/global040localonly,noautomaticGitHubpush.','WP114max3projects/12files/2MiB,exactsource/admission/costs first;no newmathproof orscientificoutput beforeindependent executablepreregistration.','If boundedmodularconsumerqualificationfindsnosame-Sfullkernelinterface,retainAPP02001 androtatealgebraic/complexgeometryF047/F053 basedactualsource;noforcedcandidate/check.']
c['recovery_observation']['WP113_close']={'at':now,'new_scientific_experiments':0,'actual_existing_representative_replays':2,'running_project_processes':[],'upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','upstream_clean':True,'clean_copy_removed':True,'next_work_package':'WP-114','body_credit_for_next':0,'all_local_quality_handles_terminal':True}
save('state/checkpoint.json',c)
pub=load('state/publication.json');pub['local_progress_after_verified_snapshot']='WP113 GEN11088newrecords305edges/28bindings24contracts/one pending APP02001 complete;fullgraph48impact/69core/no-mathclean/storage andglobal040closed. Verifiedpublicd48dd19 stillcoversWP112 andearlierunfinishedWP113;routinepushdisabled.';save('state/publication.json',pub)
line='WP113最终闭包（'+now+'）：69核心与无math干净副本均退出0；副本'+str(clean['files'])+'文件／'+str(clean['bytes'])+'字节逐项散列一致，副本删除。48正负传播、完整图对象、15归档267源码及5076旧规范行保持；实际221／325全raw/summary重放匹配。九第三方HTML1993868字节核散列后清理，自有'+str(len(members))+'成员压缩回解核验。WP113完成来源草稿，全族／历史／人审未完成；复盘040计数归零，下一WP114真实模算法有界准入，正文尚未读取。无GitHub推送，整体active_incomplete。'
for name in ['state/status.md','reports/retrospectives/040-effective-interfaces-and-bounded-admission.md']:
    with (root/name).open('a') as f:f.write('\n\n'+line+'\n')
assert str(work)=='/private/tmp/ai-paper-WP113';shutil.rmtree(work)
storage['work_root_removed']=True;storage['removed_at']=datetime.now(timezone.utc).isoformat();save(str((out/'storage.json').relative_to(root)),storage)
print(json.dumps({'WP113':'completed_current_source_draft','next':'WP-114','global_review':'040','canonical_records_added':88,'candidate_count':46,'initial_checks':13,'clean_files':clean['files'],'clean_bytes':clean['bytes'],'archived_helpers':len(members),'temporary_research_root_removed':True,'github_push':False}))
