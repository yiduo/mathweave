from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
batch=json.loads((work/sys.argv[1]).read_text());jp=root/'state/reading-progress/WP-115.json';j=json.loads(jp.read_text())
def merge(rs):
    out=[]
    for a,b in sorted(rs):
        if out and a<=out[-1][1]+1:out[-1][1]=max(out[-1][1],b)
        else:out.append([a,b])
    return out
for r in batch['reads']:
    f=next(f for f in j['source_files'] if f['path'].endswith('/'+r['file']))
    assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'];assert all(1<=a<=b<=f['lines'] for a,b in r['ranges'])
    f['actually_read_ranges']=merge(f.get('actually_read_ranges',[])+r['ranges']);f['actual_lines_read']=sum(b-a+1 for a,b in f['actually_read_ranges']);f['actually_body_read']=True;f['whole_file_actually_read']=f['actual_lines_read']==f['lines']
read=[f for f in j['source_files'] if f['path'].endswith('.tex') and f.get('actual_lines_read')]
j['actual_source_files_read']=read;j['actual_source_lines_read']=sum(f['actual_lines_read'] for f in read);j['actual_full_tex_files_read']=sum(f['whole_file_actually_read'] for f in read)
now=datetime.now(timezone.utc).isoformat();j['updated_at']=now;j['reading_batches'].append({'at':now,'input':sys.argv[1],**batch});j['provisional_reading_notes']+=batch['notes'];j['next_action']=batch['next_action'];j['full_current_source_read_complete']=j['actual_source_lines_read']==2281;jp.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
b=json.loads((root/'state/backlog.json').read_text());t=next(t for t in b['tasks'] if t['id']=='WP-115');t['next_action']=j['next_action'];t['execution_progress'].update({'files_fully_read':j['actual_full_tex_files_read'],'tex_lines_read':j['actual_source_lines_read'],'new_full_manuscripts':0,'canonical_credit_added':False});b['updated_at']=now;(root/'state/backlog.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
c=json.loads((root/'state/checkpoint.json').read_text());c['saved_at']=now;c['active_work_package']=t;c['next_work_package']=t;c['recovery_commands'][3]=j['next_action'];c['recovery_commands'][4]='F047actualTeXreading '+str(j['actual_source_lines_read'])+'/2281lines;sourcequalification/formal/history stillpending,nocanonicalcoveragecredit.';(root/'state/checkpoint.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
with (root/'state/status.md').open('a') as out:out.write('\n\nWP115阅读检查点（'+now+'）：累计'+str(j['actual_source_lines_read'])+'/2281TeX行，'+str(j['actual_full_tex_files_read'])+'个文件全文。'+batch['summary_zh']+' 未新增规范覆盖／候选／初检，未运行科学实验。下一：'+j['next_action']+'\n')
print(json.dumps({'actual_tex_lines':j['actual_source_lines_read'],'full_tex_files':j['actual_full_tex_files_read'],'canonical_credit_added':False}))
