from pathlib import Path
import json
w=Path(__file__).resolve().parent
S={
'thm:density':['固定四至八次多项式的(d−2)次幂自由值正密度','f为固定Z[x]、Q上不可约、4≤d≤8、k=d−2；每个素数rho_f(p^k)<p^k。无本原／首项符号要求；S=cX+o_f(X)，Euler乘积正且收敛。固定f常数，不给系数一致性、有限N0或密度全误差幂次。'],
'cor:all-degrees':['全部d≥4的(d−2)次幂自由值密度','固定不可约整数多项式，k=d−2且无固定素数k次幂因子。4..8用新尾界，≥9用旧Xiao/Browning范围k≥(3d+1)/4并转回原content因子。非全部次数的新独立证明。'],
'cor:separable-products':['可分多项式乘积与固定族同时幂自由值','k≥2，固定非零可分整数多项式，每不可约因子次数≤k+2。单个乘积的k自由与各F_i分别k自由不同；共享因子计一次，联合Omega_p是局部坏集合的并，不是个别Euler因子乘积。保留content／首项／判别式／结式坏素数；无移动族／重复不可分因子推论。'],
'prop:large-prime-tail':['本原正首项四至八次多项式的大素数尾幂次节省','固定本原Q不可约f、正首项、4≤d≤8、k=d−2；X<n≤2X，存在p>X且p^k|f(n)计数≪_f X^(1−delta_f)，delta_f>0。无需局部可容许；不提供统一f常数或实用阈值。'],
'prop:sieve-transfer':['由本原多项式尾o(X)转回原局部Euler密度','固定不可约deg≥2、k≥2、原f局部可容许；写f=s c g，本原正首项g的p>X尾o(X)是输入假设。有限CRT先固定Y，X趋∞后Y趋∞；O(product p^k)不支持任意增长Y。不能把此条件命题反向当作已证明尾界。'],
'lem:density-content':['保留原content局部指数的密度转移','固定f=s c g、deg≥2、k≥2及原f局部可容许。由本原g的密度推原f密度；p|c的e=v_p(c)<k时rho_f(p^k)=p^e rho_g(p^(k−e))，不得删除content后沿用未经修正因子。'],
'thm:affine-counting':['所有有界次数子簇均一Hilbert替代下的仿射点计数','固定N,r,e0,C、正权omega和delta_h；对每个固定次数上界、每个Q定义复不可约A meeting S，统一满足任意小幂异常点数或H_A(T)≥T^h/(h!delta_h^h)−C_eT^(h−1)。E_h=max_{s≥h}delta_s，|S|≪eps X^(sum E+eps)。无初始方程系数界，但均一替代前提不可省；不是S／全核／补丁的高效构造。'],
'lem:affine-patches':['固定有限S上的有界次数完整核补丁','固定加权多项式大小整数点盒S和有界次数Z。有限补丁(A,G,Delta)覆盖S∩Z，所覆盖z有非零整数Delta(z)，系数和值为X固定幂界。构造仅由Z和同一个S决定；使用完整有界次数求值核，不能单选多项式或额外依素数历史。'],
'lem:affine-residue-cut':['累计好素数乘积触发真余维切割','固定nu>0和补丁次数、h>0及该A的Hilbert下界。z处所有q不除Delta(z)，distinct q乘积≥X^(delta_h+nu)，充分大X时同余点位于不恒消于A的有界次数多项式；可额外加同余。是输入Hilbert的条件引理，不是仿射计数主结论的循环前提。'],
'lem:affine-deletion':['变长均匀素数块的删除与全路径坏素数比例','固定z、其他块和不交池[X^zeta,CX^zeta]，zeta固定、池大小趋∞；t在T0个连续固定正整数均匀，块是均匀t子集。全路径非零子式被选素数整除比例的期望≤B0/T0+o(1)。完整混合进制秩记录单调且相等蕴含全部核／补丁／子式相同；先固定删除路径，不在稳定事件下宣称独立。包括失败降维的固定深度路径；不是一般模p核稳定性或有限算法失败概率。'],
'lem:balanced-factorization':['数域理想与单位平衡表示及固定alpha重数','固定f及K，排除固定坏素数，充分大X、dyadic p~P；mu(n−theta)=alpha^k beta，有限理想类代表，|N alpha|=pN(c)，各嵌入alpha~P^(1/d)、beta/mu~X/P^(k/d)。每n选一表示；固定alpha及理想情况至多d个n。类群／单位计算及全部常数依f，不是免费算法或系数一致性。'],
'lem:paired-boxes':['正反局部解析图与有界配对网格','固定算术／坐标图、0<w<1、M~X^w可为合数，非零归一化共轭与分母；t依(s,z)局部解析，反向至多k^d局部分支，固定半径／任意固定阶导数均一。每盒O_f(1)配对，总O_f(M^(d−1))。无环域全局根分支保证。'],
'lem:bicone':['双锥素完全交与双齐次Hilbert主项','固定算术双锥的d−2个(k,1)方程为素完全交，双射影维数d；A,B沿固定正有理比趋∞，R(A,B)以源公式给出，误差O(A^(d−1))。整闭／Cohen–Macaulay／无嵌入分量／边界维数须实际核对，不由generic reduced单独推出素性。'],
'prop:archimedean-cuts':['双向解析行列式给混合截面或低维余项','配对盒、正上指数eta+,b+、宽X^-w、z=O(X^-1)、统一导数及两条严格cut不等式。输出有限有界次数混合饱和截面(lambda,s0≥1)或双射影dim≤d−2，仿射维数分别d或≤d−1；纯单坐标分量需第二次切割。移动关系用原单项式秩比较，不能除可能趋零关系系数。'],
'lem:lattice-basis':['乘积范数受共体积控制的格基','固定维数满格Delta及最短非零长度lambda1；存在基使prod||b_i||≤C_d Delta，||v||≤C时整数基坐标≤CC_d/lambda1。存在性界不计实际寻找基的成本。'],
'prop:lattice-boxes':['双格共同超额与盒数—坐标权重分组','现在M必须取素数~X^w，m=(d−1)w<min(eta+,b+)，固定tau及源格参数；j为tau网格且j≤m/d，盒数O(X^(m−dj))，U=u+j+tau,V=v+j+tau，整单模变换及逆系数X固定幂界。两格使用同一个超额j；解析配对引理的无素性条件不能迁移此处。'],
'lem:quartic-fibers':['先删无限n纤维以保证后续子簇代数性','d=4、a_i非零、初始cut集dim≤3或不可约F(a,n)对n正次数。无限n纤维基闭包dim≤2、有界次数，按固定a重数成本O_f(X^(2U))删去后，每个遇剩余S的不可约子簇n在a域上代数。不是任意四维多项式系统的纤维保证。'],
'prop:weighted-hilbert':['选定共轭坐标对的加权完全交Hilbert系数','2≤h≤d不可约Y、a_i≠0开集、n非常数、固定正有理U,V；选h−1个在C(n)上独立a和另一索引，F1不可约。除去局部共因子后D>0，H_pair=(kU+V)^(h−1)D/(U^h V^h)·T^h/h!+O(T^(h−1)+1)≤H_Y；域扩张次数≥2可倍增。须核仿射边界、加权无穷远及根单位极点误差；不只看generic图。'],
'prop:quartic-surface':['Q定义四次数面在共轭约束下的Hilbert下界','d=4、Q定义几何不可约面、a_i≠0、n非常数且在a域上代数；D0=min(3U,2V,U+V)。H≥T²/2·min((2U+V)D0/(U²V²),3/U²)−O(T)，固定权和次数下随坐标／系数均一。平面排除依有理迹超平面、Galois传递与所有共轭非零；不覆盖任意复面。'],
'prop:quintic-discard':['固定分裂域内临界值五次族的全局删除','固定f分裂域L，四个不同临界点0,1,z3,z4及指定不同临界值theta_i；归一化五次多项式族有限，所有L输入整数值的一个全局集合在[-2X,2X]计数O_f(X^(1/5))。有理值轨迹dim1、固定分数格 essential；异常集只删一次，不按每盒／曲线重复计成本。'],
'lem:rational-values':['有界整数输入及输出下非多项式有理函数稀少值','固定正D,A,B,C0，R∈Q(s)非多项式、约分后分子分母次数≤D；输入整数|s|≤C0X^A，输出整数|R(s)|≤C0X^B，排除极点，数量≪eps X^eps且常数独立系数。插值与结式除数法都用双重高度限制；不是任意有理输入或无界输出。'],
'prop:curve-alternatives':['固定算术曲线的稀少点或Hilbert斜率替代','Q定义几何不可约有界次数曲线，a_i^k b_i=n−theta_i及选定S，固定正权紧集。g=(d−1)(k−1)+1_{d=4}，delta1=max(U/2,min(U,V/g))；或X^eps稀少点，或H≥T/delta1−O(1)。用全局五次异常先删、非线性像／域次数增益；不能忽略Q结构、固定n／x重数或五次等号。'],
'prop:parameter-certificate':['严格有理参数网格与共同平移界的来源证书','d=4..8,K=3000,G=100000,t网格i/50(i=1..499),tau=1/50000；根上取严格上网格，连恰为根时也前进一格。source stopping5124/4084/3552/3226/3003，两cut严格不等式、3/20≤v/u≤5、m+sumE<999/1000及Q模式m+2u<999/1000。共同平移delta_h(U+s,V+s)≤delta_h(U,V)+s分支分别核；max不自动凹。本地仅阅读，未执行源计算证书，表值不是本地观察。'],
'cor:cyclotomic-density':['n四次方加一的平方自由密度及充分大区间下界','c8=prod_{p≡1mod8}(1−4/p²)>3/4，count=c8X+o(X)，充分大实N时[N,2N]至少N/2。局部因子依该特定多项式；未给有效N0，不是所有N的生成保证。'],
'prop:cyclotomic-central':['特殊四次式中心素数带尾节省','epsilon0=10^-6，p∈[N^(1−epsilon0),N^(3/2+epsilon0)]且p²|n^4+1的n∈[N,2N]计数O(N^(1−delta0))。扩展首Q格还需p²>N及排除固定坏素数的算术论证；不从代码参数表单独推出。'],
'lem:cyclotomic-pell':['固定乘法间距给D一致的Pell上素数尾','正整数D一致，n^4+1=Dq²、n∈[N,2N]正整数解O(1+logN)；用norm−1单位解间比≥2+sqrt3。固定epsilon>0时p>N^(3/2+epsilon)的输入O(N^(1−2epsilon)(1+logN))。只限该Pell结构及正整数，不泛化全部四次式。']}
assert len(S)==26
M=[
['CONTENT-LOCAL','lem:density-content','原f=s c g及各p的v_p(c)','保留原f局部密度','固定多项式、e<k、局部可容许','不可使用未经修正的g因子'],
['FIXED-CUTOFF-CRT','prop:sieve-transfer','有限素数截断与独立大素数尾输入','固定Y的CRT密度后取双极限','先X→∞后Y→∞，尾o(X)','不给增长Y或有效N0'],
['JOINT-LOCAL-UNION','cor:separable-products','固定可分多项式族与共享因子','Omega_p并集Euler密度','各因子degree≤k+2，所有局部非满','各多项式分别k自由不等于乘积k自由'],
['UNIFORM-PATCH-KERNEL','lem:affine-patches','同一个有限整数点集S及当前代数集','确定性有界高度补丁和非零子式','完整有界次数Q求值核，依当前对象和S','一个选定多项式／Fp核或历史依赖补丁不等价'],
['RANK-STABILITY-DELETE','lem:affine-deletion','完整嵌套核路径及全部混合进制余维记录','删除一素数时稳定状态与坏事件分解','记录相等推出所有后继核／补丁／子式同一','秩一个数相同不够；不在稳定事件条件化后声称独立'],
['VARIABLE-BLOCK-SAMPLING','lem:affine-deletion','固定其他块、均匀连续长度再均匀子集','期望坏比例≤B0/T0+o(1)','池趋∞且各固定参数先于X，所有固定深度路径','不是整算法失败概率或有限可用风险证书'],
['CUMULATIVE-PRIME-TREE','lem:affine-residue-cut','每层好素数及先前累计同余','乘积跨过阈值给真切割','本层Hilbert下界、非零子式、固定正裕量','不只累计本层，也不省失败分支'],
['BALANCED-IDEAL-FACTOR','lem:balanced-factorization','数域因子及有限理想／单位代表','各嵌入平衡并固定alpha输入重数','固定f、排除固定坏素数、每n选一表示','不忽略类群和单位基构造成本'],
['PAIRED-LOCAL-CHARTS','lem:paired-boxes','共轭归一化坐标、非零分母','正反局部解析图与O(M^(d−1))盒','w<1、统一解析半径和各固定阶导数','不要求此M素数但后续格步骤另要求'],
['MIXED-PURE-SECOND-CUT','prop:archimedean-cuts','双向小盒与两条严格行列式不等式','混合截面或低维集合','纯方向分量必须二次切割、饱和、lambda,s0≥1','不能把纯坐标关系当作已合格混合切割'],
['RELATION-RANK-NO-DIVISION','prop:archimedean-cuts','移动关系与原单项式列空间','系数一致的评价秩上界','沿原单项式比较、参数固定','不能除趋零关系系数或假定重基系数有界'],
['COMMON-LATTICE-EXCESS','prop:lattice-boxes','素数近似格与两块短向量','同一j下盒数X^(m−dj)、权U,V共同增加','m<min(eta+,b+)、j≤m/d、整单模基','两格不能各自挑不同有利超额；寻找基成本另计'],
['EXCEPTIONAL-FIBER-DELETE','lem:quartic-fibers','四次cut集及无限n纤维基','先付X^(2U)删除后所有子簇n代数','Q算术输入及固定a重数','不能把只在母簇generic代数代替每个子簇条件'],
['WEIGHTED-INFINITY-AUDIT','prop:weighted-hilbert','选定坐标对的不可约方程及正权','显式Hilbert主项且误差降一阶','除共同因子、查加权无穷远及非平凡根单位极点','generic完全交或仿射边界检查单独不够'],
['FIELD-DEGREE-GAIN','prop:weighted-hilbert','同维pair像与域次数≥2','两个独立有界权函数族使主项加倍','固定权和有界几何次数、域独立性','不是数值秩或任意采样协方差改进'],
['QUARTIC-CONJUGATE-SURFACE','prop:quartic-surface','Q定义几何不可约面与全共轭','面Hilbert下界的三个候选权','n非常数且对a域代数、Galois/迹结构','不能直接用于任意复面或只检查一个嵌入'],
['GLOBAL-QUINTIC-DISCARD','prop:quintic-discard','固定分裂域及四指定不同临界值','一个全局O_f(X^(1/5))异常集合','归一化有限五次族、整数输出、有理值轨迹dim1','每曲线重复删除会错误累计成本'],
['INTERPOLATE-RESULTANT','lem:rational-values','有界次数非多项式Q有理函数及双整数高度','系数一致的稀少值计数','足够插值点恢复高度、非零结式除数界','无输出高度限制或任意有理输入不覆盖'],
['EXACT-PARAM-UPPER-GRID','prop:parameter-certificate','有理格、源多项式及严格裕量','可逐项复核的有限参数覆盖声明','向上根网格、固定分支和Q模式边界；本地未运行','看过代码不等于执行证书，表值非新实验数据'],
['SHIFT-CUMULATIVE-COST','prop:parameter-certificate','权比例受限的各Hilbert替代分支','共同平移delta界与累计E最大值','逐分支导数检查，再合并固定有限格','max不自动凹；不能选独立最优分支后漏累计成本'],
['CYCLOTOMIC-LEVEL-SAVE','unlabelled:level-saving','特定方向簇的体积下界及真实S=−1代表','嵌套列空间平均指数节省与真cut阈值','v0>0、正有理ray、固定mesh/T；局部光滑好素数','仅projective零 locus没有level信息；此附加方法非主密度必要依赖'],
['UNIFORM-PELL-UPPER','lem:cyclotomic-pell','n^4+1=Dq²正解及norm−1结构','D一致对数解数与上素数尾','固定乘法间距、D正整数、固定epsilon','不能用于没有相同单位结构的任意四次式'],
['COMMON-ANALYTIC-GERM','unlabelled:analytic-relation','同一复多圆盘上统一有界连续Taylor族','评价矩阵近似秩、奇异值与行列式界','非零拉回极限germ、同一矩阵固定同一lambda；固定Z/矩阵先于N','不是精确秩；原section归一化不保证拉回germ非零'],
['GRID-INCIDENCE-MULTIPLICITY','prop:lattice-boxes','M>T≥1整数网格与非零原坐标见证v','固定v至多O_C((T/||v||∞)^3)盒','|v0|≤T、|Mvi−ci v0|≤T及|ci|≤CM','原坐标v不同于格余量向量；来源附录盒计数不是新应用']]
D=[
['计算代数','far','完整核删除方法或可审计自适应选素数；保留唯一APP02001，但尚无满足契约的软件消费者。',True],
['生物序列设计','far','若设计约束可精确编码为固定整数多项式可研究幂自由过滤；真实质量目标、局部条件和有限误差均未建立。',False],
['交通排程','far','模冲突可形式类比局部并集合，但排程约束非k次幂整除；CRT计数不提供可行路径或调度效用。',False],
['能源材料','far','寻找可由固定算术参数族定义的公开组合样本；物性目标不由幂自由密度控制，尚无同输出映射。',False],
['语言生成','bold','层级状态稳定与删除观测的类比保留；token候选集没有完整Q评价核和非零整数子式契约。',False],
['艺术生成','bold','稀少异常集可作参数图案想法；视觉质量与正密度不是同一判据，无具体外部裁判。',False],
['机器人感知','far','解析约束的近似秩或可描述局部退化；噪声数据未给共同复邻域、同一lambda与非零germ，不承诺数值压缩。',False],
['金融模拟','far','坏事件并集与固定条件后删除可作审计提示；交易过程不具源整数点和局部整除结构，不导出风险保证。',False],
['机器学习特征','far','共同解析关系可能压缩局部特征评价矩阵；未经有效常数和非零germ准入，不替代SVD低秩基线。',False],
['科学算例构造','near','固定多项式k自由值可标注渐近密度；未给有限生成成本／新强基线优势，已知计数展示不算应用初检。',False]]
C=[
{'family_ids':['F-020','F-025'],'existing_method':'PART-025-EXPOSED-PRODUCT','assessment':'独立样本暴露下的复合模数和F020删除路径有解耦结构类比；F025特定分母供给不是可直接嵌套Q核，联合构造与成本待定，不新建第二卡。'},
{'family_ids':['F-020','F-238'],'existing_method':'PART-238-COMP-FULL-PATH-CYLINDER','assessment':'完整固定路径与先固定环境的条件法能辅助审计；F238开关圆柱分布不等于素数子集删除分布，不把边际均匀代替完整路径法。'},
{'family_ids':['F-020','F-174'],'existing_method':'PART-174-RATIONAL-PSD-OUTERS','assessment':'精确有理证书提醒区分存在与实际输出；PSD外积证书未提供F020全核／补丁构造，数值分解不能替代算术准入。'}]
(w/'qualification.json').write_text(json.dumps({'claims':S,'methods':M,'domains':D,'cross_family':C},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'claims':len(S),'methods':len(M),'domains':len(D),'cross_family':len(C)}))
