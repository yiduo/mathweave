from pathlib import Path
from datetime import datetime,timezone
import ast,copy,gzip,hashlib,io,json,tarfile,subprocess
r=Path.cwd();w=Path('/private/tmp/ai-paper-WP125');now=datetime.now(timezone.utc).isoformat();out=r/'reports/reproducibility/20261027-F059-source-scope';out.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=w/'curate.py';old=p.read_text();needle="p=f['path'];t=(r/p).read_text();directory=Path(p).parent";replacement="p=f['path'];t=(r/p).read_text();directory=Path(next(m['directory'] for m in manuscripts.values() if m['manuscript_id']==owners[p]))/'build'"
assert old.count(needle)==1
(w/'curate-attempt1.py').write_text(old);p.write_text(old.replace(needle,replacement));ast.parse(p.read_text())
# Check actual input closure with TeX's document build directory; no code or numerical execution.
j=json.loads((r/'state/reading-progress/WP-125.json').read_text());paths={f['path'] for m in j['manuscripts'] for f in m['source_files']}|{f['path'] for f in j['additional_static_code_read']};links=[]
import re
for m in j['manuscripts']:
 for f in m['source_files']:
  t=(r/f['path']).read_text()
  for v in re.finditer(r'\\(input|include|lstinputlisting|bibliography)\s*\{([^}]+)\}',t):
   name=v[2];suffix='.bib' if v[1]=='bibliography' else '.tex';target=(r/m['directory']/'build'/(name if Path(name).suffix else name+suffix)).resolve();rel=str(target.relative_to(r));assert rel in paths,rel;links.append({'source':f['path'],'target':rel,'kind':v[1]})
h=json.loads((r/'data/provenance/readings/F-059-history.json').read_text());removed=[]
for row in h['rows']:
 for ext,k,n in [('pdf','sha256','bytes'),('txt','text_sha256','text_bytes')]:
  p=w/(row['key']+'.'+ext);b=p.read_bytes();assert sha(b)==row[k] and len(b)==row[n];removed.append({'name':p.name,'bytes':len(b),'sha256':sha(b)});p.unlink()
archive=out/'partial-helpers-and-failure-logs.tar.gz';members={p.name:p.read_bytes() for p in w.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'}}
with tarfile.open(archive,'w:gz') as tf:
 for name,b in sorted(members.items()):
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mtime=0;tf.addfile(ti,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 assert {m.name for m in tf.getmembers()}==set(members)
 for m in tf.getmembers():assert sha(tf.extractfile(m).read())==sha(members[m.name])
receipt={'at':now,'work_package':'WP-125','status':'partial_not_canonically_admitted','source_TeX_Bib_lines_read':5601,'additional_code_lines_statically_read':288,'selected_Lean_module_lines_read':400,'source_result_draft_count':51,'method_contract_draft_count':27,'selected_original_works':5,'full_historical_lineage':False,'canonical_credit_added':False,'scientific_experiments_executed':0,'terminal_handle':65337,'terminal_handle_exit':1,'failure':'Include resolution incorrectly used containing section directory; actual TeX resolves paths from document build directory. Assertion stopped before canonical writes.','repair':'Curator now resolves include/listing paths from each manuscript build directory; syntax and all actual include targets checked; curation has not been rerun.','include_links_verified':links,'helper_archive':str(archive.relative_to(r)),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_roundtrip_all_members_verified':True,'members':[{'name':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())],'third_party_raw_and_text_hash_verified_then_removed':removed,'removed_bytes':sum(x['bytes'] for x in removed),'temporary_helpers_retained':str(w),'remaining_work':['Rerun repaired curation once; retain failure evidence','Full graph/source/FK/impact/export/core/clean/archive checks','Compression/storage closure and WP125 completion','Mandatory global retrospective044'],'no_github_push':True}
save(out/'partial-checkpoint.json',receipt)
next_action='Run repaired /private/tmp/ai-paper-WP125/curate.py once with pinned Python3.12; all 5601 TeX/Bib+288 code lines already read, 400-line selected Lean source and five original selected scopes qualified. Then full canonical graph/source/impact/export/core/clean/archive/storage closure and mandatory global044. Do not run arithmetic verification programs without separate frozen specification.'
j.update(updated_at=now,status='all_current_source_and_selected_formal_history_read_curation_repair_checked_pending_canonical_admission',next_action=next_action,partial_evidence_receipt=str((out/'partial-checkpoint.json').relative_to(r)))
save(r/'state/reading-progress/WP-125.json',j)
c=json.loads((r/'state/checkpoint.json').read_text());b=json.loads((r/'state/backlog.json').read_text());a=copy.deepcopy(c['active_work_package']);a.update(actual_source_lines_read=5601,additional_static_code_lines=288,execution_state='all_5601_TeX_Bib_plus288_static_code_read_selected_formal_history_qualified_canonical_curation_pending',next_action=next_action,partial_evidence_receipt=str((out/'partial-checkpoint.json').relative_to(r)))
c.update(saved_at=now,updated_at=now,active_work_package=a,next_work_package=copy.deepcopy(a),running_research_experiments=[],previous_goal_turn_classification=c.get('current_goal_turn_classification'),current_goal_turn_classification='status_request_with_recovery_repair: verified actual reading/formal/history artifacts, preserved failed curation and repaired include resolver, no canonical admission or new scientific experiment.')
c['resume_commands']=['Read goal/AGENTS/charter/roadmap/status/checkpoint/backlog/global043; inspect disk and known handles before research.',next_action,'If temporary helpers are missing, recover partial-helpers-and-failure-logs.tar.gz from reports/reproducibility/20261027-F059-source-scope; verify member hashes in partial-checkpoint.json before use. No third-party PDF/text bodies retained; do not redownload merely to count reading.','Canonical metrics remain 63 reading families/58 current-source drafts; do not promote pending F059. Global044 mandatory after WP125 closure. Human/second-provider review deferred; math read-only; no routine GitHub push.']
c.setdefault('recovery_observation',{})['WP125_status_checkpoint']={'at':now,'known_curation_handle_terminal':True,'curation_handle':65337,'experiment_handles':[],'process_census_scope':'Known tool handles only; no claim of system-wide process inventory','available_disk_observed':'30GiB','canonical_graph_unchanged':True,'partial_receipt':str((out/'partial-checkpoint.json').relative_to(r))}
for i,t in enumerate(b['tasks']):
 if t.get('id')=='WP-125':b['tasks'][i]=copy.deepcopy(a)
b['updated_at']=now;save(r/'state/checkpoint.json',c);save(r/'state/backlog.json',b)
with (r/'state/status.md').open('a') as f:f.write('\n\nWP125进度检查点（'+now+'）：两当前稿24TeX/Bib5601行及288行附带代码已实际读完，另核400行选定Lean源文与五部历史原作的选定转换文字范围；51命题绑定／27方法合同仍为待入图草稿，不增63阅读／58草稿或47候选／14初检。入图首次因TeX包含路径按章节目录解析而提前停止，规范图未改；已按文档build目录修复并核全部包含目标，尚未重跑入图或最终回归。原失败日志与自有辅助压缩回解逐成员核验，第三方PDF及转换文字'+str(receipt['removed_bytes'])+'字节核散列后清理。无新数值实验、无GitHub推送；下一入图与完整质量闭包，随后强制全局044。证据：`reports/reproducibility/20261027-F059-source-scope/partial-checkpoint.json`。\n')
print(json.dumps({'status':'saved_partial','include_links_verified':len(links),'helper_members':len(members),'archive_bytes':archive.stat().st_size,'third_party_bytes_removed':receipt['removed_bytes'],'canonical_credit_added':False},ensure_ascii=False))
