from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;s=json.loads((w/'curation-summary.json').read_text());base=s['base_commit']
def old(p):return subprocess.check_output(['git','show',base+':'+p])
oldrows={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};newrows={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)}
assert len(oldrows)==5484 and len(newrows)==5620 and len(s['new_record_ids'])==136
for id,raw in oldrows.items():assert newrows[id]==raw,id
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
oldcov=json.loads(old('data/graph/reading_coverage.json'));cov=json.loads((r/'data/graph/reading_coverage.json').read_text());assert gzip.decompress((r/'data/graph/history/GEN-20261027-122-reading-coverage-before.json.gz').read_bytes())==old('data/graph/reading_coverage.json')
assert set(cov['partially_read_families'])==set(oldcov['partially_read_families'])|{'F-059'}
assert set(cov['source_decomposition_drafts'])==set(oldcov['source_decomposition_drafts'])|{'F-059'}
for f in oldcov['partially_read_families']:assert cov['partially_read_families'][f]==oldcov['partially_read_families'][f]
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==64 and generated['source_decomposition_drafts']==59 and generated['candidate_connections']==47
assert generated['externally_checked_cards']==14 and generated['distinct_validation_hypotheses']==14 and generated['effective_leads']==6 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')):
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
a=nodes['ANALYSIS-F-059']['properties'];assert len(a['result_ids_by_label'])==51 and len(a['method_ids'])==27 and len(a['source_sections'])==26 and a['source_line_count']==5889
assert a['source_decomposition_draft_complete'] and len(a['manuscript_source_drafts_complete_ids'])==2 and not a['full_family_complete'] and not a['historical_lineage_complete']
assert sum(nodes[id]['properties']['source_claim_grade']=='B' for id in a['result_ids_by_label'].values())==1
assert all(nodes[id]['properties']['source_claim_grade']=='C' for id in a['main_claim_ids'])
assert all(nodes[id]['properties']['dependency_chain_grade']=='unknown' for id in a['result_ids_by_label'].values())
assert sum(nodes[id]['properties'].get('source_bound_classical_input',False) for id in a['result_ids_by_label'].values())==8
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F238-analytic/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 key='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[key] in impact_report(nodes,edges,{v['seed']})['affected'])==(key=='required_affected');impacts.append(v)
L=a['result_ids_by_label'];hi=L['high:thm:main'];fo=L['four:thm:main']
newcases=[(hi,fo,False),(fo,hi,False),(L['high:seed:product'],hi,True),(L['high:seed:chain'],hi,True),(L['four:lem:bock'],fo,True),(L['four:lem:cover-adjunction'],fo,True),(L['four:lem:plane-data'],fo,True),('LIT-059-KATO1974',fo,True),('LIT-059-KATO1974',hi,False),('LIT-059-LEVINE1970',hi,True),('LIT-059-LEVINE1970',fo,False),('PROB-059-FULL-TOPOLOGY',hi,False),('EXPLORE-F-059',fo,False)]
for seed,target,positive in newcases:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive,(seed,target)
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'F059 independent high-dimensional and C4 constructions; selected arithmetic and historical proof interfaces, no exploration/problem-to-proof propagation'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==17 and members==337
ledger=json.loads((r/'data/provenance/readings/F-059.json').read_text());assert len(ledger['results'])==51 and len(ledger['method_contracts'])==27 and len(ledger['include_links_checked'])==23 and ledger['external_root_work_count']==53
for f in ledger['read_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
for v in ledger['include_links_checked']:assert v['target'] in {f['path'] for f in ledger['read_files']}
formal=json.loads((r/ledger['formal_evidence']).read_text());indexfiles=set()
for f in formal['selected_actual_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
index=formal['static_index'];z=(r/index['path']).read_bytes();assert hashlib.sha256(z).hexdigest()==index['sha256'];idx=json.loads(gzip.decompress(z))
for f in idx['local_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256'];indexfiles.add(f['path'])
assert len(indexfiles)==1 and index['declarations']==30 and index['lexical_placeholders']==0 and index['lexical_axioms']==0 and formal['local_build']=='not_run'
history=json.loads((r/ledger['historical_evidence']).read_text());assert history['newly_checked_original_works']==5 and all(x['actual_selected_text_ranges_read'] for x in history['rows']) and not history['complete_original_lineage']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':5484,'versioned_old_records':0,'new_records':136,'new_edges':617,'protected_files':len(preserved),'canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'selected_index_files_hash_checked':len(indexfiles),'new_primary_selected_scopes':5,'TeX_Bib_source_files':24,'TeX_Bib_lines':5601,'included_or_supplemental_code_files':2,'included_or_supplemental_code_lines':288,'source_bindings':51,'source_B':1,'source_C':50,'classical_input_bindings_not_project_discoveries':8,'method_contracts':27,'include_links_checked':23,'external_original_roots':53,'full_family_or_history':False,'new_scientific_runs':0,'new_initial_checks':0,'new_candidates':0,'scope':'Current two-source qualification; selected chain Lean statement only, no build/main proof or full historical/human/provider acceptance. No supplied verification program executed.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics']},ensure_ascii=False))
