from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;s=json.loads((w/'curation-summary.json').read_text());base=s['base_commit']
def old(p):return subprocess.check_output(['git','show',base+':'+p])
oldrows={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};newrows={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)};changed=set(s['modified_old_record_ids']);assert len(oldrows)==5457 and len(newrows)==5484 and changed=={'ANALYSIS-F-238','LIT-058-DEMAILLY2012'}
for id,raw in oldrows.items():
 if id not in changed:assert newrows[id]==raw,id
archive=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-121-before.json.gz').read_bytes()));assert {x['id']:x for x in archive['records']}=={id:json.loads(oldrows[id]) for id in changed}
for id in changed:
 n=json.loads(newrows[id]);assert n['version']==json.loads(oldrows[id])['version']+(2 if id=='ANALYSIS-F-238' else 1) and n['updated_by_generation_id']=='GEN-20261027-121'
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
oldcov=json.loads(old('data/graph/reading_coverage.json'));cov=json.loads((r/'data/graph/reading_coverage.json').read_text());assert oldcov['source_decomposition_drafts']==cov['source_decomposition_drafts'];assert set(cov['partially_read_families'])==set(oldcov['partially_read_families'])
for f in oldcov['partially_read_families']:
 if f!='F-238':assert oldcov['partially_read_families'][f]==cov['partially_read_families'][f]
 else:assert cov['partially_read_families'][f][:len(oldcov['partially_read_families'][f])]==oldcov['partially_read_families'][f]
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')) and name not in ['reports/families/F-238.md','reports/families/F-058.md']:
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==63 and generated['source_decomposition_drafts']==58 and generated['candidate_connections']==47
assert generated['externally_checked_cards']==14 and generated['distinct_validation_hypotheses']==14 and generated['effective_leads']==6 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
a=nodes['ANALYSIS-F-238']['properties'];oa=json.loads(oldrows['ANALYSIS-F-238'])['properties'];assert len(a['result_ids_by_label'])==233 and len(a['source_sections'])==73 and a['source_line_count']==20259 and len(a['manuscript_source_drafts_complete_ids'])==7
assert not a['source_decomposition_draft_complete'] and not a['full_family_complete'] and not a['historical_lineage_complete']
for k in ['result_ids_by_label','result_ids_by_source','historical_references_by_key','manuscript_reading_ledgers']:
 for key,value in oa[k].items():assert a[k][key]==value
for id in ['APP-238-01','APP-238-02','APP-124-01','APP-337-01']:assert nodes[id]==json.loads(oldrows[id])
assert nodes['LIT-058-DEMAILLY2012']['properties']['prior_F058_citation_scope_still_unverified']
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F124-generator-admission/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 key='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[key] in impact_report(nodes,edges,{v['seed']})['affected'])==(key=='required_affected');impacts.append(v)
newcases=[('CLM-238-ANALYTIC-THM-CONDITIONAL','CLM-238-ANALYTIC-THM-BINARY',True),('CLM-238-ANALYTIC-THM-BINARY','CLM-238-ANALYTIC-THM-CONDITIONAL',False),('CLM-238-ANALYTIC-LEM-DENSITY','CLM-238-ANALYTIC-THM-CONDITIONAL',True),('PROB-238-ANALYTIC-CONDITIONAL-Z1','CLM-238-ANALYTIC-THM-BINARY',False),('CLM-238-ANALYTIC-PROP-SUPPORT','CLM-238-ANALYTIC-THM-BINARY',False),('LIT-238-ANALYTIC-CHRISTANDL-KONIG-RENNER-2009','CLM-238-ANALYTIC-LEM-DENSITY',False),('LIT-058-DEMAILLY2012','PART-238-ANALYTIC-SLIT-TRANSFER',True),('AUDIT-238-ANALYTIC-SCOPE','CLM-238-ANALYTIC-THM-BINARY',False)]
for seed,target,positive in newcases:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive,(seed,target)
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'ConditionalnearuniformproofversusHemptyanalyticroute,physicalsupportandhistoricalanalogykeptdistinct;noaudit-to-proofpropagation'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==17 and members==337
ledger=json.loads((r/'data/provenance/readings/F-238-analytic.json').read_text());assert len(ledger['results'])==6 and len(ledger['method_contracts'])==14 and ledger['aliases_not_extra_results']=={'ac:main':'thm:conditional'}
for f in ledger['read_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
formal=json.loads((r/ledger['formal_evidence']).read_text());indexfiles=set()
for f in formal['actual_selected_ranges']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
for index in formal['indices']:
 b=(r/index['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==index['sha256'];d=json.loads(gzip.decompress(b))
 for f in d['local_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256'];indexfiles.add(f['path'])
assert formal['index_intersection_files']==0 and formal['index_union_files']==226
history=json.loads((r/ledger['historical_evidence']).read_text());assert history['newly_checked_original_works']==4 and all(x['actual_selected_text_ranges_read'] for x in history['rows']) and not history['complete_original_lineage']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':5455,'versioned_old_records':2,'new_records':27,'new_edges':81,'prior_versions_archived_exactly':True,'old_family_binding_and_source_maps_preserved':True,'global_family_coverage_counts_unchanged':True,'protected_files':len(preserved),'canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'selected_index_distinct_files_hash_checked':len(indexfiles),'draft_correction_archive':'data/graph/history/GEN-20261027-121-draft-correction-before.json.gz','local_index_intersection':0,'new_primary_selected_scopes':4,'source_files':10,'source_lines':1791,'new_source_bindings':6,'new_source_B':2,'new_source_C':4,'new_method_contracts':14,'family_manuscript_drafts':'7/12','source_named_bindings':233,'original_APP238_cards_exactly_unchanged':True,'new_scientific_runs':0,'new_initial_checks':0,'new_candidates':0,'scope':'Current sourcequalificationonly;fullfamily/history/human/secondprovider/proof/buildremainincomplete. Scientificcodeunchanged;no expensive replay repeated afterglobal043.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics']},ensure_ascii=False))
