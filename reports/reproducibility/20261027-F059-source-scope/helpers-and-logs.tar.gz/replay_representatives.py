from pathlib import Path
import subprocess,sys,json
w=Path(__file__).parent
for run in ['EXP-238-001-a1d52c04aeb9b1ba','EXP-076-002-1f8537b7fd40d564']:
 with (w/(run+'-replay.log')).open('wb') as f:p=subprocess.run([sys.executable,'scripts/replay_run.py','experiments/runs/'+run,'--receipt',str(w/(run+'-replay.json'))],stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(p.returncode)
 print(json.dumps({'run':run,'replay_exit':0}),flush=True)
