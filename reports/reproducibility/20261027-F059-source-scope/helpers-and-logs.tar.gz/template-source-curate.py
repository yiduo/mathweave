from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess,sys
sys.path.insert(0,'src')
from ai_value.graph import load,validate
from ai_value.source_results import named_results
r=Path.cwd();w=Path(__file__).parent;now=datetime.now(timezone.utc).isoformat()
G='GEN-20261027-119';F='F-181';M='P-aa4a9f7b64d5fc71';UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
np=r/'data/graph/nodes.jsonl';ep=r/'data/graph/edges.jsonl';cp=r/'data/graph/reading_coverage.json'
on=np.read_bytes();oe=ep.read_bytes();oc=cp.read_bytes();by={n['id']:n for n in map(json.loads,on.decode().splitlines())}
assert len(by)==5408 and G not in by and 'ANALYSIS-F-181' not in by
s=json.loads((w/'qualification.json').read_text());j=json.loads((r/'state/reading-journal-WP122.json').read_text())
hist=json.loads((r/'data/provenance/readings/F-181-history.json').read_text());formal=json.loads((r/'data/provenance/readings/F-181-formal.json').read_text())
assert j['all_current_source_files_read'] and j['source_lines_read']==2566
new=[];edges=[];keys={(e['source'],e['relation'],e['target']) for e in map(json.loads,oe.decode().splitlines())}
def save(p,d):
 p=r/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def src(p,loc):return {'path':p,'locator':loc,'commit':UP if p.startswith('math/') else None,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()}
def add(id,kind,props,sources,status='source_claim'):
 assert id not in by,id
 n={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':status,'properties':{'model_generation_id':G,'dependency_closure_complete':False,**props},'sources':sources};by[id]=n;new.append(n);return n
def edge(a,rel,b,loc):
 if (a,rel,b) in keys:return
 keys.add((a,rel,b));edges.append({'id':'E-'+hashlib.sha256((a+'|'+rel+'|'+b).encode()).hexdigest()[:16].upper(),'source':a,'relation':rel,'target':b,'version':1,'created_at':now,'evidence_status':'source_claim','source_commit':UP,'source_locator':loc})
def cid(label):return 'CLM-181-'+re.sub('[^A-Za-z0-9]+','-',label).strip('-').upper()
fp='data/provenance/readings/F-181-formal.json';hp='data/provenance/readings/F-181-history.json';lp='data/provenance/readings/F-181.json'
files=j['completed_body_ranges'];paths={f['path'] for f in files};rows=[];labels={};bysource={};includes=[];entries={}
for f in files:
 p=f['path'];t=(r/p).read_text();assert hashlib.sha256((r/p).read_bytes()).hexdigest()==f['sha256'] and f['ranges']==[[1,len(t.splitlines())]]
 bysource[p]={};build=Path(p.split('/build/')[0]+'/build')
 for m in re.finditer(r'\\(?:input|include)\s*\{([^}]+)\}',t):
  target=str(build/(m[1]+('' if Path(m[1]).suffix else '.tex')));assert target in paths,target;includes.append({'source':p,'target':target,'read':True})
 for v in named_results(t):
  lab=v['label'];assert lab in s['claims'] and lab not in labels
  id=cid(lab);labels[lab]=id;bysource[p][lab]=id;title,cond=s['claims'][lab]
  rows.append({'id':id,'manuscript_id':M,'label':lab,'kind':v['kind'],'path':p,'sha256':f['sha256'],'statement_lines':[t.count('\n',0,v['statement_start'])+1,t.count('\n',0,v['statement_end'])+1],'statement_tex':t[v['statement_start']:v['statement_end']].strip(),'summary':title,'conditions':cond,'source_claim_grade':'B' if lab=='thm:main' else 'C','aliases':v['label_aliases']})
 if p.endswith('.bib'):
  matches=list(re.finditer(r'^@\w+\s*\{([^,]+),',t,re.M))
  for i,m in enumerate(matches):
   ent=t[m.start():matches[i+1].start() if i+1<len(matches) else len(t)].strip();entries[m[1]]={'path':p,'entry':ent,'lines':[t.count('\n',0,m.start())+1,t.count('\n',0,m.start()+len(ent))+1]}
assert len(rows)==16 and len(entries)==11 and len(s['methods'])==12 and not any(x['aliases'] for x in rows)
verified={x['key']:x for x in hist['rows'] if x.get('actual_selected_ranges_read')};assert len(verified)==4
bmap={key:'LIT-181-'+key.upper() for key in entries}
gaps=['Current single manuscript fully read and16namedbindings/12contracts curated;full family versions,recursive historical proofs and human review not complete.',
 'Four of11 primary historical originals checked only in selected converted-text scopes;seven original roots remain unqualified. AH publisher metadata and BM statement are not AH original-body review;Lovasz local403 remains a gap.',
 'Only main Cn existence endpoint sourceB after actual definition/signature comparison. Eulerian corollary andother15source statements C,all dependency chains unknown;34files1270declarations staticindex is not mathematical reading/build/Comparator/human approval.',
 'No concrete finite C,Dstar or running-time claim inferred. Noncomputable Nat.find/existential formal model is no executable construction. All-path hypergraph and maximal-long-cycle/sparse-cut searches lack a practical cost certificate.',
 'Finite simple undirected unweighted edge sets,not directed flows,multigraph demands,capacitated links orarbitrarycyclescover. Pairfolding andcyclelifting conditions cannotbe dropped.',
 'Ten domains/two crossfamily attempts are exploration records,not12cards. No new candidate,initial check,simulation or numerical run. Oldmethod sufficiency for qualifieddense/randomgraph classes retained.',
 'No true human grading/specification,second provider,pilot or new GitHub publication. Current selectedOpenAI exactbackend unknown.']
config='data/provenance/research-at-generation-119.json';(r/config).write_bytes((r/'configs/research.json').read_bytes())
ledger={'family_id':F,'work_package':'WP-122','generation_id':G,'at':now,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream_commit':UP,'manuscript_ids':[M],'read_files':files,'actual_read_ranges':'All nine TeX/Bib files,2566lines plusREADME;converted historical text only,noPDFpixelanalysis','source_sections':list(bysource),'source_tex_lines':2566,'include_links_checked':includes,'results':rows,'methods':s['methods'],'domain_attempts':s['domains'],'cross_family_attempts':s['cross_family'],'historical_references_by_key':bmap,'bibliography_entries_by_key':entries,'historical_external_work_count':11,'historical_selected_originals':hp,'unread_or_unqualified_original_root_ids':[bmap[k] for k in entries if k not in verified],'formal_status':fp,'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':0,'new_initial_checks':0,'numeric_or_symbolic_run':False,'gaps':gaps,'third_party_acquired_bytes':hist['bytes'],'third_party_republication':False,'dependencies_installed':False,'github_push':False}
save(lp,ledger);ls=src(lp,'AllcurrentF181source16bindings/12conditionalcontracts;selectedformal andfouroriginalscopes,notcompletehistory orproofaudit')
for key,e in entries.items():
 prop={'title':key,'bibliography_key':key,'bibliography_entry':e['entry'],'retrieval_status':'upstream_bibliography_only','verified_scope':'Sourcebibliographyread;originalbodynotqualified','full_original_proof_review':False,'credibility':'unknown'}
 ss=[src(e['path'],'Bibliography '+key+';lines'+str(e['lines']))];status='source_claim'
 if key in verified:
  h=verified[key];prop.update(retrieval_status='selected_original_scope_checked',verified_scope=h['selected_scope_statement'],selected_scope_locator=h['selected_scope_locator'],actual_text_ranges=h['actual_selected_ranges_read'],limitations='Selected statement/interface scopes only;recursive proof verification absent.')
  ss.append({'url':h['requested_url'],'sha256':h['sha256'],'source_file_sha256':h['sha256'],'locator':h['selected_scope_locator'],'content_checked':True,'checked_at':h['at']});status='source_content_checked'
 elif key=='AH2000':prop.update(retrieval_status='publisher_metadata_and_BM_restatement_only',verified_scope='Actual publisher metadata/abstract andBMTheorem6 statement;originalAHbodyunread.')
 elif key=='Lovasz1968':prop.update(retrieval_status='original_transport403_BM_restatement_only',verified_scope='ActualBMTheorem21/Corollary22 statement;originalLovaszTheorem1 notqualified.')
 add(bmap[key],'literature',prop,ss,status)
for x in rows:
 add(x['id'],'claim',{'title':x['summary'],'statement':x['summary'],'statement_tex':x['statement_tex'],'conditions':[x['conditions']],'family_ids':[F],'manuscript_id':M,'source_label':x['label'],'source_statement_lines':x['statement_lines'],'credibility':x['source_claim_grade'],'source_claim_grade':x['source_claim_grade'],'dependency_chain_grade':'unknown','constants_and_constructions':['Exact source statement retained;specified cutoff/quantifier assumptions retained;no accepted mathematical proof or numerical benchmark inferred.']},[copy.deepcopy(ls),src(x['path'],x['label']+';lines'+str(x['statement_lines']))]+([src(fp,'Actual main signature/definitions/registration read;sourceB only,no build')] if x['label']=='thm:main' else []))
 edge(x['id'],'member_of',F,'Current source result');edge(x['id'],'derived_from',M,'Fixed current manuscript')
deps={'thm:main':['prop:induction-bound'],'cor:eulerian-cycles':['thm:main'],'cor:endpoint-paths':['thm:lovasz'],'lem:routing':['thm:aharoni-haxell'],'lem:edge-split':['lem:chernoff'],'lem:vertex-sampling':['lem:chernoff'],'lem:small-residue':['lem:edge-split','lem:vertex-sampling','cor:endpoint-paths','lem:routing'],'lem:scale-split':['lem:split-vertex-expansion'],'lem:batch-resolution':['lem:pair-folding','cor:endpoint-paths','lem:routing'],'prop:induction-bound':['lem:prefix-choice','lem:scale-split','lem:small-residue','lem:edge-split','lem:batch-resolution']}
for child,parents in deps.items():
 for parent in parents:edge(labels[child],'depends_on',labels[parent],'Explicit source proof contract with all qualifiers;not claiming identical formal proofroute')
for child,key in [('cor:eulerian-cycles','GGKO2021'),('thm:lovasz','Lovasz1968'),('thm:aharoni-haxell','AH2000')]:edge(labels[child],'depends_on',bmap[key],'Mandatory selected historical theorem interface;unread original proof keeps chainunknown')
for x in rows:
 t=(r/x['path']).read_text()
 for chunk in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',t):
  for key in chunk.split(','):
   key=key.strip()
   if key in bmap:edge(x['id'],'historical_context',bmap[key],'Bibliographic context in containing fullyreadsource;not automatically a mandatory mathematical dependency')
methods=[]
for key,title,inp,out,label,limit in s['methods']:
 id='PART-181-'+key;methods.append(id);x=next(v for v in rows if v['label']==label)
 add(id,'method',{'title':title,'input':inp,'output':out,'conditions':x['conditions'],'cannot_transfer':limit,'family_ids':[F],'credibility':'C','dependency_chain_grade':'unknown'},[copy.deepcopy(ls),src(x['path'],label+';conditional methodinterface')]);edge(id,'depends_on',x['id'],'Qualified source contract')
add('PROB-181-CONSTRUCTIVE-COST','problem',{'title':'线性分解数量与完整构造成本的桥接','statement':'Need an actual decomposition construction with explicit finite input/cutoff/witness,total runtime/memory and comparison against old cycle/edge methods. Main is existence of few parts;all-path/matching/sparsecut/longcycle selection not implemented.','family_ids':[F],'credibility':'unknown','prerequisite_status':'not_admitted'},[copy.deepcopy(ls)],'hypothesis')
edge('PROB-181-CONSTRUCTIVE-COST','references','PART-181-ORDER-POTENTIAL','Missing algorithmcost bridge retained;not an applicationvalidation')
add('PROB-181-ROUTE-CERTIFICATE','problem',{'title':'商图环提升的边与顶点资源证书','statement':'Before reusing quotientcycles require unique retainedoriginaledges,switchendpoint membership,forbiddenoriginalendpoints,samecycleinteriordisjointness andglobalbatchload. Need real route inputs andold certificateverification baseline;smallknownexamples alone no new application credit.','family_ids':[F],'credibility':'unknown','prerequisite_status':'conditional_input_missing'},[copy.deepcopy(ls)],'hypothesis')
edge('PROB-181-ROUTE-CERTIFICATE','references','PART-181-SIMPLE-CYCLE-LIFT','Concrete route/certificate interface gap')
expl=add('EXPLORE-F-181','exploration',{'title':'F181十领域及两跨族条件探索','family_ids':[F],'attempts':[{'domain':d,'analogy':a,'assessment':v,'accepted_connection':False} for d,a,v in s['domains']],'cross_family_attempts':s['cross_family'],'new_connection_ids':[],'interpretation':s['reason_no_candidate'],'credibility':'unknown'},[copy.deepcopy(ls)],'hypothesis')
for id in methods:edge(expl['id'],'uses',id,'Exploratory mapping,not a validatedapplication')
for x in s['cross_family']:assert x['existing_method'] in by;edge(expl['id'],'references',x['existing_method'],'Cross-family comparison,no joint proof dependency')
add('ANALYSIS-F-181','family_analysis',{'title':'F181一般图的环与单边分解当前源码草稿','family_id':F,'family_ids':[F],'manuscript_ids':[M],'manuscript_source_drafts_complete_ids':[M],'source_sections':list(bysource),'source_line_count':2566,'result_ids_by_label':labels,'result_ids_by_source':bysource,'method_ids':methods,'formal_statement_comparison':formal['selected_comparison'],'formal_status':{'evidence':fp,'index':formal['static_index'],'local_lean_build':False,'comparator_run':False,'human_spec_review':False,'complete_proof_or_axiom_audit':False},'historical_references_by_key':bmap,'historical_verified_keys':list(verified),'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'gaps':gaps,'credibility':'unknown','completion_basis':'Allcurrent9TeX/Bib2566lines,16namedbindings12contracts;fourselectedoriginalscopes,actualmainformalendpoint;notfullhistorical/proof/human/provideracceptance.'},[copy.deepcopy(ls)],'source_content_checked')
add(G,'generation',{'title':'F181completecurrent manuscript withconditionaldecomposition contracts','family_ids':[F],'project_base_commit':ledger['base_commit'],'provider':'OpenAI','model':'Current selected session;exactbackendunknown','human_review':None,'independent_second_provider':None,'seed_list_exposed':True,'credibility':'unknown'},[copy.deepcopy(ls),src(config,'Policy snapshot'),src(fp,'Selected actual formal scopes'),src(hp,'Four originalselectedconvertedtextscopes')],'source_content_checked')
cov=json.loads(oc);assert F not in cov['partially_read_families'];archive='data/graph/history/'+G+'-reading-coverage-before.json.gz';z=gzip.compress(oc,mtime=0);assert gzip.decompress(z)==oc;(r/archive).write_bytes(z)
cov['partially_read_families'][F]=['Fullcurrent singlemanuscript9TeX/Bib2566lines,16namedbindings/12contracts;notfullfamily/history.','Four of11 originalrootsselectedconvertedtextscopes,sevenoriginalroots/recursiveproofsunqualified.','Selectedmain sourceB,other15C,allchainsunknown;34files1270declarationsstaticindexnotproof/build.','Ten domains/two crossfamilyattempts;constructivecost andliftingcertificate gaps,nonewcandidate/check/run.'];cov['source_decomposition_drafts'].append(F);cov.update(updated_at=now,update_reason='WP122actualcurrentF181sourcescope;nohistorical/fullfamily/applicationcredit',prior_version_archive=archive)
summary={'generation':G,'base_commit':ledger['base_commit'],'old_records':len(on.splitlines()),'new_records':len(new),'new_explicit_edges':len(edges),'named_bindings':16,'method_contracts':12,'unique_literature_nodes':11,'source_B':1,'source_C':15,'new_candidates':0,'new_application_checks':0,'new_scientific_experiments':0,'new_record_ids':[n['id'] for n in new]}
try:
 np.write_bytes(on+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new).encode());ep.write_bytes(oe+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges).encode());save('data/graph/reading_coverage.json',cov);summary['initial_graph_validation']=validate(r)
except Exception as e:
 (w/'unaccepted-curation-failure.json').write_text(json.dumps({'error':str(e),'type':type(e).__name__,'summary':summary,'rollback':'nodes/edges/coverage restored;source evidence retained'},ensure_ascii=False,indent=2)+'\n');np.write_bytes(on);ep.write_bytes(oe);cp.write_bytes(oc);raise
assert np.read_bytes().startswith(on) and ep.read_bytes().startswith(oe)
save('state/reading-journal-WP122.json',{**j,'body_draft_complete':True,'canonical_generation':G,'canonical_credit_added':True,'updated_at':now})
(w/'curation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='new_record_ids'},ensure_ascii=False))
