from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile
r=Path.cwd();w=Path(__file__).parent;now=datetime.now(timezone.utc).isoformat()
q=json.loads(gzip.decompress((w/'quality.json.gz').read_bytes()));c=json.loads(gzip.decompress((w/'clean-check.json.gz').read_bytes()));assert c['core_exit_code']==0 and not (w/'clean').exists()
for name in ['core.log','clean-core.log']:
 t=(w/name).read_text();assert 'Ran 88 tests' in t and '\nOK\n' in t and 'OK (skipped' not in t and '"canonical_citations": 9825' in t
for name in ['EXP-238-001-a1d52c04aeb9b1ba-replay.json','EXP-076-python314-replay.json']:
 x=json.loads((w/name).read_text());assert all(x['deterministic_outputs_match'].values()) and x['replay_resource_envelope_met']
f=r/'experiments/replay-failures/EXP-076-002-1f8537b7fd40d564-1d900635e2ec';fmeta=json.loads((f/'receipt.json').read_text());z=(f/'failure.tar.gz').read_bytes();assert hashlib.sha256(z).hexdigest()==fmeta['archive_sha256']
with tarfile.open(f/'failure.tar.gz','r:gz') as tf:
 for name,h in fmeta['members'].items():assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==h
wp={'id':'WP-126','priority':1,'status':'ready','parent_task':'WP-007','objective':'Prepare a source-qualified executable preregistration for existing APP14901 continuous-permanence versus finite Euler certificate separation, with independent finite-time reference and strong old per-step baseline. No target outputs before a separate specification/source freeze.','selection_reason':'Global044 redirects from two source/admission packages with no new initial checks to a previously registered, explicitly synthetic-eligible external-test hypothesis. Missing real consumers are not added as a universal gate. Finite Euler positivity is cheap but known; a nonlinear multi-linkage eligibility and reference audit must prevent another uninformative linear control and explicitly allow zero new-mathematics gain.','inputs':['APP-149-01','experiments/plans/MAP-149-001.json','reports/families/F-149.md','F-149 current source and existing canonical provenance'],'resource_limit':'One bounded preparation package using existing runtimes/stdlib and existing source evidence. No large solver install,upstream write,biology deployment,parameter search or target numerical outputs. Synthetic fixtures and full reference/algorithm costs frozen before later execution.','acceptance':'Recheck exact weak-reversibility/fixed-positive-rate/stoichiometric assumptions on whole proposed instances; distinguish continuous asymptotic permanence from finite-time solver properties. Implement independent exact-rational Euler judge and justified analytic/validated finite-time reference where nonlinear evidence is required. Preserve old per-step coordinate check as an honest eligible baseline. Source-complete/full-field card and executable spec,immutable fixtures,tolerances,resource caps,failure handling,compressed source binding and local freeze before any target run. No automatic initial-check credit for preparing a spec or running known calibration.','stop_or_redirect':'Do not claim uniform burn-in/effective permanent region,replace a nonlinear judge with linear controls,or use a deliberately false guarantee as the only baseline. If reference/eligibility cannot be justified within the package,preserve exact gap and redirect to selected missing F181 primary history. Keep original APP149 prediction and no 2026 integrator-gain claim;no widened target based on results.','depends_on':['WP-125'],'created_at':now,'next_action':'Read APP149 canonical source scopes and exact pending plan;qualify nonlinear multi-linkage fixtures and independent finite-time reference before writing/finalizing executable spec. No target output.','body_read_credit':0,'new_initial_checks':0,'github_push':False,'execution_state':'selected_not_started','retrospective_due':'Global045 after three substantive packages beyond044 or earlier material evidence change.'}
(w/'next-selection.json').write_text(json.dumps(wp,ensure_ascii=False,indent=2)+'\n')
text='''# 全局复盘044：完整桥接、复现环境与待检假设

2026-10-27；覆盖WP123、WP124、WP125。第一阶段仍未完成；本次仅本地保存及提交，不例行推送GitHub。

## 1. 目标对齐与实际增量

WP123有界核查APP124的真实源描述生成器：字面K=10000枚举及拟议范围内的语义幂集，不能被旧子集DP替代后称为新描述方法。108PiB仅限制N=54的完整显式位表，不能推断一切符号/惰性实现均无用。没有改变原25%状态/全成本预测，也没有新应用运行。

WP124读完F238条件/解析伴随稿10TeX/Bib1791行，6项来源绑定、14合同，族增至7/12篇233绑定。小实参数条件通行界与无条件H为空的解析端点分开。四部历史原作仅选段，2来源B/4C、完整链未知；静态索引错误重叠说法已更正并留26个旧版本。

WP125实际读完F059两篇24TeX/Bib5601行及288行附带程序，51项来源绑定/27合同入图；8项是经典输入，不是项目新数学。实际400行Lean文件只对应一个链引理，50项仍C含两主定理。五部原作仅选段；53部外部根中48部原文和递归历史仍缺。十领域/三跨族均为探索，未增加候选。有限秩和见证程序未运行，不能把算术检查当完整拓扑结论。

本周期没有新增候选或合格初检。当前47/500候选、14/100合格初检、14不同合格验证（6限定支持、8不利），另1不计初检诊断。达到10项验证的数量子项不完成M4。规范图增长用于保留依据和边界，不作为应用价值替代指标。

## 2. 覆盖与偏差

64/372族有实际阅读，59族为当前稿全文拆解草稿，308族尚无实际阅读。完整族版本/历史及六阶段仍0；F238的7/12不是全族完成。代数复几何从4/36到5/36；组合5/37、数学物理3/25、实复分析2/16、微分几何4/29等仍低。17门类均有阅读不意味着均充分研究。未把当前稿、局部形式化或少数原作选段算完整族。

33张候选没有合格初检，其中F337虽有真实诊断仍未满足原标准。持续重复准入筛查而无新外部检验有机会成本；反过来，不能用复制卡片、运行已知小例或降低成功标准提高计数。原方案允许合成任务的卡片，不应额外被“必须先有真实商业调用者”卡住；原卡明确要求真实输入的仍遵守原要求。

## 3. 证据改变了什么判断

F059高维2/3构造的实Seifert型、整数monodromy及整数Seifert同余是不同对象；逐完整特征空间行列式消除和非紧SU条件不可省。C4的4/5构造依赖实际投影/transfer/mod4粘合、符号/Spin与Kato开书分类，不能从抽象平面型或球面Levine分类跳到结论。两条源证明独立，图中不把引用关系误连成主定理依赖。环境对拓扑、右等价、度量/解析等价与mu常数族结论分别保留。尚无可执行效率或应用增益依据。

代表重放揭示环境边界：F238在现有Python3.12.14下完整raw/summary相等；F076同环境raw有14处浮点叶差（最大8.881784197001252e-16），summary相等。失败压缩归档保留，不能据摘要称完整通过。原F076记录3.14.7，本机已有3.14.8的严格全字段重放随后通过原资源约束。未安装旧运行时，未改代码/输入/容差/比较字段；此观察不能证明所有平台或Python版本一致，也不证明差异原因仅是版本。以后重放F076优先使用已验证3.14.8路径，保留3.12失配事实。

## 4. 不同路线和旧方法零假设

| 路线 | 价值与约束 | 决策 |
| --- | --- | --- |
| F059附带有限秩/见证组件检验 | 可核算术输入，但旧精确线性代数已足够；不验证局部—整体/拓扑桥，尚无准入应用 | 留待单独组件规格，不为增加初检立即运行 |
| APP124完整源生成器数值实现 | 原枚举不可简化为旧DP；惰性实现需完整语义/构造/全成本证据 | 保留有条件重访，近期不扩大字面枚举 |
| 继续只增加新族稿件或F238剩余五篇 | 对M2有用，但本周期已两包源文且未减少待检队列 | 保留下一周期覆盖预算，不立即第三包连续同类阅读 |
| 补F181其余七部历史原作 | 直接降低已读族历史根缺口，无需实验 | 可执行替代；当下包参考裁判不准入时转此路 |
| **既有APP149的可执行预注册准备** | 计划已明确允许固定合成反应网络；独立非线性有限时间参考和完整前提是实质缺口。原预测是证书分离，既有逐步非负检查是诚实强基线 | **WP126一次限定准备，之后冻结再执行；不新增真实调用者门槛** |

零假设是旧逐坐标Euler检查已完全覆盖有限步风险，新连续永久性结论不给新积分器/有限步误差收益。旧单链接/详细平衡永久性也可能足够；必须逐例列旧覆盖，不能把旧例称2026新增适用。可以获得不利或零增量结论，不能因为可能无收益而无限延期一个已有可证伪、合成合格的检验。也不能以新数学增益未成立为由把任何普通校准都算有效应用。

## 5. 机会成本与资源重排

若重新分配下一份资源，先给APP149一个有界准备包。读已有规范来源和原计划，明确所有复合物、反应、弱可逆/固定率/正初态/守恒或化学计量前提；冻结非线性多链接情形及旧覆盖分类；落实独立exact-rational Euler与有依据的有限时间连续参考。原预测和成功/失败范围保留，所有查找、验证、求解、异常归档及资源计入。仅完成计划不算初检，目标输出前本地提交规格/源码冻结。

若非线性参考无法在限定资源内资格化，保存具体原因并转F181选定历史根，不能拿已知线性Euler例替代失败路线。后续仍留低覆盖族和F238深度预算；配置40/30/20/10是选择原则，不捏造已用工时。真人和第二供应商待用户后补，不反复询问。

## 6. 全局技术和存储回归

F059新增136条规范记录、617条显式边；原5484条规范行逐字节保持，758个已有科学/测试/语料/族报告/卡片/阅读账本文件保持。阅读覆盖前版压缩保留。完整图8850节点26048关系，规范来源9812，完整审计9825项/2074来源制品；165单种子正负传播、2多种子替代路线、完整JSON/GraphML对象一致。两主定理独立，以及Kato/Levine必要范围的正反传播都实检。

17份科学归档、337个源码成员逐项压缩和散列校验通过；本地88核心与无math干净副本88项无跳过。F238限定支持和F076不利代表已按上述环境完整重放，原资源标准通过；3.12下F076失败作为单独证据保留，不计新科学假设或初检。干净副本移除，收据说明后置闭包/状态/复盘文本的范围，不能把后写元数据称已在副本中测试。

首次F059入图因TeX相对路径按章节目录解析而停止，规范图未写；按实际文档build目录修复，全部23项包含目标核对后成功。错误脚本、日志和修复版本均保留，未弱化验证器。第三方PDF/转换文字5109556字节已逐项核散列后移除且不转载；自有辅助/失败/日志最终压缩逐成员回解核验。最终闭包收据为本包完成依据。

## 7. 明确决策

完成WP125后转WP126原APP149检验准备，规格/实现冻结后才运行。保留F059/F124待定路线，不把存在性当效率；保留远类比和跨族尝试，不复制候选。F076跨运行时不一致作为可见复现限制，不覆盖旧证据、不降低标准。下一周期确保实际检验准备与低覆盖/历史两条线并行，允许零增量证据改变排序。整体active_incomplete，公开快照仍以state/publication.json最后核验记录为准；无本次GitHub推送。
'''
(r/'reports/retrospectives/044-full-bridges-and-replay-environments.md').write_text(text)
print(json.dumps({'retrospective':'044','next_package':'WP-126','core':88,'clean':88,'impact_cases':len(q['impact_cases']),'alternative_routes':len(q['alternative_route_cases']),'failed_replay_members_verified':len(fmeta['members'])}))
