from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,subprocess,json
w=Path(__file__).parent
sources=[('Kato1974','https://webhomes.maths.ed.ac.uk/~v1ranick/papers/kato2.pdf',2000000),('Levine1970','https://webhomes.maths.ed.ac.uk/~v1ranick/papers/levsome.pdf',2000000),('Rapinchuk2014','https://library.slmath.org/books/Book61/files/70rapi.pdf',2000000),('Massey2015LeCycles','https://arxiv.org/pdf/1410.3312v2',2000000),('BobadillaPelka2024','https://arxiv.org/pdf/2204.07007v5',3500000)]
def fetch(s):
 key,url,cap=s;r={'key':key,'url':url,'cap_bytes':cap,'at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-audit/1.0'}),timeout=30) as x:raw=x.read(cap+1);r.update(final_url=x.url,http_status=x.status)
  assert len(raw)<=cap and raw.startswith(b'%PDF'),'not bounded PDF'
  p=w/(key+'.pdf');t=w/(key+'.txt');p.write_bytes(raw);r.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  z=subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(p),str(t)],capture_output=True,timeout=25);r['conversion_exit']=z.returncode;assert z.returncode==0
  b=t.read_bytes();r.update(text_bytes=len(b),text_sha256=hashlib.sha256(b).hexdigest(),text_lines=len(b.splitlines()),status='retrieved_not_yet_read')
 except Exception as e:r.update(status='failed',failure=repr(e))
 return r
with ThreadPoolExecutor(max_workers=3) as x:rows=list(x.map(fetch,sources))
assert sum(r.get('bytes',0) for r in rows)<=8000000
(w/'history-fetch.json').write_text(json.dumps({'rows':rows,'raw_bodies_republished':False,'pdf_analysis':'converted text only'},ensure_ascii=False,indent=2)+'\n');print(json.dumps(rows,ensure_ascii=False))
