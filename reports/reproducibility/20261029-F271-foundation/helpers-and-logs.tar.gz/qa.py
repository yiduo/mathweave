from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,os,shutil,subprocess,sys,tarfile,re,xml.etree.ElementTree as ET
root=Path.cwd();work=Path('/private/tmp/ai-paper-WP129-foundation');out=root/'reports/reproducibility/20261029-F271-foundation'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def savegz(p,d):
 raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;p.write_bytes(z)
assert 'Ran 95 tests' in (work/'core.log').read_text() and '\nOK\n' in (work/'core.log').read_text();assert 'skipped=' not in (work/'core.log').read_text()
assert not git('diff','01df3ee','--','data/corpus','experiments','src','tests','data/graph/reading_coverage.json')
assert not git('-C','math','status','--porcelain')
assert git('-C','math','rev-parse','HEAD').decode().strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
sys.path.insert(0,str(root/'src'));from ai_value.graph import load, affected_nodes, theoretical_grade
nodes,edges=load(root);j=json.loads(gzip.decompress((root/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes;assert {e['id']:e for e in j['edges']}=={e['id']:e for e in edges}
xml=ET.fromstring(gzip.decompress((root/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
xnodes={n.attrib['id']:json.loads(n.find('g:data[@key="properties"]',ns).text) for n in xml.findall('.//g:node',ns)};xedges={e.attrib['id']:json.loads(e.find('g:data[@key="evidence"]',ns).text) for e in xml.findall('.//g:edge',ns)};assert xnodes==nodes and xedges=={e['id']:e for e in edges}
prior=json.loads(gzip.decompress((root/'reports/reproducibility/20261027-F181-history/quality.json.gz').read_bytes()))
for case in prior['impact_cases']:
 affected=affected_nodes(nodes,edges,{case['seed']})
 key=case.get('required_affected')
 if key:assert (key in affected)==case['confirmed'],case
 forbidden=case.get('must_not_propagate_to')
 if forbidden:assert forbidden not in affected,case
for case in prior['alternative_route_cases']:assert set(case['required_affected'])<=affected_nodes(nodes,edges,set(case['seeds']))
new=[n for n in nodes.values() if n['id'].startswith('PART-271-')]
assert len(new)==8
for n in new:
 mid=next(e['target'] for e in edges if e['source']==n['id'] and e['relation']=='derived_from')
 assert n['id'] in affected_nodes(nodes,edges,{mid})
 assert theoretical_grade(nodes,edges,n['id'])=='unknown'
oldn=git('show','01df3ee:data/graph/nodes.jsonl');olde=git('show','01df3ee:data/graph/edges.jsonl')
assert (root/'data/graph/nodes.jsonl').read_bytes().startswith(oldn)
assert (root/'data/graph/edges.jsonl').read_bytes().startswith(olde)
foundation=[n for n in nodes.values() if n['id'].startswith('CLM-271-F-')]
assert len(foundation)==34
for n in foundation:assert theoretical_grade(nodes,edges,n['id'])=='unknown'
new_interfaces=[e for e in edges if e['source'].startswith('CLM-271-F-') and e['relation']=='depends_on']
for e in new_interfaces:assert e['source'] in affected_nodes(nodes,edges,{e['target']})
main_id='CLM-271-F-THM-MAIN'
for seed in ['CLM-271-F-THM-PIN-BOOTSTRAP','CLM-271-F-LEM-SURFACE-COST','CLM-271-F-LEM-DEEP-DYNAMICS','CLM-271-F-LEM-STRIP-LIMIT']:
 assert main_id in affected_nodes(nodes,edges,{seed})
 assert 'PART-271-DUAL-CAPACITY' not in affected_nodes(nodes,edges,{seed})
archives=[];members=0
for mf in sorted((root/'experiments/runs').glob('*/manifest.json')):
 d=json.loads(mf.read_text());folder=mf.parent
 for path,digest in d['outputs'].items():assert sha((folder/path).read_bytes())==digest,(mf,path)
 for path,meta in d['compressed_payloads'].items():
  raw=gzip.decompress((folder/path).read_bytes());assert sha(raw)==meta['uncompressed_sha256'];json.loads(raw)
 snapshot=json.loads(gzip.decompress((folder/d['source_snapshot']).read_bytes()))
 for path,content in snapshot.items():assert sha(content.encode())==d['inputs'][path],(mf,path)
 members+=len(snapshot);archives.append({'run_id':d['run_id'],'source_members':len(snapshot),'outputs_and_decompressed_hashes_verified':True})
assert len(archives)==18 and members==378,(len(archives),members)
clean=work/'clean';assert not clean.exists();clean.mkdir()
names=sorted(set(filter(None,git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0'))));manifest=[]
for n in names:
 assert n.split('/')[0] not in {'math','.git','.venv','.cache','tmp'}
 src=root/n;assert src.is_file() and not src.is_symlink();b=src.read_bytes();dst=clean/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);dst.chmod(src.stat().st_mode&0o777);assert sha(dst.read_bytes())==sha(b);manifest.append({'path':n,'bytes':len(b),'sha256':sha(b)})
assert not (clean/'math').exists()
with (work/'no-math-core.log').open('wb') as f:p=subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
receipt={'at':datetime.now(timezone.utc).isoformat(),'files':len(manifest),'bytes':sum(i['bytes'] for i in manifest),'official_math_paths':0,'copy_hashes_verified':True,'core_exit_code':p.returncode,'runtime':sys.version,'manifest':manifest};savegz(out/'no-math-clean.json.gz',receipt)
if p.returncode:
 print((work/'no-math-core.log').read_text()[-3000:]);sys.exit(p.returncode)
assert 'Ran 95 tests' in (work/'no-math-core.log').read_text() and '\nOK\n' in (work/'no-math-core.log').read_text();assert 'skipped=' not in (work/'no-math-core.log').read_text()
for i in manifest:assert sha((clean/i['path']).read_bytes())==i['sha256'],i['path']
shutil.rmtree(clean)
quality={k:v for k,v in receipt.items() if k!='manifest'};quality.update(core_tests=95,clean_core_tests=95,skips=0,clean_directory_removed=True,scientific_implementation_unchanged_from='01df3ee',full_JSON_GraphML_objects_equal=True,scientific_archives=archives,source_archive_members=members,prior_complete_dependency_impact_receipt='reports/reproducibility/20261027-F181-history/quality.json.gz',prior_strict_supported_adverse_replays='reports/reproducibility/20261027-F181-history/closure.json',new_scientific_runs=0,WP129_full_family_credit_added=False,scope='Partial foundation source-claim and reproducibility QA. No new mathematics,application,human/provider or complete-family acceptance.')
# Store helper/log plaintext compressed; verify every archive member before deleting it later.
entries=['curate.py','qa.py','core.log','no-math-core.log'];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for n in entries:
  b=(work/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for n in entries:assert t.extractfile(n).read()==(work/n).read_bytes()
(out/'helpers-and-logs.tar.gz').write_bytes(z);quality.update(old_impact_cases_rechecked=len(prior['impact_cases']),old_multi_seed_cases_rechecked=len(prior['alternative_route_cases']),new_method_dependency_cases=8,old_canonical_rows_byte_preserved=True,foundation_source_claims=34,foundation_dependency_interfaces=len(new_interfaces),helper_members_verified=len(entries),helper_compressed_sha256=sha(z),helper_decompressed_sha256=sha(raw));(out/'quality.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in quality.items() if k!='scientific_archives'}),flush=True)
