from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib
r=Path.cwd();out=r/'reports/reproducibility/20261029-F271-foundation';w=Path('/private/tmp/ai-paper-WP129-foundation')
def pack(n,b):
 z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/n).write_bytes(z)
pack('first-core-failed.log.gz',(w/'core.log').read_bytes())
p=r/'data/graph/edges.jsonl';lines=p.read_bytes().splitlines(keepends=True);new=[];before=[]
for l in lines:
 e=json.loads(l)
 if e['relation']=='cites' and e['target'].startswith('CLM-271-F-'):
  before.append(e);e['relation']='compares_with';e['id']='E-'+hashlib.sha256((e['source']+'|'+e['relation']+'|'+e['target']).encode()).hexdigest()[:16].upper();new.append((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode())
 else:new.append(l)
assert len(before)==3;pack('new-comparison-edges-before-citation-type-repair.json.gz',json.dumps(before,ensure_ascii=False).encode());p.write_bytes(b''.join(new))
p=r/'state/publication.json';raw=p.read_bytes();pack('publication-state-before-schema-repair.json.gz',raw);d=json.loads(raw);v=json.loads(gzip.decompress((r/d['verification_receipt']).read_bytes()));assert d['verified_commit']==v['head_commit'] and v['public'] and v['full_tree_equal'];d['state']='published';d['state_value_repair']={'at':datetime.now(timezone.utc).isoformat(),'previous':'public_published_verified','current':'published','reason':'Align existing publication renderer contract using actual saved verification; no new remote-state observation or CI claim.','previous_archive':str((out/'publication-state-before-schema-repair.json.gz').relative_to(r))};p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('3 comparison edges typed correctly; actual verified publication recognized without changing verification evidence.')
