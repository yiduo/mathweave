from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
sys.path.insert(0,'src')
from ai_value.source_results import named_results
now=datetime.now(timezone.utc).isoformat();p=Path('state/reading-progress/WP-110.json');j=json.loads(p.read_text());new=[]
for m in j['manuscripts']:
 for f in m['tex_files']:
  raw=Path(f['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==f['sha256']
  if not f.get('body_actually_read'):
   assert f['path'].endswith(('sections/transfer-supplement.tex','build/references.tex'))
   f['body_actually_read']=True;f['actually_read_ranges']=[[1,f['lines']]];new.append(f['path']);j['actual_source_files_read'].append({'path':f['path'],'sha256':f['sha256'],'lines':f['lines'],'actually_read_ranges':[[1,f['lines']]],'source_result_inventory_only':named_results(raw.decode())})
assert len(new)==2
j['actual_source_lines_read']=sum(f['lines'] for f in j['actual_source_files_read']);assert j['actual_source_lines_read']==10336
j.update({'updated_at':now,'status':'selected_sources_fully_read_qualification_pending','new_source_body_read_manuscripts':2,'actual_current_bodies_read_including_uncurated':6,'next_actual_read':'Selected current source closure complete38TeX10336lines. Next qualify formal endpoints/historical original scopes,curate all results and method contracts;canonicalcoverage4/12 unchanged until curation/QA. Mandatory039 after WP110.'})
j['reading_batches'].append({'at':now,'files':new,'lines':322,'status':'last_source_closure_read_not_yet_canonical','notes':['Fixed-coset coefficient-space average32blocks cap4,orbit average256blocks and fourfactor coefficient decomposition are separate operator routes,not new applications. Fulljointtypes counted without multiplicity inflation; projection averages invertible on selected lowerbound.','Peeling subcharacter subgroup index<=D^(512^2),asymptotic inverse-first-degree sum and b=2^22 equalblock transfer require sufficient blocksize,retainedmass1-o1 and originalsignmean o1. Existence/largeconstant proofs do not give practical implementation.','References93lines read;only bibliographic identity,not originalbodyverification. Distinguish three internal companions from externalroots andauthor2011Etingof notes numbering.']})
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
cpath=Path('state/checkpoint.json');c=json.loads(cpath.read_text());c['saved_at']=now;c['previous_goal_turn_classification']={'classification':'progress','evidence':'Previous goal turn published b31ffce,fulltree7anonymousfilesverified,CI40269977360success;postreceipts localabfa2c4. No science experiment repeated.'};c['recovery_observation']['current_research_recovery']={'at':now,'head':'abfa2c4','available_disk':'19GiB','running_project_processes':[],'math_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','math_clean':True}
for key in ['active_work_package','next_work_package']:c[key]['execution_progress']={'source_files_fully_read':38,'source_lines_read':10336,'new_manuscripts_fully_read':2,'canonical_family_qualified_manuscripts':'4/12','actual_bodies_read_including_uncurated':'6/12','qualification_status':'formal/history/canonicalcuration pending'}
c['recovery_commands']=[j['next_actual_read'] if ('remaining' in s or 'source closure' in s or 'Currentonly' in s) else s for s in c['recovery_commands']]
cpath.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print({'files':38,'lines':10336,'canonical':'4/12pendingcuration'})
