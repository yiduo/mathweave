from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,urllib.request,subprocess
work=Path('/private/tmp/ai-paper-WP110')
sources={'etingof2011':'https://math.mit.edu/~etingof/replect.pdf','alonlovett2013':'https://theoryofcomputing.org/articles/v009a015/v009a015.pdf','larsenshalev2008':'https://citeseerx.ist.psu.edu/document?doi=aee51075af196ee1fa6014c8c03230e5ae98652f&repid=rep1&type=pdf'}
def fetch(kv):
 key,url=kv;out={'key':key,'url':url,'at':datetime.now(timezone.utc).isoformat(),'max_bytes':2500000}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-bounded-primary-source-audit'})
  with urllib.request.urlopen(req,timeout=30) as r:
   raw=r.read(2500001);assert len(raw)<=2500000 and raw.startswith(b'%PDF');out.update({'status':r.status,'final_url':r.url,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  p=work/(key+'.pdf');p.write_bytes(raw);subprocess.run(['pdftotext','-layout',str(p),str(work/(key+'.txt'))],check=True);out['state']='acquired_not_yet_read'
 except Exception as e:out.update({'state':'failed','error':type(e).__name__+':'+str(e)})
 return out
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(fetch,sources.items()))
assert sum(x.get('bytes',0) for x in results)<=8*1024*1024
(work/'acquisition.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
