from pathlib import Path
from datetime import datetime,timezone
import sys,subprocess,json,gzip,hashlib,tarfile,io,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.knowledge import export
from ai_value.reporting import render
root=Path.cwd();work=Path('/private/tmp/ai-paper-WP110');base='abfa2c4';summary=json.loads((work/'curation-summary.json').read_text());modified=set(summary['modified_old_record_ids'])
def show(p):return subprocess.check_output(['git','show',base+':'+p])
def gzsave(p,d):
 raw=json.dumps(d,ensure_ascii=False,indent=2).encode();b=gzip.compress(raw,mtime=0);assert gzip.decompress(b)==raw;Path(p).write_bytes(b)
old=show('data/graph/nodes.jsonl').splitlines();current=Path('data/graph/nodes.jsonl').read_bytes().splitlines();cur={json.loads(s)['id']:s for s in current}
for line in old:
 id=json.loads(line)['id']
 if id not in modified:assert cur[id]==line,id
 assert id in cur
assert Path('data/graph/edges.jsonl').read_bytes().startswith(show('data/graph/edges.jsonl'))
archive=json.loads(gzip.decompress(Path('data/graph/history/GEN-20261026-107-before.json.gz').read_bytes()));before={n['id']:n for n in archive['nodes']}
for line in old:
 n=json.loads(line)
 if n['id'] in modified:assert before[n['id']]==n and json.loads(cur[n['id']])['version']==n['version']+1
files=subprocess.check_output(['git','ls-tree','-r','--name-only',base]).decode().splitlines();kept=[]
for p in files:
 if p.startswith(('src/','tests/','experiments/','data/corpus/')) or (p.startswith('reports/families/') and p!='reports/families/F-238.md') or p in ['data/provenance/readings/F-238-information.json','data/provenance/readings/F-238-revealed.json']:
  assert Path(p).read_bytes()==show(p),p;kept.append(p)
previous=json.loads(show('data/graph/reading_coverage.json'));now=json.loads(Path('data/graph/reading_coverage.json').read_text());assert now['source_decomposition_drafts']==previous['source_decomposition_drafts'] and now['full_family_decompositions_complete']==previous['full_family_decompositions_complete']
for fam,record in previous['partially_read_families'].items():
 if fam=='F-238':assert now['partially_read_families'][fam][:len(record)]==record
 else:assert now['partially_read_families'][fam]==record
metrics=validate(root);generated=render(root);exported=export(root);nodes,edges=load(root)
js=json.loads(gzip.decompress(Path('reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in js['nodes']}==nodes;assert js['edges']==edges
xml=ET.fromstring(gzip.decompress(Path('reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xmlnodes={e.attrib['id']:json.loads(next(d.text for d in e.findall('g:data',ns) if d.attrib['key']=='properties')) for e in g.findall('g:node',ns)};xmledges=[json.loads(next(d.text for d in e.findall('g:data',ns) if d.attrib['key']=='evidence')) for e in g.findall('g:edge',ns)];assert xmlnodes==nodes and xmledges==edges
# Dependency failure propagation on actual new and old graph paths, preserving ordinary gate checks in core.
cases=[('CLM-238-FOURIER-L-DEGREE-ALL-POWERS','CLM-238-FRAMES-SHEAR-COR-512'),('CLM-238-FOURIER-L-CENTRAL-ISOTYPIC','CLM-238-FOURIER-L-ISOTYPIC-COMPLETION'),('CLM-238-FRAMES-LEM-FRAMES','PART-238-COMP-FIXED-FRAME'),('CLM-238-FRAMES-CHAR-REPAIR','PART-238-COMP-DEPENDENT-HALF-REPAIR'),('CLM-238-FOURIER-L-TABLOID-PRODUCT','PART-238-COMP-CONDITIONAL-PRODUCT'),('CLM-238-FOURIER-L-TILTED-ENTROPY','PART-238-COMP-ALL-TILTS'),('CLM-238-FOURIER-L-EQUIVARIANT-SIXTEEN','PART-238-COMP-KERNEL-SIGN-FIBER'),('CLM-238-FOURIER-L-THREE-GROUP','PART-238-COMP-KERNEL-ROW-COLUMN'),('CLM-238-FOURIER-L-FOREST-HYBRID','PART-238-COMP-SPARSE-HYBRID')]
impact=[]
for seed,target in cases:
 d=impact_report(nodes,edges,{seed});assert target in d['affected'],(seed,target,d);impact.append({'seed':seed,'required_affected':target,'confirmed':True})
# All historical numerical/source archives retain their declared compressed/raw/member hashes. No reruns here.
archive_checks=[];members=0
for mp in sorted(Path('experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());folder=mp.parent
 for name,digest in m['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,(mp,name)
 for name,meta in m.get('compressed_payloads',{}).items():
  assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256'],(folder,name)
 snapshot=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
 for name,body in snapshot.items():
  assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name],(folder,name)
 members+=len(snapshot)
 archive_checks.append({'run_id':folder.name,'compressed_output_hashes':True,'gzip_roundtrip':True,'source_members':len(snapshot)})
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_records':len(old),'unmodified_old_records_byte_equal':len(old)-len(modified),'versioned_old_records':len(modified),'prior_versions_object_equal':True,'new_records':len(current)-len(old),'old_explicit_edges_prefix_equal':True,'preserved_science_code_tests_corpus_and_old_reports_files':len(kept),'old_reading_coverage_members_preserved':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_node_and_edge_objects_equal':True,'impact_cases':impact,'experiment_archives':archive_checks,'source_archive_members':members,'scientific_runs_added':0,'application_checks_added':0,'limitations':'Graph/software/source integrity,not proof checking,independent provider,human review or application success;source-member declared content checks additionally reuse core/replay contracts.'}
gzsave(work/'quality.json.gz',receipt);print(json.dumps({k:v for k,v in receipt.items() if k not in ['experiment_archives','impact_cases','generated_metrics']}))
