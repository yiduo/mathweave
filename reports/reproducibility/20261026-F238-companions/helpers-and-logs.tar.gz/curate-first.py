from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess
root=Path.cwd();work=Path('/private/tmp/ai-paper-WP110');now=datetime.now(timezone.utc).isoformat();GEN='GEN-20261026-107';COMMIT='1581d4cbdd69a0faf34b2089614fe2a814316a6a';BASE='abfa2c4';history_path='data/graph/history/GEN-20261026-107-before.json.gz'
np=Path('data/graph/nodes.jsonl');ep=Path('data/graph/edges.jsonl');oldlines=np.read_text().splitlines();nodes=[json.loads(s) for s in oldlines];by={n['id']:n for n in nodes};assert GEN not in by
oldedges=ep.read_bytes();edges=[json.loads(s) for s in oldedges.decode().splitlines()];edgekeys={(e['source'],e['relation'],e['target']) for e in edges};oldrecords=copy.deepcopy(by);modified=set();new=[]
def save(p,d):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def gzsave(p,d):
 raw=json.dumps(d,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_bytes(packed)
def src(p,loc):return {'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'commit':COMMIT if p.startswith('math/') else None,'locator':loc}
def add(id,kind,props,sources,evidence='source_claim'):
 assert id not in by,id
 n={'id':id,'kind':kind,'created_at':now,'version':1,'evidence_status':evidence,'properties':{'model_generation_id':GEN,'dependency_closure_complete':False,**props},'sources':sources};by[id]=n;new.append(n);return n

def revise(id):
 if id not in modified:
  n=by[id];n['version']+=1;n['updated_at']=now;n['updated_by_generation_id']=GEN;n['prior_version_archive']=history_path;modified.add(id)
 return by[id]
def edge(a,r,b,loc,status='source_claim'):
 if (a,r,b) in edgekeys:return
 edgekeys.add((a,r,b));edges.append({'id':'E-'+hashlib.sha256(f'{a}|{r}|{b}'.encode()).hexdigest()[:16].upper(),'source':a,'relation':r,'target':b,'version':1,'evidence_status':status,'source_locator':loc,'source_commit':COMMIT,'created_at':now})
def cid(prefix,label):return 'CLM-238-'+prefix.upper()+'-'+re.sub('[^A-Za-z0-9]+','-',label).strip('-').upper()
read=json.loads(Path('state/reading-progress/WP-110.json').read_text());assert read['actual_source_lines_read']==10336
formal=json.loads(Path('data/provenance/readings/F-238-companions-formal.json').read_text());hist=json.loads(Path('data/provenance/readings/F-238-companions-history.json').read_text())
frames_summaries='''32800d物理洗牌的最坏初始牌序渐近全排列混合
随机位支持下界与2d-O(1)时钟
单牌支持与d步单牌均匀
固定完整方向序列的线性框架路径律比较
指定输入列表重标记与独立均匀列表平均
隐藏牌平均-运输的精确能量递减
终端隐藏律识别后的列表平均TV界
存在一个确定分块使补集边际误差和小
逆十六次维数和一致有界且非线性尾消失
任意非空不等块的轨道范数提升
同一事件重余类删除与归一化代价
保留全部重数的一向量轨道维数提升
概率质量变换下的Plancherel-TV界
公平洗牌符号系数及删质量代价
有界独立量、鞅与抽样集中界
固定已观察标签的无条件两半平衡
固定大列表的正逆向、相位一致TV估计
独立剪切键与逐时新方向分解
随机遗漏储备的列表平均误差
均匀随机输入列表的平均条件距离
不同遗漏比例的时间代入
随机七八比例列表与隐藏牌能量
六十四遗漏块的平均端点距离
保留原观察场的延迟对称与能量损失
任意正逆维数幂与同一子概率裁剪
不必覆盖全体的互不交块Fourier提升
未归一化子概率Plancherel与缺质量
借助伴随等型估计的512d结论
独立轨道路线2048d及2056d结论
六十四共同上界与32768d路线
三十二块HS放大的65568d路线
分枝计数放大的4096d路线
混合时间最优对数量级与512d渐近上界
固定方向框架与轨迹标签匹配不变性
完整可行路径圆柱下隐藏牌后验流
整个方向表及完整前驱路径的条件接口
新方向横穿超平面的能量界
固定观察标签的交叉平衡与期望递推
固定分块与次序的倒序删除共同事件
逐点余类上界的4096d和40976d路线
嵌套停止事件只计一次的322d列表界
停止边际与谱裁剪的5152d路线
参考历史只用于索引的后验行流
共同历史事件控制所有储备平均误差
共同好事件上任意倾斜律的相对熵不等式
稀有系数事件尾与1/a条件化代价
4096块全倾斜熵放大路线
固定初始框架的512040d辅助路线
额外剪切信息与全未来观察的条件分解
所有仿射半空间控制后的隐藏能量
随机独立列表的平均端点距离
辅助路线的轨道范数幂衰减
四组随机分块的2052d路线
十六组等变核的32784d路线
遗漏集合多项式的262152d路线
角色平滑的6060000d路线
半牌列表正逆向100d相位一致性
一次坐标通行的归一化HS衰减
一次通行的绝对幂迹界
非平凡非符号表示的最小维数
用输出半牌前像上界控制块范数
精确半牌边际修复后角色放大
同时修复两半边际但允许联合依赖'''.splitlines();assert len(frames_summaries)==63
fourier_summaries='''次数1024的小指数一维子角色
含所有重数的子角色等型估计
子角色指数的任意互不交块提升
有限群矩阵系数评价不等式
系数投影的轨道范数估计
系数与逐点角色的两种等型界
不同B幂和指数的两种HS提升
中心投影的轨道与HS替代界
分枝类型计数的HS细化
单个向量的子群轨道维数与重数
互不交余类系统的轨道提升
八余类系统经四次卷积混合
保留总质量z的全群等型Plancherel界
保留完整Fourier矩阵的HS提升
八余类系统经两次独立卷积混合
逆二十次维数和及类型计数
逆平方和的多条初等证明
逆十三和十六次幂的初等路线
对角线填充的逆四次幂路线
首行交错构造的逆十次幂路线
维数的缺口平方根下界
子图扩展、交错、投票和对角填充
精确钩长比与重排下界
每个固定正幂的逆维数和及缺口增长
逆一次幂的首行与大缺口路线
固定B后类型数被维数幂吸收
同一小块商误差的一次谱裁剪
自适应遗漏集合共同事件与标量投影
1024遗漏比例的八次放大
256遗漏比例的三十二次放大
十六等变核的完整符号重数HS条件
三组核的每行每列及全符号矩阵条件
十六边际熵的单一共同裁剪
限制首列后的首行缺口维数
受限大维数范围的谱衰减
另一个独立稀疏核的混合乘积
每个固定正幂的维数和基础结论
存在一个共同等分块误差和小
统一子概率裁剪与重余类删除
缺质量分开的Plancherel公式
算子与HS各自所需的卷积次数
有限任意非空分块余类上界主估计
两个揭露次序的逐点调色板信息上界
长行或长列缺口与调色板维数
含一维角色的带符号调色板
所有调色板与两半上界的四次放大
随机分块共同好事件的轨道路线
同一未归一化子概率的熵裁剪
随机大列表熵到确定分块
只在logD>d^8范围的HS吸收
带符号tabloid嵌入后的逆维数和
给定环境后实际乘积与逆像上界的转移
大常数幂维数的带符号tabloid嵌入
每个缓冲补集的归一化HS界
LR完整重数的两侧最小维数界
保留质量与符号后的一百次独立组合
共同好事件上的每个倾斜概率律条件
三十二低类型投影平均的系数路线
二百五十六低类型投影平均的轨道路线
四块完整联合类型的系数分解
剥离最长行列的一维子角色
最长线剥离的逆一次幂独立路线
2^22等分块的剥离角色转移
联合限制类型数与维数和消失
联合类型的质量敏感算子界
四块储备的渐近常数一估计
八块探针的渐近常数一估计
左右余类方向及乘积次序的双侧估计
左右不同子概率的两律卷积结论'''.splitlines();assert len(fourier_summaries)==69
# Each note is a section-scope boundary, not a new assumption silently imposed on every theorem.
notes={
'00-introduction.tex':'32800d独立自然证明与旧1600d、伴随512d路线分别保留；渐近结论没有有效有限d0。',
'01-preliminaries.tex':'n=2^d；物理一步使用n/2公平独立位；单牌边际不决定全排列。',
'02-frames.tex':'完整固定方向表之后的框架可用未来；一般L0同时重标记输入；仅L0=I保持同一指定列表。',
'03-marginals.tex':'在线观察场只含方向及前驱路径前缀和独立Xi；额外终端数据要核对隐藏律识别。无条件坏平衡概率在去除路径条件后使用。',
'04-degrees.tex':'自证逆16次幂弱于已核LS2004全固定正幂旧界；轨道计数是不同类型平方和，保留完整重数。',
'05-lift.tex':'所有余类共同裁剪一个事件；归一化上界2/(1-epsilon)，不能分别裁剪后当成同一概率律。',
'06-completion.tex':'普通未归一化Fourier质量变换；平凡、符号和非线性表示分开恢复。',
'07-shear.tex':'固定列表和随机独立输入列表平均分别处理；剪切键与完整方向表的条件分解不能替换为任意未来附加披露。',
'07b-delayed-symmetry.tex':'原有观察场下的B0和p0保持函数定义；额外历史只固定它们，不将p0偷换为全牌位置后验。',
'07c-transfer-applications.tex':'不覆盖全体也可取互不交支持；算子/HS、K与K²、两次/八次/三十二次放大是不同路线。512d依赖伴随HS而非所选Lean32800d。',
'08-frame-variants.tex':'完整路径须是固定公平开关阵列的可行圆柱。参考历史只是索引；共同G选在任意倾斜律之前。停止坏事件代价只计一次；平均TV不是混合平均律TV。',
'09-equivariant.tex':'等变双随机核保留所有重数，符号纤维矩阵条件不能用整体标量符号均值代替；最坏起点须传递等变。',
'10-character-explicit.tex':'BP用输出半牌前像上界；PB用输入半牌像修复，不能混换左右余类。uniform固定slack字符界只有所读2024重述范围，2008原作未得。',
'11-character-repair.tex':'两半条件边际均匀仍可依赖；正算子估计取min(qalpha,qbeta)而非乘积。存在性修复未给高效采样器。',
'characters.tex':'子角色存在性与巨大次数不等于实际高效构造；等型投影必须包含所有重数。',
'comparisons.tex':'Bz、B²和角色a4是不同估计；分枝缺口是n-max(firstrow,firstcolumn)，固定参数后才取n充分大。',
'core.tex':'八系统共同子概率的算子路线四卷积、HS路线两卷积。l:eight-convolutions/l:four-convolutions是旧标签别名，不按名字读次数。',
'degrees.tex':'固定u>0先给定再取n极限；包含平凡与符号两项，局部证明不优化旧LS2004速率。',
'degree-supplement.tex':'多条逆幂/填充证明是同一接口的替代路线，不计新应用或独立验证。',
'domains.tex':'同一完整商测试并集的坏集合预算只计一次；遗漏投影可以不交换，展开须保留乘积次序。',
'equivariant.tex':'16核需要保留核每个符号重数HS；3组需要每行每列TV及未裁剪全符号矩阵绝对行列和，不是标量奇偶均值。',
'forests.tex':'k=n-firstrow，不可转置抹去首列限制；独立K还须小缺口n^(-k/10)及首列>n/2精确零，不假定与mu卷积根有关。',
'foundations.tex':'同一未归一化f必须满足全部上界；质量缺损、符号和高维表示分开。',
'introduction.tex':'有限非空不等块、非负子概率、全部左余类上界、任意固定正u和未归一化范数；不由有限估计自动完成渐近两卷积。',
'palettes.tex':'同一好事件逐点控制两种半优先揭露顺序，所有调色板/放置/两半上界先成立；普通P平均不能在稀有Q下沿用。',
'random-partition.tex':'选共同好事件后才分拆向量；保留质量M和2/M归一化因子，另恢复符号。',
'replica.tex':'单律相对熵裁剪出同一未归一化v；logD>d^8的大维数范围不能外推到小维数。',
'tabloid-supplement.tex':'钩长、Pieri与带符号嵌入为数学存在性输入，未建立全原作谱系。',
'tabloid.tex':'给定环境z后nuA⊗nuC实际乘积是必要接口；仅条件边际均匀不够。L>=4000000与独立xi的逆像上界及保留总质量/符号分别要求。',
'tilts.tex':'一个先选的G上EVERY sigma；相对熵参照原P，不是P|G。尾事件再倾斜，条件化代价1/a。',
'transfer-supplement.tex':'平均低类型投影与完整联合类型分拆是不同证明；剥离C=512²和b=2^22为粗大存在常数。',
}
analysis=revise('ANALYSIS-F-238');ap=analysis['properties'];assert len(ap['result_ids_by_label'])==95
results={};rows_by_prefix={};labelmaps={}
for prefix,summaries,mid in [('frames',frames_summaries,read['manuscripts'][0]),('fourier',fourier_summaries,read['manuscripts'][1])]:
 rows=json.loads((work/(prefix+'-result-review.json')).read_text());assert len(rows)==len(summaries)
 rows_by_prefix[prefix]=rows;labelmaps[prefix]={}
 for i,(r,summary) in enumerate(zip(rows,summaries)):
  id=cid(prefix,r['label']);labelmaps[prefix][r['label']]=id
  for a in r['aliases']:labelmaps[prefix][a]=id
  grade='B' if (prefix,r['label']) in [('frames','thm:main'),('fourier','l:main')] else 'C'
  n=add(id,'claim',{'title':summary,'family_ids':['F-238'],'manuscript_id':mid['manuscript_id'],'natural_label':r['label'],'label_aliases':r['aliases'],'natural_statement_source':r['source'],'statement':summary,'statement_tex':r['statement'],'conditions':['原命题完整量词、对象与公式见statement_tex；依赖所在章先行定义和设定，不将局部结论外推。'],'context_boundaries':[notes[Path(r['source']).name]],'constants_and_constructions':[notes[Path(r['source']).name]],'credibility':grade,'formal_scope':'Selected static main conclusion only;not local build or full natural-route correspondence' if grade=='B' else 'No exact individual formal correspondence established;source C','independent_proof_review':False},[src(r['source'],f"{r['label']};line{r['line']};entire selected statement and containing proof/source body actually read;aliases not extra results")])
  if grade=='B':
   for p in (['math/lean/OAI/Probability/ThorpResults/Mixing.lean'] if prefix=='frames' else ['math/lean/OAI/RepresentationTheory/PartialPermutation/Model.lean','math/lean/OAI/RepresentationTheory/PartialPermutation/Main.lean','math/lean/OAI/RepresentationTheory/PartialPermutation/NormBounds.lean']):n['sources'].append(src(p,'Actually read selected formal statement/model/proof interface;not build or transitive proof audit'))
  ap['result_ids_by_label'][prefix+':'+r['label']]=id;ap['result_ids_by_source'].setdefault(r['source'],{})[r['label']]=id
  edge(id,'derived_from',mid['manuscript_id'],'Qualified actual source statement;not new project theorem')
  edge(analysis['id'],'analyzes',id,'Source binding in complete selected manuscript closure')
  results[id]=r
 for f in mid['tex_files']:
  if f['path'] not in ap['source_sections']:ap['source_sections'].append(f['path'])
  ap['result_ids_by_source'].setdefault(f['path'],{})
# Bibliography identity: explicit manuscript links and established same-work aliases; no DOI-driven evidence promotion.
oldmap=ap['historical_references_by_key'];common={k.split(':',1)[1]:v for k,v in oldmap.items() if k.startswith('information:')}
common.update({'DiaconisShahshahani1981':'LIT-238-A3BAC570AC','diaconis-shahshahani':'LIT-238-A3BAC570AC','Morris2009':'LIT-238-9DB965FBBC','Morris2013':'LIT-238-9CD198B10C','Thorp1973':'LIT-238-E4A8F13028','keller-lifshitz-sheinfeld2024':'LIT-238-REVEALED-35C7E9E543','larsen-shalev2008':'LIT-238-REVEALED-F0F40184F9'})
internal={'partial-fourier':'P-d7bc9b13ce9fc85f','optimal-thorp':'P-025591fd075b13f8','companion-information':'P-494bf6af76754487','companion-kernels':'P-ce6a8a7cfdd51cf0','companion-frames':'P-33d1bc7e07c70610'}
bibmaps={};new_literature=[]
for prefix,mid in [('frames',read['manuscripts'][0]),('fourier',read['manuscripts'][1])]:
 bib=next(f for f in mid['tex_files'] if f['path'].endswith('/references.tex'));text=Path(bib['path']).read_text();matches=list(re.finditer(r'\\bibitem\{([^}]+)\}',text));bm={}
 for i,m in enumerate(matches):
  key=m[1];entry=text[m.start():matches[i+1].start() if i+1<len(matches) else text.index('\\end{thebibliography}')].strip();id=internal.get(key) or common.get(key)
  doi_m=re.search(r'https://doi.org/([^}\s]+)',entry);doi=doi_m[1].replace('\\_','_') if doi_m else None
  if not id and doi:
   candidates=[n['id'] for n in by.values() if n['kind']=='literature' and n['properties'].get('doi','') and n['properties']['doi'].lower()==doi.lower()]
   if len(candidates)==1:id=candidates[0]
  if not id:
   id='LIT-238-COMPANIONS-'+hashlib.sha256((doi or key).encode()).hexdigest()[:10].upper()
   if id not in by:
    add(id,'literature',{'title':key,'bibliography_entry_tex':entry,'bibliography_key':key,'doi':doi,'retrieval_status':'upstream_bibliography_only','verified_scope':'Complete local bibliography entry read;original body not independently checked.'},[src(bib['path'],'Complete bibliography entry '+key)]);new_literature.append(id)
  elif by.get(id,{}).get('kind')=='literature':
   n=revise(id);n['properties'].setdefault('additional_bibliography_entries',[]).append({'key':prefix+':'+key,'entry_tex':entry,'generation_id':GEN});n['sources'].append(src(bib['path'],'Complete '+prefix+' bibliography entry '+key))
  bm[key]=id;oldmap[prefix+':'+key]=id
  edge(mid['manuscript_id'],'references',id,'Bibliographic reference only;not automatic full dependency or original-proof check')
 bibmaps[prefix]=bm
# New original-content checks version shared literature records. Keep all prior source bytes and statements.
for key,id in [('etingof2011','LIT-238-EA937F2E0E'),('alonlovett2013',bibmaps['frames']['alon-lovett2013'])]:
 x=next(x for x in hist['primary_retrievals'] if x['key']==key);n=revise(id) if id in oldrecords else by[id];n['evidence_status']='source_content_checked';n['properties'].update({'retrieval_status':'selected_original_scope_checked','verified_scope':x['scope'],'original_link':x['url'],'selected_scope_locator':x['locators'],'full_original_proof_review':False});n['sources'].append({'url':x['url'],'sha256':x['sha256'],'source_file_sha256':x['sha256'],'content_checked':True,'checked_at':now,'locator':x['locators']+';selected scopes only;not whole book/article'})
for prefix,bm in bibmaps.items():
 for key,id in bm.items():
  if key in ['etingof','alon-lovett2013','liebeck-shalev2004','keller-lifshitz-sheinfeld2024','DiaconisShahshahani1981','diaconis-shahshahani','Morris2009','Morris2013','morris4','morris3','morris-exclusion2006','morris44'] and by.get(id,{}).get('evidence_status')=='source_content_checked':ap['historical_verified_keys'].append(prefix+':'+key)
# Preserve per-result lexical references separately; only manually confirmed proof premises become depends_on.
for prefix,rows in rows_by_prefix.items():
 lm=labelmaps[prefix]
 for i,r in enumerate(rows):
  text=Path(r['source']).read_text();start=text.index(r'\begin{'+r['kind']+'}',text.index(r['statement'][:15]) if False else max(0,text.find(r'\label{'+r['label']+'}')-300)) if False else None
  # Use indexed statement/proof span through the next result in the same source, retaining exact locators.
  from sys import path as syspath
  if str(root/'src') not in syspath:syspath.insert(0,str(root/'src'))
  from ai_value.source_results import named_results
  rr=next(x for x in named_results(text) if x['label']==r['label']);allr=named_results(text);pos=allr.index(rr);segment=text[rr['start']:allr[pos+1]['start'] if pos+1<len(allr) else len(text)]
  prop=by[lm[r['label']]]['properties'];prop['lexical_reference_labels']=sorted(set(re.findall(r'\\(?:eq)?ref\{([^}]+)\}',segment)));prop['lexical_citation_keys']=sorted({k.strip() for keys in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',segment) for k in keys.split(',')})
  prop['lexical_reference_scope']='Statement and following proof/context through next result in same file;references are not automatically mandatory mathematical premises.'
  for key in prop['lexical_citation_keys']:
   if key in bibmaps[prefix]:edge(lm[r['label']],'references',bibmaps[prefix][key],'Lexical citation in source proof/context;not automatically a complete proof dependency')
# Explicit mathematical dependency routes, independently qualified; do not feed the two manuscripts' final mixing conclusions into one another.
manual={
'frames:thm:main':['frames:prop:marginals','frames:lem:trim','frames:prop:lift','frames:lem:degrees','frames:lem:plancherel','frames:lem:fair-sign'],
'frames:shear:cor:512':['frames:shear:prop:fixed-marginal','fourier:l:isotypic','fourier:l:degree-all-powers','fourier:l:trim','frames:lem:fair-sign'],
'frames:shear:thm:2048':['frames:shear:prop:fixed-marginal','frames:shear:prop:disjoint-transfer','frames:lem:fair-sign'],
'fourier:l:main':['fourier:l:isotypic','fourier:l:orbit-span','fourier:l:degree-all-powers'],
'fourier:l:isotypic':['fourier:l:central-isotypic','fourier:l:degree-all-powers'],
'fourier:l:orbit-span':['fourier:l:single-orbit','fourier:l:degree-all-powers'],
'fourier:l:isotypic-completion':['fourier:l:partition-selection','fourier:l:trim','fourier:l:isotypic','fourier:l:degree-all-powers','fourier:l:amplification'],
'fourier:l:orbit-completion':['fourier:l:partition-selection','fourier:l:trim','fourier:l:orbit-span','fourier:l:degree-all-powers','fourier:l:amplification'],
'frames:frames:shadow-entropy':['frames:frames:reference-rows','frames:frames:typical-history'],
'frames:frames:entropy-tail':['frames:frames:shadow-entropy','fourier:l:tilted-entropy'],
'fourier:l:tabloid-product':['fourier:l:tabloid-embedding','fourier:l:tabloid-hs','fourier:l:tabloid-lr'],
'fourier:l:tabloid-completion':['fourier:l:tabloid-product','fourier:l:amplification'],
'fourier:l:forest-hybrid':['fourier:l:forest-clipping','fourier:l:forest-bulk','fourier:l:degree-all-powers'],
'frames:char:main':['frames:char:repair','frames:frames:char:half-list','frames:char:sweep-trace'],
}
def resolve(q):p,l=q.split(':',1);return labelmaps[p][l]
for a,bs in manual.items():
 for b in bs:edge(resolve(a),'depends_on',resolve(b),'Manually qualified source route;not complete dependency closure')
# Reusable contracts: every entry names the exact source conclusion and a failure boundary.
contracts=[
('FIXED-FRAME','frames','lem:frames','固定完整方向表、每d连续方向为基','同一路径律的可逆位置框架','一般初始L0还重标输入；固定表后可用未来','不能作为适应式在线调度算法'),
('HIDDEN-ENERGY','frames','lem:marginal-averaging','合法观察场中的隐藏位置后验与可用位置','双空位平均、单空位运输及精确能量损失','方向前缀/前驱路径前缀；新方向在超平面外均匀','不能加入任意未来辅助信息'),
('TERMINAL-IDENTIFICATION','frames','shear:lem:tuple','终端数据与完整前驱路径','从隐藏能量到实际列表平均TV','额外Lambda下后验必须等于在线pT','一般披露数据不自动满足'),
('COMMON-TRIM','fourier','l:trim','多个补集余类TV误差','一个共同f<=mu，质量>=1-误差和且所有cap1','不归一化；重余类删除是另一个c/(c-1)代价','各自修剪后的不同律不能合成'),
('DISTINCT-ORBIT','fourier','l:single-orbit','一个向量在若干子群类型中的分量','轨道维数<=不同类型维数平方和','每个类型的所有重数均保留','不把全等型维数误当一个向量轨道'),
('ISOTYPIC-CAP','fourier','l:central-isotypic','非负子概率的所有左余类上界','全群加权等型HS能量<=Bza²','质量z和完整投影/Plancherel归一化','不能将算子范数当HS范数直接放大'),
('HS-COMPOSITION','fourier','l:isotypic-completion','八系统平均TV=o1与符号均值=o1','两次独立全排列组合渐近均匀','先选同一分块和共同f，固定正逆幂界','没有实际有限n阈值或廉价实现保证'),
('FIXED-LIST','frames','shear:prop:fixed-marginal','公平二进制循环匹配中的指定大列表','正逆向与相位一致的有限表达TV界','至少固定正比例遗漏储备、实际物理步计数','一牌均匀不能替代联合律'),
('SHEAR-DISCLOSURE','frames','shear:lem:keys','与开关独立的剪切键','方向前缀产品律和新方向条件分解','整方向表后的剩余键不改虚拟路径律需对应因子分解','不能把条件键等式当任意观测独立'),
('DELAYED-SYMMETRY','frames','shear:lem:delayed-symmetry','原观察场中的集合B0和质量p0','穿越前若干不改半空间的延迟对称','保持p0原定义；过去完整开关只固定函数','不能重定义为全牌后验再沿用证明'),
('FULL-PATH-CYLINDER','frames','frames:conditional-interface','完整可行固定标签路径与给定方向表','隐藏前缀律不受其余合法路径披露改变','公平独立时间边开关，观察是可行圆柱','自适应选择/未来辅助披露要另证'),
('BACKWARD-REMOVAL','frames','frames:backward-removal','固定分块、固定补集次序、共同能量事件','同一子概率中所有补集cap2','倒序去除后续约束；归一化最终cap4','不独立修剪各个补集'),
('STOPPED-LIST','frames','frames:stopped-marginals','嵌套的阶段/时间平衡事件','322d指定列表界及一次坏事件预算','保留真实端点耦合核，不条件化历史成功','不能按牌数重复计坏事件或改变耦合目标'),
('REFERENCE-ROWS','frames','frames:reference-rows','给定其余标签完整路径的隐藏后验','用参考历史重索引得到行随机流','参考完整历史仅索引，条件仍是已观察标签','不能宣称隐藏牌独立'),
('ALL-TILTS','fourier','l:tilted-entropy','共同G上每个sigma相对原P的熵不等式','稀有矩阵系数事件尾及条件算子界','先选G后选sigma/u/z；条件化损失1/a','单律熵或P平均小不够'),
('KERNEL-SIGN-FIBER','fourier','l:equivariant-sixteen','双随机等变核的平均补集商误差','16次核平均TV混合','额外完整符号重数HS趋零；最坏起点还需传递等变','整体标量符号公平不够'),
('KERNEL-ROW-COLUMN','fourier','l:three-group','三组核每行每列商TV控制','15次核平均TV混合','未裁剪全符号矩阵绝对行列和趋零','不能仅平均行或标量奇偶替换'),
('ORDERED-CAPS','fourier','l:two-sided','alpha右余类与beta左余类上界','widehatbeta*widehatalpha的HS控制','乘积顺序/两侧总质量/完整联合类型数','像边际不自动是逆像边际'),
('SPECTRAL-PRUNING','fourier','l:spectral-pruning','16固定补集整个商分布误差','一个共同nu<=mu的常数一谱上界','对完整坏测试并集只用一次delta','没有给大规模执行的成本界'),
('OMITTED-PROJECTIONS','fourier','l:omitted-set-transfer','随机遗漏储备平均误差','共同条件事件与八次放大','标量平均投影，非交换投影乘积次序保持','不能换成独立/交换投影'),
('PALETTE-CAP','fourier','l:palette-information','两种半优先次序的逐点累积揭露误差','所有调色板余类信息上界','同一G上逐点界；各历史和两半一致','普通原P平均在稀有Q下不保留'),
('SIGNED-PALETTE','fourier','l:signed-palette','对称群不可约类型','一维带符号子角色与熵复杂度<=C logD','所有类大小放置都有效，Pieri谱系仍未完整审核','存在性不提供高效构造'),
('ENTROPY-CLIP','fourier','l:replica-clipping','同一律q个边际相对熵总K','共同v<=w，损失<=(K+q/e)/t及cap exp(t)','未归一化质量变换；碰撞checkv*v次序','不能由大维数吸收推所有维数'),
('SPARSE-HYBRID','fourier','l:forest-hybrid','熵受控mu及另一个独立核K','mu^12*K^40混合','K有小首行缺口衰减及高首列精确零','K不是未经证实的mu卷积根'),
('CONDITIONAL-PRODUCT','fourier','l:tabloid-product','给定Z后的实际半群乘积与独立xi逆像cap','算子<=sqrt22 D^-1/40','两半每个缓冲补集cap2，L>=4000000','只有条件均匀边际、无独立不能直接用'),
('DEPENDENT-HALF-REPAIR','frames','char:repair','两半像注入边际误差与分块误差','精确条件均匀边际、TV<=eps1+eps2+3epspart','允许联合依赖，分别耦合后再修分块','不产生条件乘积分布或高效采样器'),
('CHARACTER-ORDER','frames','frames:char:block-norm','BP独立通行与长混合段','有条件的角色平滑算子幂衰减','输出半牌前像cap及保留所有乘数','PB半牌像修复是另一条路线'),
('INVERSE-DEGREES','fourier','l:degree-all-powers','固定u>0的对称群表示次数','Cu有限且非线性逆幂尾消失','先固定u；去掉平凡/符号；有效阈值未知','旧LS2004更强率已足够，不算新收益'),
('SUBCHARACTER','fourier','l:small-index-character','对称群不可约表示D','含符号一维子角色指数<=D^1024','子群存在性、完整重数','不等于现实低成本算法'),
('PEELING','fourier','l:peeling-character','Young图最长行列逐次移除','子角色指数<=D^(512²)','b=2^22的最终转移仅大块渐近','替代证明不计新的应用卡片')]
method_ids=[]
for key,prefix,label,inp,out,cond,lim in contracts:
 id='PART-238-COMP-'+key;claim=labelmaps[prefix][label];s=copy.deepcopy(by[claim]['sources'][0]);s['locator']+=';curated transferable I/O and failure boundary'
 add(id,'method',{'title':key,'family_ids':['F-238'],'input':inp,'output':out,'conditions':cond,'cannot_transfer':lim,'credibility':'C'},[s]);edge(id,'depends_on',claim,'Exact source conclusion and scoped conditions');ap['method_ids'].append(id);method_ids.append(id)
# First-class unresolved application premises: these are gaps, not counted new candidate hypotheses.
gaps=[('PROB-238-COMP-FINITE-THRESHOLD','有效有限规模与预算','512d和两卷积结论仍为渐近；没有可部署d0、误差容差和全成本比较。'),('PROB-238-COMP-CONDITIONAL-PRODUCT','真实条件乘积分布','给定环境后的两半必须实际独立；条件均匀边际不能推出乘积。'),('PROB-238-COMP-SIGN-MULTIPLICITY','完整符号重数控制','核路线需要完整符号纤维矩阵的HS或行列和，整体均值公平不够。'),('PROB-238-COMP-ALL-TILTS','共同事件与每个倾斜律','普通单律熵、平均边际或分开好事件不能代替共同G上所有倾斜律。')]
for id,title,detail in gaps:add(id,'problem',{'title':title,'family_ids':['F-238'],'prerequisite_status':'unestablished_for_real_application','statement':detail,'credibility':'unknown'},[src('data/provenance/readings/F-238-companions-formal.json','Explicit scope exclusion and unestablished application premise')],'source_content_checked')
# Retain current APP23802 exactly; new qualified gaps route to it without altering its original prediction or test plan.
for id,_,_ in gaps:edge('APP-238-02','references',id,'Supplementary route qualification gap,not assertion that original candidate necessarily uses every alternative')
attempts=[('software randomization QA','near','已有APP23801/02；公平循环开关、真实观察与联合律目标才吻合，不再复制一张卡。'),('warehouse routing','near','固定带储备列表有结构类比；容量/自适应调度改变路径圆柱，尚无实际输入。'),('biological lineage','far','共同观测事件与遗漏谱有类比，选样/删失不必是固定公平路径。'),('materials transport','far','平均与运输能量可作结构提示，实数扩散非置换核，未建立比较裁判。'),('traffic scheduling','far','左右边际不同有诊断意义；拥堵/先后约束不满足全对称群参考律。'),('energy allocation','far','均匀代币置换可类比；实际负荷权重与动态约束未匹配。'),('language generation audits','bold','单平均与全倾斜条件差别值得保留；非可逆序列过程及共同G没有构造，不能搬用指数。'),('financial stress paths','far','端点/路径条件差别可提示审计；真实非均匀历史和相关性通常是目标。'),('causal experiment allocation','far','条件于共同事件的边际修复与公平性有关，但独立半边与完整随机置换目标未准入。'),('robotics swarm assignment','far','不完全观测后余留分配像有限置换；碰撞/几何可行性改支持，尚无外部收益证据。')]
cross=[{'families':['F-238','F-131'],'finding':'两种受约束随机置换都要保留真实一步与停止时钟；图换边核不能用Thorp二进制方向表替换。'},{'families':['F-238','F-139'],'finding':'TV目标和计算成本都须声明；只收紧查询数或物理步不提供端到端高效算法。'},{'families':['F-238','F-221'],'finding':'平均/全部倾斜与限制类型要区分；Poisson自旋模型不满足对称群余类接口，暂无可证伪联合应用。'}]
expl=add('EXPLORE-F-238-COMPANIONS','exploration',{'title':'F238坐标框架与Fourier接口的十域和三跨族尝试','family_ids':['F-238'],'attempts':[{'domain':d,'analogy':a,'assessment':s,'accepted_connection':False} for d,a,s in attempts],'cross_family_attempts':cross,'new_connection_ids':[],'interpretation':'结构联想与负面接口资格结果；不是应用初检、实用性否定或新数学发现。','credibility':'unknown'},[src('state/reading-progress/WP-110.json','Complete selected reading record;qualified interface exploration')],'hypothesis')
for id in method_ids:edge(expl['id'],'uses',id,'Structural mapping attempt;not verified application value')
# Family ledger/version: preserve old95 bindings andfour source drafts, append these two only.
ap['manuscript_source_drafts_complete_ids']+= [m['manuscript_id'] for m in read['manuscripts']];assert len(set(ap['manuscript_source_drafts_complete_ids']))==6
ap['source_line_count']+=10336;ap['completion_basis']='Six of12current source manuscripts read/decomposed;227 qualified named-result bindings (95prior+63frames+69Fourier),sixremainingbodies unread. Aliases not extra results;not227independentnewtheorems. Complete historical/formal/human closure remains missing.'
ap['formal_statement_comparison']+=formal['comparisons'];ap['formal_status']['frames_fourier_selected_scope']=formal;ap['source_decomposition_draft_complete']=False;ap['full_family_complete']=False;ap['historical_lineage_complete']=False
ap['quantifier_and_boundary_notes']+=list(dict.fromkeys(notes.values()))
ap['gaps']=[('PriorWP035/036scope snapshot: '+g) if ('Eight other' in g or '11of16' in g or '10of17' in g) else g for g in ap['gaps']]
ap['gaps']+=['Current6/12source drafts;the other six current manuscripts remain unread/decomposed.','Two new originals in selected scopes/fivePDFpages;LarsenShalev2008 download returnednonPDF and original remains unverified;Pieri/LR/James/Sagan/fullrecursiveclosure remains open.','Selected finite Fourier mainB and32800d conclusionB only;130new resultsC,fullchainsunknown. Actual32800dLeanproofuses1600dmonotonicity,notnaturalindependentroute;512d andtwo-convolution asymptotics outside selected scope.','No new actual application workload,finite threshold,numerical run,independent provider or human review;APP23801/02 unchanged.']
for prefix,m in [('frames',read['manuscripts'][0]),('fourier',read['manuscripts'][1])]:
 ledger='data/provenance/readings/F-238-'+prefix+'.json';ap['manuscript_reading_ledgers'][m['manuscript_id']]=ledger
 save(ledger,{'work_package':'WP-110','generation_id':GEN,'at':now,'family_id':'F-238','manuscript_id':m['manuscript_id'],'upstream_commit':COMMIT,'status':'full_current_source_decomposition_draft','full_natural_source_read':True,'independent_mathematical_proof_audit':False,'read_files':m['tex_files'],'tex_files_total':len(m['tex_files']),'tex_lines_total':sum(f['lines'] for f in m['tex_files']),'named_results':len(rows_by_prefix[prefix]),'aliases_not_extra_results':sum(len(r['aliases']) for r in rows_by_prefix[prefix]),'canonical_result_ids':{r['label']:labelmaps[prefix][r['label']] for r in rows_by_prefix[prefix]},'all132_result_statements_reviewed':True,'section_scope_notes':notes,'formal_evidence':'data/provenance/readings/F-238-companions-formal.json','historical_evidence':'data/provenance/readings/F-238-companions-history.json','bibliography_keys':bibmaps[prefix],'method_contract_ids':method_ids,'full_family_complete':False,'application_checks_added':0,'scientific_experiments':[]})
# Exact research config and full primary retrieval metadata are sources for this generation.
config='data/provenance/research-at-generation-107.json';Path(config).write_bytes(Path('configs/research.json').read_bytes())
add(GEN,'generation',{'title':'F238 two companion source decompositions,formal/historical scope andtransfer contracts','family_ids':['F-238'],'project_base_commit':subprocess.check_output(['git','rev-parse',BASE]).decode().strip(),'provider':'OpenAI','model':'Current user-selected session;exact backend unknown','human_review':None,'independent_second_provider':None,'credibility':'unknown'},[src(config,'Research execution policy snapshot atgeneration107'),src('data/provenance/readings/F-238-frames.json','Complete actual source ledger andqualifiedbindings'),src('data/provenance/readings/F-238-fourier.json','Complete actual source ledger andqualifiedbindings')],'source_content_checked')
# Stable family analysis cites both immutable new ledgers, not the changing working journal.
analysis['sources'] +=[src('data/provenance/readings/F-238-'+p+'.json','WP110complete selected source ledger;qualificationnotfullfamily') for p in ['frames','fourier']]
# Keep exact old canonical JSONL lines for every untouched record.
gzsave(history_path,{'at':now,'generation_id':GEN,'reason':'Version family reading/formal scope andshared bibliography/original selected scopes;oldsourceclaims/versions preserved','nodes':[oldrecords[id] for id in sorted(modified)]})
coveragep=Path('data/graph/reading_coverage.json');oldcoverage=coveragep.read_bytes();gzsave('data/graph/history/GEN-20261026-107-reading-coverage-before.json.gz',json.loads(oldcoverage));coverage=json.loads(oldcoverage);coverage['partially_read_families']['F-238']+=['WP110 two current companions38TeX10336lines fullyread;63frames+69Fourier namedbindings,sixaliases notextra;6/12current source drafts/227bindings,notfullfamily.','Two selected mainB/130newC/fullchainunknown;120local Lean import-file entries across2indices onlystatic;actual32800dproofmonotonicitynotnaturalroute.','Two original works inselected scopes and5PDFpages;LS2004/KLS2024selected scopes reused,2008Larsenoriginalunavailable/Pieri/LR/fullhistoryopen.','30methodcontracts,10domain/3crossfamilyattempts andfourexplicitpremisegaps;no newcandidate,check,experiment,humanorproviderreview.'];coverage['updated_at']=now;save(coveragep,coverage)
np.write_text('\n'.join(json.dumps(by[json.loads(line)['id']],ensure_ascii=False,sort_keys=True) if json.loads(line)['id'] in modified else line for line in oldlines)+'\n'+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new));ep.write_bytes(oldedges+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges[len(oldedges.decode().splitlines()):]).encode())
assert all(by[id]==oldrecords[id] for id in oldrecords if id not in modified);assert len(ap['result_ids_by_label'])==227;assert len(contracts)==30
summary={'generation':GEN,'base_commit':BASE,'old_records':len(oldrecords),'new_records':len(new),'modified_old_record_ids':sorted(modified),'new_explicit_edges':len(edges)-len(oldedges.decode().splitlines()),'named_bindings':132,'label_aliases_not_extra_results':6,'method_contracts':len(method_ids),'family_source_drafts':'6/12','family_result_bindings':227,'new_source_B':2,'new_source_C':130,'new_candidates':0,'new_application_checks':0,'new_scientific_experiments':0,'new_literature_nodes':new_literature,'bibliography_maps':bibmaps}
save(work/'curation-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
