from pathlib import Path
from datetime import datetime,timezone
import gzip,json,shutil
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP112-publication'
cand=json.loads((work/'public-candidate.json').read_text())
v=json.loads(gzip.decompress((work/'verification.json.gz').read_bytes()))
ci=json.loads(gzip.decompress((work/'CI-observation.json.gz').read_bytes()))
assert v['head_commit']==cand['commit'] and v['full_tree_equal'] and v['official_math_paths']==0
shutil.copyfile(work/'verification.json.gz',out/'verification.json.gz')
shutil.copyfile(work/'CI-observation.json.gz',work/'CI-first-observation.json.gz')
p=json.loads((root/'state/publication.json').read_text())
p['pending_batch'].update({'status':'pushed_remote_verified_ci_in_progress','commit':cand['commit'],'tree':cand['tree'],'verification_receipt':str((out/'verification.json.gz').relative_to(root)),'remote_verified':True,'ci':ci})
(root/'state/publication.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
c=json.loads((root/'state/checkpoint.json').read_text());c['saved_at']=datetime.now(timezone.utc).isoformat()
c['publication_work'].update({'status':'pushed_remote_verified_ci_in_progress','pending_public_commit':cand['commit'],'pending_public_tree':cand['tree'],'pending_ci_run':ci['runs'][0]['id'],'active_push_exec_session':None,'synchronization_status':'remote_tree_verified_ci_pending'})
(root/'state/checkpoint.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'remote_verified':cand['commit'],'ci':ci['runs'][0]['status']}))
