from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,tarfile
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP112-publication'
def read(p):return json.loads((root/p).read_text())
def save(p,d):(root/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
cand=json.loads((work/'public-candidate.json').read_text())
v=json.loads(gzip.decompress((work/'verification.json.gz').read_bytes()))
ci=json.loads(gzip.decompress((work/'CI-observation.json.gz').read_bytes()))
assert v['head_commit']==cand['commit'] and v['full_tree_equal'] and v['official_math_paths']==0
assert all(x['byte_equal'] for x in v['anonymous_file_reads'])
assert ci['commit']==cand['commit'] and ci['runs']
assert all(r['status']=='completed' and r['conclusion']=='success' for r in ci['runs'])
for name in ['verification.json.gz','CI-observation.json.gz']:shutil.copyfile(work/name,out/name)
raw=(work/'final-audit.json').read_bytes();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
(out/'final-audit.json.gz').write_bytes(packed)
members=sorted(p for p in work.iterdir() if p.is_file())
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for p in members:
        raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for p in members:assert t.extractfile(p.name).read()==p.read_bytes()
(out/'postpublication-helpers-and-receipts.tar.gz').write_bytes(packed)
now=datetime.now(timezone.utc).isoformat()
p=read('state/publication.json');assert p['verified_commit']==cand['parent']
p['prior_verifications'].append({k:p[k] for k in ['verified_at','verified_commit','verified_tree','verification_receipt','verification_scope','latest_scoped_ci','latest_ci_receipt','latest_ci_conclusion']})
p.update({'state':'published','public':True,'remote_verified':True,'verified_at':v['at'],'verified_commit':cand['commit'],'verified_tree':cand['tree'],'verification_receipt':str((out/'verification.json.gz').relative_to(root)),'anonymous_api_verification':not bool(v['api_fallbacks']),'upstream_math_paths':0,'upstream_math_included':False,'verification_scope':'Completed WP112 GEN109 plus unfinished WP113 actual full-source reading and selected formal/history checkpoint; exact full remote tree and seven anonymous byte-equal reads; no official math or bulk local history','latest_progress_packages':['WP-111','WP-112'],'latest_scoped_ci':ci,'latest_ci_receipt':str((out/'CI-observation.json.gz').relative_to(root)),'latest_ci_conclusion':'success','anonymous_public_file_reads':7,'incomplete_reading_journal':'state/reading-progress/WP-113.json','pending_batch':None,'latest_snapshot_files':v['files'],'latest_snapshot_bytes':v['total_bytes'],'local_progress_after_verified_snapshot':'Only post-push receipts/checkpoint saved locally; WP113 canonical qualification and mandatory global040 remain pending.','receipt_storage_scope':'Post-push verification and CI saved locally; no extra push solely for receipts.'})
save('state/publication.json',p)
c=read('state/checkpoint.json');c['saved_at']=now
c['release_state']='Public MathWeave '+cand['commit']+' through WP112 GEN109 and unfinished WP113 checkpoint; exact tree/seven public files verified, scoped CI success.'
c['publication_work'].update({'status':'published_verified_ci_success','latest_public_commit':cand['commit'],'latest_public_tree':cand['tree'],'latest_ci':ci['runs'],'latest_verification_receipt':p['verification_receipt'],'latest_ci_receipt':p['latest_ci_receipt'],'synchronization_status':'published_verified','pending_public_commit':None,'pending_public_tree':None,'pending_ci_run':None,'active_push_exec_session':None,'current_local_research_not_yet_pushed':p['local_progress_after_verified_snapshot'],'scientific_local_commit':cand['local_commit'],'receipt_storage_scope':p['receipt_storage_scope'],'current_batch_qa':read(str((out/'quality.json').relative_to(root)))})
c['recovery_commands'][4]='Public '+cand['commit']+' through WP112 and unfinished WP113 verified; scoped CI success. Keep routine work local; resume WP113 canonical curation, then mandatory global040.'
c['recovery_observation']['publication_boundary']={'at':now,'running_project_processes':[],'new_scientific_experiments':0,'expensive_experiments_repeated':False,'math_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','math_clean':True,'public_commit':cand['commit'],'next_action':c['active_work_package']['next_action']}
save('state/checkpoint.json',c)
with (root/'state/status.md').open('a') as f:f.write('\n\n发布后核验（'+now+'）：MathWeave公开提交'+cand['commit']+'，'+str(v['files'])+'文件／'+str(v['total_bytes'])+'字节；全树路径／模式／大小／blob相等，七公开入口匿名字节一致，官方math路径0。CI实际completed/success，覆盖69核心、13既有归档重放、导出和发布审计；研究及人审未因此验收。后验收据仅本地提交，不追加推送。WP113规范整理与强制复盘040仍待完成，整体active_incomplete。\n')
save(str((out/'postpublication-storage.json').relative_to(root)),{'at':now,'members_verified':len(members),'compressed_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'temporary_publication_helpers_removed':False,'third_party_source_downloads_published':False,'incomplete_WP113_work_retained':True,'new_scientific_experiments':0})
print(json.dumps({'verified_public_commit':cand['commit'],'ci':'success','files':v['files'],'bytes':v['total_bytes'],'math_paths':0,'receipts_local_only':True}))
