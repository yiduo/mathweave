from pathlib import Path
import json
work=Path(__file__).resolve().parent
source=(work/'verify.py').read_text()
ns={'__file__':str(work/'verify.py')}
exec(compile(source[:source.index("if '--ci-only' not in sys.argv:")],str(work/'verify.py'),'exec'),ns)
observed=json.loads(ns['gzip'].decompress((work/'CI-observation.json.gz').read_bytes()))
run=observed['runs'][0]
jobs=ns['js'](ns['base']+'/actions/runs/'+str(run['id'])+'/jobs')
summary={'at':ns['datetime'].now(ns['timezone'].utc).isoformat(),'run_id':run['id'],'commit':run['head_sha'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'steps':j['steps']} for j in jobs['jobs']]}
ns['save']('CI-jobs-observation.json.gz',summary)
print(json.dumps(summary))
