from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,urllib.error,urllib.request,sys

root=Path('/Users/smzdm/projects/ai_paper')
work=Path(__file__).resolve().parent
c=json.loads((work/'public-candidate.json').read_text())
base='https://api.github.com/repos/yiduo/mathweave'
fallbacks=[]
def get(url):
    headers={'User-Agent':'MathWeave-owner-publication-verification','Cache-Control':'no-cache'}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as r:return r.read()
    except urllib.error.HTTPError as e:
        if e.code!=403 or not url.startswith(base):raise
        credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,check=True,cwd=root)
        fields=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
        assert fields.get('password') and fields.get('host')=='github.com'
        headers['Authorization']='Bearer '+fields['password']
        fallbacks.append({'endpoint':url[len(base):],'anonymous_status':403,'retry':'configured GitHub credential helper; secret not logged or saved'})
        with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as r:return r.read()
def js(url):return json.loads(get(url))
def save(name,x):
    raw=json.dumps(x,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0)
    assert gzip.decompress(packed)==raw
    (work/name).write_bytes(packed)
if '--ci-only' not in sys.argv:
    repo=js(base);head=js(base+'/git/ref/heads/main');remote=js(base+'/git/commits/'+c['commit']);tree=js(base+'/git/trees/'+c['tree']+'?recursive=1')
    assert repo['private'] is False and repo['id']==1429150108 and repo['full_name']=='yiduo/mathweave'
    assert head['object']['sha']==c['commit'] and remote['tree']['sha']==c['tree']
    assert [p['sha'] for p in remote['parents']]==[c['parent']]
    assert tree['sha']==c['tree'] and not tree['truncated']
    expected={}
    for line in subprocess.check_output(['git','ls-tree','-r','-z','--long',c['commit']],cwd=root).split(b'\0'):
        if not line:continue
        meta,path=line.split(b'\t');mode,kind,sha,size=meta.decode().split()
        expected[path.decode()]={'mode':mode,'type':kind,'sha':sha,'size':int(size)}
    actual={x['path']:{k:x[k] for k in ['mode','type','sha','size']} for x in tree['tree'] if x['type']=='blob'}
    assert actual==expected and len(actual)==c['files']
    assert not any(p=='math' or p.startswith('math/') for p in actual)
    observed=[]
    for p in ['README.md','README.en.md','CHARTER.en.md','PROGRESS.en.md','reports/metrics.json','reports/retrospectives/039-conditional-transfer-and-coverage-rotation.md','state/reading-progress/WP-113.json']:
        want=subprocess.check_output(['git','show',c['commit']+':'+p],cwd=root)
        got=get('https://raw.githubusercontent.com/yiduo/mathweave/'+c['commit']+'/'+p)
        assert want==got,p
        observed.append({'path':p,'bytes':len(got),'sha256':hashlib.sha256(got).hexdigest(),'byte_equal':True,'authentication':'none'})
    receipt={'at':datetime.now(timezone.utc).isoformat(),'repository':repo['html_url'],'repository_id':repo['id'],'public':True,'head_commit':c['commit'],'tree':c['tree'],'parent':c['parent'],'full_tree_equal':True,'files':len(actual),'total_bytes':sum(x['size'] for x in actual.values()),'official_math_paths':0,'anonymous_file_reads':observed,'api_fallbacks':fallbacks.copy(),'bulk_local_history_included':False,'phase_one_complete':False}
    save('verification.json.gz',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['anonymous_file_reads','api_fallbacks']}),flush=True)
run_path='/actions/runs?head_sha='+c['commit']+'&per_page=10'
runs=js(base+run_path)
selected=[{k:r[k] for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at']} for r in runs['workflow_runs'] if r['head_sha']==c['commit']]
# Direct run reads avoid a previously observed stale list response.
selected=[{k:v for k,v in js(base+'/actions/runs/'+str(r['id'])).items() if k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at']} for r in selected]
ci={'at':datetime.now(timezone.utc).isoformat(),'commit':c['commit'],'runs':selected,'api_fallbacks':fallbacks,'scope':'69 core checks,13 archived replays,exports and publication audit; no EXP076 strict Linux,optional NumPy,Lean,human/provider or research acceptance'}
save('CI-observation.json.gz',ci)
print(json.dumps(ci))
