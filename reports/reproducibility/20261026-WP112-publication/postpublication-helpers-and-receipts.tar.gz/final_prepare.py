from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP112-publication'
q=json.loads((out/'quality.json').read_text())
assert q['core_exit_code']==0 and q['local_core_exit_code']==0
assert not subprocess.check_output(['git','diff','7b5bdf9','--','data','experiments','src','tests','reports/families','reports/graph'],cwd=root)
c=json.loads((root/'state/checkpoint.json').read_text());c['saved_at']=datetime.now(timezone.utc).isoformat()
c['publication_work']['current_batch_qa']=q;c['publication_qa_evidence']=str(out.relative_to(root))
c['publication_work']['status']='checks_passed_pending_staged_audit_push_readback_ci'
(root/'state/checkpoint.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
with (root/'state/status.md').open('a') as f:
    f.write('\n\n本批发布前核验：69核心及完整来源审计退出0；无math干净副本'+str(q['files'])+'文件／'+str(q['bytes'])+'字节逐项散列一致且核心退出0，副本已删除。规范科学数据／源码测试／实验／族报告与图谱导出保持7b5bdf9；WP112既有26传播和15归档267成员证据保留。自有日志／代码已压缩回解验证。精确索引审计、实际推送／回读／CI仍分别取证；不新增研究检验信用。\n')
print(json.dumps({'preparation_complete':True,'qa':str(out.relative_to(root))}))
