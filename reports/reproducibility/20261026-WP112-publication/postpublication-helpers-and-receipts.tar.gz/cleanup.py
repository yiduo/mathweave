from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,tarfile
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP112-publication'
s=json.loads((out/'postpublication-storage.json').read_text())
a=out/'postpublication-helpers-and-receipts.tar.gz'
packed=a.read_bytes();raw=gzip.decompress(packed)
assert hashlib.sha256(packed).hexdigest()==s['compressed_sha256']
assert hashlib.sha256(raw).hexdigest()==s['decompressed_sha256']
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for p in work.iterdir():
        assert p.is_file()
        assert t.extractfile(p.name).read()==p.read_bytes()
assert str(work)=='/private/tmp/mathweave-WP112-publication'
shutil.rmtree(work)
s['temporary_publication_helpers_removed']=True;s['removed_at']=datetime.now(timezone.utc).isoformat()
(out/'postpublication-storage.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
c=json.loads((root/'state/checkpoint.json').read_text());c['saved_at']=s['removed_at']
c['recovery_observation']['publication_boundary'].update({'local_temporary_publication_root_removed':True,'all_local_quality_handles_terminal':True,'incomplete_WP113_work_retained':True})
(root/'state/checkpoint.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'publication_temporary_removed':True,'postpublication_members_verified':s['members_verified'],'incomplete_WP113_research_retained':True}))
