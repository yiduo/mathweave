from pathlib import Path
import json, os, subprocess

root=Path('/Users/smzdm/projects/ai_paper')
work=Path(__file__).resolve().parent
def git(*args,**kwargs):
    return subprocess.check_output(['git',*args],cwd=root,**kwargs).decode().strip()
audit=json.loads((work/'final-audit.json').read_text())
assert audit['failure_count']==0 and audit['upstream_math_paths']==0
assert not git('status','--porcelain=v1')
parent='21ce7dcf480ef0d423626596b10ff2ccb8efc170'
assert git('ls-remote','origin','refs/heads/main').split()[0]==parent
tree=git('rev-parse','HEAD^{tree}')
assert not git('ls-tree','-r','--name-only','HEAD','--','math')
env=dict(os.environ,GIT_AUTHOR_NAME='MathWeave contributors',GIT_AUTHOR_EMAIL='yiduo@users.noreply.github.com',GIT_COMMITTER_NAME='MathWeave contributors',GIT_COMMITTER_EMAIL='yiduo@users.noreply.github.com')
commit=git('-c','commit.gpgsign=false','commit-tree',tree,'-p',parent,'-m','Publish MathWeave consumer audit and unfinished F020 reading checkpoint',env=env)
assert git('rev-list','--count',commit,'^'+parent)=='1'
candidate={'repository':'https://github.com/yiduo/mathweave','commit':commit,'tree':tree,'parent':parent,'local_commit':git('rev-parse','HEAD'),'files':audit['files'],'bytes':audit['total_bytes'],'upstream_math_paths':0,'bulk_local_history_included':False,'state':'prepared_not_pushed','ci':'unobserved'}
(work/'public-candidate.json').write_text(json.dumps(candidate,indent=2)+'\n')
print(json.dumps(candidate))
