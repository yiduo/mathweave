from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request
W=Path(__file__).resolve().parent;D=W/'history';D.mkdir(exist_ok=True)
rows=[('Reuss2015PowerFree','https://arxiv.org/html/1307.2802v1'),('Xiao2017PowerFree','https://arxiv.org/html/1505.05587v2'),('HeathBrown2013Powerfree','https://arxiv.org/html/1103.2028v1')]
rows += [('stacks-project-'+tag,'https://stacks.math.columbia.edu/tag/'+tag) for tag in ['00NQ','02JN','00NB','00NA','031Q','031R']]
cap=8*1024*1024;total=0;manifest=[]
for name,url in rows:
 p=D/(name+'.html');assert not p.exists()
 req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-bounded-source-inspection'})
 with urllib.request.urlopen(req,timeout=40) as response:
  raw=response.read(cap-total+1);assert len(raw)<=cap-total
  metadata={k:response.headers.get(k) for k in ['Content-Type','ETag','Last-Modified']}
 p.write_bytes(raw);total+=len(raw)
 manifest.append({'work':name,'url':url,'retrieved_at':datetime.now(timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'response_headers':metadata,'temporary_path':str(p),'scope':'OriginalHTMLversion/tag body;downloadhashnotfullreadingorproofreview'})
 (W/'history-acquisition.json').write_text(json.dumps({'works':4,'files':manifest,'total_bytes':total,'budget_bytes':cap,'scientific_experiments':0,'full_source_bodies_for_publication':False},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'name':name,'bytes':len(raw),'total':total}),flush=True)
