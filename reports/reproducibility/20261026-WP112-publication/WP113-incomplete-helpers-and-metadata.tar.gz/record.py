from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
R=Path('/Users/smzdm/projects/ai_paper');W=Path(__file__).resolve().parent
payload=json.loads(Path(sys.argv[1]).read_text());now=datetime.now(timezone.utc).isoformat()
p=R/'state/reading-progress/WP-113.json';j=json.loads(p.read_text())
assert payload['batch'] not in [x['batch'] for x in j.get('reading_batches',[])]
for suffix in payload['files']:
 f=next(f for f in j['source_files'] if f['path'].endswith('/'+suffix))
 raw=(R/f['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==f['sha256']
 assert len(raw.decode().splitlines())==f['lines']
 f['actually_read']=True;f['actually_read_ranges']=[[1,f['lines']]]
j['actual_source_files_read']=[f for f in j['source_files'] if f['actually_read']]
j['actual_source_lines_read']=sum(f['lines'] for f in j['actual_source_files_read'] if f['path'].endswith('.tex'))
j['actual_full_tex_files_read']=sum(f['path'].endswith('.tex') for f in j['actual_source_files_read'])
j['bibliography_lines_read']=sum(f['lines'] for f in j['actual_source_files_read'] if f['path'].endswith('.bib'))
j.setdefault('reading_batches',[]).append({'batch':payload['batch'],'at':now,'files':payload['files'],'notes':payload['notes']})
j['provisional_reading_notes'].extend(payload['notes']);j['updated_at']=now;j['next_action']=payload['next']
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'state/backlog.json';b=json.loads(p.read_text());task=next(t for t in b['tasks'] if t['id']=='WP-113')
task['execution_progress'].update({'files_fully_read':j['actual_full_tex_files_read'],'tex_lines_read':j['actual_source_lines_read'],'bibliography_lines_read':j['bibliography_lines_read']});task['next_action']=payload['next'];b['updated_at']=now;p.write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
p=R/'state/checkpoint.json';c=json.loads(p.read_text());c['saved_at']=now;c['active_work_package']=task;c['next_work_package']=task;c['recovery_commands'][2]=payload['next'];c['recovery_commands'][3]=f"WP113 actuallyread{j['actual_full_tex_files_read']}TeX/{j['actual_source_lines_read']}lines and{j['bibliography_lines_read']}Bib;fullsource qualification/formal/history/canonical stages remainpending. No newapplicationcredit."
c['previous_goal_turn_classification']={'classification':'progress','evidence':'Previous goal turn completedWP112 GEN10924records83edges/26impact/69core/no-mathclean/15archives267members,compressedcleanup andlocal7b5bdf9;startedF0201375actualsource lines andsaved97190fe. No GitHubupdate.'}
p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actual_tex_files':j['actual_full_tex_files_read'],'actual_tex_lines':j['actual_source_lines_read'],'bib_read':j['bibliography_lines_read'],'canonical_credit':False}))
