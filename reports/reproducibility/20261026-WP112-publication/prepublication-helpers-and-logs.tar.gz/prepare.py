from pathlib import Path
from datetime import datetime, timezone
import gzip,hashlib,io,json,tarfile

root=Path('/Users/smzdm/projects/ai_paper')
work=Path(__file__).resolve().parent
research=Path('/private/tmp/ai-paper-WP113')
out=root/'reports/reproducibility/20261026-WP112-publication'
out.mkdir(exist_ok=True)
now=datetime.now(timezone.utc).isoformat()
def load(name):return json.loads((root/name).read_text())
def save(name,obj):(root/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def pack(files,target):
    buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w') as t:
        for name,path in files:
            raw=path.read_bytes(); info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0
            t.addfile(info,io.BytesIO(raw))
    raw=buf.getvalue();packed=gzip.compress(raw,mtime=0)
    assert gzip.decompress(packed)==raw
    with tarfile.open(fileobj=io.BytesIO(raw)) as t:
        for name,path in files:assert t.extractfile(name).read()==path.read_bytes()
    target.write_bytes(packed)
    return {'members':len(files),'compressed_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'all_members_verified':True}

j=load('state/reading-progress/WP-113.json')
assert j['actual_source_lines_read']==3967 and j['canonical_credit_added'] is False
old=(root/'state/reading-progress/WP-113.json').read_bytes()
history=root/'state/reading-progress/history/WP113-before-WP112-publication.json.gz'
assert not history.exists();history.write_bytes(gzip.compress(old,mtime=0));assert gzip.decompress(history.read_bytes())==old
formal=json.loads((research/'formal-scope.json').read_text())
historical=json.loads((research/'history-scope.json').read_text())
for row in j['actual_source_files_read']+formal['actual_read_files']:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
acquired=json.loads((research/'history-acquisition.json').read_text())
for row in acquired['files']:
    assert hashlib.sha256(Path(row['temporary_path']).read_bytes()).hexdigest()==row['sha256']
assert len(acquired['files'])==9
members=sorted((p.name,p) for p in research.iterdir() if p.is_file())
assert all(p.suffix in {'.json','.py','.md','.log','.gz'} for _,p in members)
storage=pack(members,out/'WP113-incomplete-helpers-and-metadata.tar.gz')
storage.update({'at':now,'third_party_bodies_included':False,'external_body_hashes_verified':9,'external_bytes_retained_temporarily_for_incomplete_research':sum(r['bytes'] for r in acquired['files']),'temporary_work_retained_for_incomplete_task':True,'numerical_experiments':0})
save(str((out/'reading-storage.json').relative_to(root)),storage)
j['updated_at']=now
j['publication_recovery']={'at':now,'previous_version':str(history.relative_to(root)),'reason':'Preserve actual completed reading and selected formal/historical scope before owner-requested publication; canonical qualification still pending.','archive':str((out/'WP113-incomplete-helpers-and-metadata.tar.gz').relative_to(root)),'full_current_source_read_complete':True,'tex_files':15,'tex_lines':3967,'bibliography_lines':345,'formal_scope':formal,'historical_scope':historical,'auxiliary_reviews':{'packet':'neutral-mapping-packet.json','opinions':['defender.md','skeptic.md'],'provider':'OpenAI','exact_backend':'unknown','isolated_same_provider_roles':True,'second_provider_review':False,'human_review':False,'status':'Provisional mapping discussion, not an admitted canonical candidate or executed application check; raw opinions archived.'}}
j['full_current_source_read_complete']=True
j['next_action']='Qualify source result bindings, method contracts, domain/cross-family attempts and provisional adaptive-prime mapping before GEN110 canonical curation; preserve role disagreement and all admission gaps. Then full graph/impact/export/core/archives/no-math QA and mandatory global040. No numerical execution without independent preregistration.'
save('state/reading-progress/WP-113.json',j)
b=load('state/backlog.json')
for task in b['tasks']:
    if task['id']=='WP-113':
        task['next_action']=j['next_action'];task['execution_progress']['actual_current_source_read_complete']=True
        task['execution_progress']['formal_historical_selected_scopes_saved']=True
b['updated_at']=now;save('state/backlog.json',b)

summary='This owner-requested publication batch includes completed WP112 / GEN109 and an explicitly unfinished [WP113 reading checkpoint](state/reading-progress/WP-113.json). WP112 qualifies three pinned software projects: 11 source/license files and 2,588 actually read lines. Full solves, inverse blocks and tensor-compatible truncation still do not establish an identical-output F300 application benchmark. Totals remain 59 canonically credited reading families, 54 current-source decomposition drafts, 8,128 graph nodes and 23,260 relations; 45 candidates and 13 preliminary application checks. F020 now has all 15 TeX files / 3,967 lines and 345 bibliography lines actually read, plus selected formal and four historical-work scopes. Canonical qualification, complete history and global review040 remain pending. Same-provider auxiliary opinions add no independent-provider or human review credit. No new application check or numerical experiment is added. The previous verified public snapshot is `21ce7dc`; this batch requires separate push, readback and CI observations.'
p=root/'README.en.md';s=p.read_text();a=s.index('Current local WP112');z=s.index('\n\nRepository:',a);p.write_text(s[:a]+summary+s[z:])
p=root/'README.md';s=p.read_text();a=s.index('最新[谱压缩真实消费者核查]');z=s.index('\n\n当前来源拆解',a)
cn='本次按用户要求集中发布：已完成的[WP112真实消费者核查](reports/F300-paving-consumer-audit.md)与[WP113未完成阅读检查点](state/reading-progress/WP-113.json)。WP112固定三个项目11文件2588行，新增24规范记录、83显式边；完整求解、逆块及张量兼容截断尚未接通同输出F300增益任务。F020已实际读完15TeX3967行与345Bib，并保存选定形式规格及四部历史原作选段；规范拆解、完整历史与复盘040仍待完成，不增加图谱覆盖、候选、初检或人审信用。上一公开21ce7dc及其成功CI覆盖旧快照，本批推送、远端回读和CI分别核验。名称与仓库统一为 **MathWeave（数学织网）**：把数学成果、历史方法与可检验应用织成证据网络。'
s=s[:a]+cn+s[z:]
s=s.replace('本次用户要求合并发布WP111／GEN108完整F300来源草稿及WP112未完成检查点：三项目固定版本、11文件已获取、983行选定源码／许可实际阅读，其他正文待核。上一公开453a806与其CI只覆盖旧快照；本批推送、回读及CI分别核验。','该早期批次已经公开，后续WP112完整核查与WP113当前检查点见上方本次范围。')
s=s.replace('当前本地WP111已整理','此前WP111已整理').replace('本次F300增量本地保存，继续里程碑合并发布。','该F300来源增量已在21ce7dc公开；本次最新范围见页首。')
p.write_text(s)
p=root/'PROGRESS.en.md';s=p.read_text();a=s.index('Snapshot:');z=s.index('\n\n| Measure',a)
s=s[:a]+'Snapshot: October 26, 2026, curated through WP112 / GEN109, with unfinished WP113 actual full-source reading and selected formal/historical qualification. This explicit owner request prepares one publication batch. Public `21ce7dc` and its successful scoped CI cover the previous snapshot; this batch is separately verified. Global039 remains the latest review; global040 is mandatory after WP113. **Phase one remains incomplete.**'+s[z:]
s+='\n\n## Owner-requested WP112 publication and unfinished WP113\n\n'+summary+'\n\nPublication boundary: retain MathWeave and the existing [yiduo/mathweave](https://github.com/yiduo/mathweave) address. The official `math/` directory, third-party full-text downloads and bulk local Git history remain excluded. Reading helpers, provisional role outputs and metadata are compressed with verified round trips. Temporary original HTML bodies remain local only to finish the incomplete research. Post-push receipts stay local until the next meaningful batch, avoiding an extra metadata-only push.\n'
p.write_text(s)
p=load('state/publication.json');assert p['verified_commit']=='21ce7dcf480ef0d423626596b10ff2ccb8efc170'
p['pending_batch']={'requested_at':now,'status':'prepared_not_pushed','scope':'Completed WP112 GEN109 plus unfinished WP113 F020 full-source reading and selected formal/history checkpoint; no new canonical F020 or application credit','official_math_excluded':True,'previous_public_commit':p['verified_commit'],'qa_directory':str(out.relative_to(root)),'new_scientific_experiments':0}
p['local_progress_after_verified_snapshot']=p['pending_batch']['scope']+'; owner-requested batch pending push/readback.'
save('state/publication.json',p)
c=load('state/checkpoint.json');c['saved_at']=now
for key in ['active_work_package','next_work_package']:c[key]=next(t for t in b['tasks'] if t['id']=='WP-113')
c['publication_work'].update({'status':'preparing_owner_requested_WP112_batch','current_local_research_not_yet_pushed':p['local_progress_after_verified_snapshot'],'prepush_audit':str((out/'final-audit.json.gz').relative_to(root))})
c['recovery_commands'][2]=j['next_action'];c['recovery_commands'][3]='WP113 full current natural source actually read; selected formal/history scopes and same-provider role outputs archived. No canonical/application/human credit added.'
c['recovery_commands'][4]='Owner-requested WP112/unfinishedWP113 batch pending; consult state/publication.json for actual verified boundary. Avoid routine pushes.'
c['previous_goal_turn_classification']={'classification':'progress','evidence':'WP113 full natural source read with selected formal/history scopes and isolated same-provider auxiliary opinions; canonical curation pending. Current user publication request takes priority.'}
save('state/checkpoint.json',c)
text='用户要求先提交当前进展，集中发布WP112／GEN109及WP113未完成检查点。MathWeave（数学织网）及https://github.com/yiduo/mathweave已完成命名／地址更新，沿用现有仓库，不另建库。F02015TeX3967行与345Bib已实际阅读，形式／四历史原作仅选定范围核对，同供应商角色意见仅辅助；规范入图、完整历史和复盘040待做，数量不增加。官方math、第三方正文和批量本地历史排除。旧21ce7dc仍是已验证公开边界；本批检查、推送、远端回读与CI另行取证，后验收据仅本地保存。'
for name in ['state/status.md','docs/roadmap.md','docs/publication.md']:
    with (root/name).open('a') as f:f.write('\n\n## 2026-10-26 当前批次：WP112与WP113检查点\n\n'+text+'\n')
print(json.dumps({'prepared':True,'source_tex_lines':3967,'bibliography_lines':345,'third_party_bodies_published':False,'helper_members':storage['members']}))
