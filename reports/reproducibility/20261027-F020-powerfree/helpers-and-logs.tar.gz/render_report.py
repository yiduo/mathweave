from pathlib import Path
import json,gzip
root=Path.cwd();ledger=json.loads((root/'data/provenance/readings/F-020.json').read_text())
formal=json.loads((root/ledger['formal_status']).read_text());hist=json.loads((root/ledger['historical_selected_originals']).read_text())
roles=json.loads(gzip.decompress((root/ledger['isolated_reviews']).read_bytes()))
lines=['# F020：固定多项式幂自由值、历史范围与条件性应用','',
'由规范来源记录 `data/provenance/readings/F-020.json` 和图谱生成。当前全文来源草稿，不是完整成果族、历史谱系或数学／应用验收。','',
'## 实际范围','',
f"固定上游 `{ledger['upstream_commit']}`；一篇当前稿，15TeX／{ledger['source_tex_lines']}行及{ledger['bibliography_lines']}行Bib与README已实际阅读。26具名结果＋2附加无标签方法结论，24项契约。先前未完成日志保留，未重复计数。",'',
'## 关键输入输出边界','']
for label in ['thm:density','cor:all-degrees','cor:separable-products','prop:large-prime-tail','lem:affine-deletion','prop:parameter-certificate','unlabelled:analytic-relation']:
    row=next(r for r in ledger['results'] if r['label']==label)
    lines += [f"- `{row['id']}`：{row['conditions']}"]
lines += ['','参数证书只阅读，未在本地执行；源表、固定网格与形式化另一证明路线不混为本地数值观察。','',
'## 形式化与历史','',formal['actual_selected_endpoint_scope'],'',formal['distinct_formal_route'],'',formal['index_scope'],'',
'| 原作 | 实际选段 | 限定核对结果 |','| --- | --- | --- |']
for key,h in hist['verified_scopes'].items():lines.append(f"| {key} | {h['scope']}；{h['version']} | {h['summary']} |")
lines += ['',hist['limits'],'',
'## 一条待准入的条件候选','',
'[APP-020-01](cards/APP-020-01.md)考察：对真正满足同一S上的完整Q评价核、全路径秩稳定性及非零子式高度契约的有限模重构任务，变长素数块政策是否能在全部构造／验证成本相同的条件下降低重启或证书失败。当前没有实际消费者、有限非空风险证书、独立裁判或可执行预注册；结果待定，不增加初检数。','',
roles['disagreement'],'',roles['decision'],'',
'普通模p核不是同一个有理子空间中的嵌套核。精确最终验证已经保证正确性时，应比较总成本和重启，不能声称提升了最终正确率。完整核／补丁构造可能已经支付原问题的主要代价；旧lucky-prime检查、独立重抽、确定性大素数或确切验算可能已经足够。两个角色提出的有限界只保留为待证明的应用侧线索，不作为已获风险证书或新数学成果。','',
'## 十领域与跨族尝试','',
'| 领域 | 距离 | 条件与当前判断 |','| --- | --- | --- |']
for domain,analogy,assessment,accepted in ledger['domain_attempts']:lines.append(f'| {domain} | {analogy} | {assessment} |')
for c in ledger['cross_family_attempts']:lines += ['',f"- {' / '.join(c['family_ids'])}，`{c['existing_method']}`：{c['assessment']}"]
lines += ['','## 明确缺口','']+['- '+gap for gap in ledger['gaps']]
lines += ['','所有来源绑定、完整方法契约及定位见[生成的族报告](families/F-020.md)。本报告由代码导出，不另设研究事实。','']
(root/'reports/powerfree-F020-reading.md').write_text('\n'.join(lines))
print('Generated reports/powerfree-F020-reading.md from canonical records.')
