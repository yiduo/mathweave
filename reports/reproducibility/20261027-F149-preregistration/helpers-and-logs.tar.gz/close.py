from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,shutil
r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261027-F149-preregistration';out.mkdir(parents=True,exist_ok=True);now=datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=json.loads(gzip.decompress((w/'quality.json.gz').read_bytes()));c=json.loads(gzip.decompress((w/'clean-check.json.gz').read_bytes()));s=json.loads((w/'curation-summary.json').read_text());rep=json.loads((w/'representative-replay.json').read_text());metrics=json.loads((r/'reports/metrics.json').read_text())
assert c['core_exit_code']==0 and not (w/'clean').exists() and len(q['impact_cases'])==170 and len(q['alternative_route_cases'])==2
for n in ['core.log','clean-core.log']:
 t=(w/n).read_text();assert 'Ran 95 tests' in t and '\nOK\n' in t and 'OK (skipped' not in t and '"canonical_citations": 9834' in t
assert all(rep['deterministic_outputs_match'].values()) and rep['replay_resource_envelope_met']
assert not list((r/'experiments/runs').glob('EXP-149-*')) and not list((r/'experiments/attempts').glob('EXP-149-*'))
freeze=json.loads((r/'experiments/freezes/EXP-149-001-source-manifest.json').read_text())
for x in freeze['input_files']:assert sha((r/x['path']).read_bytes())==x['sha256']
for x in c['manifest']:assert sha((r/x['path']).read_bytes())==x['sha256'],x['path']
for n in ['quality.json.gz','clean-check.json.gz']:shutil.copyfile(w/n,out/n)
closure={'at':now,'work_package':'WP-126','status':'quality_closed_pending_local_implementation_commit','generation':s['generation'],'base_commit':s['base_commit'],'new_records':3,'new_explicit_edges':4,'versioned_old_records':1,'old_rows_byte_preserved':5619,'protected_files':q['protected_files'],'prepared_cases':72,'runtime_input_files':len(freeze['input_files']),'new_target_outputs':0,'new_candidates':0,'new_initial_checks':0,'core_tests':95,'new_UNIT_software_tests':7,'clean_core_tests':95,'skipped_tests':0,'single_seed_impact_cases':170,'multi_seed_cases':2,'scientific_archives':17,'source_archive_members':337,'core_citations':9821,'full_canonical_citations':9834,'source_artifacts':2079,'graph_nodes':8858,'graph_edges':26061,'strict_existing_representative':rep,'clean_files':c['files'],'clean_bytes':c['bytes'],'clean_directory_removed':True,'implementation_freeze':'Not yet complete at this receipt;require subsequent implementation-freeze-verification.json with actual Gitcommit and every input blob match before target.','overall_status':'active_incomplete','github_push':False,'metadata_after_clean':['Closure/storage/freezeverification receipts and own helper archive','Status/checkpoint/backlog/publication metadata','Current preparation report text'],'scope':'Preparedfinite synthetic check only;no actual EXP149outputs,math/human/provideracceptance,newtheoremorintegratorgain.'};save(out/'closure.json',closure);save(w/'closure.json',closure)
nextwp={'id':'WP-127','priority':1,'status':'ready_after_commit_verification','parent_task':'WP-126','objective':'Execute the unchanged preregistered72case EXP149001 once after verified Gitfreeze;strictly replay archivedsource andupdate existingAPP149 by actual finite evidence.','selection_reason':'WP126removed finite-reference/implementationgap on originalsynthetic-eligible hypothesis;externaloutput still0. Actualfrozenexecution canreduceonependingcard withoutclaimingnewmathematicalorintegratorgain.','inputs':['experiments/specs/EXP-149-001.json','experiments/freezes/EXP-149-001-source-manifest.json','scripts/run_experiment_attempt.py'],'resource_limit':'Original60s64MiB128MiB;setup30s/archive30s,exact72fixtures/no post-outputchanges. FreshpinnedPython3.12.14 andwholeworkerRSSsupervisor. No newdependencies/upstreamwrites.','acceptance':'Beforefirsttarget,each of41runtimeinputfilesmustmatchactualcommittedGitblob. Runonefreshattempt;inspectfullraw,sevenclaimlabels,finiteanalyticreferences,negativeevents,oldbaseline,allinconclusive/adversecases andresources. Strict archivedsource raw/summaryreplay withallfieldsandresourcegates. Preservealloutputs/source/progress/failurescompressedwithroundtriph ashs. Versionexistingcardandretainpriorrecord;noautomaticnewcandidateornewmathgain. Fullgraph/core/clean/storagechecks onactualupdate.','stop_or_redirect':'Reference/arithmeticconflict/resourcefailureisnotinitialcheck;noautomaticcap/step/typechangeorparametersearch. Valid adverseevidencekeptpendinghumanreview;noformalrejection. Missingobservationnotreasontorestart livehandle.','depends_on':['WP-126'],'created_at':now,'next_action':'Finish localimplementationcommitandverify41inputGitblobs,recordfreezeSHA,thenstartoneEXP149attemptwithpinnedruntime.','new_initial_checks':0,'body_read_credit':0,'github_push':False,'target_outputs':0}
save(w/'next-selection.json',nextwp)
bp=r/'state/backlog.json';b=json.loads(bp.read_text());item=next(t for t in b['tasks'] if t['id']=='WP-126');item.update(status='quality_closed_pending_local_freeze',execution_state='canonical_graph_core_clean_storage_checked_target0_pending_Gitcommit',evidence=['data/provenance/preparation/F-149-preexecution.json','experiments/specs/EXP-149-001.json','experiments/freezes/EXP-149-001-source-manifest.json',str(out.relative_to(r))+'/closure.json'],next_action=nextwp['next_action'],canonical_credit_added=True,target_outputs=0,quality_completed_at=now)
assert not any(t['id']=='WP-127' for t in b['tasks']);b['tasks'].append(nextwp);b['updated_at']=now;save(bp,b)
cp=r/'state/checkpoint.json';d=json.loads(cp.read_text());d.update(saved_at=now,updated_at=now,overall_status='active_incomplete',metrics=metrics,active_work_package=item,next_work_package=nextwp,last_quality_evidence=str(out.relative_to(r)),storage_receipt=str(out.relative_to(r))+'/storage.json',running_research_experiments=[],current_goal_turn_classification='progress:WP126executable72case spec/nonlinearanalyticreference/reactionandexpandedjudges,7UNITsoftwarecontrols,GEN123versionedcard,170single2multi/fullgraph/95core/clean95 andstorageclosed;target0pendingactualcommitverification.')
d['resume_commands']=['Readgoal/AGENTS/charter/roadmap/status/checkpoint/backlog/global044;checkdiskandknownhandlesbeforework.','WP126QAclosedbutfreezecommitnotyetrecorded;do notrununtil41inputfilesexactlymatchcommittedGitblobs and actualSHAreceipt saved. No EXP149targetoutputs atthischeckpoint.','NewspecEXP14900172fixedsyntheticcases,3/4speciesnonlinearmultilinkageandone-specieslogisticcontrol;exactreference/updatesand7reportclaims. Originalpredictionunchanged;oldcoordinatecheckmayfullysuffice,no2026gain.','All95core/clean95/170single2multi/17archives337members/strict238representativepassed. Do notrerunpreviouscurator;initialbadarchivewrapperrolledbackandcorrected,allfailuresretained.','Firsttargetmustfreshrun_experiment_attempt withpinnedPython3.12.14;preservehandle/progress/failures,thenstrict archivedsource replay. No postoutputcap/step changes;referenceconflict/resourcefailure notinitialcredit.','Humans/secondproviderdeferred;mathreadonly/noGitHubpush. AfteractualWP126freeze completion count1beyond044;WP127 count2;global045afterthirdsubstantivepackage.'];d['recovery_commands']=d['resume_commands'];d['recovery_observation']['WP126_quality_boundary']={'at':now,'known_tool_handles_terminal':[47484,52226,10303,61575,21540,94601],'known_research_experiments':[],'scope':'Knownhandlesonly,notfullsystemprocessinventory.','target_outputs':0,'source_inputs':41,'clean_removed':True,'local_freeze_pending':True};save(cp,d)
pp=r/'state/publication.json';p=json.loads(pp.read_text());p['local_progress_after_verified_snapshot']='WP113throughWP126localonly. F149GEN123executable72case spec/finite-time reference/codeand7UNITcontrols,95core/clean95;noEXP149targetoutputs. Implementationfreeze pendinglocalcommit. NoGitHubpush.';save(pp,p)
report='''# WP126：F149可执行检验准备

执行前质量检查已完成，源码提交冻结待单独Git核验。72个合成目标实例尚未执行；7项UNIT软件控制不是外部应用结果。

完整规格：`experiments/specs/EXP-149-001.json`。原预测与原MAP149计划不变：检查连续理论资格和有限Euler更新的证书分离，不把有限非负历史升级成长时间数值永久性。包含三物种多链接交换、四物种带权守恒组装，以及一物种非守恒logistic旧对照；各三初值、两速率倍率、四步长，最多八步，首次非正即停止。

有限时间参考使用正守恒量的逐反应消耗上界，独立路径先合并多项式系数再验证守恒/负系数及损失界；logistic对照检查实际标量多项式与正不变区间。它不是数值轨迹包围、永久性证明、统一epsilon或进入时间。旧微分不等式和逐坐标Euler检查已经足够，不预设2026数学或积分器增益。

每例实际请求并比较七种报告标签，两个Euler组织必须精确相等；有限非负与严格正分开，最后三类长期/任意步长推断缺证书标unsupported。参考/算术冲突是待定，裁判有效而分类错误是不利，不能靠成功摘要覆盖失败。逐参考及逐步压缩进度保留异常前结果；运行成本留在manifest，科学raw/summary不含时钟。

当前会话未隔离的怀疑/辩护自查如实保存在review-packet-v2，不是第二供应商或真人。原v1参考草稿保留未覆盖；所有来源与新代码散列见`data/provenance/preparation/F-149-preexecution.json`。来源B/C和完整链未知不变，没有Lean/Comparator/人审或试点。

GEN123新增3规范/4显式边，APP149前版压缩保留，5619旧规范行与763保护文件保持；170单种子/2多种子、完整导出、17归档337成员、95核心/无math干净副本95无跳过及旧238严格源码重放通过。首次归档wrapper错误和缺PYTHONPATH的软件调用失败均留日志，验证器未放宽。

下一先提交并核41个输入的Git blob，再执行一次原规格并严格重放；不能因准备/UNIT通过增加初检。完整收据见`reports/reproducibility/20261027-F149-preregistration/`。第一阶段仍未完成，无GitHub推送。
''';(r/'reports/preparation/WP126-continuous-reference.md').write_text(report)
status=r/'state/status.md';t=status.read_text();intro=f'''# 当前状态

更新时间：{now}。第一阶段仍未完成。

固定上游1581d4cbdd69a0faf34b2089614fe2a814316a6a，372族/719当前手稿；math只读且未重新部署。规范图8858节点26061关系；64阅读族/59当前稿草稿，47候选/14合格初检/14不同验证（6限定支持8不利），另1诊断。完整族/历史/人审/第二供应商/试点仍0。

WP126已准备原APP149的72例执行规格、非线性有限时间参考、两个精确更新组织及七类报告裁判。7项UNIT软件控制、95核心/无math干净副本95、完整图170单种子2多种子、17归档337成员和旧238严格重放通过；目标输出0。尚待本地提交并核验41个输入Git blob，不能把准备计初检。参考不提供轨迹误差、永久区域、统一进入时间或2026积分器增益。

WP125及全局044已完成；F059一链B/50C、完整链未知，五部原作仅选段。F076在3.12下14处浮点失配留证，在已安装3.14.8严格完整重放通过，未降低标准。

下一WP127在提交冻结核验后执行EXP149001一次，严格保留失败及全字段重放；人审/第二供应商待后补，不反复询问。不推GitHub。

''';assert '以下为历次工作记录' in t;status.write_text(intro+'以下为历次工作记录'+t.split('以下为历次工作记录',1)[1]);note=f'\n\nWP126执行前质量闭包（{now}）：72例规格/有限解析参考/独立精确更新与七类标签已准备；7UNIT、95核心/干净95、170单种子2多种子/全导出/17归档337源码和238严格代表通过。GEN123新增3规范4显式，APP149前版保留、5619旧行763保护文件保持。尚待本地Git冻结41输入，目标输出0、不增候选/初检。下一核验冻结后WP127，旧逐坐标方法可能已足够，无新积分器收益承诺。\n'
for p in [status,r/'docs/roadmap.md']:
 with p.open('a') as f:f.write(note)
allowed={'state/backlog.json','state/checkpoint.json','state/publication.json','state/status.md','docs/roadmap.md','reports/preparation/WP126-continuous-reference.md'};changed=[]
for x in c['manifest']:
 if sha((r/x['path']).read_bytes())!=x['sha256']:assert x['path'] in allowed,x['path'];changed.append(x['path'])
save(w/'post-clean-metadata-check.json',{'unchanged_tested_files':c['files']-len(changed),'postclean_metadata_changes':changed,'scientific_inputs_and_code_unchanged':True})
manifest=[];stream=io.BytesIO();names=sorted(p.name for p in w.iterdir() if p.is_file())
with tarfile.open(fileobj=stream,mode='w') as tf:
 for n in names:
  b=(w/n).read_bytes();ti=tarfile.TarInfo(n);ti.size=len(b);ti.mtime=0;tf.addfile(ti,io.BytesIO(b));manifest.append({'name':n,'bytes':len(b),'sha256':sha(b)})
raw=stream.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed))) as tf:
 for x in manifest:assert sha(tf.extractfile(x['name']).read())==x['sha256']
(out/'helpers-and-logs.tar.gz').write_bytes(packed);assert sha((out/'helpers-and-logs.tar.gz').read_bytes())==sha(packed)
storage={'at':now,'archive':str((out/'helpers-and-logs.tar.gz').relative_to(r)),'sha256':sha(packed),'decompressed_sha256':sha(raw),'compressed_bytes':len(packed),'decompressed_bytes':len(raw),'member_manifest':manifest,'members_byte_verified':len(manifest),'clean_directory_removed':True,'new_downloads':0,'new_target_outputs':0,'third_party_bodies_copied':0,'scope':'Ownhelpers/logs/failureversions compressedandmemberverified;no numericaltarget data created. Postcleanmetadataidentified.'}
for n in names:(w/n).unlink()
assert not list(w.iterdir());w.rmdir();storage['temporary_work_root_removed']=not w.exists();save(out/'storage.json',storage)
print(json.dumps({'WP126':'QAandstorageclosed_pendingcommit','core':95,'clean':95,'inputs':41,'target_outputs':0,'archive_bytes':len(packed),'next':'commitverify_thenWP127','goal':'active_incomplete'}))
