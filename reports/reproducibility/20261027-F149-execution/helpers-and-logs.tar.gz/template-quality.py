from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;s=json.loads((w/'curation-summary.json').read_text());base=s['base_commit']
def old(p):return subprocess.check_output(['git','show',base+':'+p])
a={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};b={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)}
assert len(a)==5620 and len(b)==5623
for id,raw in a.items():
 if id!='APP-149-01':assert b[id]==raw,id
archive=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-123-before.json.gz').read_bytes()));assert archive['records']==[json.loads(a['APP-149-01'])]
n=json.loads(b['APP-149-01']);assert n['version']==2 and n['properties']['prediction']==json.loads(a['APP-149-01'])['properties']['prediction']
assert n['properties']['run_ids']==[] and n['properties']['application_result']=='待定' and n['properties']['summary']['target_outputs']==0
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
preserved=[];changed_code=['src/ai_value/experiments.py'];changed_report=['reports/cards/APP-149-01.md']
for p in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if p.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')) and p not in changed_code+changed_report:
  assert (r/p).read_bytes()==old(p),p;preserved.append(p)
metrics=validate(r);generated=json.loads((r/'reports/metrics.json').read_text());assert generated['partial_reading_families']==64 and generated['source_decomposition_drafts']==59 and generated['candidate_connections']==47 and generated['externally_checked_cards']==14 and generated['distinct_validation_hypotheses']==14 and generated['effective_leads']==6 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
export(r);nodes,edges=load(r)
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes())).find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F059-source-scope/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
for seed,target,pos in [('PART-149-FINITE-REFERENCE','APP-149-01',True),('CLM-149-PERMANENCE','PART-149-FINITE-REFERENCE',False),('PART-149-FINITE-REFERENCE','CLM-149-PERMANENCE',False),('REVIEW-149-PREEXECUTION','CLM-149-PERMANENCE',False),('REVIEW-149-PREEXECUTION','APP-149-01',False)]:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==pos,(seed,target)
 impacts.append({'seed':seed,('required_affected' if pos else 'must_not_propagate_to'):target,'confirmed':True,'scope':'Finite analytic reference independent of sourcepermanence proof;selfreview metadata cannot validate/invalidate main mathematics.'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==17 and members==337
assert not list((r/'experiments/runs').glob('EXP-149-*')) and not list((r/'experiments/attempts').glob('EXP-149-*'))
ledger=json.loads((r/'data/provenance/preparation/F-149-preexecution.json').read_text())
for f in ledger['pinned_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
spec=json.loads((r/'experiments/specs/EXP-149-001.json').read_text());count=sum(len(x['initial_states']) for x in spec['input']['models'])*len(spec['input']['rate_scales'])*len(spec['input']['steps']);assert count==72 and spec['resource_limit_seconds']==60 and spec['resource_limit_mb']==64 and spec['resource_limit_rss_mb']==128
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':5619,'versioned_old_records':1,'new_records':3,'new_edges':4,'protected_files':len(preserved),'scientific_engine_change':'Only explicit opt-in runtime-metrics persistence;existing runner defaults unchanged. AddedEXP149dispatch,notcalled.','canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'new_target_outputs':0,'initial_checks_added':0,'new_candidates':0,'prepared_cases':72,'source_body_count_unchanged':True,'scope':'Executable pre-output preparation only,notapplication/human/providerorproofacceptance. New UNIT tests neverload frozen targetpack.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics']},ensure_ascii=False))
