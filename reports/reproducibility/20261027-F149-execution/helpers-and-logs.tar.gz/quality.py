from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src');from ai_value.graph import load,validate,impact_report
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;s=json.loads((w/'curation-summary.json').read_text());base=s['base_commit']
def old(p):return subprocess.check_output(['git','show',base+':'+p])
a={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};b={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)};changed=set(s['versioned_old_record_ids']);assert len(a)==5623 and len(b)==5624 and changed=={'APP-149-01','PROB-149-SIMULATION'}
for id,raw in a.items():
 if id not in changed:assert b[id]==raw,id
archive=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-124-before.json.gz').read_bytes()));assert {x['id']:x for x in archive['records']}=={id:json.loads(a[id]) for id in changed}
for id in changed:assert json.loads(b[id])['version']==json.loads(a[id])['version']+1
assert (r/'data/graph/edges.jsonl').read_bytes()==old('data/graph/edges.jsonl') and (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
preserved=[]
for p in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if p.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')) and p!='reports/cards/APP-149-01.md':assert (r/p).read_bytes()==old(p),p;preserved.append(p)
metrics=validate(r);generated=json.loads((r/'reports/metrics.json').read_text());assert generated['partial_reading_families']==64 and generated['source_decomposition_drafts']==59 and generated['candidate_connections']==47 and generated['externally_checked_cards']==15 and generated['distinct_validation_hypotheses']==15 and generated['effective_leads']==7 and generated['diagnostic_executions_not_initial_checks']==1
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
card=json.loads(b['APP-149-01']);assert card['properties']['prediction']==json.loads(a['APP-149-01'])['properties']['prediction'] and card['properties']['theoretical_grade']=='unknown' and card['properties']['source_claim_grade']==json.loads(a['APP-149-01'])['properties']['source_claim_grade'];assert card['properties']['summary']['new_2026_application_gain_demonstrated'] is False
export(r);nodes,edges=load(r);j=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes())).find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F149-preregistration/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
# Actual run/evidence projections must not retroactively become a main proof.
for seed,target in [('RUN-EXP-149-001-E334AC2404104E6A','CLM-149-PERMANENCE')]:
 # Discover the exact projected run ID rather than inventing its casing.
 matching=[id for id in nodes if nodes[id]['kind']=='experiment_run' and nodes[id]['properties'].get('run_id')==s['run_id']]
 if not matching:matching=[id for id in nodes if s['run_id'] in id]
 assert len(matching)==1,matching;seed=matching[0];assert target not in impact_report(nodes,edges,{seed})['affected'];impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Finite externalcheck cannot prove/invalidate sourcepermanence theorem by run provenance.'})
ors=[]
for v in previous['alternative_route_cases']:assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==18 and members==378
rep=json.loads((w/'strict-replay.json').read_text());audit=json.loads((w/'result-audit.json').read_text());assert all(rep['deterministic_outputs_match'].values()) and rep['replay_resource_envelope_met'] and audit['exact_transitions_audited']==401 and audit['full_attempt_progress_members_verified']==545
freeze=json.loads((r/'experiments/freezes/EXP-149-001-source-manifest.json').read_text())
for f in freeze['input_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':5621,'versioned_old_records':2,'new_records':1,'new_edges':0,'protected_files':len(preserved),'scientific_source_code_exactly_unchanged_since_freeze':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'strict_replay':rep,'actual_row_audit':audit,'new_initial_checks':1,'new_distinct_hypotheses':1,'new_candidates':0,'source_grade_promotions':0,'scope':'Original72case finite reportprediction supports limited lead,oldbaselineidentical,zero new2026increment;notmathematics/accuracy/solver/pilotacceptance.'};raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics','actual_row_audit','strict_replay']},ensure_ascii=False))
