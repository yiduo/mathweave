from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import json,gzip,hashlib
r=Path.cwd();w=Path(__file__).parent;run=r/'experiments/runs/EXP-149-001-e334ac2404104e6a';m=json.loads((run/'manifest.json').read_text());sp=json.loads((run/'spec.json').read_text());rows=json.loads(gzip.decompress((run/'raw.json.gz').read_bytes()));summary=json.loads(gzip.decompress((run/'summary.json.gz').read_bytes()));freeze=json.loads((r/'experiments/freezes/EXP-149-001-source-manifest.json').read_text());source=json.loads(gzip.decompress((run/'inputs.json.gz').read_bytes()))
for x in freeze['input_files']:assert m['inputs'][x['path']]==x['sha256'] and hashlib.sha256(source[x['path']].encode()).hexdigest()==x['sha256']
for p,h in m['outputs'].items():assert hashlib.sha256((run/p).read_bytes()).hexdigest()==h
expected={}
for model,scale,h in product(sp['input']['models'],sp['input']['rate_scales'],sp['input']['steps']):
 for i,x in enumerate(model['initial_states']):expected[model['id']+'-scale'+scale+'-h'+h+'-x'+str(i)]=(model,F(scale),F(h),list(map(F,x)))
assert len(rows)==len(expected)==72 and len({x['id'] for x in rows})==72;negative=[];nonlinear=[];transitions=0
for row in rows:
 model,scale,h,state=expected[row['id']];initial=state[:];assert row['status']=='complete' and row['source_eligible'];assert list(map(F,row['initial']))==initial
 for j,t in enumerate(row['trace']):
  assert t['step']==j+1 and all(v>0 for v in state) and list(map(F,t['state_before']))==state
  delta=[sum(F(e['rate'])*scale*prod(x**p for x,p in zip(state,e['source']))*(e['target'][i]-e['source'][i]) for e in model['reactions']) for i in range(len(state))]
  actual=[x+h*y for x,y in zip(state,delta)];assert actual==list(map(F,t['reaction_update']))==list(map(F,t['old_expanded_update']))
  assert t['negative']==any(x<0 for x in actual) and t['strictly_positive']==all(x>0 for x in actual)
  if 'conservation_weights' in model:
   weights=list(map(F,model['conservation_weights']));assert sum(x*y for x,y in zip(weights,actual))==sum(x*y for x,y in zip(weights,initial))
  state=actual;transitions+=1
  if any(x<=0 for x in state):assert j==len(row['trace'])-1
 assert 1<=len(row['trace'])<=8 and F(row['horizon'])==h*len(row['trace'])
 assert len(row['trace'])==8 or any(x<=0 for x in state)
 assert row['independent_reference']['verified'] and all(F(x)>0 for x in row['finite_continuous_lower'])
 hasnegative=any(t['negative'] for t in row['trace']);assert hasnegative==row['euler_has_negative']==row['old_coordinate_guard_catches_negative']==row['separated_guard_catches_negative']
 report=row['report'];assert report==row['independent_old_report'] and report['conditional_continuous_permanence']=='conditional' and report['finite_continuous_positive']=='supported'
 assert report['finite_euler_nonnegative']==('refuted' if hasnegative else 'supported')
 assert all(report[k]=='unsupported' for k in ['eventual_numerical_permanence','uniform_initial_burnin','arbitrary_step_from_continuous_theorem'])
 assert row['eventual_numerical_permanence_certified'] is False and row['new_integrator_or_2026_increment_certified'] is False
 if hasnegative:
  negative.append(row['id'])
  if row['stratum']=='nonlinear_multilinkage':nonlinear.append(row['id'])
assert negative==summary['negative_euler_cases'] and nonlinear==summary['nonlinear_multilinkage_negative_cases'] and len(negative)==27 and len(nonlinear)==18 and transitions==401
attempts=list((r/'experiments/attempts').glob('EXP-149-*'));assert len(attempts)==1;ap=attempts[0];attempt=json.loads((ap/'attempt.json').read_text());assert attempt['target_completed'] and attempt['execution_qualified'] and attempt['source_hashes_unchanged']
for p in attempt['progress']:
 b=(ap/p['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==p['sha256'] and hashlib.sha256(gzip.decompress(b)).hexdigest()==p['uncompressed_sha256']
assert len(attempt['progress'])==545 and m['resource_envelope_met'] and m['measurement_state']=='parent_child_lifecycle_finalized'
out={'experiment':'EXP-149-001','run_id':m['run_id'],'implementation_freeze_commit':'8a71a29f39828b0e7c41b279105869c19c8e5135','all41inputs_match_prefreeze_hashes':True,'all72rows_audited':True,'exact_transitions_audited':transitions,'negative_cases':27,'nonlinear_multilinkage_negative_cases':18,'guard_and_old_baseline_agree_all':True,'conditional_source_not_math_acceptance':True,'new2026gain':False,'full_attempt_progress_members_verified':545,'attempt_id':ap.name,'original_resources_qualified':True,'runtime_measurement':{k:m[k] for k in ['elapsed_seconds','peak_traced_python_bytes','process_peak_rss_bytes','stage_runtime_metrics']},'scope':'Third post-output raw-data audit recomputes every finite transition,whole-input coverage,scope labels and hashes. This audits the frozen finite experiment,not source theorem validity or general effectiveness.'};(w/'result-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='runtime_measurement'}))
