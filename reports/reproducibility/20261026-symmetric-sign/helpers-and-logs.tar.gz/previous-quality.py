from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime,xml.etree.ElementTree as ET,collections
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP107');O=R/'reports/reproducibility/20261023-weak-mtw';sys.path.insert(0,str(R/'src'))
from ai_value.graph import load,validate,impact_report,read_jsonl
from ai_value.knowledge import export
sha=lambda b:hashlib.sha256(b).hexdigest()
def old(p):return subprocess.check_output(['git','show','4e34ea2:'+p],cwd=R)
def put(p,x):b=(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.write_bytes(z)
for p in ['data/graph/nodes.jsonl','data/graph/edges.jsonl']:
 assert (R/p).read_bytes().startswith(old(p)),p
for folder in ['experiments','src','tests','data/corpus']:
 tracked=subprocess.check_output(['git','ls-tree','-r','--name-only','4e34ea2',folder],cwd=R).decode().splitlines()
 for p in tracked:assert (R/p).read_bytes()==old(p),p
for p in subprocess.check_output(['git','ls-tree','-r','--name-only','4e34ea2','reports/families'],cwd=R).decode().splitlines():assert (R/p).read_bytes()==old(p),p
prior=json.loads(old('data/graph/reading_coverage.json'));current=json.loads((R/'data/graph/reading_coverage.json').read_bytes())
assert all(current['partially_read_families'][k]==v for k,v in prior['partially_read_families'].items());assert set(current['source_decomposition_drafts'])-set(prior['source_decomposition_drafts'])=={'F-360'};assert current['full_family_decompositions_complete']==[]
metrics=validate(R);nodes,edges=load(R);result=export(R)
actual=json.loads(gzip.decompress((R/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in actual['nodes']}==nodes and actual['edges']==edges
x=ET.fromstring(gzip.decompress((R/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};graph=x.find('g:graph',ns);gn={n.attrib['id']:json.loads(next(d for d in n if d.attrib.get('key')=='properties').text) for n in graph.findall('g:node',ns)};ge=[json.loads(next(d for d in e if d.attrib.get('key')=='evidence').text) for e in graph.findall('g:edge',ns)];assert gn==nodes and ge==edges
cases=[]
for seed,target,expect in [('CLM-360-G-GEO-SUPPORT','CLM-360-R-THM-MAIN',True),('CLM-360-G-GEO-DEGREE','CLM-360-G-GEO-SUPPORT',False),('LIT-360-CEMS2001','CLM-360-R-THM-MAIN',True),('LIT-360-CIL1992','CLM-360-R-JET-DETERMINANTS',True),('CLM-360-R-JET-OUTER-CONJUGACY','CLM-360-R-JET-DETERMINANTS',True),('CLM-360-R-SPEC-COMPARISON','CLM-360-R-THM-MAIN',True),('CLM-360-R-SC-PARAMETER','CLM-360-R-THM-MAIN',True),('CLM-360-G-GEO-SUPPORT','CLM-174-LEM-RATIONAL-PSD',False),('CLM-174-LEM-RATIONAL-PSD','CLM-360-R-THM-MAIN',False),('CLM-360-G-GEO-CONVEXITY','CLM-360-R-GEO-CONVEXITY',True)]:
 r=impact_report(nodes,edges,{seed});assert (target in r['affected'])==expect,(seed,target,expect);cases.append({'seed':seed,'target':target,'expected':expect,'actual':target in r['affected'],'affected':r['affected']})
archives=[];members=0
for p in sorted((R/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(p.read_bytes());folder=p.parent
 for name,h in m['outputs'].items():assert sha((folder/name).read_bytes())==h,(p,name)
 for name,record in m.get('compressed_payloads',{}).items():assert sha(gzip.decompress((folder/name).read_bytes()))==record['uncompressed_sha256'],(p,name)
 snapshot=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
 for name,body in snapshot.items():assert sha(body.encode())==m['inputs'][name],(p,name)
 members+=len(snapshot);archives.append({'run_id':m['run_id'],'source_members':len(snapshot),'compressed_and_decompressed_hashes_verified':True})
assert len(archives)==15 and members==267
sources=[s for n in read_jsonl(R/'data/graph/nodes.jsonl') for s in n['sources']];counts=collections.Counter('local_hashed' if 'path'in s else 'external_hashed' if s.get('sha256') else 'external_no_byte_hash' for s in sources)
subjects=collections.Counter();readsubjects=collections.Counter()
for f in read_jsonl(R/'data/corpus/families.jsonl'):
 subjects[f['subject']]+=1
 if f['id'] in current['partially_read_families']:readsubjects[f['subject']]+=1
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metrics':metrics,'canonical_records':len(read_jsonl(R/'data/graph/nodes.jsonl')),'canonical_citations':len(sources),'citation_kinds':dict(counts),'old4531canonical_lines_and_alloldedges_byte_exact':True,'old_experiment_source_specs_data_tests_corpus_byte_exact':True,'old51family_reports_byte_exact':True,'old_coverage_members_byte_exact':True,'full_json_and_graphml_object_equality':True,'export':result,'impact_cases':cases,'archive_count':len(archives),'archived_source_members':members,'archive_integrity':archives,'coverage_by_subject':{k:{'read':readsubjects[k],'registered':v} for k,v in subjects.items()},'scientific_replay_scope':'Archive hash integrity only here;retro representative actual replays logged separately;not new efficacy evidence'}
put(O/'source-contracts.json.gz',receipt);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','archive_integrity','export','coverage_by_subject']},ensure_ascii=False))
