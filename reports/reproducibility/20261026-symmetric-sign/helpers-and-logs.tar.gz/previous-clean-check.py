import datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess,time
R=pathlib.Path('/Users/smzdm/projects/ai_paper');T=pathlib.Path('/private/tmp/ai-paper-WP107');C=T/'no-math-clean';OUT=R/'reports/reproducibility/20261023-weak-mtw'
assert not C.exists();C.mkdir()
raw=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R)
paths=sorted(set(x.decode() for x in raw.split(b'\0') if x))
manifest=[]
for name in paths:
 p=pathlib.PurePosixPath(name)
 if p.parts[0] in {'math','tmp','.git','.venv','.cache'} or '__pycache__' in p.parts:continue
 source=R/name
 if not source.is_file():continue
 assert not source.is_symlink(),name
 target=C/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 b=target.read_bytes();assert b==source.read_bytes();manifest.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert not (C/'math').exists()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env['PATH']='/Users/smzdm/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
start=time.perf_counter()
with (T/'no-math-clean.log').open('w') as log:r=subprocess.run(['/Users/smzdm/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3','scripts/check.py'],cwd=C,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(manifest),'copied_bytes':sum(x['bytes'] for x in manifest),'upstream_math_present':False,'source_byte_copy_verified':True,'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-start,'environment':'Existing Python3.12.14/bundled Node,no install','manifest':manifest,'scope':'Working files,including new WP107 evidence;independent clean directory,no math,no Git history. Source hash verification without math uses pinned corpus manifest,not fresh upstream bytes.'}
b=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(OUT/'no-math-clean-directory.json.gz').write_bytes(z)
if r.returncode==0:shutil.rmtree(C)
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'},indent=2));raise SystemExit(r.returncode)
