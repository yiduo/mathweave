from pathlib import Path
import urllib.request,urllib.error,hashlib,json,datetime,subprocess
root=Path('/private/tmp/ai-paper-WP108-history');receipt=root/'acquisition.json';d=json.loads(receipt.read_text()) if receipt.exists() else {'limit_bytes':8*1024*1024,'downloaded_bytes':0,'files':[],'failures':[]}
items=[('reverse-minkowski-v6','https://arxiv.org/pdf/1611.05979v6'),('cjms-v2','https://arxiv.org/pdf/2105.11384v2'),('talagrand1988','https://www.ams.org/journals/proc/1988-104-03/S0002-9939-1988-0964871-7/S0002-9939-1988-0964871-7.pdf'),('talagrand1994-v1','https://arxiv.org/pdf/math/9406212v1')]
for key,url in items:
 if any(x['key']==key for x in d['files']):continue
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-bounded-source-research'})
  with urllib.request.urlopen(req,timeout=35) as r:
   remaining=d['limit_bytes']-d['downloaded_bytes'];size=int(r.headers.get('Content-Length','0'))
   if size>remaining:raise ValueError('Content-Length exceeds remaining8MiBbudget: '+str(size))
   raw=r.read(remaining+1);d['downloaded_bytes']+=len(raw)
   assert len(raw)<=remaining and raw.startswith(b'%PDF'), 'PDF/budget check failed'
   resolved=r.url
  p=root/(key+'.pdf');p.write_bytes(raw);subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(p),str(p.with_suffix('.txt'))],check=True)
  row={'key':key,'url':url,'resolved_url':resolved,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'local_path':str(p),'third_party_not_for_redistribution':True};d['files'].append(row);print(json.dumps(row),flush=True)
 except Exception as e:
  row={'key':key,'url':url,'type':type(e).__name__,'error':str(e),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};d['failures'].append(row);print(json.dumps(row),flush=True)
 receipt.write_text(json.dumps(d,indent=2)+'\n')
