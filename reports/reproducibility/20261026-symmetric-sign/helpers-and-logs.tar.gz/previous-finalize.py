from pathlib import Path
import json,gzip,tarfile,io,hashlib,datetime,sys,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP107');O=R/'reports/reproducibility/20261023-weak-mtw';sys.path.insert(0,str(R/'src'))
from ai_value.graph import validate
sha=lambda b:hashlib.sha256(b).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat();ledger=json.loads((R/'data/provenance/readings/F-360.json').read_bytes());clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not (T/'no-math-clean').exists();q=json.loads(gzip.decompress((O/'source-contracts.json.gz').read_bytes()));assert validate(R)==q['metrics'];subprocess.run(['git','diff','--check'],cwd=R,check=True)
third=[]
for d in ledger['historical_selected_originals']:
 p=Path(d['path']);b=p.read_bytes();assert sha(b)==d['sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'primary_pdf'})
for d in ledger['actual_pdf_pixels']:
 p=Path(d['image']);b=p.read_bytes();assert sha(b)==d['sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'viewed_pdf_pixels'})
for p in sorted(T.glob('*.txt')):
 b=p.read_bytes();third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'temporary_third_party_text_not_published'})
assert len(third)==15
for d in third:Path(d['path']).unlink()
assert all(not Path(d['path']).exists() for d in third)
(T/'cleanup-source-receipt.json').write_text(json.dumps({'at':now,'verified_removed':third,'bytes':sum(d['bytes'] for d in third),'policy':'Retain own notes/locators/hashes,not third-party complete works;no new numerical data'},indent=2)+'\n')
# All jobs are terminal. Preserve exact own helpers and all failure/check/replay logs.
own=sorted(p for p in T.iterdir() if p.is_file());assert len(own)==len(list(T.iterdir())),[p.name for p in T.iterdir()];members=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tf:
 for p in own:
  b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b));members.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;archive=O/'helpers-and-logs.tar.gz';archive.write_bytes(z)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive.read_bytes())),mode='r:') as tf:
 assert tf.getnames()==[m['name'] for m in members]
 for m in members:assert sha(tf.extractfile(m['name']).read())==m['sha256']
for p in own:p.unlink()
assert not list(T.iterdir());T.rmdir()
receipt={'at':now,'archive':str(archive.relative_to(R)),'compressed_bytes':len(z),'uncompressed_tar_bytes':len(raw),'archive_sha256':sha(z),'decompressed_tar_sha256':sha(raw),'members':members,'all_member_roundtrip_hashes_verified':True,'own_plaintext_bytes_removed':sum(m['bytes'] for m in members),'third_party_temporary_files_verified_removed':third,'third_party_temporary_bytes_removed':sum(d['bytes'] for d in third),'temporary_root_removed':not T.exists(),'scientific_archive_integrity':{'archives':15,'source_members':267},'representative_actual_replays':['EXP-332-001-b2607a9926c44586','EXP-374-001-bc1d2887fa6a5d33'],'new_scientific_experiment':False,'new_numeric_data':'None;replays isolated and cleaned;all original numerical/raw/source payloads remain compressed','all_quality_jobs_terminal':True,'upstream_math_written':False,'github_write':False,'overall_goal':'active_incomplete'};(O/'storage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','third_party_temporary_files_verified_removed']},ensure_ascii=False))
