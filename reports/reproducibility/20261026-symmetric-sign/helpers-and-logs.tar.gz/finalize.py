from pathlib import Path
import json,gzip,tarfile,io,hashlib,datetime,subprocess
R=Path('/Users/smzdm/projects/ai_paper');T=Path('/private/tmp/ai-paper-WP108-history');O=R/'reports/reproducibility/20261026-symmetric-sign';sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();ledger=json.loads((R/'data/provenance/readings/F-239.json').read_bytes());clean=json.loads(gzip.decompress((O/'no-math-clean-directory.json.gz').read_bytes()));assert clean['exit_code']==0 and not(T/'no-math-clean').exists()
# Selected original files and extracted source/figure pixels stay temporary,not in public archives.
third=[]
for row in ledger['historical_selected_originals']:
 p=Path(row['local_path']);b=p.read_bytes();assert sha(b)==row['sha256'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'primary_pdf'})
for row in ledger['actual_pdf_pixels']:
 p=Path(row['path']);b=p.read_bytes();assert sha(b)==row['sha256'] and row['actually_viewed'];third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'actually_viewed_pixels'})
for p in T.glob('*.txt'):
 b=p.read_bytes();third.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'type':'temporary_fulltext_or_automatic_source_statement_index_not_published'})
assert len(third)==17
for row in third:Path(row['path']).unlink()
assert all(not Path(row['path']).exists() for row in third)
(T/'cleanup-sources.json').write_text(json.dumps({'at':now,'temporary_files_verified_removed':third,'bytes':sum(x['bytes'] for x in third),'new_scientific_experiment':False},indent=2)+'\n')
assert all(p.is_file() for p in T.iterdir());own=sorted(T.iterdir());members=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in own:
  b=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b));members.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);p=O/'helpers-and-logs.tar.gz';p.write_bytes(z);assert gzip.decompress(p.read_bytes())==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(p.read_bytes()))) as t:
 assert t.getnames()==[x['name'] for x in members]
 for row in members:assert sha(t.extractfile(row['name']).read())==row['sha256']
for p in own:p.unlink()
assert not list(T.iterdir());T.rmdir()
receipt={'at':now,'archive':'reports/reproducibility/20261026-symmetric-sign/helpers-and-logs.tar.gz','compressed_bytes':len(z),'uncompressed_tar_bytes':len(raw),'archive_sha256':sha(z),'decompressed_tar_sha256':sha(raw),'members':members,'all_member_roundtrip_hashes_verified':True,'own_plaintext_bytes_removed':sum(x['bytes'] for x in members),'third_party_files_verified_removed':third,'third_party_temporary_bytes_removed':sum(x['bytes'] for x in third),'temporary_root_removed':not T.exists(),'scientific_archive_integrity':{'archives':15,'source_members':267},'new_scientific_experiment':False,'scientific_replays_this_package':[],'new_numerical_data':'None;unchanged original raw/summary/source experiment payloads remain compressed;only software/data checks run.','all_quality_handles_terminal':True,'upstream_math_written':False,'github_write':False,'overall_goal':'active_incomplete'};(O/'storage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','third_party_files_verified_removed']},ensure_ascii=False))
