from pathlib import Path
import json,gzip,hashlib
r=Path.cwd();out=r/'reports/reproducibility/20261029-F271-methods';p=r/'data/provenance/readings/F-271-methods-WP129.json';before=p.read_bytes();z=gzip.compress(before,mtime=0);assert gzip.decompress(z)==before;(out/'initial-method-contracts-before-explicit-test-radius.json.gz').write_bytes(z)
d=json.loads(before);m=next(x for x in d['methods'] if x['id']=='PART-271-DUAL-CAPACITY');m['conditions']=['Counting measure and column-forward U. Real c; ||h||infinity<=M.','There are X,epsilon>=0 with |<mu_d,z>|<=X sqrt(<z,(I-U)z>)+epsilon for BOTH d=+,- and EVERY real z vanishing on K with ||z||infinity<=1+M.'];m['output']='For the probability q of a positive-step return to i before killing, |q-(1-c)|<=|<h,mu+>|+2X^2+2epsilon.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');digest=hashlib.sha256(p.read_bytes()).hexdigest()
p=r/'data/graph/nodes.jsonl';lines=p.read_bytes().splitlines(keepends=True);changed=[];result=[]
for line in lines:
 n=json.loads(line)
 if n['id'].startswith('PART-271-') or n['id']=='GEN-20261029-126':
  changed.append(n)
  for s in n['sources']:
   if s.get('path')=='data/provenance/readings/F-271-methods-WP129.json':s['sha256']=digest
  if n['id']=='PART-271-DUAL-CAPACITY':n['properties'].update(conditions=m['conditions'],output=m['output'])
  if n['id']=='PART-271-PRESSURE-INCREMENTS':n['sources'][-1]['locator']+='; entire containing pressure section and final integrated-derivative proof, not mixture statement alone'
  result.append((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode())
 else:result.append(line)
(out/'initial-new-records-before-explicit-radius.json.gz').write_bytes(gzip.compress(json.dumps(changed,ensure_ascii=False).encode(),mtime=0));p.write_bytes(b''.join(result));print('Explicit test radius and return-probability meaning retained; initial drafts archived.')
