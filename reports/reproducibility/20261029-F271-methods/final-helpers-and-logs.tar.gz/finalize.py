from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess
r=Path.cwd();tmp=Path('/private/tmp/ai-paper-WP129-curation');out=r/'reports/reproducibility/20261029-F271-methods';now=datetime.now(timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=json.loads((out/'quality.json').read_text());assert q['core_exit_code']==0 and q['clean_core_tests']==95 and q['new_method_dependency_cases']==8
ledger=json.loads((r/'data/provenance/readings/F-271-methods-WP129.json').read_text());nodes={json.loads(l)['id']:json.loads(l) for l in (r/'data/graph/nodes.jsonl').read_text().splitlines()};parts=[nodes[m['id']] for m in ledger['methods']]
text='# F271：八个来源方法接口，完整族整理仍在进行\n\n本报告由规范方法记录导出。原文主张不是数学审核通过；八个接口均为来源C、完整链未知，无新增候选或科学运行。118个带标签定位仅是词法索引，不计118个完成拆解。四当前稿已实际读完，整族命题、历史书目和跨域关系仍待整理。\n\n'
for n in parts:
 p=n['properties'];text+='## '+n['id']+' — '+p['title']+'\n\n输入：'+p['input']+'\n\n输出：'+p['output']+'\n\n条件：'+'；'.join(p['conditions'])+'\n\n迁移限制：'+p['cannot_transfer']+'\n\n旧方法比较：'+p['old_baseline']+'\n\n来源：'+n['sources'][-1]['path']+'；'+n['sources'][-1]['locator']+'。\n\n'
(r/'reports/F271-partial-methods.md').write_text(text)
cpath=r/'state/checkpoint.json';c=json.loads(cpath.read_text());c['saved_at']=now;c['updated_at']=now;c['metrics']=json.loads((r/'reports/metrics.json').read_text());item=c['active_work_package'];item.update(execution_state='eight_source_methods_canonical_whole_family_still_in_progress',partial_method_ids=[n['id'] for n in parts],partial_method_curation_evidence=str((out/'quality.json').relative_to(r)),next_action='Semantically qualify all four manuscripts source propositions using the118 source locators, reconcile bibliography aliases and historical dependencies, then ten-domain/crossfamily exploration and whole-family draft QA. Eight method interfaces already canonical; do not recreate them. No numerical run without a frozen specification.');c['next_work_package']=item;c['current_goal_turn_classification']={'previous_turn':'progress','this_turn':'progress','evidence':'Canonical8source methods+generation and8derived_from edges; all prior node/edge bytes retained,95core/95clean,181oldsingle+2multi and8newdependency cases,fullJSON/GraphML/18archives verified. WP129 whole-family and application credit remain incomplete.','goal':'active_incomplete'};c['last_quality_evidence']=str((out/'quality.json').relative_to(r));c['running_research_experiments']=[];c['running_quality_checks']=[];save(cpath,c)
bpath=r/'state/backlog.json';b=json.loads(bpath.read_text());i=next(i for i,t in enumerate(b['tasks']) if t['id']=='WP-129');b['tasks'][i]=item;b['updated_at']=now;save(bpath,b)
s=r/'state/status.md';t=s.read_text();t=t.replace('规范图8874节点26094关系','规范图8891节点26119关系',1).replace('最后核验公开快照仍d48dd19','最后已核验公开快照为612e91b（本轮新增方法仅本地）',1);t=t.replace(t.splitlines()[2],'更新时间：'+now+'。第一阶段仍未完成。',1);t+='\n\nWP129部分规范整理（'+now+'）：八个来源方法与一生成记录、八条derived_from边已入规范图，覆盖条件下一钉均值、双残差容量、环面截流、封闭类迹界、条带曲率、循环迹非零、压力增量与调和选择。全部旧节点/边字节保留，初稿在明确测试半径和返回概率含义前另压缩留档。118定位为词法索引，不计完整命题拆解。95核心/95无math干净副本、181旧单种子/2多种子及8新依赖、全导出/18归档378源码成员通过；未改科学实现或重复实验。候选47/初检15/64阅读59草稿保持；整族命题与历史/跨域仍待。未推GitHub。\n';s.write_text(t)
with (r/'docs/roadmap.md').open('a') as f:f.write('\n\nWP129部分接口整理：八来源方法入图，9新记录8显式边，旧规范行/边字节保持。118词法结果定位不是完整拆解，四稿历史和跨域仍待；不增加完整族、应用候选/初检。95核心/干净95、全图/来源/依赖/导出/归档通过。继续整族语义资格核对。\n')
# Preserve all remaining own helpers/logs before cleanup; no source corpus copies.
buf=io.BytesIO();files=sorted(p for p in tmp.iterdir() if p.is_file())
with tarfile.open(fileobj=buf,mode='w') as t:
 for p in files:
  data=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(data);i.mtime=0;t.addfile(i,io.BytesIO(data))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
(out/'final-helpers-and-logs.tar.gz').write_bytes(z)
for p in files:p.unlink()
assert not list(tmp.iterdir());tmp.rmdir()
save(out/'closure.json',{'at':now,'status':'WP129 remains in_progress','canonical_new_records':9,'canonical_new_edges':8,'method_interfaces':8,'lexical_locators_not_semantic_credit':118,'old_rows_byte_preserved':True,'core_tests':95,'clean_core_tests':95,'old_single_seed_cases':181,'old_multi_seed_cases':2,'new_dependency_cases':8,'scientific_archives':18,'source_members':378,'numerical_target_runs':0,'new_candidates':0,'new_full_family_credit':0,'clean_directory_removed':True,'helper_roundtrip_verified':True,'helper_compressed_sha256':hashlib.sha256(z).hexdigest(),'helper_raw_sha256':hashlib.sha256(raw).hexdigest(),'github_push':False,'goal':'active_incomplete'})
subprocess.run(['git','diff','--check'],check=True);print('Partial method curation checkpoint closed; WP129 remains in progress.')
