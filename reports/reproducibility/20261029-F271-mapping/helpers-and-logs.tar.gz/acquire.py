from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
from concurrent.futures import ThreadPoolExecutor
import urllib.request,urllib.error,json,hashlib

w=Path(__file__).parent;out=Path.cwd()/'reports/reproducibility/20261029-F271-mapping'
class Text(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag in {'script','style'}:self.skip+=1
        if tag in {'p','div','li','h1','h2','h3','h4','pre','tr','br'}:self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in {'script','style'}:self.skip=max(0,self.skip-1)
        if tag in {'p','div','li','h1','h2','h3','h4','pre','tr'}:self.parts.append('\n')
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)
def one(item):
    key,url=item;receipt={'id':key,'url':url,'at':datetime.now(timezone.utc).isoformat()}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-bounded-source-inspection'})
        with urllib.request.urlopen(req,timeout=25) as response:
            b=response.read(2*1024*1024+1);assert len(b)<=2*1024*1024
            receipt.update(status=response.status,final_url=response.url,content_type=response.headers.get('Content-Type'),etag=response.headers.get('ETag'))
        text=b.decode('utf-8')
        if 'html' in (receipt['content_type'] or ''):
            parser=Text();parser.feed(text);text=''.join(parser.parts)
        text='\n'.join(s.strip() for s in text.splitlines() if s.strip())+'\n'
        (w/(key+'.raw')).write_bytes(b);(w/(key+'.txt')).write_text(text)
        receipt.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),text_sha256=hashlib.sha256(text.encode()).hexdigest(),text_lines=len(text.splitlines()),content_read_credit='Selected sections only; acquisition is not semantic reading')
    except Exception as exc:receipt.update(status='unavailable',error=type(exc).__name__+': '+str(exc))
    return receipt
with ThreadPoolExecutor(max_workers=3) as pool:receipts=list(pool.map(one,json.loads((w/'urls.json').read_text())))
assert sum(x.get('bytes',0) for x in receipts)<=16*1024*1024
(out/'acquisitions.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'id':r['id'],'status':r['status'],'bytes':r.get('bytes'),'lines':r.get('text_lines')} for r in receipts]),flush=True)
