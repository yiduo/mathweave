from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,io,tarfile,subprocess

r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-F271-mapping';now=datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=json.loads((out/'quality.json').read_text());m=json.loads((r/'reports/metrics.json').read_text());cur=json.loads((out/'curation.json').read_text())
assert q['core_tests']==q['clean_core_tests']==97 and q['clean_directory_removed']
assert q['old_impact_cases_rechecked']==181 and q['old_multi_seed_cases_rechecked']==2
assert m['candidate_connections']==48 and m['externally_checked_cards']==15
assert m['nodes']==8990 and m['edges']==26373 and cur['new_records']==39
checks=json.loads(gzip.decompress((out/'new-mapping-checks.json.gz').read_bytes()))
assert checks['mandatory_impact_cases']==52 and checks['old47cards_preserved']
rawq=(out/'quality.json').read_bytes();packedq=gzip.compress(rawq,mtime=0);assert gzip.decompress(packedq)==rawq
(out/'quality-before-scope-clarification.json.gz').write_bytes(packedq)
q.update(scope='One conditional application candidate added; no new numerical/external-check,mathematical,human/provider or complete-family acceptance.',new_candidates=1,new_initial_checks=0,new_mapping_nodes=39,new_explicit_edges=54,new_mandatory_dependency_cases=52,primary_document_selected_scopes=11)
save(out/'quality.json',q)
for n in ['representative149','representative325']:
    d=json.loads(gzip.decompress((r/'reports/reproducibility/20261029-CI119'/(n+'.json.gz')).read_bytes()))
    assert all(d['deterministic_outputs_match'].values()) and d['replay_resource_envelope_met']
# Keep the prior pending-review sample and execution state, without calling it
# human review. The reporter also retains versioned sample files.
for rel,name in [('state/human_review_queue.json','human-review-queue-before.json.gz'),('state/checkpoint.json','checkpoint-before-mapping-close.json.gz'),('state/backlog.json','backlog-before-mapping-close.json.gz')]:
    raw=subprocess.check_output(['git','show','61eb419:'+rel]);packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(out/name).write_bytes(packed)
dedup=[]
for line in subprocess.check_output(['git','show','61eb419:data/graph/nodes.jsonl']).splitlines():
    n=json.loads(line)
    if n['kind']=='connection':dedup.append({'id':n['id'],'title':n['properties']['title'],'dedup_key':n['properties']['dedup_key']})
assert len(dedup)==47 and all(d['dedup_key']!='F-271|finite-killed-singleton-return|two-energy-residual-certificate' for d in dedup)
save(out/'dedup-review.json',{'at':now,'old47cards':dedup,'new_hypothesis':'APP-271-01 restricted killed-return dual-certificate workflow','scope':'Manual source/output/baseline comparison plus exact key check. The software, molecular and other domain attempts are not separate cards.','candidate_credit':1,'external_check_credit':0})
closure={'at':now,'generation': 'GEN-20261029-128','WP129':'in_progress','new_records':39,'new_explicit_edges':54,'ten_domains':10,'cross_family_attempts':3,'primary_documents_selected_scopes':11,'new_candidates':1,'candidate_id':'APP-271-01','new_initial_checks':0,'new_numerical_targets':0,'new_full_family_credit':0,'source_claims_semantically_bound':35,'remaining_October_lexical_statements':83,'core_tests':97,'clean_core_tests':97,'old_single_seed_cases':181,'old_multi_seed_cases':2,'new_mandatory_edge_cases':52,'full_JSON_GraphML_equal':True,'scientific_archives':18,'source_snapshot_members':378,'scientific_code_and_old_inputs_unchanged':True,'old_rows_and47cards_preserved':True,'all_new_full_chain_grades_unknown':True,'graph_nodes':8990,'graph_edges':26373,'new_source_claim_grade':'C','real_consumer_instance_admitted':False,'retrospective_counter':1,'github_push':False,'goal':'active_incomplete'}
save(out/'closure.json',closure)

p=r/'state/backlog.json';b=json.loads(p.read_text());t=next(t for t in b['tasks'] if t['id']=='WP-129')
t['next_action']='Global046 application-first action completed: ten documented-domain comparisons, three cross-family attempts and one conditional APP27101 plan, no execution. Continue remaining83 October semantic statements (finite-range30, correction23, spherical30), reusing CLM-271-CORR-CAPACITY for lem:capacity, then bibliography aliases/history and whole-family QA. APP271 requires complete trial/dual certificate cost admission and a separate frozen executable spec before any target. Keep an independent low-coverage/old-candidate action in this cycle; do not keep expanding the same method indefinitely.'
t['partial_application_mapping_evidence']='data/provenance/readings/F-271-application-mapping-WP129.json'
t['application_candidate_ids']=['APP-271-01'];t['additional_semantic_bindings']={'P-e4168cfdc9df4b3b':{'lem:capacity':'CLM-271-CORR-CAPACITY'}}
t['remaining_October_semantic_locators']=83;t['application_mapping_quality_receipt']=str((out/'closure.json').relative_to(r));t['retrospective_due']='Counter1 after global046; next global after two further substantive outputs, or earlier major event.'
b['updated_at']=now;save(p,b)
p=r/'state/checkpoint.json';c=json.loads(p.read_text());c['saved_at']=now;c['updated_at']=now;c['work_packages_since_last_retrospective']=1
c['active_work_package']=t;c['next_work_package']=t;c['substantive_outputs_since_last_retrospective']=['F271 documented ten-domain/three cross-family mapping,one conditional card and selected capacity binding GEN128']
c['metrics']=m;c['last_quality_evidence']=str((out/'quality.json').relative_to(r));c['running_quality_checks']=[];c['running_research_experiments']=[]
c['current_goal_turn_classification']={'previous_turn':'progress','this_turn':'progress','evidence':'GEN128 adds39 source-bound records/54edges,one conditional card after10domain/3cross comparisons and exact input-admission check;97/97,fullgraph/impact/source/archive checks. No numerical/application acceptance.','goal':'active_incomplete'}
save(p,c)
p=r/'state/publication.json';d=json.loads(p.read_text());d['local_progress_after_verified_snapshot']='After public f2aa303: local CI119 diagnostic/controller/upload edits and global046, then GEN128 ten-domain/three cross-family application mapping and conditional APP27101 (48candidates/15checks; graph8990/26373). Not pushed; official math excluded. Public CI remains failure.';save(p,d)
p=r/'state/status.md';old=p.read_text();history=old.split('以下为历次工作记录，数字保留为当时快照。',1)[1]
head='# 当前状态\n\n更新时间：'+now+'。第一阶段仍未完成。\n\n固定上游1581d4cbdd69a0faf34b2089614fe2a814316a6a，math只读未部署。图8990节点26373关系，64阅读/59草稿、48候选/15初检/15不同验证（7限定支持8不利），另1诊断/2组件。完整族/历史/人审/第二供应商/试点仍未完成。\n\nWP129本轮按全局046先完成11官方文档选段的十领域/三跨族对照，新增39规范54边及APP27101有条件返回概率证书候选。源例转列前向/杀死后行和7/5不准入；真实领域输入、完整双方向证书与成本未建立。没有数值目标或新初检。四稿14199行已读；基础34加容量1共35来源绑定，剩余83十月定位待语义整理，整族/历史仍未完成。\n\n97核心/无math干净97，181单种子/2多种子、52新依赖、完整JSON/GraphML与18归档378源码核验通过；旧47卡和全部旧规范行保持。证据reports/reproducibility/20261029-F271-mapping/closure.json。全局046后计数1，下一83语义/历史/全族QA，APP271只准入后另冻可执行规格，不制造有利小实验。保留本周期旧候选/低覆盖动作预算。\n\n公开快照仍f2aa303，远端CI40831475096为failure；CI119本机严格匹配不解释Linux差异，本地失败上传修复尚未部署。本轮未推GitHub。当前没有已知活动研究/检查句柄，真人与第二供应商由用户后补，不重复询问。\n\n以下为历次工作记录，数字保留为当时快照。'
p.write_text(head+history+'\n\nWP129应用映射闭包（'+now+'）：GEN128新增39规范54边，11官方文档仅选段、十领域三跨族及一张条件候选；48候选15初检，来源C/完整链未知，35语义绑定和剩83分开记录。97/干净97与全图/来源/依赖/归档通过，原科学代码/输入/47旧卡保持。第三方暂存正文核散列后清理，自有辅助日志压缩回解核验；不计全族完成，不推送。\n')
p=r/'docs/roadmap.md';s=p.read_text().replace('| M3 广泛连接 | 500候选、150真人分级 | 47候选；','| M3 广泛连接 | 500候选、150真人分级 | 48候选；')
s+='\n\nWP129部分应用映射（'+now+'）：十领域/三跨族对照后保留APP27101有限杀死返回概率双残差证书条件计划，48候选15初检。真实领域输入及双证书完整构造/成本待准入，无数值目标；35来源绑定，剩83十月定位，完整族和历史仍未完成。97/无math干净97与全图/依赖/来源/18归档检查通过。全局046后计数1，下一语义/历史/全族QA，另保留一独立旧候选或低覆盖动作，避免单族垄断。无GitHub推送。\n';p.write_text(s)

# Synchronize local entry docs, explicitly separating them from the old public
# snapshot. These prose updates do not grant any extra research count.
p=r/'README.md';s=p.read_text().replace('8,936节点、26,265关系','8,990节点、26,373关系').replace('| 候选连接 | 47／500','| 候选连接 | 48／500')
s=s.replace('近期可核对的成果：','本地后续进展（尚未推送）：已完成[十领域与跨族对照](reports/F271-application-mapping.md)，保留一张[有条件候选](reports/cards/APP-271-01.md)。当前48候选、15初检，不能把来源文档或计划计为应用验证；公开f2aa303仍为47候选，远端CI的EXP119 raw重放失败另有留证。\n\n近期可核对的成果：')
s=s.replace('十月三稿84条定位仍待语义整理，历史与跨域探索未完成。','另已绑定有限容量引理，十月三稿剩83条定位待语义整理；十领域/三跨族探索已进行，整族与历史仍未完成。')
s=s.replace('最新完成包有95项核心检查','最新本地回归有97项核心检查').replace('reports/reproducibility/20261029-publication/','reports/reproducibility/20261029-F271-mapping/')
p.write_text(s)
p=r/'README.en.md';s=p.read_text().replace('47 candidate connections','48 candidate connections').replace('8,936 nodes and 26,265 relations','8,990 nodes and 26,373 relations')
s=s.replace('Recent checks preserve the old-method null hypothesis.','Local work after public snapshot f2aa303 adds [ten-domain and three cross-family comparisons](reports/F271-application-mapping.md), one conditional [killed-return certificate candidate](reports/cards/APP-271-01.md), and a selected capacity-lemma binding. No numerical target or new preliminary check was run; current local counts are48 candidates/15 checks. The public snapshot remains47 candidates and its latest CI failed EXP119 raw equality (summary matched). Local failure-retention edits are not deployed.\n\nRecent checks preserve the old-method null hypothesis.')
p.write_text(s)
p=r/'PROGRESS.en.md';s=p.read_text().replace('through generation127','through generation128; application mapping and a selected capacity lemma are partial local additions after public f2aa303').replace('47 / 500','48 / 500').replace('8,936 nodes; 26,265 relations','8,990 nodes; 26,373 relations').replace('9,932 core citation annotations','9,986 core citation annotations')
s=s.replace('## Research evidence and current publication delta','## Local additions after the verified public snapshot\n\nGEN128 checked selected sections of11 official consumer documents, retained10 domain and3 cross-family comparisons, and added one restricted killed-return certificate candidate with an unexecuted conditional plan. The source API example fails the matrix contract; no actual molecular data or consumer instance is admitted. There are35 semantically bound source statements,83 October locators still pending, and no added application validation. Local core/clean checks each pass97 tests. These changes are not pushed. Public f2aa303 retains its own47-candidate snapshot and failedCI: EXP119 raw mismatch with matching summary; local failure-upload changes have not been deployed.\n\n## Earlier research evidence and publication context')
s=s.replace('Qualify the remaining 84 October statements (finite range 30, lattice correction 24, spherical law 30), with separate model and limit scopes. The next substantive research output triggers global review046, even while WP129 is unfinished. Then reconcile bibliography/history aliases and ten-domain/cross-family exploration before considering whole-family draft credit.','Continue the remaining83 October statements (finite range30, lattice correction23, spherical law30), reusing the selected capacity binding, then reconcile bibliography/history aliases and whole-family QA. Ten-domain/three-cross exploration has been performed; only APP27101 is proposed. It needs complete dual-certificate cost admission and a separately frozen executable spec. Global046 is complete; this is the first substantive output of its next cycle, which must also preserve old-candidate/low-coverage work.')
p.write_text(s)

# Verify and remove acquired third-party bodies. Retain hashes and selected
# paraphrases, not full external pages or datasets, in the project.
acq=json.loads((out/'acquisitions.json').read_text());removed=[]
for a in acq:
    for ext,key in [('raw','sha256'),('txt','text_sha256')]:
        p=w/(a['id']+'.'+ext);raw=p.read_bytes();assert sha(raw)==a[key]
        removed.append({'name':p.name,'bytes':len(raw),'sha256':sha(raw)});p.unlink()
assert not (w/'clean').exists()
files=sorted(p for p in w.iterdir() if p.is_file());manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
    for p in files:
        raw=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(raw);i.mtime=0;tar.addfile(i,io.BytesIO(raw));manifest.append({'name':p.name,'bytes':len(raw),'sha256':sha(raw)})
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
    for a in manifest:assert sha(tar.extractfile(a['name']).read())==a['sha256']
(out/'final-helpers-and-logs.tar.gz').write_bytes(packed)
for p in files:p.unlink()
w.rmdir()
save(out/'storage.json',{'at':now,'removed_external_artifacts':removed,'external_raw_bytes':sum(a['bytes'] for a in acq),'helper_members':manifest,'compressed_sha256':sha(packed),'decompressed_sha256':sha(raw),'gzip_bytes':len(packed),'roundtrip_verified':True,'temporary_directory_removed':not w.exists(),'clean_copy_removed':True,'official_math_copied':False,'new_numerical_targets':0,'github_push':False})
print(json.dumps({'graph':[8990,26373],'candidates':48,'initial_checks':15,'core':97,'clean':97,'domains':10,'cross':3,'remaining_claims':83,'counter':1,'external_bodies_removed':len(removed),'helper_roundtrip':True,'goal':'active_incomplete'}))
