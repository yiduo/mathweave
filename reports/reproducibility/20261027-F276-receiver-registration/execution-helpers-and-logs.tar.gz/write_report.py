from pathlib import Path
import gzip,json,hashlib
r=Path.cwd(); out=r/'reports/reproducibility/20261027-F276-receiver-registration'
p=r/'reports/F276-receiver-preregistration.md';b=p.read_bytes();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b
saved=out/'preregistration-report-before-execution.md.gz';assert not saved.exists();saved.write_bytes(z)
p.write_text('''# F276 固定接收机审计：注册、执行与证据边界

原预测和原计划保留。执行前 v1 规格经两个实际隔离的同供应商角色静态审查；意见不构成真人审核或第二供应商复核。审查发现的 RSS、失败留证、阈值歧义、端点及优化器规则，在任何目标输出前修订为 v2，再实现并冻结代码。

冻结实现提交为 `f77389a`，规格 v2 SHA256 为 `affc2f794cf6110b12a863726f3b6801d98f615cf73b8cbfc54e3a2ebc42ebd1`。原125点、27内部点、0.01 bit/use阈值、60秒与双64MiB上限没有根据结果调整。两角色实际评阅的是 v1；v2修订及实现由执行者核查，不能称两角色已复审通过 v2 或代码。

原始意见及冻结包：`data/provenance/reviews/APP-276-01-pre-execution.json.gz`。旧执行前报告原字节：`reports/reproducibility/20261027-F276-receiver-registration/preregistration-report-before-execution.md.gz`。

实现包含真实四 Kraus 矩阵乘法、两个输出谱、实际投影概率和联合分布互信息；另一路独立 Decimal 标量概率和熵以70/100位复核。两条计算路径仍由同一供应商实现，精度一致不等于严格区间证明。软件层面6项控制及首次运行前75项核心检查通过；旧归档缺少资源布尔字段的兼容问题在首次目标输出前依据原规格与实际度量修复，失败日志保留。

## 实际有限结果

`EXP-276-001-b27918614d6d2c9d`完成125点与25组近似优化比较。27个内部点中14个在所有声明路径上超过原0.01 bit/use阈值及预先固定的1e-10安全裕量；没有阈值不确定点或检查错误。矩阵／标量最大残差约6.0e-15。首次按网格顺序超阈的参数为 gamma=nu=p=1/4：Holevo为0.5278361889、固定X互信息为0.4564355568、差值为0.0714006321 bit/use。所有125点最大差值为0.1658570271，含边界点；内部最大值为0.0714006321，两者不能混称。

主网格86次浮点端点修剪逐条保存；没有无记录归一化。近似优化严格96步，候选不回填主网格，未给出全局最优证书。算法耗时3.537805秒，Python分配峰值2,653,305字节，进程生命周期峰值RSS为37,617,664字节（Darwin原始单位字节，约35.875MiB）；压缩另耗0.110186秒。资源闸门均通过。首次尝试保存源码、stdout/stderr及151个压缩进度成员，异常和失败路径不因成功而删除。

隔离目录使用归档源码重放，完整raw和summary JSON完全相等，没有排除任何字段；重放同样满足资源上限。数据、汇总和输入源码快照压缩保留，输出与解压散列逐项检查。

## 改变的判断与未改变的缺口

原 APP-276-01 的限定合成预测得到一次实际初检支持。它说明同一编码的Holevo信息不能直接标为固定X接收机已实现的速率。人为错误标签不是发现真实软件缺陷；诚实旧经典条件概率已经给出正确预算。没有建立2026结果带来的新计算增益。

没有真实硬件标定、最优单次POVM、有限码、一般多次使用可加性证明或新定理验证。理论完整链仍未知，人审、第二供应商、完整成果族与完整历史谱系均未完成。APP-276-01保留原预测及旧硬件准入不成立的记录，版本2归档后更新为版本3、工作流待人工。125点和25组优化只计同一条假设，隔离重放不另增数量。

规范依据：`data/graph/nodes.jsonl`中的`APP-276-01`、`OBS-276-FROZEN-RECEIVER-AUDIT`、`PART-276-TYPED-RECEIVER-AUDIT`与`GEN-20261027-114`；原记录归档于`data/graph/history/GEN-20261027-114-before.json.gz`。实际运行清单位于`experiments/runs/EXP-276-001-b27918614d6d2c9d/manifest.json`。

停止扩大已知校准网格。下一工作包优先补一条关键历史依赖，之后继续低覆盖成果族／未读伴随稿；完整质量、干净复现和临时文件清理状态依本包收据，不从一次实验成功推定。日常只本地保存，不推送GitHub。
''')
for name in ['README.md','README.en.md','PROGRESS.en.md','docs/roadmap.md']:
 p=r/name; text=p.read_text()
 if name=='README.md':
  text=text.replace('其中13张局部初检卡片、13项不同假设的可复现检验；五项限定预测支持、八项不利观察。这些结果不等于五项新数学或工程收益。','其中14张局部初检卡片、14项不同假设的可复现检验；六项限定预测支持、八项不利观察。这些结果不等于六项新数学或工程收益。')
  needle='最新本地[F047映射消费者核查]'
  text=text.replace(needle,'最新本地[F276固定接收机审计](reports/F276-receiver-preregistration.md)完成125个预注册参数点和25组优化比较；14/27内部点超过原阈值，隔离归档源码重放全部raw/summary完全相等，60秒／双64MiB资源闸门通过。原卡片版本化，限定合成预测支持；旧经典概率已经足够，没有建立2026计算增益、真实设备收益或可加性证明。\n\n'+needle,1)
 elif name=='docs/roadmap.md':
  lines=text.splitlines()
  for i,line in enumerate(lines):
   if line.startswith('| M1 '):lines[i]='| M1 代表性闭环 | 跨学科/可信度/应用距离样例，从原文到卡片和外部检验 | 十四项局部闭环；完整谱系、独立模型和真人审核仍缺 |'
   elif line.startswith('| M2 '):lines[i]='| M2 全量知识底座 | 372族完整拆解、可信度与历史谱系 | 61族实际阅读，56族当前稿全文草稿；F238为6/12篇；完整族与完整历史谱系仍0 |'
   elif line.startswith('| M3 '):lines[i]='| M3 广泛连接 | 500候选、150真人分级 | 46候选；十域尝试、书目与需求反查不等于应用候选；真人0 |'
   elif line.startswith('| M4 '):lines[i]='| M4 检验排序 | 100初检、10不同假设复现 | 14卡/14假设；6项限定预测支持、8项不利；仅达到10的数量子项，M4尚未完成；2项组件检查另列 |'
  text='\n'.join(lines)+'\n'
 else:
  # Keep older dated paragraphs as a history, with an explicit current boundary first.
  header='''
Current local WP117 result: 46 candidates, 14 initially checked cards / distinct hypotheses, six limited predictions supported and eight adverse observations; 61 families actually read and 56 current-source drafts. The frozen F276 synthetic fixed-X audit completed 125 fixtures and 25 optimizer comparisons; 14 of 27 interior fixtures exceed the original 0.01 bit/use threshold. Exact archived-source replay matches complete raw and summary outputs. Honest old classical probabilities already suffice: no new 2026 computational advantage or device benefit. Full family/history closure and human/provider reviews remain incomplete. This local increment is not on GitHub. See [execution and limits](reports/F276-receiver-preregistration.md) and [generated metrics](reports/metrics.json).
'''
  parts=text.split('\n',1);text=parts[0]+'\n'+header+'\n'+parts[1]
 p.write_text(text)
print('Execution report and bilingual current-progress entries saved; older dated statements retained as history.')
