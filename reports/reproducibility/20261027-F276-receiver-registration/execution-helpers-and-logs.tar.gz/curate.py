from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import copy, gzip, hashlib, json, subprocess

r=Path.cwd(); w=Path(__file__).resolve().parent
now=datetime.now(timezone.utc).isoformat(); gen='GEN-20261027-114'
rid='EXP-276-001-b27918614d6d2c9d'; run='experiments/runs/'+rid+'/'
def read(p): return json.loads((r/p).read_text())
def save(p,d):
    p=r/p; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def packed(p,d):
    b=json.dumps(d,ensure_ascii=False,indent=2).encode(); z=gzip.compress(b,mtime=0)
    assert gzip.decompress(z)==b
    p=r/p; assert not p.exists(); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(z)
def source(p,loc): return {'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest(),'locator':loc}
np=r/'data/graph/nodes.jsonl'; ep=r/'data/graph/edges.jsonl'
oldlines=np.read_bytes().splitlines(keepends=True); old=[json.loads(x) for x in oldlines]; by={x['id']:x for x in old}
assert gen not in by and len(old)==5263 and by['APP-276-01']['version']==2
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert base.startswith('f77389a')
spec=read('experiments/specs/EXP-276-001.json'); m=read(run+'manifest.json')
assert hashlib.sha256((r/'experiments/specs/EXP-276-001.json').read_bytes()).hexdigest()=='affc2f794cf6110b12a863726f3b6801d98f615cf73b8cbfc54e3a2ebc42ebd1'
raw=json.loads(gzip.decompress((r/(run+'raw.json.gz')).read_bytes()))
s=json.loads(gzip.decompress((r/(run+'summary.json.gz')).read_bytes()))
assert m['result']=='passes_preregistered_prediction' and m['resource_envelope_met'] and s['meets_prediction']
replay='reports/reproducibility/20261027-F276-receiver-registration/first-target-replay.json.gz'
rr=json.loads(gzip.decompress((r/replay).read_bytes())); assert all(rr['deterministic_outputs_match'].values()) and rr['replay_resource_envelope_met']
fixtures=[x for x in raw if x['kind']=='fixture']; interior=[x for x in fixtures if x['stratum']=='interior']
assert len(raw)==150 and len(fixtures)==125 and len(interior)==27 and len(s['interior_gap_exceedance_indices'])==14
first=next(x for x in fixtures if x['index']==s['interior_gap_exceedance_indices'][0])
precision=max(abs(Decimal(x['decimal70'][k])-Decimal(x['decimal100'][k])) for x in fixtures for k in ['holevo_bits','fixed_x_mi_bits','gap_bits'])
compact={k:v for k,v in s.items() if k not in ['control_residuals','naive_and_honest_old_labels']}
compact.update(interior_gap_exceedances=14,maximum_interior_same_encoder_gap_bits=max(x['matrix']['gap_bits'] for x in interior),max_decimal70_100_fixture_disagreement=str(precision),primary_fixture_clamps_recorded=sum(len(x['matrix']['clamps']) for x in fixtures),first_in_order_interior_exceedance={'index':first['index'],'gamma':first['gamma'],'nu':first['nu'],'p':first['p'],'holevo_bits':first['matrix']['holevo_bits'],'fixed_x_mi_bits':first['matrix']['fixed_x_mi_bits'],'gap_bits':first['matrix']['gap_bits']},exact_complete_archived_replay=True,initial_check_eligible=True,incremental_value='Finite synthetic receiver-label calibration only; honest old classical probabilities already supply the correct receiver budget. No new 2026 computational gain established.',naive_labels='Primary: same encoder Holevo incorrectly labeled as achieved fixed-X rate. Separate approximate optimized Holevo label also retained, never substituted into primary grid.',baseline='Honest old classical conditional probability computation; not a weak dimension-only bound.')
ledger='data/provenance/experiments/EXP-276-001-execution.json'
save(ledger,{'at':now,'generation_id':gen,'implementation_commit_before_outputs':base,'original_prediction_preserved':by['APP-276-01']['properties']['prediction'],'original_plan_sha256':by['APP-276-01']['sources'][0]['sha256'],'specification_version':2,'specification_sha256':m['inputs']['experiments/specs/EXP-276-001.json'],'run_id':rid,'attempt_receipt':'experiments/attempts/EXP-276-001-20261027T043051267838Z-51ff22b5/attempt.json','replay_receipt':replay,'summary':compact,'resources':{k:m[k] for k in ['elapsed_seconds','peak_traced_python_bytes','process_peak_rss_bytes','process_rss_measurement','archive_compression_seconds','resource_envelope_met']},'interpretation':'Nonblind finite synthetic numerical calibration. Not a mathematical proof, full family closure, optimal individual POVM, finite-code or device result. Two static isolated auxiliary roles reviewed v1; v2 repaired execution semantics before implementation and first target outputs. No human or independent-provider review.','source_hashes_checked':True})
config='data/provenance/research-at-generation-114.json'; assert not (r/config).exists(); (r/config).write_bytes((r/'configs/research.json').read_bytes())
reviews='data/provenance/reviews/APP-276-01-pre-execution.json.gz'
srcs=[source(ledger,'Actual first frozen run, old-method null, costs, limitations and strict complete replay'),source(run+'manifest.json','Actual compressed outputs and input hashes; both frozen resource gates pass'),source(run+'summary.json.gz','125 fixed fixtures, 27 interior, 14 conservative threshold exceedances, all controls and 25 optimizer pairs'),source(run+'raw.json.gz','All 150 complete fixture and optimization records, matrices, probabilities and numerical endpoint adjustments'),source(replay,'Archived-source isolated exact complete raw and summary replay; no excluded fields'),source('experiments/specs/EXP-276-001.json','Version 2 frozen before target outputs; original grid, 0.01 bit threshold and 60 seconds / dual 64 MiB caps')]
new=[]
def node(id,kind,evidence,p,sources):
    x={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':evidence,'properties':p,'sources':sources};new.append(x);return x
common={'model_generation_id':gen,'family_ids':['F-276'],'credibility':'unknown','dependency_closure_complete':False}
node(gen,'generation','source_content_checked',dict(common,title='F276 frozen synthetic fixed-X audit execution and evidence-bounded card version',provider='OpenAI',model='Current selected session; exact backend unknown',seed_list_exposed=True,project_base_commit=base,independent_second_provider=None,human_review=None),[source(ledger,'Execution evidence, actual finite scope and unaltered original prediction'),source(config,'Research policy snapshot')])
method='PART-276-TYPED-RECEIVER-AUDIT'; observation='OBS-276-FROZEN-RECEIVER-AUDIT'
node(method,'method','experiment_observation',dict(common,title='Typed fixed-encoder receiver budget audit',input='Frozen rational GAD gamma, nu, p; equiprobable phase pair; explicitly fixed Pauli-X projective receiver',output='Same-encoder Holevo and actual joint-probability mutual information with separate receiver labels, cross-checks and resource receipts',conditions='125 fixed cases; 27 interior. Actual four-Kraus matrix multiplication and spectra compared with independent Decimal scalar probabilities/entropy at 70/100 digits. Bits per use. Exact replay and frozen resource envelope.',cannot_transfer='No hardware calibration, optimal POVM, finite code, arbitrary-block additivity proof, rigorously certified global optimizer, interval certificate or new 2026 computational advantage.'),[source('src/ai_value/receiver_audit.py','Implementation frozen in f77389a before outputs; distinct matrix and scalar paths'),source('experiments/specs/EXP-276-001.json','Unchanged executable v2 and declared numerical tolerances'),source(ledger,'Actual finite test scope and old classical comparator')])
node(observation,'claim','experiment_observation',dict(common,title='Finite frozen same-encoder Holevo versus fixed-X gap observation',statement='At 14 of the 27 preregistered interior fixtures all declared numerical paths exceed the original 0.01 bit/use gap with the frozen 1e-10 safety allowance. All 125 fixtures and 25 approximate optimizer comparisons pass declared controls. This supports only the original synthetic receiver-constraint calibration.',conditions=['Same equiprobable phase-pair encoder at identical p; no optimized p inserted into the primary grid','Only the 125 frozen rational fixtures; precision agreement is not an interval proof','Honest old classical conditional probabilities already compute the receiver rate; no incremental 2026 computational gain established'],summary=compact,source_claim_grade='unknown',dependency_chain_grade='unknown'),srcs)
changed={}
archive='data/graph/history/GEN-20261027-114-before.json.gz'
for id in ['APP-276-01','PROB-276-LINK','ANALYSIS-F-276']:
    x=copy.deepcopy(by[id]); x.update(version=x['version']+1,updated_at=now,updated_by_generation_id=gen,prior_version_archive=archive)
    x['properties'].update(last_updated_at=now,prior_version_archive=archive,version_reason='Actual frozen synthetic run and strict replay completed; preserve original prediction, origin generation, theoretical and hardware gaps')
    changed[id]=x
app=changed['APP-276-01']; app['evidence_status']='experiment_observation';p=app['properties']
p.update(application_result='通过',workflow='待人工',external_check_type='preregistered_synthetic_four_Kraus_matrix_and_independent_classical_Decimal_crosschecks_with_exact_archived_replay',test_spec='experiments/specs/EXP-276-001.json',run_ids=[rid],summary=compact,resources=f"Python standard library; runner {m['elapsed_seconds']:.6f}s, traced Python peak {m['peak_traced_python_bytes']} bytes, whole-process lifecycle peak RSS {m['process_peak_rss_bytes']} bytes; 60s / dual 64MiB gates met. Compression {m['archive_compression_seconds']:.6f}s separately reported. Raw, summary, source snapshot and progress compressed.",priority_reason='Original synthetic prediction now checked once. Stop expanding known calibration grids; prioritize critical historical dependency closure and low-coverage families. Old honest probabilities already suffice.',limitations='仅固定125个合成参数点与固定X接收机；14/27内部点超原阈值。端点修剪全部留痕、70/100位与矩阵一致仍非严格区间证明。96步优化仅近似标杆、未认证全局最优。非实际硬件标定、最优单次POVM、有限块码、新可加性证明或2026计算增益。人为错误标签不等于发现真实软件误用。完整理论链未知、人审与独立第二供应商缺失。',publication_scope='Finite synthetic receiver-constraint calibration; no new theorem or engineering performance gain',revisit_when='有实际接收机/信道校准与具体设计决策，或严格误差证书需求时重新准入；新理论增量需另登记真实旧新界差异实例。',original_plan='experiments/plans/MAP-276-001.json',finite_observation_id=observation)
assert p['prediction']==by['APP-276-01']['properties']['prediction'] and p['theoretical_grade']=='unknown'
p['part_ids']=p['part_ids']+[method]
for role,text in [('opposition','检验前隔离意见：固定X差距属于旧信息论；人为错误标签不证明真实工作流误用，新2026增量、真实设备与最优POVM不能据此成立。RSS、失败留证、阈值歧义与端点规则须在输出前落实。'),('defense','检验前隔离意见：原同编码、固定X预测可作为有限合成校准；诚实旧经典概率是必须保留的强基线。只有实际全部裁判、控制和资源闸门通过才记一次原卡片初检。')]:
    p[role]={'text':text,'type':'actual isolated same-provider auxiliary static review','timing':'pre-experiment;specification_v1_before_implementation_and_v2_execution_repairs','independent':False,'isolated_same_provider_agent':True,'provider':'OpenAI','exact_backend_model':'unknown','source':reviews,'second_provider':False,'human':False}
app['sources']+=srcs+[source(reviews,'Actual isolated static opinions before target outputs; reviewed v1, execution repairs versioned in v2 before outputs')]
pr=changed['PROB-276-LINK']['properties'];pr['verification']='Source and five selected original historical scopes checked previously. Now finite synthetic fixed-X numerical calibration and exact replay completed; no real customer/device, full lineage or general capacity proof validation.';pr['synthetic_observation_id']=observation
changed['PROB-276-LINK']['sources']+=[source(ledger,'Finite synthetic observation only; original real-calibration/model eligibility gap unchanged')]
an=changed['ANALYSIS-F-276']['properties']; assert 'No calibratedquantumdevice,finitecollectivereceiverimplementationorcompletednumericaltest' in an['gaps']
an['gaps']=[('No calibrated quantum device or finite collective receiver implementation. Frozen fixed-X synthetic calibration completed; not theorem, hardware or new-2026-gain validation.' if v=='No calibratedquantumdevice,finitecollectivereceiverimplementationorcompletednumericaltest' else v) for v in an['gaps']];an['application_check_scope']='APP-276-01 finite synthetic calibration; full family and historical lineage remain incomplete'
changed['ANALYSIS-F-276']['sources']+=[source(ledger,'Update numerical-gap wording only; no new source-reading coverage, formal build or historical closure')]
packed(archive,{'generation_id':gen,'reason':'Preserve all three exact prior records, original prediction and gaps before finite numerical evidence update','records':[by[x] for x in changed]})
edges=[]; existing={x['id'] for x in map(json.loads,ep.read_text().splitlines())}
def edge(a,rel,b,loc):
    id='E-'+hashlib.sha256(f'{a}|{rel}|{b}'.encode()).hexdigest()[:16].upper(); assert id not in existing;existing.add(id)
    edges.append({'id':id,'source':a,'relation':rel,'target':b,'version':1,'created_at':now,'evidence_status':'experiment_observation','source_locator':loc})
edge(observation,'uses',method,'Actual distinct matrix and scalar numerical paths; implementation/spec changes invalidate finite observation')
edge(observation,'member_of','F-276','Finite observation only; not a source theorem or full-family completion')
edge('APP-276-01','derived_from',observation,'Only original finite synthetic prediction supported; theoretical dependency grade unchanged')
edge('APP-276-01','uses',method,'Explicit receiver-typed budget, fixed encoder and honest classical comparator')
edge('PROB-276-LINK','has_finite_calibration',observation,'Contextual synthetic observation; no actual-device admission')
edge('ANALYSIS-F-276','records_observation',observation,'Numerical gap update; no added source coverage')
edge(gen,'records_execution',observation,'Actual frozen first run and strict replay; not human or independent-provider review')
nb=b''.join((json.dumps(changed[x['id']],ensure_ascii=False,sort_keys=True).encode()+b'\n') if x['id'] in changed else line for line,x in zip(oldlines,old))
nb+=b''.join(json.dumps(x,ensure_ascii=False,sort_keys=True).encode()+b'\n' for x in new);np.write_bytes(nb)
with ep.open('ab') as f:
    for e in edges:f.write(json.dumps(e,ensure_ascii=False,sort_keys=True).encode()+b'\n')
save(w/'curation-summary.json',{'at':now,'generation':gen,'base_commit':base,'old_records':len(old),'old_records_preserved_bytewise':len(old)-len(changed),'updated_records':{k:[by[k]['version'],v['version']] for k,v in changed.items()},'new_records':[x['id'] for x in new],'new_explicit_edges':len(edges),'prior_archive':archive,'new_candidates':0,'new_initial_checks':1,'new_distinct_hypotheses':1,'new_limited_support':1,'scientific_runs':[rid],'original_prediction_exactly_preserved':True})
print(json.dumps({'new_nodes':len(new),'updated':list(changed),'new_edges':len(edges),'expected_candidates':46,'expected_initial_checks':14,'expected_limited_support':6},ensure_ascii=False))
