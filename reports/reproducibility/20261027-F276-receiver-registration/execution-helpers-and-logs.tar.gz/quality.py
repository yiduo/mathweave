from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,copy,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report,CARD_FIELDS
from ai_value.reporting import render
from ai_value.knowledge import export
from ai_value.attempts import within_frozen_resources
r=Path.cwd();w=Path(__file__).resolve().parent;base='f77389a'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
oldlines=old('data/graph/nodes.jsonl').splitlines(keepends=True);current=(r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)
changed={'APP-276-01','PROB-276-LINK','ANALYSIS-F-276'}
archive=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-114-before.json.gz').read_bytes()))
prior={n['id']:n for n in archive['records']}; kept_nodes=0
for a,b in zip(oldlines,current):
 x=json.loads(a);y=json.loads(b);assert x['id']==y['id']
 if x['id'] in changed: assert prior[x['id']]==x and y['version']==x['version']+1
 else:assert a==b;kept_nodes+=1
assert kept_nodes==5260 and len(current)==5266
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert len((r/'data/graph/edges.jsonl').read_bytes().splitlines())-len(old('data/graph/edges.jsonl').splitlines())==7
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')) and name!='reports/families/F-276.md':
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==61 and generated['source_decomposition_drafts']==56
assert generated['candidate_connections']==46 and generated['externally_checked_cards']==14 and generated['effective_leads']==6 and generated['distinct_validation_hypotheses']==14
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
p=nodes['APP-276-01']['properties'];assert CARD_FIELDS<=p.keys() and p['prediction']==prior['APP-276-01']['properties']['prediction'] and p['dedup_key']==prior['APP-276-01']['properties']['dedup_key']
assert p['theoretical_grade']=='unknown' and not p['dependency_closure_complete'] and p['workflow']=='待人工' and p['application_result']=='通过'
assert p['demand_reviews']==prior['APP-276-01']['properties']['demand_reviews']
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)}
xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F047-map-consumers/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
def source_id(path):
 xs=[x['id'] for x in nodes.values() if x['kind']=='source_artifact' and x['properties'].get('path')==path];assert len(xs)==1;return xs[0]
obs='OBS-276-FROZEN-RECEIVER-AUDIT';method='PART-276-TYPED-RECEIVER-AUDIT';rid='EXP-276-001-b27918614d6d2c9d';folder=r/'experiments/runs'/rid
for a,b in [('CLM-276-THM-MAIN','APP-276-01'),(method,obs),(obs,'APP-276-01'),(source_id('src/ai_value/receiver_audit.py'),obs),(source_id('experiments/runs/'+rid+'/manifest.json'),'APP-276-01')]:
 assert b in impact_report(nodes,edges,{a})['affected'];impacts.append({'seed':a,'required_affected':b,'confirmed':True})
for a,b in [(obs,'CLM-276-THM-MAIN'),(method,'CLM-276-THM-MAIN'),(source_id('experiments/runs/'+rid+'/raw.json.gz'),'CLM-276-THM-MAIN'),(obs,'APP-142-01'),(obs,'APP-221-01')]:
 assert b in nodes and b not in impact_report(nodes,edges,{a})['affected'];impacts.append({'seed':a,'must_not_propagate_to':b,'confirmed':True,'scope':'Finite observation/code evidence does not certify a source theorem or unrelated application'})
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,digest in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==digest
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==16
replay=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F276-receiver-registration/first-target-replay.json.gz').read_bytes()));assert all(replay['deterministic_outputs_match'].values()) and replay['replay_resource_envelope_met'] and replay['comparison_scope']=='Exact complete JSON payloads; no fields excluded'
m=json.loads((folder/'manifest.json').read_text());spec=json.loads((folder/'spec.json').read_text());assert within_frozen_resources(m,spec)
for mutate in [dict(process_peak_rss_bytes=65*1024**2),dict(resource_envelope_met=False),dict(elapsed_seconds=61),dict(peak_traced_python_bytes=65*1024**2)]:
 negative=copy.deepcopy(m);negative.update(mutate);assert not within_frozen_resources(negative,spec)
attempt=json.loads((r/'experiments/attempts/EXP-276-001-20261027T043051267838Z-51ff22b5/attempt.json').read_text())
assert attempt['target_completed'] and attempt['worker_exit_code']==0
progress=sorted((r/'experiments/attempts/EXP-276-001-20261027T043051267838Z-51ff22b5/progress').glob('*.json.gz'));assert len(progress)==151
for p in progress:json.loads(gzip.decompress(p.read_bytes()))
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_rows_byte_equal':kept_nodes,'updated_record_versions':{k:[prior[k]['version'],nodes[k]['version']] for k in sorted(changed)},'new_records':3,'new_explicit_edges':7,'old_explicit_edge_prefix_equal':True,'preserved_science_code_tests_corpus_other_family_reports_and_reading_ledgers':len(preserved),'reading_coverage_byte_equal':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'experiment_archives':archives,'source_archive_members':members,'actual_representative_replays':[replay],'new_candidates':0,'application_checks_added':1,'distinct_hypotheses_added':1,'new_scientific_runs':1,'original_card_prediction_dedup_demand_reviews_preserved':True,'resource_negative_cases':4,'compressed_progress_members':151,'limitations':'Finite synthetic prediction only. Exact repeat is reproducibility evidence, not a new hypothesis; no new 2026 gain, full family/history closure, human/provider review or real device acceptance.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','experiment_archives','generated_metrics','actual_representative_replays']},ensure_ascii=False))
