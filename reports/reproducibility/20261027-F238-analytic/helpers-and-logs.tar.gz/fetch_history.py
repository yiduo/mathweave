from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,subprocess,json
w=Path(__file__).parent
sources=[('Demailly2012','https://www-fourier.univ-grenoble-alpes.fr/~demailly/manuscripts/agbook.pdf',8000000),('BereleRegev1983','https://www.ams.org/journals/bull/1983-08-02/S0273-0979-1983-15110-8/S0273-0979-1983-15110-8.pdf',1000000),('ChristandlKonigRenner2009','https://arxiv.org/pdf/0809.3019v1',1000000),('DiaconisShahshahani1981','https://www.imo.universite-paris-saclay.fr/~pierre-loic.meliot/symmetric/texts/Diaconis%2C%20Shahshahani%20-%20Generating%20a%20random%20permutation%20with%20random%20transpositions.pdf',2000000)]
def fetch(s):
 key,url,cap=s;r={'key':key,'url':url,'cap_bytes':cap,'at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-audit/1.0'}),timeout=30) as x:raw=x.read(cap+1);r.update(final_url=x.url,http_status=x.status)
  assert len(raw)<=cap and raw.startswith(b'%PDF'),'not bounded PDF'
  p=w/(key+'.pdf');t=w/(key+'.txt');p.write_bytes(raw);r.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  z=subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(p),str(t)],capture_output=True,timeout=25);r['conversion_exit']=z.returncode;assert z.returncode==0
  b=t.read_bytes();r.update(text_bytes=len(b),text_sha256=hashlib.sha256(b).hexdigest(),text_lines=len(b.splitlines()),status='retrieved_not_yet_read')
 except Exception as e:r.update(status='failed',failure=repr(e))
 return r
with ThreadPoolExecutor(max_workers=4) as x:rows=list(x.map(fetch,sources))
(w/'history-fetch.json').write_text(json.dumps({'rows':rows,'raw_bodies_republished':False,'pdf_analysis':'converted text only'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False))
