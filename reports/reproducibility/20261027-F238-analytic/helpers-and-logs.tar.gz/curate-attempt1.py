from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess,sys
sys.path.insert(0,'src')
from ai_value.graph import validate
from ai_value.source_results import named_results
r=Path.cwd();w=Path(__file__).parent;now=datetime.now(timezone.utc).isoformat();G='GEN-20261027-121';M='P-2a0250a8d5ca112d';F='F-238';UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a';prefix='math/preprints/Conditional-coordinate-sweeps-and-analytic-transfer-September-26-2026/build/'
np=r/'data/graph/nodes.jsonl';ep=r/'data/graph/edges.jsonl';cp=r/'data/graph/reading_coverage.json';on=np.read_bytes();oe=ep.read_bytes();oc=cp.read_bytes();oldrows=on.splitlines();by={n['id']:n for n in map(json.loads,oldrows)};old=copy.deepcopy(by);assert len(by)==5457 and G not in by
history_path='data/graph/history/'+G+'-before.json.gz';changed=set();new=[];edges=[];keys={(e['source'],e['relation'],e['target']) for e in map(json.loads,oe.splitlines())}
s=json.loads((w/'qualification.json').read_text());j=json.loads((r/'state/reading-progress/WP-124.json').read_text());hp='data/provenance/readings/F-238-analytic-history.json';fp='data/provenance/readings/F-238-analytic-formal.json';lp='data/provenance/readings/F-238-analytic.json';h=json.loads((r/hp).read_text());formal=json.loads((r/fp).read_text())
assert j['full_manuscript_read'] and j['actual_source_lines_read']==1791 and not j['remaining_source_paths']
def save(p,d):p=r/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def gzsave(p,d):
 raw=json.dumps(d,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;p=r/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z)
def src(p,loc):return {'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest(),'commit':UP if p.startswith('math/') else None,'locator':loc}
def add(id,kind,props,sources,status='source_claim'):
 assert id not in by,id
 n={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':status,'properties':{'model_generation_id':G,'dependency_closure_complete':False,**props},'sources':sources};by[id]=n;new.append(n);return n
def revise(id):
 if id not in changed:by[id].update(version=by[id]['version']+1,updated_at=now,updated_by_generation_id=G,prior_version_archive=history_path);changed.add(id)
 return by[id]
def edge(a,rel,b,loc):
 assert a in by and b in by,(a,b)
 if (a,rel,b) in keys:return
 keys.add((a,rel,b));edges.append({'id':'E-'+hashlib.sha256((a+'|'+rel+'|'+b).encode()).hexdigest()[:16].upper(),'source':a,'relation':rel,'target':b,'version':1,'created_at':now,'evidence_status':'source_claim','source_commit':UP,'source_locator':loc})
def cid(l):return 'CLM-238-ANALYTIC-'+re.sub('[^A-Za-z0-9]+','-',l).strip('-').upper()
files=j['actual_source_ranges'];paths={x['path'] for x in files};rows=[];bysource={};labels={};entries={};includes=[]
for f in files:
 p=f['path'];t=(r/p).read_text();assert hashlib.sha256((r/p).read_bytes()).hexdigest()==f['sha256'] and f['ranges']==[[1,len(t.splitlines())]] and f['complete_file_read'];bysource[p]={}
 for m in re.finditer(r'\\(?:input|include)\s*\{([^}]+)\}',t):
  target=prefix+m[1]+('' if Path(m[1]).suffix else '.tex');assert target in paths;includes.append({'source':p,'target':target})
 for v in named_results(t):
  lab=v['label'];title,conditions=s['claims'][lab];id=cid(lab);assert lab not in labels;labels[lab]=id;bysource[p][lab]=id
  rows.append({'id':id,'label':lab,'aliases':v['label_aliases'],'path':p,'statement_lines':[t.count('\n',0,v['statement_start'])+1,t.count('\n',0,v['statement_end'])+1],'statement_tex':t[v['statement_start']:v['statement_end']].strip(),'summary':title,'conditions':conditions,'source_claim_grade':'B' if lab in formal['source_B_labels'] else 'C'})
 if p.endswith('.bib'):
  ms=list(re.finditer(r'^@\w+\s*\{([^,]+),',t,re.M))
  for i,m in enumerate(ms):entries[m[1]]={'path':p,'entry':t[m.start():ms[i+1].start() if i+1<len(ms) else len(t)].strip(),'line':t.count('\n',0,m.start())+1}
assert len(rows)==6 and len(entries)==16 and sum(len(x['aliases']) for x in rows)==1 and len(files)==10 and sum(len((r/x['path']).read_text().splitlines()) for x in files)==1791
ap=revise('ANALYSIS-F-238')['properties'];assert len(ap['result_ids_by_label'])==227 and len(ap['manuscript_source_drafts_complete_ids'])==6
common={k.split(':',1)[1]:v for k,v in ap['historical_references_by_key'].items() if k.startswith('trace:')};common.update({'hmr2014':'LIT-238-23372BEA1E','mrs':'LIT-238-FAE783EF81','DiaconisShahshahani1981':'LIT-238-A3BAC570AC','Demailly2012':'LIT-058-DEMAILLY2012','Czumaj2015':'LIT-238-COMPANIONS-66ADB6D3EE','CzumajVocking2014':'LIT-238-ACA7026C59','BereleRegev1983':'LIT-238-ANALYTIC-BERELE-REGEV-1983','ChristandlKonigRenner2009':'LIT-238-ANALYTIC-CHRISTANDL-KONIG-RENNER-2009'})
bmap={k:common[k] for k in entries};verified={x['key']:x for x in h['rows']};selected=set(verified)|{x['key'] for x in h['reused_selected_scopes']}
gaps=['Seven of12currentmanuscripts read/decomposed,233namedbindings;five othercurrent bodies unread. Fullfamily/history/sixstages stillincomplete.','Fourfreshoriginalselectedscopes andtwooldselectedbounds reused;10otherrootkeysandunreadparts/recursiveproofs notqualified. BR1983announcementdefersfullproof;convertedhookformula degraded;nofalseclaimof1987proofreading.','Onlyselectedconditional/binaryendpoints sourceB;fournewnamedresultsC,allcompletechainsunknown. No Leanbuild/Comparator/humanproof/specaudit. Staticindicesoverlap.','Analytictransfer appliesHemptyonly;conditionalnearuniformmomenttheorem doesnotextendtoarbitraryH atz1 orcomplexprobabilitylaw. No perobservedtrace guarantee.','FixedR/q/g/w/d0exist;no effectivefiniteengineeringcutoff/tolerance orwalltimebenefit. Physicalrotationclock/support propositionremain sourceC.','ExistingAPP23801/02predictions/plans/runids andstatusunchanged. No newcandidate,initialcheck,targetrun,human/secondproviderreview orGitHubpush.']
ledger={'at':now,'work_package':'WP-124','generation_id':G,'family_id':F,'manuscript_id':M,'upstream_commit':UP,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':'full_current_manuscript_source_decomposition_draft','full_natural_source_read':True,'independent_mathematical_proof_audit':False,'read_files':files,'source_files_total':10,'source_lines_total':1791,'include_links_checked':includes,'results':rows,'canonical_result_ids':labels,'aliases_not_extra_results':{'ac:main':'thm:conditional'},'method_contracts':s['methods'],'section_scope_notes':s['notes'],'bibliography_entries_by_key':entries,'bibliography_keys':bmap,'historical_selected_keys':sorted(selected),'historical_evidence':hp,'formal_evidence':fp,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':0,'new_initial_checks':0,'scientific_experiments':[],'gaps':gaps,'external_body_republication':False}
save(lp,ledger);ls=src(lp,'Complete10sourcefiles1791lines/sixnamedbindings14contracts;selectedoriginal/formalinterfaces,notfullfamily/proof/history acceptance')
# Demailly is the same exact author/book/date already registered forF058. Preserveits oldrecord and F058-specific unverified scope.
n=revise(bmap['Demailly2012']);n['properties'].update(retrieval_status='selected_original_scope_checked',content_verified=True,verified_scope=verified['Demailly2012']['verified_scope'],prior_F058_citation_scope_still_unverified='F058originaluse andfullbook not checked by these selectedmaximum-principle/log-modulus ranges.');n['properties']['family_ids']=list(dict.fromkeys(n['properties'].get('family_ids',[])+[F]));n['sources']+=[src(hp,'Demaillyauthor2012selectedconvertedtextscopes,raw/textSHA/date;nofullbookreview'),src(entries['Demailly2012']['path'],'BibliographyDemailly2012 sameauthor/title/date/url as existingF058record')]
for key in ['BereleRegev1983','ChristandlKonigRenner2009']:
 x=verified[key];e=entries[key]
 add(bmap[key],'literature',{'title':key,'bibliography_key':key,'bibliography_entry':e['entry'],'family_ids':[F],'retrieval_status':'selected_original_scope_checked','verified_scope':x['verified_scope'],'selected_scope_locator':x['selected_scope_locator'],'full_original_proof_review':False,'credibility':'unknown'},[src(e['path'],'Completebibliographyentry'+key),src(hp,key+'originalselectedconvertedtextscopeandhash'),{'url':x['url'],'sha256':x['sha256'],'source_file_sha256':x['sha256'],'content_checked':True,'locator':x['selected_scope_locator'],'checked_at':x['at']}],'source_content_checked')
for x in rows:
 add(x['id'],'claim',{'title':x['summary'],'statement':x['summary'],'statement_tex':x['statement_tex'],'conditions':[x['conditions']],'family_ids':[F],'manuscript_id':M,'natural_label':x['label'],'label_aliases':x['aliases'],'source_claim_grade':x['source_claim_grade'],'credibility':x['source_claim_grade'],'dependency_chain_grade':'unknown','independent_proof_review':False},[copy.deepcopy(ls),src(x['path'],x['label']+';statementlines'+str(x['statement_lines']))]+([src(fp,'Selectedactualmodel/signature/endpointcomparison;notbuildorfullproofaudit')] if x['source_claim_grade']=='B' else []));edge(x['id'],'derived_from',M,'Fixedcurrentmanuscriptclaim,notprojectnewtheorem');edge(x['id'],'member_of',F,'Scopequalifiedsourcebinding')
 ap['result_ids_by_label']['analytic:'+x['label']]=x['id'];ap['result_ids_by_source'].setdefault(x['path'],{})[x['label']]=x['id']
methods={}
for key,title,inp,out,file,lo,hi,lim in s['methods']:
 id='PART-238-ANALYTIC-'+key;methods[key]=id;add(id,'method',{'title':title,'input':inp,'output':out,'conditions':lim,'cannot_transfer':lim,'family_ids':[F],'credibility':'C','dependency_chain_grade':'unknown'},[copy.deepcopy(ls),src(prefix+'sections/'+file,'Readsource lines'+str([lo,hi])+';conditionalI/Ocontract')]);ap['method_ids'].append(id)
# Explicit sufficient proof interfaces; child-grid IH is a quantified contract,not a self-cycle in this dependency graph.
for child,parents in {'lem:overlap':['lem:density'],'thm:conditional':['lem:sparse'],'thm:binary':['thm:conditional']}.items():
 for p in parents:edge(labels[child],'depends_on',labels[p],'Actualselectedsourceroutewithallconditions;fullproofclosureunknown')
for key,lab in [('SIGNED-DENSITY','lem:density'),('ROW-COLUMN-OVERLAP','lem:overlap'),('SUPPORT-BUDGET','prop:support'),('SPARSE-ALTERNATION','lem:sparse'),('SHARED-LINE-MOMENTS','lem:sparse')]:edge(methods[key],'depends_on',labels[lab],'Conditionaltransfercontractofexactsourceclaim')
for child,parents in {'HOOK-RESERVE':['SIGNED-DENSITY','ROW-COLUMN-OVERLAP','PARAMETER-ORDER'],'CYCLIC-POTENTIAL':['HOOK-RESERVE','WITHOUT-REPLACEMENT-COST'],'WITHOUT-REPLACEMENT-COST':['CONDITIONAL-LINE-LAW'],'UNCONDITIONED-POLYNOMIAL':['CONDITIONAL-LINE-LAW'],'SLIT-TRANSFER':['UNCONDITIONED-POLYNOMIAL'],'FOURIER-TV':['SLIT-TRANSFER']}.items():
 for p in parents:edge(methods[child],'depends_on',methods[p],'Readproofinterfaceandfailureboundary;notexecutableguarantee')
edge(labels['thm:conditional'],'depends_on',methods['CYCLIC-POTENTIAL'],'Nonsparseinductionusesallaugmentedpathsandpotentialcancellation')
edge(methods['UNCONDITIONED-POLYNOMIAL'],'depends_on',labels['thm:conditional'],'SpecializeHempty,notgeneralconditionalcomplexlaw')
edge(labels['thm:binary'],'depends_on',methods['FOURIER-TV'],'Independentrepetitionsanddimensiontails,notone-cardmarginal')
for child,key in [('SLIT-TRANSFER','Demailly2012'),('SIGNED-DENSITY','BereleRegev1983'),('FOURIER-TV','DiaconisShahshahani1981')]:edge(methods[child],'depends_on',bmap[key],'Selectedhistoricalinterface;recursiveproofreviewstillunknown')
edge(methods['SIGNED-DENSITY'],'references',bmap['ChristandlKonigRenner2009'],'Historicalordinarypostselectionanalogy,notproof ofgradeddomination')
for x in rows:
 t=(r/x['path']).read_text();refs=set()
 for chunk in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',t):refs.update(k.strip() for k in chunk.split(','))
 for key in sorted(refs):
  if key in bmap:edge(x['id'],'historical_context',bmap[key],'Containingfullyreadsourcebibliographiccontext;notallmandatoryproofdependencies')
gapid=[]
for key,title,detail in [('CONDITIONAL-Z1','任意轨迹条件下的端点保证缺口','CurrentanalyticargumentsetsHempty;nearsmallrealztheoremdoesnot supplygeneralH z1orpertracecertificate.'),('FINITE-COST','有限误差与完整执行成本','Actualconsumer/finiteR/q/g/w/d0,declaredTVtoleranceandfairoldalgorithmcostrequiredbeforeapplication;asymptoticmixingorderaloneinsufficient.'),('GRADED-HISTORY','带符号正密度的历史证明闭包','BR1983announcementandordinaryCKRpostselectionselectedinterfacesdonotclosegradedPieri/SchurWeyl/fullpositivedominationprooflineage.')]:
 id='PROB-238-ANALYTIC-'+key;gapid.append(id);add(id,'problem',{'title':title,'statement':detail,'family_ids':[F],'credibility':'unknown','prerequisite_status':'unestablished_for_application'},[copy.deepcopy(ls)],'hypothesis');edge('APP-238-02','references',id,'Supplementaryscopegap,notchangeoforiginalpredictionorproofofnegativevalue')
audit=add('AUDIT-238-ANALYTIC-SCOPE','audit',{'title':'条件估计与无条件解析转移的范围审核','family_ids':[F],'observations':s['notes'],'existing_application_ids':['APP-238-01','APP-238-02'],'new_candidate_ids':[],'new_initial_checks':0,'new_runs':0,'interpretation':s['no_new_candidate_reason'],'credibility':'unknown'},[copy.deepcopy(ls),src(fp,'Actual selectedmodels/endpoints'),src(hp,'Fourfreshselectedoriginals andtwo priorbounds')],'source_content_checked')
for id in methods.values():edge(audit['id'],'references',id,'Qualifiedsourcecontract;noapplicationvaliditycredit')
for key,id in bmap.items():ap['historical_references_by_key']['analytic:'+key]=id
ap['historical_verified_keys']+=['analytic:'+k for k in sorted(selected)]
for p in paths:
 if p not in ap['source_sections']:ap['source_sections'].append(p)
 ap['result_ids_by_source'].setdefault(p,{})
ap['manuscript_source_drafts_complete_ids'].append(M);ap['manuscript_reading_ledgers'][M]=lp;ap['source_line_count']+=1791;ap['formal_statement_comparison']+=formal['comparisons'];ap['formal_status']['conditional_analytic_selected_scope']=formal;ap['quantifier_and_boundary_notes']+=s['notes'];ap['gaps']+=gaps;ap.update(source_decomposition_draft_complete=False,full_family_complete=False,historical_lineage_complete=False,completion_basis='Sevenof12currentmanuscripts read/decomposed;233namedbindings(227prior+6analytic),onealiasnotextra. Fivecurrentbodiesunread;fullhistory/formal/humanclosuremissing.')
by['ANALYSIS-F-238']['sources'].append(copy.deepcopy(ls))
config='data/provenance/research-at-generation-121.json';(r/config).write_bytes((r/'configs/research.json').read_bytes());add(G,'generation',{'title':'F238conditional-sweepandanalytic-transfercompletecurrentsourcequalification','family_ids':[F],'project_base_commit':ledger['base_commit'],'provider':'OpenAI','model':'Currentuser-selectedsession;exactbackendunknown','human_review':None,'independent_second_provider':None,'credibility':'unknown'},[copy.deepcopy(ls),src(config,'Researchpolicysnapshot'),src(fp,'Selectedactualformalspecifications'),src(hp,'Selectedoriginalscopes')],'source_content_checked')
gzsave(history_path,{'at':now,'generation_id':G,'reason':'AppendcompleteanalyticcompaniontoF238;reuseexactDemailly2012bookidentityandqualifyselectednewscopeswithoutupgradingpriorF058use.','records':[old[id] for id in sorted(changed)]})
gzsave('data/graph/history/'+G+'-reading-coverage-before.json.gz',json.loads(oc));cov=json.loads(oc);cov['partially_read_families'][F]+=['WP124all10TeX/Bib1791lines,6namedbindings/14contracts;7/12currentmanuscripts/233bindings,notfullfamily.','Two selectedsourceB/fourC,allchainsunknown;conditionalnearsmallrealzversusanalyticHemptyendpoint keptdistinct.','Fouroriginalselectedconvertedtextscopes/twooldboundsreused;nohuman/provider/build ornewcandidate/check/run.'];cov.update(updated_at=now,update_reason='WP124F238analyticcompaniononly;global63reading/58sourcefamilydraftcountsunchanged',prior_version_archive='data/graph/history/'+G+'-reading-coverage-before.json.gz')
summary={'generation':G,'base_commit':ledger['base_commit'],'old_records':len(oldrows),'new_records':len(new),'modified_old_record_ids':sorted(changed),'new_edges':len(edges),'named_bindings':6,'method_contracts':14,'source_B':2,'source_C':4,'family_source_manuscripts':7,'family_named_bindings':233,'new_candidates':0,'new_initial_checks':0,'new_runs':0,'new_literature_nodes':2,'fresh_selected_originals':4,'reused_selected_originals':2,'new_record_ids':[n['id'] for n in new]}
try:
 np.write_bytes(b''.join((json.dumps(by[json.loads(line)['id']],ensure_ascii=False,sort_keys=True).encode() if json.loads(line)['id'] in changed else line)+b'\n' for line in oldrows)+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new).encode());ep.write_bytes(oe+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges).encode());save('data/graph/reading_coverage.json',cov);summary['initial_graph_validation']=validate(r)
except Exception as e:
 (w/'unaccepted-curation-failure.json').write_text(json.dumps({'error':repr(e),'summary':summary,'rollback':'nodes/edges/coverage restored;new immutable evidence retained'},ensure_ascii=False,indent=2)+'\n');np.write_bytes(on);ep.write_bytes(oe);cp.write_bytes(oc);raise
assert len(ap['result_ids_by_label'])==233 and len(ap['source_sections'])==73 and ap['source_line_count']==20259
(w/'curation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='new_record_ids'},ensure_ascii=False))
