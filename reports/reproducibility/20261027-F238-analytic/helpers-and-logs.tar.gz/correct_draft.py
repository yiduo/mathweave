from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,copy
r=Path.cwd();w=Path(__file__).parent;np=r/'data/graph/nodes.jsonl';raw=np.read_text().splitlines();by={n['id']:n for x in raw if (n:=json.loads(x))};G='GEN-20261027-121';lp='data/provenance/readings/F-238-analytic.json';fp='data/provenance/readings/F-238-analytic-formal.json';ar='data/graph/history/GEN-20261027-121-draft-correction-before.json.gz';now=datetime.now(timezone.utc).isoformat()
f=json.loads((r/fp).read_text());sets=[]
for index in f['indices']:sets.append({x['path'] for x in json.loads(gzip.decompress((r/index['path']).read_bytes()))['local_files']})
assert len(sets[0]&sets[1])==0 and len(sets[0]|sets[1])==226
oldfiles={p:(r/p).read_text() for p in [fp,lp]}
f['indices_overlap']='The selected local-file sets are disjoint:34+192=226 distinct files,0 shared local paths. Both rely on external Mathlib;none of these counts establishes a mathematical proof review orbuild.';f['index_intersection_files']=0;f['index_union_files']=226
(r/fp).write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n')
l=json.loads((r/lp).read_text());l['gaps']=[x.replace('Staticindicesoverlap.','Thetwoindiceshave226distinctlocalfileswith0sharedpaths;externalMathlibstillunbuilt.') for x in l['gaps']];l['draft_corrections']=[{'at':now,'reason':'Actual static index sets have zero shared local paths;correct earlier unsupported overlapdescription. No mathematical result/grade/applicationcount changes.','prior_archive':ar}];(r/lp).write_text(json.dumps(l,ensure_ascii=False,indent=2)+'\n')
prior=[];changed=[]
for id,n in by.items():
 touches=any(s.get('path') in oldfiles for s in n['sources']) or id=='ANALYSIS-F-238'
 if not touches:continue
 prior.append(copy.deepcopy(n));changed.append(id);n.update(version=n['version']+1,updated_at=now,updated_by_generation_id=G,prior_version_archive=ar)
 for s in n['sources']:
  if s.get('path') in oldfiles:s['sha256']=hashlib.sha256((r/s['path']).read_bytes()).hexdigest()
 if id=='ANALYSIS-F-238':
  p=n['properties'];p['formal_status']['conditional_analytic_selected_scope']=f;p['gaps']=[x.replace('Staticindicesoverlap.','Thetwoindiceshave226distinctlocalfileswith0sharedpaths;externalMathlibstillunbuilt.') for x in p['gaps']]
  p['gaps']=['HistoricalWP110scope snapshot: '+x if x.startswith('Current6/12source drafts;') else x for x in p['gaps']]
  p['main_claim_ids']+= [v for v in ['CLM-238-ANALYTIC-THM-CONDITIONAL','CLM-238-ANALYTIC-THM-BINARY'] if v not in p['main_claim_ids']]
archive={'at':now,'generation_id':G,'reason':'Correct unsupported local index overlap assertion from actual setintersection;retain withdrawn provisional source ledger/formal receipt andall affectedrecordversions. Prefix old6/12 gap as historicalsnapshot;register two selected mainbindings. No change to scientific claims/grades/experimentalstandards.','records':prior,'prior_source_files':oldfiles}
b=json.dumps(archive,ensure_ascii=False,indent=2).encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(r/ar).write_bytes(z)
np.write_text('\n'.join(json.dumps(by[json.loads(x)['id']],ensure_ascii=False,sort_keys=True) if json.loads(x)['id'] in changed else x for x in raw)+'\n')
(w/'draft-correction.json').write_text(json.dumps({'at':now,'affected_ids':changed,'prior_archive':ar,'prior_scope_qa':'Initial QA passed other checks but didnot verify localfile-overlap description;provisional receipt retained andsuperseded after correcting assertion.','new_claim_or_application_credit':0},ensure_ascii=False,indent=2)+'\n');print('Versioned correction:',len(changed),'records;localindex intersection0 union226.')
