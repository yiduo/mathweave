from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess,sys
sys.path.insert(0,'src')
from ai_value.graph import validate

root=Path.cwd();work=Path(__file__).resolve().parent;now=datetime.now(timezone.utc).isoformat()
GEN='GEN-20261026-108';UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
np=root/'data/graph/nodes.jsonl';ep=root/'data/graph/edges.jsonl';cp=root/'data/graph/reading_coverage.json'
oldnodes=np.read_bytes();oldedges=ep.read_bytes();oldcoverage=cp.read_bytes()
by={n['id']:n for n in map(json.loads,oldnodes.decode().splitlines())}
assert GEN not in by and 'ANALYSIS-F-300' not in by
assert len(by)==4942
new=[];edges=[];keys={(x['source'],x['relation'],x['target']) for x in map(json.loads,oldedges.decode().splitlines())}
spec=json.loads((work/'curation-spec.json').read_text());contracts=json.loads((work/'methods-and-mappings.json').read_text())
j=json.loads((root/'state/reading-progress/WP-111.json').read_text());assert j['actual_source_lines_read']==7647 and j['actual_full_tex_files_read']==22
formal=json.loads((work/'formal-scope.json').read_text());hist=json.loads((work/'historical-scope.json').read_text())
formal['catalogue_scope']='math/CONTENTS.md:7430-7450 actual F300 entry and two manuscript descriptions;no Lean links in this entry'
formal['catalogue_sha256']=hashlib.sha256((root/'math/CONTENTS.md').read_bytes()).hexdigest()

def save(path,obj):
    p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def src(path,locator):return {'path':path,'locator':locator,'commit':UP if path.startswith('math/') else None,'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()}
def add(id,kind,prop,sources,status='source_claim'):
    assert id not in by,id
    obj={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':status,'properties':{'model_generation_id':GEN,'dependency_closure_complete':False,**prop},'sources':sources}
    by[id]=obj;new.append(obj);return obj
def edge(a,r,b,loc):
    if (a,r,b) in keys:return
    keys.add((a,r,b));edges.append({'id':'E-'+hashlib.sha256((a+'|'+r+'|'+b).encode()).hexdigest()[:16].upper(),'source':a,'relation':r,'target':b,'version':1,'created_at':now,'evidence_status':'source_claim','source_commit':UP,'source_locator':loc})
def cid(q):
    prefix,label=q.split(':',1);return 'CLM-300-'+prefix+'-'+re.sub('[^a-zA-Z0-9]+','-',label).strip('-').upper()

formalpath='data/provenance/readings/F-300-formal.json';histpath='data/provenance/readings/F-300-history.json';ledgerpath='data/provenance/readings/F-300.json'
save(formalpath,formal);save(histpath,hist)
rows=[];labels={};by_source={};manuscripts={'A':'P-095dcf7bab0be0ae','Q':'P-8a687a97b053c803'};closure=[]
for file in j['actual_source_files_read']:
    path=file['path'];text=(root/path).read_text();assert hashlib.sha256(text.encode()).hexdigest()==file['sha256']
    prefix='A' if '/Approximation-Paving-' in path else 'Q';by_source[path]={}
    base=path[:path.index('/build/source/')+len('/build/source/')]
    for match in re.finditer(r'\\(?:input|include)\s*\{([^}]+)\}',text):
        rel=match.group(1);target=base+rel+('' if Path(rel).suffix else '.tex')
        assert target in {x['path'] for x in j['actual_source_files_read']},target
        closure.append({'source':path,'target':target,'exists_and_fully_read':True})
    for result in file['source_result_inventory_only']:
        label=result['label'];assert label in spec[prefix],(prefix,label)
        q=prefix+':'+label;id=cid(q);summary,conditions=spec[prefix][label]
        body=text[result['statement_start']:result['statement_end']].strip()
        lines=[text.count('\n',0,result['statement_start'])+1,text.count('\n',0,result['statement_end'])+1]
        labels[q]=id;by_source[path][label]=id
        rows.append({'id':id,'qualified_label':q,'label':label,'kind':result['kind'],'manuscript_id':manuscripts[prefix],'path':path,'sha256':file['sha256'],'statement_lines':lines,'summary':summary,'conditions':conditions,'aliases':result.get('label_aliases',[]),'statement_tex':body})
assert len(rows)==56 and len(labels)==56 and sum(len(x) for x in spec.values())==56
assert not any(r['aliases'] for r in rows)

aliases={'Ara74':'Araki74','Mah64':'Maharam64','RS17':'RS21','Tak72':'Takesaki72'}
internal={'A:OAQuadratic26':manuscripts['Q'],'Q:ApproxCompanion26':manuscripts['A']}
originals={'MSS15':'MSS2015-v4','PV15':'PV2015-v3','RS21':'RS2017-v2','AS12':'AS2012'}
histby={x['key']:x for x in hist['works']};bibmap={};litnodes={}
for row in j['source_files']:
    if not row['path'].endswith('references.tex'):continue
    prefix='A' if '/Approximation-Paving-' in row['path'] else 'Q';text=(root/row['path']).read_text()
    matches=list(re.finditer(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',text))
    for n,match in enumerate(matches):
        key=match.group(1);q=prefix+':'+key;entry=text[match.start():matches[n+1].start() if n+1<len(matches) else text.index('\\end{thebibliography}')].strip()
        if q in internal:bibmap[q]=internal[q];continue
        canonical=aliases.get(key,key);id='LIT-300-'+re.sub('[^a-zA-Z0-9]+','-',canonical).upper()
        bibmap[q]=id
        source=src(row['path'],'Complete manuscript-qualified bibliography entry '+q)
        if canonical in litnodes:
            node=litnodes[canonical];node['sources'].append(source);node['properties']['qualified_keys'].append(q);node['properties']['bibliography_entries_by_qualified_key'][q]=entry;continue
        start=entry.find('\\emph{');title=canonical
        if start>=0:
            start+=len('\\emph{');depth=1;end=start
            while depth and end<len(entry):
                if entry[end]=='{':depth+=1
                elif entry[end]=='}':depth-=1
                end+=1
            title=' '.join(entry[start:end-1].split())
        props={'title':title,'bibliography_key':canonical,'qualified_keys':[q],'bibliography_entries_by_qualified_key':{q:entry},'retrieval_status':'upstream_bibliography_only','verified_scope':'Complete bibliography entry read;original body not checked.','full_original_proof_review':False}
        sources=[source];status='source_claim'
        if canonical in originals:
            h=histby[originals[canonical]];scope=h['read_scope'];locator='PDFpages(full)'+','.join(map(str,scope['full_pdf_pages_text_read']))+';selectedscopes:'+','.join(scope['selected_original_scopes'])
            props.update({'retrieval_status':'selected_original_scope_checked','original_link':h['url'],'selected_scope_locator':locator,'verified_scope':scope['verification'],'unverified_scope':scope['not_checked'],'original_sha256':h['sha256'],'actually_viewed_pdf_pages':h['actually_viewed_pdf_pages']})
            sources.append({'url':h['url'],'sha256':h['sha256'],'source_file_sha256':h['sha256'],'locator':locator+';selected scopes only,not whole original proof or recursive history','content_checked':True,'checked_at':now});status='source_content_checked'
        litnodes[canonical]=add(id,'literature',props,sources,status)
assert len(bibmap)==40 and len(litnodes)==27

method_ids=['PART-300-'+x[0] for x in contracts['methods']]
gaps=['Both current source bodies and56named results are qualified as drafts;no full proof audit or human specification acceptance.','27distinct external works:four selected scopes/10PDFpages,23root bodies andrecursive history unread;oldpublication andread arxivversions remain distinct.','No matching formal endpoint identified in the checked pinned registry/242docs/417Comparator metadata andpath scope;all56local sourceC andfullchainsunknown,noLeanbuild/Comparator/human review.','Strong approximation nearbyy withrelativeynorm,so-compressionoriginalx,andnormpaving/ultrapower aredifferent outputs;normalexpectation/countablydecomposable hypotheses stay onconversion corollaries.','Uniform color count andfinite-stepexistence do not provide computable g(h),cutoff/word/cylinder cost,actual consumer orengineering benefit;finite oldMSS/RSroutes mayalready suffice.','No new application candidate,scientific experiment,preliminary check,second-provider review or pilot;human grading remains pending.']
corpus_versions=[json.loads(l) for l in (root/'data/corpus/reconciliation.jsonl').read_text().splitlines() if json.loads(l).get('family_id')=='F-300']
ledger={'family_id':'F-300','work_package':'WP-111','generation_id':GEN,'at':now,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream_commit':UP,'manuscript_ids':list(manuscripts.values()),'read_files':j['actual_source_files_read'],'readmes':[x for x in j['source_files'] if x['path'].endswith('README.md')],'actual_read_ranges':'All22TeXfiles full1-last,7647lines;both18line READMEs. Earlier515/4500/4745counts retained in journal batches/history.','manual_file_reading_notes':j['source_claim_notes_not_canonical_or_reviewed'],'source_sections':list(by_source),'source_tex_lines':7647,'bibliography_lines_included_in_tex':266,'include_links_checked':closure,'results':rows,'methods':contracts['methods'],'historical_references_by_qualified_key':bibmap,'historical_external_work_count':27,'historical_selected_originals':histpath,'unread_root_work_ids':[n['id'] for key,n in litnodes.items() if key not in originals],'historical_versions_in_corpus':corpus_versions,'version_history_scope':'Both current paths map unchanged inold/current catalogue reconciliation;noF300historical_versions row orwithdrawal. This doesnot assert earlier source bytes/proof editions independently read.','formal_status':formalpath,'actual_pdf_pixels':{'pages':10,'manifest_in_historical_packet':True},'acquisition':{'new_body_bytes':927983,'maximum_original_works':4,'no_dependencies_installed':True},'domain_attempts':contracts['domains'],'cross_family_attempts':contracts['cross_family'],'gaps':gaps,'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':0,'new_initial_checks':0,'numeric_or_symbolic_run':False,'source_reuse_policy':'Officialmathread-only;onlyderived records,source locators andqualifiedstatement excerpts retained;no upstream directory or external fulltexts republished.','github_push':False}
save(ledgerpath,ledger)
ledger_source=src(ledgerpath,'Complete actual source-reading ledger,56qualified results,20methodcontracts andexplicit unreviewed scope')
for r in rows:
    add(r['id'],'claim',{'title':r['summary'],'statement':r['summary'],'statement_tex':r['statement_tex'],'conditions':[r['conditions']],'constants_and_constructions':['Exact constants,quantifiers andconstructions retained in statement_tex andsource statementlines;section hypotheses andtransfer exclusions retained inconditions.'],'family_ids':['F-300'],'manuscript_id':r['manuscript_id'],'source_label':r['label'],'source_qualified_label':r['qualified_label'],'source_statement_lines':r['statement_lines'],'credibility':'C','source_claim_grade':'C','dependency_chain_grade':'unknown'},[copy.deepcopy(ledger_source),src(r['path'],r['qualified_label']+';statementlines'+str(r['statement_lines'])+';containing proof/source body actually read;source claim not accepted mathematical theorem')])
    edge(r['id'],'member_of','F-300','Manuscript-qualified current source result')
    edge(r['id'],'derived_from',r['manuscript_id'],'Exact pinned manuscript andTeX locator')

# Only confirmed mandatory proof inputs below; lexical/background citations remain references.
deps={
'A:thm:main':['A:thm:state-paving','A:lem:separable-reduction','A:gen:no-central-approximation','A:gen:support-decomposition'],
'A:cor:so-paving':['A:thm:main'],'A:cor:quadratic-expected-approximation':['Q:thm:main'],
'A:thm:state-paving':['A:exp:normalizer-paving','A:prop:off-normalizer','A:lem:sequence-quotient'],
'A:exp:normalizer-paving':['A:thm:measured-paving'],'A:prop:off-normalizer':['A:lem:random-freeness','A:lem:free-compression'],
'A:lem:random-freeness':['A:lem:atomless'],'A:thm:measured-paving':['A:prop:sparse-pinning','A:lem:descent'],
'A:prop:sparse-pinning':['A:lem:coherent-choice','A:lem:buffered-pin'],'A:lem:coherent-choice':['A:lem:far-deletion','A:lem:slab-limits'],
'A:lem:buffered-pin':['A:poly:tail-control','A:poly:boole','A:lem:local-data'],'A:lem:slab-limits':['A:lem:local-data'],
'A:gen:no-central-approximation':['A:lem:no-central-functional'],
'Q:thm:main':['Q:prop:expected','Q:prop:state-reduction'],'Q:cor:ultrapower-paving':['Q:thm:main'],
'Q:prop:state-reduction':['Q:lem:no-central'],'Q:prop:expected':['Q:thm:bernoulli-coloring','Q:lem:free-compression','Q:prop:moment-transfer','Q:lem:cylinder-partitions','Q:lem:multiplier-calculus','Q:lem:separable-reduction'],
'Q:prop:moment-transfer':['Q:prop:atomless-kernels','Q:lem:state-multipliers','Q:lem:pinching','Q:lem:bernoulli-model'],
'Q:prop:atomless-kernels':['Q:lem:type-i-normalizers'],'Q:lem:free-compression':['Q:lem:bernoulli-model'],
'Q:lem:multiplier-calculus':['Q:lem:state-multipliers'],'Q:thm:bernoulli-coloring':['Q:lem:hazard-step','Q:lem:bad-balls'],
'Q:lem:hazard-step':['Q:lem:assignment','Q:lem:integral-change','Q:lem:homogeneous-costs','Q:lem:strip-locality'],
'Q:lem:homogeneous-costs':['Q:lem:rank-comparison','Q:lem:bounded-costs'],'Q:lem:strip-locality':['Q:lem:homogeneous-costs','Q:lem:bounded-costs'],
'Q:lem:bad-balls':['Q:lem:finite-cost-endpoints','Q:lem:integral-change','Q:lem:strip-locality'],
'Q:lem:bounded-costs':['Q:lem:rooted-locality','Q:lem:positive-cost'],'Q:lem:rank-comparison':['Q:lem:polynomial-quotients','Q:lem:bounded-costs'],
'Q:lem:finite-cost-endpoints':['Q:lem:mixed-bounds','Q:lem:polynomial-quotients'],'Q:lem:assignment':['Q:lem:positive-cost'],
'Q:lem:positive-cost':['Q:lem:polynomial-quotients'],'Q:lem:rooted-locality':['Q:lem:polynomial-quotients']}
for child,parents in deps.items():
    for parent in parents:edge(labels[child],'depends_on',labels[parent],'Confirmed supporting result in actually read proof;quantifiers retained,not grade/closure acceptance')
for claim,key in [('A:cor:so-paving','PV15'),('A:cor:quadratic-expected-approximation','PV15'),('Q:cor:ultrapower-paving','PV15'),('A:lem:mss-paving','MSS15'),('A:lem:atomless','AS12'),('Q:lem:mixed-bounds','RS21')]:
    edge(labels[claim],'depends_on',litnodes[key]['id'],'Specific original input checked only in declared selected scope;recursive original proof closure unknown')
for row in rows:
    prefix=row['qualified_label'][0];text=(root/row['path']).read_text()
    # File-level citation context is explicitly not asserted as a mandatory dependency.
    for m in re.finditer(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',text):
        for key in m.group(1).split(','):
            q=prefix+':'+key.strip()
            if q in bibmap:edge(row['id'],'historical_context',bibmap[q],'File-level literature/companion context;not per-result mandatory dependency or proof-cycle inference')
for item,id in zip(contracts['methods'],method_ids):
    key,q,inp,out,cond,lim=item;claim=by[labels[q]]
    add(id,'method',{'title':key,'family_ids':['F-300'],'input':inp,'output':out,'conditions':cond,'cannot_transfer':lim,'credibility':'C'},[copy.deepcopy(claim['sources'][-1])]);edge(id,'depends_on',claim['id'],'Source-qualified transferable contract,not measured application benefit')
problems=[('FINITE-COST','可执行截断与全成本缺口','gamma(R),g(h)、强逼近、柱集合与高阶矩均缺可部署统一有限成本，有限旧RS路线可能已足够。'),('OUTPUT-SEMANTICS','误差对象与压缩输出缺口','相对近似y误差、原x的q压缩误差、超幂范数误差不可互换；目标任务须声明能否接受丢失子空间。'),('STATE-INTERFACE','实际状态与正常期望接口缺口','真实数据/消费方尚未给出所需忠实状态、cocycle、centralizer或正常条件期望及可实施分割。'),('JOINT-LAW','颜色联合律与安全约束缺口','条件根边际均匀不等于联合独立；自由积条件期望压缩依赖指定模型，不能直接用于碰撞安全约束。')]
for suffix,title,detail in problems:add('PROB-300-'+suffix,'problem',{'title':title,'statement':detail,'family_ids':['F-300'],'credibility':'unknown','prerequisite_status':'unestablished_for_real_application'},[copy.deepcopy(ledger_source)],'source_content_checked')
expl=add('EXPLORE-F-300','exploration',{'title':'F300十域和三跨族输入输出资格探索','family_ids':['F-300'],'attempts':[{'domain':d,'analogy':a,'assessment':s,'accepted_connection':False} for d,a,s in contracts['domains']],'cross_family_attempts':contracts['cross_family'],'new_connection_ids':[],'interpretation':'保留具体结构提示及未建立条件，不是应用验证或正式否定；旧有限铺砌零假设保留。','credibility':'unknown'},[copy.deepcopy(ledger_source)],'hypothesis')
for id in method_ids:edge(expl['id'],'uses',id,'Conditional structural mapping,not empirical application support')
for suffix,_,_ in problems:edge(expl['id'],'references','PROB-300-'+suffix,'Explicit unestablished application premise')
analysis=add('ANALYSIS-F-300','family_analysis',{'title':'F300两当前稿来源拆解草稿','family_id':'F-300','family_ids':['F-300'],'manuscript_ids':list(manuscripts.values()),'manuscript_source_drafts_complete_ids':list(manuscripts.values()),'source_sections':list(by_source),'source_line_count':7647,'result_ids_by_label':labels,'result_ids_by_source':by_source,'method_ids':method_ids,'formal_statement_comparison':[{'item':'任意MASA app-paving与so-paving主结论','natural':'首稿附近y相对范数/六次阶；次稿原x强近I压缩/二次阶；两者量词和误差对象保留','Lean':'固定登记表、242形式说明、417Comparator元数据及精确路径关键词未识别对应入口；没有本地build或Comparator','assessment':'有界查无登记，不是全库无证明；56局部C，完整依赖链未知，未人审'}],'formal_status':{'evidence':formalpath,'formal_scope_state':formal['formal_scope_state'],'metadata_files':660,'local_lean_build':False,'comparator_run':False,'human_spec_review':False,'absence_of_all_possible_Lean_proofs_claimed':False},'historical_references_by_key':bibmap,'historical_references_by_qualified_key':bibmap,'historical_verified_keys':[q for q,id in bibmap.items() if id in {litnodes[k]['id'] for k in originals}],'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'gaps':gaps,'credibility':'unknown','completion_basis':'Both current22TeX/7647lines plusREADMEs read;56qualified namedsourceclaims/20contracts;27distinct historicalroots,fourselectedoriginals,notcomplete family/history/human acceptance.'},[copy.deepcopy(ledger_source)],'source_content_checked')
config='data/provenance/research-at-generation-108.json';(root/config).write_bytes((root/'configs/research.json').read_bytes())
add(GEN,'generation',{'title':'F300two current sources,scoped history andconditional paving contracts','family_ids':['F-300'],'project_base_commit':ledger['base_commit'],'provider':'OpenAI','model':'Current user-selected session;exact backend identifier unknown','human_review':None,'independent_second_provider':None,'credibility':'unknown','seed_list_exposed':True},[copy.deepcopy(ledger_source),src(config,'Research execution policy snapshot'),src(formalpath,'Bounded formal identification scope'),src(histpath,'Four original selected scopes,10actual PDF pages;not recursive historical closure')],'source_content_checked')
coverage=json.loads(oldcoverage);assert 'F-300' not in coverage['partially_read_families']
archive='data/graph/history/GEN-20261026-108-reading-coverage-before.json.gz';packed=gzip.compress(oldcoverage,mtime=0);assert gzip.decompress(packed)==oldcoverage;(root/archive).write_bytes(packed)
coverage['partially_read_families']['F-300']=['Both currentmanuscripts22TeX7647lines and2READMEs actuallyread/source-qualified;56namedbindings,20methodcontracts,notnewmath orfullfamily.','Fourselected original works/10PDFpages/927983newbytes;27distinctexternalroots,23rootbodiesandrecursivehistoryunread.','No matching formal entry identified inchecked pinnedmetadata/pathscope;56localC/fullchainunknown,noLeanbuild/Comparator/human/provider review.','10domain/3crossfamily attempts and4explicitapplicationgaps;no newcandidate/scientificrun/initialcheck.']
expected_drafts={n['properties']['family_id'] for n in by.values() if n['kind']=='family_analysis' and n['properties'].get('source_decomposition_draft_complete')}
coverage['source_decomposition_drafts']+=sorted(expected_drafts-set(coverage['source_decomposition_drafts']))
assert set(coverage['source_decomposition_drafts'])==expected_drafts
coverage['updated_at']=now;coverage['update_reason']='WP111 actual source decomposition andboundedhistorical/formal qualification,notfullfamily acceptance';coverage['prior_version_archive']=archive
summary={'generation':GEN,'base_commit':ledger['base_commit'],'old_records':len(by)-len(new),'new_records':len(new),'modified_old_record_ids':[],'new_explicit_edges':len(edges),'named_bindings':56,'label_aliases_not_extra_results':0,'method_contracts':20,'new_literature_nodes':27,'historical_selected_original_works':4,'actual_PDF_views':10,'source_C':56,'new_candidates':0,'new_application_checks':0,'new_scientific_experiments':0,'new_record_ids':[n['id'] for n in new]}
try:
    np.write_bytes(oldnodes+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new).encode())
    ep.write_bytes(oldedges+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges).encode())
    save('data/graph/reading_coverage.json',coverage)
    metrics=validate(root)
except Exception as exc:
    (work/'unaccepted-curation-failure.json').write_text(json.dumps({'error_type':type(exc).__name__,'error':str(exc),'summary':summary,'state':'canonical nodes/edges/coverage restored;new evidence files retained for repair'},ensure_ascii=False,indent=2)+'\n')
    np.write_bytes(oldnodes);ep.write_bytes(oldedges);cp.write_bytes(oldcoverage)
    raise
assert np.read_bytes().startswith(oldnodes) and ep.read_bytes().startswith(oldedges)
summary['initial_graph_validation']=metrics
(work/'curation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='new_record_ids'},ensure_ascii=False))
