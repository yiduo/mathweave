from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,urllib.request

work=Path(__file__).resolve().parent;dest=work/'pdfs';dest.mkdir(exist_ok=True)
targets=[('MSS2015-v4','https://arxiv.org/pdf/1306.3969v4'),('PV2015-v3','https://arxiv.org/pdf/1412.0631v3'),('RS2017-v2','https://arxiv.org/pdf/1706.03737v2'),('AS2012','https://jot.theta.ro/jot/archive/2012-068-002/2012-068-002-013.pdf')]
manifest={'started_at':datetime.now(timezone.utc).isoformat(),'new_body_budget_bytes':8*1024*1024,'new_body_bytes':0,'maximum_works':4,'attempts':[]}
for key,url in targets:
    row={'key':key,'url':url,'at':datetime.now(timezone.utc).isoformat()}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'MathWeave bounded historical-source inspection'})
        with urllib.request.urlopen(req,timeout=35) as response:
            remaining=manifest['new_body_budget_bytes']-manifest['new_body_bytes']
            length=response.headers.get('Content-Length')
            if length and int(length)>remaining:raise RuntimeError('Content-Length exceeds remaining registered budget')
            raw=response.read(remaining)
            row.update({'final_url':response.geturl(),'content_type':response.headers.get('Content-Type'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        manifest['new_body_bytes']+=len(raw)
        file=dest/(key+'.pdf' if raw.startswith(b'%PDF-') else key+'.unexpected')
        file.write_bytes(raw);row['path']=str(file)
        assert raw.startswith(b'%PDF-'),'response not PDF'
        parsed=subprocess.run(['pdftotext','-layout',str(file),str(dest/(key+'.txt'))],capture_output=True,text=True)
        assert parsed.returncode==0,parsed.stderr
        info=subprocess.check_output(['pdfinfo',str(file)],text=True)
        row['pdfinfo']=info;row['text_sha256']=hashlib.sha256((dest/(key+'.txt')).read_bytes()).hexdigest();row['state']='downloaded_and_extracted_not_yet_read'
    except Exception as exc:
        row['state']='failed';row['error_type']=type(exc).__name__;row['error']=str(exc)[:500]
    manifest['attempts'].append(row)
    (work/'historical-downloads.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ['pdfinfo','path']},ensure_ascii=False),flush=True)
assert manifest['new_body_bytes']<=manifest['new_body_budget_bytes']
