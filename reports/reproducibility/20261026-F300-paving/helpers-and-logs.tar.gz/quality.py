from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export

root=Path.cwd();work=Path(__file__).resolve().parent;base='5cfd31a'
def show(path):return subprocess.check_output(['git','show',base+':'+path])
old=show('data/graph/nodes.jsonl').splitlines();new=Path('data/graph/nodes.jsonl').read_bytes().splitlines()
assert new[:len(old)]==old and len(new)-len(old)==110
assert Path('data/graph/edges.jsonl').read_bytes().startswith(show('data/graph/edges.jsonl'))
kept=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
    if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/')):
        assert Path(name).read_bytes()==show(name),name;kept.append(name)
previous=json.loads(show('data/graph/reading_coverage.json'));current=json.loads(Path('data/graph/reading_coverage.json').read_text())
assert current['full_family_decompositions_complete']==previous['full_family_decompositions_complete']==[]
assert set(current['partially_read_families'])-set(previous['partially_read_families'])=={'F-300'}
for family,value in previous['partially_read_families'].items():assert current['partially_read_families'][family]==value
assert gzip.decompress(Path('data/graph/history/GEN-20261026-108-reading-coverage-before.json.gz').read_bytes())==show('data/graph/reading_coverage.json')
metrics=validate(root);generated=render(root);exported=export(root);nodes,edges=load(root)
expected={n['properties']['family_id'] for n in nodes.values() if n['kind']=='family_analysis' and n['properties'].get('source_decomposition_draft_complete')}
assert set(current['source_decomposition_drafts'])==expected and len(expected)==54
assert generated['partial_reading_families']==59 and generated['source_decomposition_drafts']==54
assert generated['candidate_connections']==45 and generated['externally_checked_cards']==13 and generated['effective_leads']==5
assert all(n['properties']['credibility']=='C' and n['properties']['dependency_chain_grade']=='unknown' for n in nodes.values() if n['kind']=='claim' and n['id'].startswith('CLM-300-'))
js=json.loads(gzip.decompress(Path('reports/graph/knowledge.json.gz').read_bytes()))
assert {n['id']:n for n in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress(Path('reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={n.attrib['id']:json.loads(next(d.text for d in n.findall('g:data',ns) if d.attrib['key']=='properties')) for n in g.findall('g:node',ns)}
xe=[json.loads(next(d.text for d in n.findall('g:data',ns) if d.attrib['key']=='evidence')) for n in g.findall('g:edge',ns)]
assert xn==nodes and xe==edges
cases=[('CLM-300-Q-LEM-ASSIGNMENT','CLM-300-Q-THM-MAIN'),('CLM-300-Q-LEM-RANK-COMPARISON','CLM-300-Q-THM-MAIN'),('CLM-300-Q-PROP-ATOMLESS-KERNELS','CLM-300-Q-PROP-MOMENT-TRANSFER'),('CLM-300-Q-PROP-MOMENT-TRANSFER','CLM-300-Q-THM-MAIN'),('CLM-300-A-LEM-ATOMLESS','CLM-300-A-THM-MAIN'),('CLM-300-A-THM-MAIN','CLM-300-A-COR-SO-PAVING'),('CLM-300-Q-THM-MAIN','CLM-300-A-COR-QUADRATIC-EXPECTED-APPROXIMATION'),('LIT-300-AS12','CLM-300-A-THM-MAIN'),('LIT-300-RS21','CLM-300-Q-THM-MAIN'),('CLM-238-FRAMES-CHAR-REPAIR','PART-238-COMP-DEPENDENT-HALF-REPAIR')]
impacts=[]
for seed,target in cases:
    report=impact_report(nodes,edges,{seed});assert target in report['affected'],(seed,target)
    impacts.append({'seed':seed,'required_affected':target,'confirmed':True})
for seed,target in [('CLM-300-A-THM-MAIN','CLM-300-Q-THM-MAIN'),('CLM-300-Q-THM-MAIN','CLM-300-A-THM-MAIN'),('LIT-300-PV15','CLM-300-Q-THM-MAIN'),('LIT-300-PV15','CLM-300-A-THM-MAIN'),('LIT-300-RS21','PART-300-SINGLE-COLOR-COST')]:
    report=impact_report(nodes,edges,{seed});assert target not in report['affected'],(seed,target)
    impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Background/context references are not mandatory proof edges;main proofs do not depend on conversion corollaries.'})
archives=[];members=0
for mp in sorted(Path('experiments/runs').glob('*/manifest.json')):
    m=json.loads(mp.read_text());folder=mp.parent
    for name,digest in m['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,(folder,name)
    for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
    snapshot=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
    for name,body in snapshot.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name],(folder,name)
    members+=len(snapshot);archives.append({'run_id':folder.name,'output_hashes':True,'gzip_payload_hashes':True,'source_members':len(snapshot)})
assert len(archives)==15 and members==267
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_records_byte_equal':len(old),'new_records':110,'old_explicit_edges_prefix_equal':True,'preserved_science_code_tests_corpus_and_family_report_files':len(kept),'old_reading_coverage_members_equal':True,'coverage_mirror_lag_repair':'F174/F304alreadydeclared drafts added to stale mirror list;prior53metric camefromanalysisflags andwasunchanged;newF300makes54. Exact oldfilecompressed.','canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'experiment_archives':archives,'source_archive_members':members,'scientific_runs_added':0,'application_checks_added':0,'all56_source_C_fullchain_unknown':True,'limitations':'Software/graph/traceability/archive integrity,not proof validation,independent provider,humanreview orapplication support. Archive hashes are not fresh scientific replays;unchanged experiment source requires no rerun merely fornewfingerprint.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(work/'quality.json.gz').write_bytes(packed)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['experiment_archives','impact_cases','generated_metrics']},ensure_ascii=False))
