from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys
sys.path.insert(0, 'src')
from ai_value.source_results import named_results

payload=json.loads(Path(sys.argv[1]).read_text())
now=datetime.now(timezone.utc).isoformat()
jpath=Path('state/reading-progress/WP-111.json')
j=json.loads(jpath.read_text());added=[]
for suffix in payload['files']:
    hits=[x for x in j['source_files'] if x['path'].endswith(suffix)]
    assert len(hits)==1,suffix
    row=hits[0];raw=Path(row['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['sha256']
    assert len(raw.decode().splitlines())==row['lines']
    assert row['path'].endswith('.tex') and not row.get('actually_read')
    assert not any(x['path']==row['path'] for x in j['actual_source_files_read'])
    row['actually_read']=True;row['actually_read_ranges']=[[1,row['lines']]]
    j['actual_source_files_read'].append({'path':row['path'],'sha256':row['sha256'],'lines':row['lines'],'actually_read_ranges':[[1,row['lines']]],'source_result_inventory_only':named_results(raw.decode())})
    added.append(row['path'])
j['partially_read_tex_files']=[x for x in j.get('partially_read_tex_files',[]) if x['path'] not in added]
j['full_file_lines_read']=sum(x['lines'] for x in j['actual_source_files_read'])
j['actual_source_lines_read']=j['full_file_lines_read']+sum(x['lines_read'] for x in j['partially_read_tex_files'])
j['actual_body_read_lines']=j['actual_source_lines_read']
j['actual_full_tex_files_read']=len(j['actual_source_files_read'])
j['new_source_manuscripts_fully_read']=sum(all(x.get('actually_read') for x in j['source_files'] if x.get('manuscript_id')==mid and x['path'].endswith('.tex')) for mid in j['manuscripts'])
j['next_actual_read']=payload['next'];j['updated_at']=now
j['reading_batches'].append({'at':now,'files':added,'notes':payload['notes'],'state':'actuallyread_notcanonicaldecomposition_orproofreview'})
j['source_claim_notes_not_canonical_or_reviewed']+=payload['notes']
jpath.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
progress={'files_fully_read':j['actual_full_tex_files_read'],'full_file_tex_lines_read':j['full_file_lines_read'],'partial_file_tex_lines_read':sum(x['lines_read'] for x in j['partially_read_tex_files']),'tex_lines_read':j['actual_source_lines_read'],'selected_total_tex_lines':j['source_tex_lines'],'new_full_manuscripts':j['new_source_manuscripts_fully_read'],'canonical_credit_added':False}
cp=Path('state/checkpoint.json');c=json.loads(cp.read_text());c['saved_at']=now
for key in ['active_work_package','next_work_package']:
    c[key]['execution_progress']=progress;c[key]['next_actual_read']=payload['next']
c['previous_goal_turn_classification']={'classification':'progress','evidence':'Previous turn published owner-requested WP110/global039 and incomplete WP111 at453a806,verified complete tree/7anonymous files and actual CI40274241467success;local receipts5cfd31a. Clean worktree,16.8GiB/no projectprocesses and fixed read-only math verified before continuing.'}
c['recovery_commands'][2]=payload['next']
c['recovery_commands'][4]='Public453a806 throughWP110/global039 and incompleteWP1114745lines;CI40274241467success verified. New research stays local under milestone-batch policy.'
c['recovery_observation']['WP111_after_publication_recovery']={'at':now,'base_commit':'5cfd31a','available_disk_GiB_observed':16.8,'project_processes_at_recovery':[],'math_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','math_clean':True,'new_scientific_experiments':0}
cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
bp=Path('state/backlog.json');b=json.loads(bp.read_text());t=next(x for x in b['tasks'] if x['id']=='WP-111');t['execution_progress']=progress;t['next_actual_read']=payload['next'];b['updated_at']=now;bp.write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fullfiles':progress['files_fully_read'],'lines':progress['tex_lines_read'],'remaining':j['source_tex_lines']-j['actual_source_lines_read'],'manuscripts_fully_read':j['new_source_manuscripts_fully_read'],'canonical_credit':False}))
