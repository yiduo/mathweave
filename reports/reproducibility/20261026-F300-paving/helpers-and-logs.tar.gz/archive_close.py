from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,tarfile

root=Path.cwd();work=Path(__file__).resolve().parent;out=root/'reports/reproducibility/20261026-F300-paving';now=datetime.now(timezone.utc).isoformat()
quality=json.loads(gzip.decompress((work/'quality.json.gz').read_bytes()));clean=json.loads(gzip.decompress((work/'clean-check.json.gz').read_bytes()))
assert clean['core_exit_code']==0 and clean['math_included'] is False and not (work/'clean').exists()
for name in ['core.log','clean-core.log']:
    s=(work/name).read_text();assert 'Ran 69 tests' in s and '\nOK\n' in s and '"canonical_citations": 8800' in s
for name in ['quality.json.gz','clean-check.json.gz']:
    shutil.copyfile(work/name,out/name);assert (out/name).read_bytes()==(work/name).read_bytes()

# Avoid duplicate copies of helper code already preserved in the previous package.
references=[]
oldarchive=root/'reports/reproducibility/20261026-F238-companions/helpers-and-logs.tar.gz'
with tarfile.open(oldarchive) as t:
    for name,member in [('previous-curator-reference.py','curate.py'),('reference-quality.py','quality.py'),('reference-clean_check.py','clean_check.py')]:
        raw=(work/name).read_bytes();assert t.extractfile(member).read()==raw
        references.append({'temporary':name,'retained_archive':str(oldarchive.relative_to(root)),'member':member,'sha256':hashlib.sha256(raw).hexdigest()})
        (work/name).unlink()

# External originals and renderings stay out of the repository. Check their hashes before deletion.
hist=json.loads((work/'historical-scope.json').read_text());views=json.loads((work/'visual-pages.json').read_text());expected={}
for h in hist['works']:
    expected[Path(h['path']).name]=h['sha256'];expected[h['key']+'.txt']=h['text_sha256']
for v in views:
    assert v['actually_viewed'];expected[Path(v['image_path']).name]=v['sha256']
removed=[]
pdfdir=work/'pdfs';assert {p.name for p in pdfdir.iterdir()}==set(expected)
for p in pdfdir.iterdir():
    raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==expected[p.name]
    removed.append({'name':p.name,'bytes':len(raw),'sha256':digest,'retained':False})
shutil.rmtree(pdfdir)

# Every new helper, failed attempt and metadata/log payload is losslessly archived.
names=sorted(p.name for p in work.iterdir() if p.is_file() and p.name not in ['quality.json.gz','clean-check.json.gz'])
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for name in names:
        raw=(work/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for name in names:assert t.extractfile(name).read()==(work/name).read_bytes()
(out/'helpers-and-logs.tar.gz').write_bytes(packed)
receipt={'at':now,'work_package':'WP-111','new_original_pdf_bytes':927983,'original_works':4,'actually_viewed_pdf_pages':10,'external_temporary_files_hash_verified_and_removed':removed,'external_temporary_bytes_removed':sum(x['bytes'] for x in removed),'helper_members_verified':len(names),'helpers_archive_bytes':len(packed),'helpers_compressed_sha256':hashlib.sha256(packed).hexdigest(),'helpers_decompressed_sha256':hashlib.sha256(raw).hexdigest(),'reused_helper_references_verified':references,'clean_core_exit_code':0,'clean_directory_removed':True,'clean_files':clean['files'],'clean_bytes':clean['bytes'],'all_copy_hashes_verified':True,'work_root_removed':False,'scientific_experiments_added':0,'scope':'Own helper/source/log snapshots compressed and every member round-tripped. Third-party fulltexts/text/pixels removed after exact hashes;only locators/hash/qualified scopes retained. Clean tested tree precedes closure receipt metadata;no claim of local Lean/human/provider/application acceptance.'}
(out/'storage.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')

def load(name):return json.loads((root/name).read_text())
def save(name,obj):(root/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
b=load('state/backlog.json');done=next(x for x in b['tasks'] if x['id']=='WP-111');done['status']='completed';done['completed_at']=now;done['outputs']=['data/provenance/readings/F-300.json','data/provenance/readings/F-300-formal.json','data/provenance/readings/F-300-history.json','reports/families/F-300.md','reports/paving-F300-reading.md',str(out.relative_to(root))];done['qualification_progress']['clean_check']='passed';done['next_actual_read']='WP111 closed ascurrent-source draft,notfullfamily;continue WP112 actualconsumer qualification.'
next_task=next(x for x in b['tasks'] if x['id']=='WP-112');next_task['status']='ready';next_task['selection_source_reading_credit']=False;next_task['next_action']='Inspect a first-party spectral deflation/block solver or state-truncation consumer;pin actual revision before selected source reading. Suggested first qualification PETSc PCDEFLATION,then choose atmost2independentoutput contracts;not yet downloaded/read.'
b['updated_at']=now;save('state/backlog.json',b)
c=load('state/checkpoint.json');c['saved_at']=now;c['metrics']=load('reports/metrics.json');c['completed_work_packages'].append('WP-111');c['work_packages_since_last_retrospective']=1;c['retrospective_due_after']='After WP113(third substantive package sinceglobal039),or earliermajorcounterevidence/dataissue';c['last_completed_work_package']={'id':'WP-111','generation':'GEN-20261026-108','at':now,'scope':'Two current F300source drafts,56C/unknownchains,20contracts,fourhistoricalselectedscopes/10PDFviews;notcompletefamily/history/humanorapplicationacceptance','quality':str(out.relative_to(root))};c['active_work_package']=next_task;c['next_work_package']=next_task;c['last_quality_evidence']=str(out.relative_to(root));c['storage_receipt']=str((out/'storage.json').relative_to(root));c['running_research_experiments']=[];c['recovery_commands']=['Read goal/AGENTS/charter/roadmap/status/checkpoint/backlog/latestglobal039;verifydisk/processes andWP111storage before continuing.','WP111 GEN108 source/history/graph/core/clean checks complete;do not rerun one-shotcurator or redownload four originals merelyforfingerprint.',next_task['next_action'],'Admit no scientificoutput until separate executable preregistration;compare exact target/error/state/partition/Q output andfull oldbaselinecost.','Public453a806 throughWP110/global039+oldunfinishedWP1114745linejournal;currentGEN108 localonly,no routineGitHubpush.','Officialmath read-only;compress own outputs/snapshots andverifyroundtrip before deletingtemporaryplaintext.'];c['recovery_observation']['WP111_final_boundary']={'at':now,'core_tests':69,'clean_exit_code':0,'all_quality_tool_handles_terminal':True,'running_project_processes':[],'new_scientific_experiments':0,'external_temporaries_removed':True,'helpers_compressed_roundtrip_verified':True,'next_package_source_reads':0};save('state/checkpoint.json',c)
j=load('state/reading-progress/WP-111.json');j['status']='completed_current_source_decomposition_draft_full_family_incomplete';j['completed_at']=now;j['canonical_qualification_summary']['clean_check']='passed';j['next_actual_read']=next_task['next_action'];j['quality_receipt']=str(out.relative_to(root));save('state/reading-progress/WP-111.json',j)
with (root/'state/status.md').open('a') as f:f.write('\n\nWP111最终闭包（'+now+'）：核心69与无math干净副本均退出0，干净复制'+str(clean['files'])+'文件／'+str(clean['bytes'])+'字节逐项散列一致，副本已删除。110新规范434显式边、全部4942旧规范行/旧边保留，15传播及完整导出、15归档267成员通过。四原作及文本/10像素页逐项散列后清理，自有源码/失败日志/'+str(len(names))+'成员压缩回解核验。WP111完成为当前源码草稿，非完整族/历史/人工或应用验收；复盘039后计数1。下一WP112ready，仅选题未下载/读源，不增加信用。没有新科学实验、安装或GitHub推送，整体active_incomplete。\n')
with (root/'docs/roadmap.md').open('a') as f:f.write('\nWP111核心69／15传播／15归档267成员及无math副本全部通过，存储核验清理完成；复盘039后计数1，WP112进入ready且没有源阅读信用。精确树/时序以本包quality、clean-check和storage收据为准。\n')
print(json.dumps({'WP111':'completed_source_draft_not_full_family','helper_members':len(names),'archive_bytes':len(packed),'external_files_removed':len(removed),'next':'WP112ready','GitHub_push':False}))
