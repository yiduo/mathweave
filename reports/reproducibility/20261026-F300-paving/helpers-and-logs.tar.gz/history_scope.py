from pathlib import Path
from datetime import datetime,timezone
import hashlib,json

work=Path(__file__).resolve().parent
visual=json.loads((work/'visual-pages.json').read_text())
for row in visual:
    assert Path(row['image_path']).is_file()
    row['actually_viewed']=True
    row['sha256']=hashlib.sha256(Path(row['image_path']).read_bytes()).hexdigest()
(work/'visual-pages.json').write_text(json.dumps(visual,indent=2)+'\n')
downloads=json.loads((work/'historical-downloads.json').read_text())
scopes={
'MSS2015-v4':{'full_pdf_pages_text_read':[3,8,11],'selected_original_scopes':['Theorem1.4','Corollary1.5','Theorem4.1','Theorem5.1','Lemma5.2'],'verification':'独立有限支撑复随机列的协方差确定混合特征多项式；PSD协方差之和为I且各迹不超过epsilon时，最大根至多(1+sqrt(epsilon))^2。存在正概率的范数界不等于高概率或高效构造。当前首稿仍须自行完成正亏损补全、列拆分和Gram删除，不能把旧定理直接套到非PSD的W。','not_checked':'没有完整阅读旧证明、全部稳定性引理或递归历史；2014v4与2015出版版字节分开。'},
'PV2015-v3':{'full_pdf_pages_text_read':[3,4,5,6,7,8,15,16],'partial_pdf_pages_text_read':[11,13,18,19],'selected_original_scopes':['Definitions2.2-2.3','Proposition2.4 and proof','Lemma2.5 and Remark2.6','Theorem2.7 and forward proof','Conjecture2.8','Theorem3.3 statement/beginning proof','Theorem4.1 statement/beginning proof','Theorem5.1 statement/beginning proof','Remark5.3','Proposition5.4 statement/beginning proof'],'verification':'转换命题保留正常条件期望；app(epsilon,n;kappa)推出任意epsilonprime>epsilon的so(2*kappa*epsilonprime,n)，反向为app(epsilonprime,n;3)。超幂方向另需A可数可分解。可分预对偶的normpaving恰限typeI且正常期望。旧Cartan特例为四次阶；奇异MASA有限代数超积的有限族已有n<1+16*epsilon^-2。Remark5.3为迹态和A-N有限生成双模缺失条件下的400*epsilon^-2乘旧计数，不能推广为所有包含。','not_checked':'只核所列范围，不是整篇证明或完整谱系审核；谱截断与epsilonprime松弛保留。'},
'RS2017-v2':{'full_pdf_pages_text_read':[3,7,9,17,18],'selected_original_scopes':['Definition5','Theorem15','Proposition16 statement/beginning proof','Theorem15 proof and zero-tuple scaling','Theorem25 and proof','Theorem1 proof ending','Corollary26 and proof'],'verification':'混合行列式采用k^-n归一化；Hermitian零对角替零单调性未要求范数归一化。Theorem25对k>=2个零对角Hermitian压缩给严格3sqrt(2)/sqrt(k)根界。Theorem6原陈述写实对称，不将其陈述直接扩大；当前首项检测可用Hermitian Theorem15和零元缩放。有限矩阵多铺砌已有二次阶，不能把该阶归作本项目新发现。','not_checked':'没有完整核第16命题中段证明、全部混合稳定性或递归引用。Corollary26的floor(m/r)块大小句在r>m时需另行限定，不能当无条件容量保证；该句未被F300关键多项式输入使用，不据此否定主根界。'},
'AS2012':{'full_pdf_pages_text_read':[6,7],'selected_original_scopes':['Theorem4.1 statement and proof'],'verification':'在typeI代数中，MASA存在正常条件期望等价于其内有和为1的abelian投影族，并推出条件期望唯一；仅从唯一性反推正常性另需sequentialfullsubset。当前所用正常期望到投影分解的方向无需把这个附加条件删掉或误加到所有方向。','not_checked':'未阅读Theorem2.1及所引Kadison-Ringrose练习原证明、整篇或递归谱系；不推广为任意无期望typeI MASA。'}
}
for row in downloads['attempts']:
    assert row['state']=='downloaded_and_extracted_not_yet_read'
    pdf=Path(row['path']);assert hashlib.sha256(pdf.read_bytes()).hexdigest()==row['sha256']
    row['state']='selected_original_scopes_read_not_full_original_proof_audit'
    row['read_scope']=scopes[row['key']]
    row['actually_viewed_pdf_pages']=[x['pdf_page_1based'] for x in visual if x['key']==row['key']]
packet={'at':datetime.now(timezone.utc).isoformat(),'family_id':'F-300','upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','status':'bounded_historical_scopes_checked_full_lineage_incomplete','new_body_bytes':downloads['new_body_bytes'],'new_body_budget_bytes':downloads['new_body_budget_bytes'],'successful_original_works':4,'actually_viewed_pdf_pages':10,'manuscript_reference_entries':{'approximation':21,'quadratic':19},'internal_companion_entries':2,'external_reference_keys':38,'distinct_external_works_after_qualified_aliases':27,'shared_external_key_pairs':[['AS12','AS12'],['Araki74','Ara74'],['FM77','FM77'],['Maharam64','Mah64'],['MSS15','MSS15'],['Popa14','Popa14'],['PV15','PV15'],['PV16','PV16'],['RS21','RS17'],['RoySamorodnitsky06','RoySamorodnitsky06'],['Takesaki72','Tak72']],'unread_external_root_bodies':23,'recursive_lineage_complete':False,'works':downloads['attempts'],'human_specification_review':False,'cross_provider_review':False,'no_scientific_experiment':True,'raw_third_party_bodies_to_be_removed_after_hash_verification':True}
(work/'historical-scope.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
jpath=Path('state/reading-progress/WP-111.json');j=json.loads(jpath.read_text());j['status']='selected_source_bodies_and_bounded_history_read_canonical_qualification_pending';j['historical_scope_pending_canonical']={k:packet[k] for k in ['successful_original_works','actually_viewed_pdf_pages','new_body_bytes','distinct_external_works_after_qualified_aliases','unread_external_root_bodies','recursive_lineage_complete']};j['source_claim_notes_not_canonical_or_reviewed'].append('Fouroriginals selectedscopes/10actualPDFviews/927983newbytes checked;first21andsecond19referenceentries include2internal,38externalkeys reduceby11qualifiedsharedaliases to27distinctworks,23rootbodiesplusrecursivehistoryunread. MSSPSD/trace/fullcovarianceconditions,PVnormalexpectation/epsilonprime/countablydecomposable/oldsingularbounds,RSnormalizedHermitianrootinputs,andASnormalexpectedtypeI projectionpartition retained. No complete proofchain/human/provider orapplicationvalidation.');jpath.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:packet[k] for k in ['successful_original_works','actually_viewed_pdf_pages','new_body_bytes','distinct_external_works_after_qualified_aliases','unread_external_root_bodies']}))
