from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess

pattern=re.compile(r'paving|kadison[ -]singer|maximal abelian subalgebras|\b300\b',re.I)
files=[Path('math/lean/formalization.yaml'),*sorted(Path('math/lean/docs').glob('*.md')),*sorted(Path('math/lean/ComparatorChallenges').glob('*.md')),*sorted(Path('math/lean/ComparatorChallenges').glob('*.json'))]
records=[];hits=[]
for p in files:
    raw=p.read_bytes();records.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    for n,line in enumerate(raw.decode().splitlines(),1):
        if pattern.search(line):hits.append({'path':str(p),'line':n,'text':line})
paths=subprocess.check_output(['rg','--files','math/lean'],text=True).splitlines()
pathpattern=re.compile(r'paving|kadisonsinger|/masa(?:/|\.)|maximalabeliansubalgebras',re.I)
matches=[x for x in paths if pathpattern.search(x)]
assert not hits and not matches
packet={'at':datetime.now(timezone.utc).isoformat(),'upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','family_id':'F-300','manuscripts':['P-095dcf7bab0be0ae','P-8a687a97b053c803'],'scope':'Pinned formalization registry,242markdownformal descriptions,417Comparator markdown/jsonmetadata files,andpathnamesunderlean. Actual matching Main/Models not identified in this bounded search. No full-library semantic/proof/build audit.','docs_300_exists':Path('math/lean/docs/300.md').exists(),'metadata_files':len(files),'metadata_search_pattern':pattern.pattern,'metadata_hits':hits,'path_pattern':pathpattern.pattern,'path_hits':matches,'input_manifest':records,'formal_scope_state':'not_identified_in_checked_pinned_scope','local_lean_build':False,'comparator_run':False,'human_specification_review':False,'natural_claim_grade_for_future_curation':'C;complete dependency grade unknown','discarded_search':'First broad /pav/i pathname pattern matched unrelated GroupAverage names and KadisonSimilarity/KadisonKastler;not used as semantic evidence. Corrected exactpaving path and declared metadata search above.'}
Path('/private/tmp/ai-paper-WP111/formal-scope.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
jpath=Path('state/reading-progress/WP-111.json');j=json.loads(jpath.read_text());j['status']='all_selected_source_bodies_read_formal_history_canonical_qualification_pending';j['source_claim_notes_not_canonical_or_reviewed'].append('All22TeX7647lines verifiedread. Pinned300.md absent;registry+242formalmd+417Comparatormetadata andnarrowfilenamepattern yieldnomatchingpavingentry. Thisisboundednegativeidentification,notabsenceofallproofs. NoLeanbuild/Comparator/humanreview. Firstbibliography21entries(1internal),second19(1internal),notearlierquestioned22external;RS21/RS17sameversionedwork. Formal/history/canonical qualification remainspending.');jpath.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in packet.items() if k in ['metadata_files','docs_300_exists','metadata_hits','path_hits','local_lean_build','formal_scope_state']}))
