# APP-337-01 isolated pre-target implementation follow-up

Status: static implementation review with required fixes before target output. Same-OpenAI-provider auxiliary opinion only; exact backend model unknown. This is not human review, independent-provider evidence, application acceptance, or an experimental result. No Autograd import, target evaluation, experiment, or contact with another reviewer occurred. No canonical files were changed.

## Evidence and scope

I read the current EXP-337-001 specification, the complete v2 packet, ad_composite.py, ad_reference.py, attempts.py (including the phase watchdog), experiments.py run/archive path, scripts/replay_run.py, and the attempt wrapper. I also inspected the CLI experiment print call to establish the finalization path. The v2 packet SHA256 independently matches `91083506a038f02c71fcd43dfcbe6649ae772f8a30a572c2594ed15ca15a3f4a`.

Hashes of inspected implementation files, relative to `/Users/smzdm/projects/ai_paper`:

- `experiments/specs/EXP-337-001.json`: `656da292dfda3c8125a2ab3c4cf1eaed4d71508d505e671b383661079b661b81`
- `src/ai_value/ad_composite.py`: `d2e0994c13bfc57ce8173327b2cc97deb135a57308a9e12f5c946e279e3609fe`
- `src/ai_value/ad_reference.py`: `6418fd52f868381a9ee9402ed97b11621c89fca3b62118cb71de1927f6e1c24c`
- `src/ai_value/attempts.py`: `473a68ee2738a55dd51f809cbdd86c64af23aac1dea1dc1ee9773b6081bce5c0`
- `src/ai_value/experiments.py`: `6df936caa8feba01eeac53e5549dabfb6a49e05c46230df763b94a1e8d83a831`
- `scripts/replay_run.py`: `7ea95047d87f21bd4bfe78923054be797f1e4b7bd48de380c5eef09decfcba93`
- `scripts/run_experiment_attempt.py`: `ea85d6f0c3ba6e5a5fe976cdaa1b92fa79a2a4d62728722c703ed9bdc5fb7c4e`

The reported five software-only controls and core80 pass are supplied context. I did not rerun them or treat them as proof of target behavior.

## Required fixes

### 1. Judge-invalid or incomplete data can still publish a positive baseline conclusion

Location: `src/ai_value/ad_composite.py:124–160`, particularly lines 134–135 and 157.

The overall `meets_prediction` is properly gated by the reference/missing-fixture outcome. However, `baseline` is calculated solely from score flags and is exported as `old_correct_branch_suffices`, even if a required reference judge is invalid or the fixture set is incomplete. The same issue affects the displayed baseline/forward/control conjunct booleans. For an empty row list all these `all(...)` expressions are vacuously true, even though the overall outcome is correctly inconclusive. For a full list whose reference precision/FD checks disagree, baseline score flags may still all be true against the high-precision formula, and `old_correct_branch_suffices` can again read true.

This conflicts with v2's explicit rule that an invalid required fixture cannot count as a validated baseline pass. It is not an overall-primary false positive, but it is a false positive sub-conclusion that can be consumed independently downstream.

Fix before target: keep raw score aggregates if useful, but label them as such. Export validated conjunction statuses as pass/fail/inconclusive, or gate the positive baseline-suffices field on complete, judge-valid data and absence of backend exceptions. Do not turn unknown into a scientific failure either. Software-only controls should cover incomplete rows and reference-invalid rows whose numeric score flags are all true.

### 2. A resource-failed replay may return normally and lose its complete replay evidence

Location: `scripts/replay_run.py:108–139`, especially line 135; `scripts/run_experiment_attempt.py:18`.

The wrapper exits successfully whenever `target_completed` is true. That means output production is complete, not that resources passed. Replay checks this completion flag, runtime binding, and exact deterministic payload equality, but it never rejects or preserves a run merely because `new_manifest.resource_envelope_met` is false. It returns a receipt with the false resource field, leaves the replay context normally, and deletes the temporary directory containing the failed attempt, progress, output payloads, and measurements.

Consequently, the resource gate can remain visibly false, but required failed-replay evidence is still lost. This violates the frozen retention rule and leaves a normal-return replay path for a resource failure.

Fix before target: validate replay resources independently with the existing `within_frozen_resources` helper (including missing/nonfinite metrics), and route a failed gate through durable failure archival before cleanup, or explicitly retain an equivalent complete artifact before returning a failure result. Do not rely solely on a boolean field that the caller might inspect later. A software-only replay with exact deterministic equality but an exceeded or missing resource metric should demonstrate retention.

### 3. Stage caps are polling-only, with no completed-stage or terminal-stage validation

Location: `src/ai_value/attempts.py:97–109,158–174`; `src/ai_value/ad_composite.py:169–197`.

The phase file contains only the latest phase and its start. On transition to calculation, the watchdog no longer knows the completed setup duration. On transition to archive it no longer knows the completed calculation duration. If `communicate` returns because the child exits, the loop breaks without checking the terminal archive duration. A stage can therefore cross its cap and transition/finish between polls, or while the parent is descheduled, without the operational overrun being recorded. The calculation metric in the final manifest independently catches calculation>60, so that particular overrun cannot pass the calculation envelope through this mechanism. Setup/archive caps have no corresponding completed-stage check and may be missed entirely.

Fix before target: preserve monotonic stage history and terminal timestamps, validate finished setup/archive durations as well as the active phase, and retain those observations in the attempt receipt. Distinguish an operational stage violation from adverse scientific prediction. Keep the existing frozen caps. Tests should cover setup-overrun-then-transition and archive-overrun-then-exit, not only a child that stays stuck in one phase.

### 4. The source archive does not contain the full license explicitly promised by the spec

Location: EXP-337-001 `external_runtime.license`; `src/ai_value/experiments.py:220–224,284–290`; `src/ai_value/ad_composite.py:51–56`.

The specification says `MIT,completeoriginallicensein sourcearchive`. The actual inputs snapshot includes ai_value Python files, the spec, configured extra paths, config, and baseline. The listed extra paths do not contain the Autograd license. The backend loader reads metadata and Python wheel members, but does not add the original license text to the archive. A hash and MIT label are not the complete original license text.

Fix before target: include the verbatim pinned wheel license as a hashed source/runtime artifact and make its membership in the promised archive explicit. Reuse the already verified wheel; no new acquisition is needed. If a separately existing runtime source archive already holds it, explicitly bind that archive in the run manifest and verify it rather than relying on an unrecorded external artifact.

### 5. The recorded RSS is not the advertised complete process-lifecycle high-water

Location: `src/ai_value/experiments.py:324–333`; CLI experiment JSON printing; `src/ai_value/attempts.py:181–233`.

The second RSS measurement is taken after payload/source compression but before final manifest serialization and before the CLI serializes/prints the manifest. The manifest honestly records this timing in one field, but other fields call it whole-process lifecycle RSS, and the spec says full-process RSS includes finalization. The parent does not collect the terminated child's high-water RSS. Allocations during final manifest construction/serialization/printing can therefore occur after the last enforced sample.

Fix before target: collect a child-exit high-water measurement in the supervising attempt and gate the full lifecycle value, with qualified units, while preserving the worker's earlier measurement as a distinct stage metric. Alternatively, a specification revision must explicitly narrow the window before target outputs, but that would change the stated full-lifecycle contract and must not be silently treated as already satisfied. A software-only finalization allocation path can verify the end-of-process measurement without target evaluation.

## Static checks that appear aligned

- The target uses exactly the frozen collapsed graph, q and c calculations, operation order, Python-float Fraction inputs, and pre-operation branch predicates. Fresh r/z grad closures are used independently. I found no injected analytic derivative or epsilon substitution.
- The analytic derivative implementation matches the frozen algebra. The literal-value finite-difference evaluator has its own rational parsing and source-composition calculation; it does not call the analytic derivative or AD. Decimal precision/rounding and both fixed steps are selected from the spec. Both components and value precision sensitivity are checked, and both finite-difference steps plus step sensitivity are compared. These remain two routes sharing Decimal and function interpretation, not an interval proof or provider-independent calculation.
- The overall primary conjunction correctly requires valid references/full count, no backend exception, all forwards, the old baseline, specified naive controls, and a judge-valid predicted z event. Exceptions do not count as the event. Zero-radial status is separately reported rather than silently added to the existential z claim.
- Nonfinite backend results are tagged and exceptions/warnings are captured by method/component. Forward arithmetic uses the frozen Python expression; tracing selects the real backend primitives.
- The wheel hash is checked before import, pre-imported Autograd is rejected, source origins/members are verified against wheel bytes, actual NumPy version is checked as well as distribution metadata, and Python version is checked by the runner. The runtime identity is recorded separately from deterministic raw/summary payloads. Strict EXP-337 complete-payload replay has no scientific-field exclusion.
- Setup and calculation tracemalloc coverage matches the specified tracing window. Calculation includes reference work, AD, controls, summary, and compressed per-fixture progress persistence. RSS units are explicitly handled for Darwin/Linux. Ordinary timeout/crash paths retain progress and compressed logs.
- Replay determinism/source mismatch raised inside the replay context does route to a roundtrip-verified compressed failure artifact. The resource-failure normal-return case above is the material missing route.

## Further bounded cautions

NumPy source/binary hashes are collected after backend import, before target execution. Autograd is checked again after the target; NumPy's imported-module set is not. A NumPy module first imported during the target would not enter the compared NumPy binding. I cannot establish from static review that this target will trigger such a lazy import, so I do not claim an observed binding escape. To support the broad runtime-binding claim robustly, record and compare the final imported NumPy source/extension set as well, or explicitly qualify the binding as the pre-target imported set. Python executable/build and native shared-library dependencies are not byte-for-byte bound by this helper; the experiment does pin Python version and compare known NumPy module files, so avoid calling this a fully hermetic runtime.

The general communication-error branch in run_attempt does not kill/reap an already started worker before proceeding to archive. That is a robustness gap for an actual communication exception, distinct from the handled TimeoutExpired path. Ensure a child cannot remain active while the attempt is labeled exited and its evidence is finalized.

The cache reuse path is not a second target execution; its resource values are historical. Preserve that distinction when recovering/replaying. The frozen initial implementation commit still must precede target output; this static opinion does not itself prove the commit gate.

## Conclusion

There is no algebra/reference-graph blocker visible in the inspected implementation. There are concrete evidence-state, resource-enforcement, retention, and archive-contract issues above that should be fixed before first target output. Their validation can be software-only and need not expose any target fixture. After fixes, any positive target result still supports only the bounded consistency calibration. The strong ordinary old branch and the absent external task mean incremental 2026 application value remains unestablished.
