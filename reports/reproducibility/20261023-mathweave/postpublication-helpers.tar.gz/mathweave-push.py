from pathlib import Path
import json,subprocess
root=Path('/Users/smzdm/projects/ai_paper');old='f0c3ddc05b4e8de3bb104216e2eb8ffa5d7875a0'
audit=json.loads(Path('/private/tmp/mathweave-final-index-audit.json').read_text());assert audit['failure_count']==0 and audit['upstream_math_paths']==0
base=['git','-c','credential.helper=','-c','credential.helper=store']
remote=subprocess.check_output(base+['ls-remote','origin','refs/heads/main'],cwd=root,timeout=60).decode().split()[0];assert remote==old,'Remote changed; inspect before retry'
subprocess.run(['git','commit','-m','Name project MathWeave and prepare milestone publication through retrospective 038'],cwd=root,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=root).decode().strip()
commit=subprocess.check_output(['git','commit-tree',tree,'-p',old],cwd=root,input=b'Publish MathWeave: research through WP107 and retrospective 038, with incomplete F239 reading journal\n').decode().strip()
Path('/private/tmp/mathweave-public-candidate.json').write_text(json.dumps({'commit':commit,'tree':tree,'parent':old,'audit':audit},indent=2)+'\n')
subprocess.run(base+['push','origin',commit+':refs/heads/main'],cwd=root,check=True,timeout=150)
subprocess.run(['git','update-ref','refs/heads/codex/publication',commit,old],cwd=root,check=True)
print(json.dumps({'published_commit':commit,'tree':tree,'parent':old,'force':False}))
