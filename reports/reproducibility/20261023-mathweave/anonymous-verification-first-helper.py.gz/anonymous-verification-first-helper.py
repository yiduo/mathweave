from pathlib import Path
import base64,datetime,gzip,hashlib,json,subprocess,sys,urllib.parse,urllib.request
root=Path('/Users/smzdm/projects/ai_paper');out=root/'reports/reproducibility/20261023-mathweave';commit=sys.argv[2]
def get(endpoint):
 req=urllib.request.Request('https://api.github.com/repos/yiduo/mathweave'+endpoint,headers={'Accept':'application/vnd.github+json','User-Agent':'MathWeave-anonymous-verification'})
 with urllib.request.urlopen(req,timeout=40) as r:
  raw=r.read(6*1024*1024+1);assert len(raw)<=6*1024*1024
 return json.loads(raw)
def save(name,d):
 raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();p=out/name;p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
if sys.argv[1]=='verify':
 metadata=get('');assert metadata['id']==1429150108 and not metadata['private'] and metadata['full_name']=='yiduo/mathweave'
 assert get('/git/ref/heads/main')['object']['sha']==commit
 obj=get('/git/commits/'+commit);expected=subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=root).decode().strip();assert obj['tree']['sha']==expected
 assert [x['sha'] for x in obj['parents']]==['f0c3ddc05b4e8de3bb104216e2eb8ffa5d7875a0']
 tree=get('/git/trees/'+expected+'?recursive=1');assert not tree['truncated'];blobs={x['path']:(x['mode'],x['sha'],x['size']) for x in tree['tree'] if x['type']=='blob'}
 local={}
 for row in subprocess.check_output(['git','ls-tree','-rzl',commit],cwd=root).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid,size=meta.split();assert kind==b'blob' and mode!=b'120000';local[path.decode()]=(mode.decode(),oid.decode(),int(size))
 assert local==blobs and not any(x=='math' or x.startswith('math/') for x in blobs)
 files=[]
 for name in ['README.md','README.en.md','CHARTER.en.md','PROGRESS.en.md','CITATION.cff','state/reading-progress/F-239.json','reports/families/F-360.md']:
  data=get('/contents/'+urllib.parse.quote(name)+'?ref='+commit);raw=base64.b64decode(data['content']);assert raw==subprocess.check_output(['git','show',commit+':'+name],cwd=root)
  files.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 receipt=dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),repository_url=metadata['html_url'],repository_id=metadata['id'],public=True,anonymous_api=True,commit=commit,tree=expected,all_blob_paths_modes_sizes_and_git_object_ids_match=True,files=len(blobs),upstream_math_paths=0,selected_public_bytes=files,parent_is_only_previous_public_snapshot=True,CI_verified=False,scope='Curated through WP107/retro038 plus WP108 incomplete reading journal; no bulk local history or phase-one acceptance')
 save('publication-verification.json.gz',receipt);print(json.dumps(receipt,ensure_ascii=False))
elif sys.argv[1]=='ci':
 runs=get('/actions/runs?per_page=10')['workflow_runs'];selected=[x for x in runs if x['head_sha']==commit and x['name']=='offline-core']
 receipt=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_sha=commit,runs=[{k:x.get(k) for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at','run_attempt']} for x in selected],scope='69core and13scoped archivedreplays,exports,publication scan; no Lean/human/second-provider/application acceptance')
 save('CI-observation.json.gz',receipt);print(json.dumps(receipt))
