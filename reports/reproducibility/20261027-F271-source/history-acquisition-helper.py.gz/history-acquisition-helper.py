from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request, hashlib, json, subprocess
from datetime import datetime,timezone
r=Path('/private/tmp/ai-paper-WP129-history');items=[('GL2014','https://arxiv.org/pdf/1111.2445v1'),('CGS2015','https://arxiv.org/pdf/1312.7873v2'),('BFU2020','https://arxiv.org/pdf/1811.12834v2')]
def acquire(item):
 key,url=item
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-scope/1.0'}),timeout=35) as resp:b=resp.read(3*1024*1024+1);resolved=resp.url
  assert len(b)<=3*1024*1024 and b.startswith(b'%PDF'),(key,len(b),b[:10]);pdf=r/(key+'.pdf');pdf.write_bytes(b)
  txt=r/(key+'.txt');p=subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(pdf),str(txt)],capture_output=True,text=True);assert p.returncode==0,p.stderr
  t=txt.read_bytes()
  return {'key':key,'url':url,'resolved_url':resolved,'pdf_bytes':len(b),'pdf_sha256':hashlib.sha256(b).hexdigest(),'text_bytes':len(t),'text_sha256':hashlib.sha256(t).hexdigest(),'text_lines':len(t.splitlines()),'conversion':'pdftotext -layout','conversion_stderr':p.stderr,'status':'acquired_not_read','local_pdf':str(pdf),'local_text':str(txt)}
 except Exception as e:return {'key':key,'url':url,'status':'failed','error':str(e)}
with ThreadPoolExecutor(max_workers=3) as ex:results=list(ex.map(acquire,items))
assert sum(x.get('pdf_bytes',0)+x.get('text_bytes',0) for x in results)<=16*1024*1024
receipt={'at':datetime.now(timezone.utc).isoformat(),'normal_TLS':True,'max_pdf_bytes':3*1024*1024,'total_limit_bytes':16*1024*1024,'analysis_format':'converted text only','items':results}
(r/'acquisition.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False))
