from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,io,tarfile,subprocess,shutil

r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-CI119'
now=datetime.now(timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
q=json.loads((out/'quality.json').read_text())
assert q['core_tests']==q['clean_core_tests']==97 and q['clean_directory_removed']
assert q['full_JSON_GraphML_objects_equal'] and q['old_impact_cases_rechecked']==181
assert q['old_multi_seed_cases_rechecked']==2 and q['foundation_dependency_interfaces']==39
snapshot_paths=['scripts/replay_run.py','tests/test_replay_diagnostics.py','.github/workflows/check.yml',
                'reports/reproducibility/20261029-CI119/diagnostic-spec.json']
snapshot={p:(r/p).read_text() for p in snapshot_paths}
for p,text in snapshot.items():assert text.encode()==subprocess.check_output(['git','show','42901e6:'+p])
rawsnapshot=(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n').encode()
packedsnapshot=gzip.compress(rawsnapshot,mtime=0);assert gzip.decompress(packedsnapshot)==rawsnapshot
(out/'controller-source-snapshot.json.gz').write_bytes(packedsnapshot)
for n in ['local119-replay','representative149','representative325']:
    d=json.loads((w/(n+'.json')).read_text())
    assert all(d['deterministic_outputs_match'].values()) and d['replay_resource_envelope_met']
    raw=(w/(n+'.json')).read_bytes();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
    (out/(n+'.json.gz')).write_bytes(z)
# Preserve the failed dispatch, which used a nonexistent run path and never
# executed an experiment. Its complete failure capsule remains independently
# hashed; moving it after QA avoids mutating a live clean-copy input list.
wrong=list((r/'experiments/replay-failures').glob('EXP-149-001-5d2e4196482dc8aa-*'))
assert len(wrong)==1
wrong=wrong[0];receipt=json.loads((wrong/'receipt.json').read_text());packed=(wrong/'failure.tar.gz').read_bytes()
assert sha(packed)==receipt['archive_sha256']
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed))) as tar:
    for n,h in receipt['members'].items():assert sha(tar.extractfile(n).read())==h
dest=out/'dispatch-path-failure';assert not dest.exists();shutil.move(str(wrong),dest)
save(out/'dispatch-path-correction.json',{'at':now,'error':'Wrong149 run-folder suffix in auxiliary command; manifest missing, no target executed','corrected_from':'EXP-149-001-5d2e4196482dc8aa','corrected_to':'EXP-149-001-e334ac2404104e6a','evidence':'dispatch-path-failure/','correct_run_strict_raw_summary_and_resources':True,'scientific_failure_or_new_check_credit':False})
# All old tests and scientific/canonical records remain byte-identical.
oldtests=subprocess.check_output(['git','ls-tree','-r','--name-only','8805716','--','tests'],text=True).splitlines()
for p in oldtests:assert (r/p).read_bytes()==subprocess.check_output(['git','show','8805716:'+p])
assert not subprocess.check_output(['git','diff','8805716','--','data','experiments/runs','experiments/specs','src','reports/graph'])
assert not subprocess.check_output(['git','-C','math','status','--porcelain'])
closure={'at':now,'maintenance_output':'MAINT-CI119-20261029','local_implementation':'verified; remote deployment and Linux cause still pending','frozen_controller_commit':'42901e6bad529508ac65e8686ba6621e7c59f688','core_tests':97,'clean_core_tests':97,'new_software_controls':2,'local119_strict_raw_summary_equal':True,'local119_resources_pass':True,'local119_runtime':'macOS/Python3.14.8','Linux_failure_reproduced_locally':False,'Linux_cause_localized':False,'strict_supported_adverse_representatives':['EXP-149-001-e334ac2404104e6a','EXP-325-001-9bedfaa5ac3a53d0'],'single_seed_cases':181,'multi_seed_cases':2,'method_cases':8,'foundation_proof_interfaces':39,'full_graph_and_exports_equal':True,'scientific_archives':18,'scientific_snapshot_members':378,'old_tests_byte_preserved':len(oldtests),'canonical_and_scientific_data_unchanged':True,'prior_cause_description_corrected_with_old_versions_preserved':True,'dispatch_path_error_preserved':True,'new_scientific_hypotheses':0,'new_candidates_or_initial_checks':0,'retrospective':'reports/retrospectives/046-proof-scope-and-replay-evidence.md','substantive_outputs_since045_closed':3,'WP129':'in_progress','github_push':False,'public_CI_still':'failure','goal':'active_incomplete'}
save(out/'closure.json',closure)
retro=r/closure['retrospective']
with retro.open('a') as f:
    f.write('\n\n最终质量闭包（'+now+'）：本机Python3.14.8实际EXP119完整raw/summary相等、原资源通过；不解释Linux失败。F149限定支持和F325不利代表均完整严格重放及资源通过。97核心/无math干净97无跳过、181单种子/2多种子、8方法/39证明接口、全图JSON/GraphML和18归档378源码核验通过，'+str(q['files'])+'文件/'+str(q['bytes'])+'字节干净副本已核散列删除。旧测试逐文件和规范/科学数据保持。一次149辅助命令写错目录、未执行目标，错误日志与完整失败胶囊保留，按实际清单路径更正后严格重放通过；不是科学反证。全部自有辅助与日志压缩回解核散列后清理。三项实质输出后计数归零，WP129仍in_progress，按本复盘先做八接口的需求/十域/组合探索，84条语义整理继续保留；无GitHub推送。\n')
p=r/'state/backlog.json';b=json.loads(p.read_text())
next_action='Global046 route adjustment: first use the eight already source-bound F271 method contracts for bounded demand/old-baseline, ten-domain and cross-family exploration, preserving failed mappings and extra prerequisites. Register a candidate only with concrete source/problem/conditions and falsifiable distinction. Then finish the remaining84 October claims (30 finite-range/24 correction/30 spherical), bibliography aliases/history and whole-family QA. Do not repeat119 locally or run new numerical targets without separate frozen specs.'
t=next(t for t in b['tasks'] if t['id']=='WP-129')
t['next_action']=next_action;t['retrospective_due']='Global046 completed after third substantive partial/maintenance output; next cycle threshold3 unchanged.'
t['route_adjustment']={'retrospective':closure['retrospective'],'at':now,'decision':'Bring bounded application mapping forward before exhaustive remaining claim curation; preserve full-family requirements.','reason':'Two source-curation outputs and one maintenance output produced no application/distant-exploration count increase.'}
b['updated_at']=now;save(p,b)
p=r/'state/checkpoint.json';c=json.loads(p.read_text());c['saved_at']=now;c['updated_at']=now
c['latest_retrospective']=closure['retrospective'];c['work_packages_since_last_retrospective']=0
c['substantive_partial_outputs_since045'].append('MAINT-CI119 local comparison/upload controls, actual119 strict local replay and global046')
c['substantive_outputs_since_last_retrospective']=[];c['active_work_package']=t;c['next_work_package']=t
c['last_quality_evidence']=str((out/'quality.json').relative_to(r));c['running_quality_checks']=[];c['running_research_experiments']=[]
c['publication_work']['followup'].update(status='local_retention_fix_verified_remote_diagnosis_pending',next_action='Do not rerun same local119; macOS3.14.8 raw/summary/resource pass. New comparison diagnostics and upload step stay local until next meaningful authorized batch. Future Linux failure payload is needed before cause attribution.',evidence=str((out/'closure.json').relative_to(r)))
c['maintenance_output']=closure;c['current_goal_turn_classification']={'previous_turn':'progress','this_turn':'progress','evidence':'Corrected preservation cause, two real software mismatch controls, frozen actual119 strict local replay, representative strict replays and97/97 global QA; global046 changes next research allocation. No scientific count increase.','goal':'active_incomplete'}
save(p,c)
p=r/'state/publication.json';d=json.loads(p.read_text());d['local_followup']={'evidence':str((out/'closure.json').relative_to(r)),'status':'local_fix_verified_not_pushed','local119_strict_match':True,'runtime':'macOS/Python3.14.8','Linux_cause':'unknown','workflow_artifact_upload':'local only, not remotely verified'};save(p,d)
p=r/'state/status.md';old=p.read_text();history=old.split('以下为历次工作记录，数字保留为当时快照。',1)[1]
head='# 当前状态\n\n更新时间：'+now+'。第一阶段仍未完成。\n\n固定上游1581d4cbdd69a0faf34b2089614fe2a814316a6a；math只读未部署。图8936节点26265关系，64阅读/59草稿、47候选/15初检/15不同验证（7限定支持8不利），另1诊断/2组件；完整族、历史、人审、第二供应商与试点均未完成。\n\n最新维护：CI119留证缺口在工作流上传，旧控制器已压缩留证，前次措辞已校正并归档。新增有界差异与worker日志、CI失败上传仅本地。实际本机3.14.8 EXP119完整raw/summary及原资源通过；Linux26.04/3.14.9失败原因仍未知。公开快照f2aa303已核验，CI40831475096仍failure，不能继承旧成功或改判。\n\n97核心/干净97、181单种子/2多种子、8方法/39命题接口、完整图和18归档378源码核验，F149支持/F325不利代表严格重放通过。证据reports/reproducibility/20261029-CI119/closure.json。全局046完成，计数归零。WP129仍在进行：四稿14199行已读、八方法与34基础命题已规范，下一优先需求/旧基线与十域/跨族探索，随后剩余84条语义整理及全族历史；不强行增加候选。\n\n不例行推送GitHub，真人和第二供应商由用户后补，不重复询问。当前没有已知活动研究/检查句柄。\n\n以下为历次工作记录，数字保留为当时快照。'
p.write_text(head+history+'\n\nCI119维护与全局046闭包（'+now+'）：本机严格重放通过不能定位Linux差异，工作流失败上传尚未部署；两项软件控制加全局97/97与全图/归档/代表重放通过。辅助路径错误及此前原因措辞原版保留。三项实质输出后计数归零，下一改为八方法需求/十域/跨族探索，整族未完。无推送。\n')
with (r/'docs/roadmap.md').open('a') as f:
    f.write('\n\n全局046（'+now+'）：八方法、34命题和CI119维护三项实质输出后计数归零。当前97/干净97及全图/归档/代表严格重放通过，本机119严格匹配，Linux原因未知且公开CI仍失败；本地失败上传尚未部署。不把软件或图谱规模计为应用收益。WP129下一先做已整理八接口的需求/十域/跨族比较，再完成84条语义和历史，保留旧方法已足够的零假设、32个未初检候选及低覆盖预算；无例行GitHub推送。\n')
# Archive every executed helper and observed log, including this finalizer.
assert not (w/'clean').exists();files=sorted(p for p in w.iterdir() if p.is_file());manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
    for p in files:
        raw=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(raw);i.mtime=0;tar.addfile(i,io.BytesIO(raw));manifest.append({'name':p.name,'bytes':len(raw),'sha256':sha(raw)})
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
    for i in manifest:assert sha(tar.extractfile(i['name']).read())==i['sha256']
(out/'final-helpers-and-logs.tar.gz').write_bytes(packed)
for p in files:p.unlink()
w.rmdir()
save(out/'storage.json',{'at':now,'members':manifest,'compressed_sha256':sha(packed),'decompressed_sha256':sha(raw),'gzip_bytes':len(packed),'roundtrip_verified':True,'temporary_directory_removed':not w.exists(),'clean_copy_removed':True,'official_math_copied':False,'failed_dispatch_capsule_preserved':'dispatch-path-failure/','no_GitHub_push':True})
print(json.dumps({'core':97,'clean':97,'119_local_strict_equal':True,'retrospective':'046','cycle_count':0,'temporary_directory_removed':True,'Linux_cause':'unknown','next':'WP129 application mapping before remaining84 claims','goal':'active_incomplete'}))
