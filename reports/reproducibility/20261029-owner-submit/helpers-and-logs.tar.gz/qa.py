from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,os,shutil,subprocess,sys,tarfile,re,xml.etree.ElementTree as ET
root=Path.cwd();work=Path('/private/tmp/mathweave-owner-submit');out=root/'reports/reproducibility/20261029-owner-submit'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def savegz(p,d):
 raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;p.write_bytes(z)
assert 'Ran 97 tests' in (work/'core.log').read_text() and '\nOK\n' in (work/'core.log').read_text();assert 'skipped=' not in (work/'core.log').read_text()
assert not git('diff','cd96e41','--','data/corpus','experiments','src','tests','data/graph/reading_coverage.json')
assert not git('-C','math','status','--porcelain')
assert git('-C','math','rev-parse','HEAD').decode().strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
sys.path.insert(0,str(root/'src'));from ai_value.graph import load, affected_nodes, theoretical_grade
nodes,edges=load(root);j=json.loads(gzip.decompress((root/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in j['nodes']}==nodes;assert {e['id']:e for e in j['edges']}=={e['id']:e for e in edges}
xml=ET.fromstring(gzip.decompress((root/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'}
xnodes={n.attrib['id']:json.loads(n.find('g:data[@key="properties"]',ns).text) for n in xml.findall('.//g:node',ns)};xedges={e.attrib['id']:json.loads(e.find('g:data[@key="evidence"]',ns).text) for e in xml.findall('.//g:edge',ns)};assert xnodes==nodes and xedges=={e['id']:e for e in edges}
prior=json.loads(gzip.decompress((root/'reports/reproducibility/20261027-F181-history/quality.json.gz').read_bytes()))
for case in prior['impact_cases']:
 affected=affected_nodes(nodes,edges,{case['seed']})
 key=case.get('required_affected')
 if key:assert (key in affected)==case['confirmed'],case
 forbidden=case.get('must_not_propagate_to')
 if forbidden:assert forbidden not in affected,case
for case in prior['alternative_route_cases']:assert set(case['required_affected'])<=affected_nodes(nodes,edges,set(case['seeds']))
new=[n for n in nodes.values() if n['id'].startswith('PART-271-')]
assert len(new)==8
for n in new:
 mid=next(e['target'] for e in edges if e['source']==n['id'] and e['relation']=='derived_from')
 assert n['id'] in affected_nodes(nodes,edges,{mid})
 assert theoretical_grade(nodes,edges,n['id'])=='unknown'
oldn=git('show','cd96e41:data/graph/nodes.jsonl');olde=git('show','cd96e41:data/graph/edges.jsonl')
assert (root/'data/graph/nodes.jsonl').read_bytes().startswith(oldn)
assert (root/'data/graph/edges.jsonl').read_bytes().startswith(olde)
foundation=[n for n in nodes.values() if n['id'].startswith('CLM-271-F-')]
assert len(foundation)==34
for n in foundation:assert theoretical_grade(nodes,edges,n['id'])=='unknown'
new_interfaces=[e for e in edges if e['source'].startswith('CLM-271-F-') and e['relation']=='depends_on']
for e in new_interfaces:assert e['source'] in affected_nodes(nodes,edges,{e['target']})
main_id='CLM-271-F-THM-MAIN'
for seed in ['CLM-271-F-THM-PIN-BOOTSTRAP','CLM-271-F-LEM-SURFACE-COST','CLM-271-F-LEM-DEEP-DYNAMICS','CLM-271-F-LEM-STRIP-LIMIT']:
 assert main_id in affected_nodes(nodes,edges,{seed})
 assert 'PART-271-DUAL-CAPACITY' not in affected_nodes(nodes,edges,{seed})
cur=json.loads((root/'reports/reproducibility/20261029-F271-finite-range/curation.json').read_text());newclaims=[nodes[n] for n in cur['node_ids'] if nodes[n]['kind']=='claim']
assert len(newclaims)==30 and cur['new_records']==31 and cur['new_edges']==77
from ai_value.source_results import named_results
ledger=json.loads((root/'data/provenance/readings/F-271-finite-range-claims-WP129.json').read_text())
found=set()
for path in {c['source']['path'] for c in ledger['claims']}:
 found.update(x['label'] for x in named_results((root/path).read_text()))
assert found=={c['label'] for c in ledger['claims']}
for c in ledger['claims']:
 p=root/c['source']['path'];assert sha(p.read_bytes())==c['source']['file_sha256']
 a,b=c['source']['statement_lines'];statement='\n'.join(p.read_text().splitlines()[a-1:b]);assert '\\label{'+c['label']+'}' in statement
for n in newclaims:
 assert n['properties']['credibility']=='C' and theoretical_grade(nodes,edges,n['id'])=='unknown'
 assert not n['properties']['independent_proof_review']
new_edges=[e for e in edges if e['id'] in cur['edge_ids']]
proofs=[e for e in new_edges if e['relation']=='depends_on'];assert len(proofs)==44
for e in new_edges:
 if e['relation'] in {'depends_on','uses','derived_from'}:assert e['source'] in affected_nodes(nodes,edges,{e['target']})
main='CLM-271-FR-THM-MAIN'
for seed in ['CLM-271-FR-THM-RETURN-BOUNDS','CLM-271-FR-PROP-LONG-TAIL','CLM-271-FR-LEM-PIN-MIXTURE','CLM-271-FR-THM-SPARSE-PINS']:
 assert main in affected_nodes(nodes,edges,{seed})
 assert 'CLM-271-F-THM-MAIN' not in affected_nodes(nodes,edges,{seed})
 assert 'APP-271-01' not in affected_nodes(nodes,edges,{seed})
# Conditional local diffusion must not depend circularly on the global bootstrap.
assert 'CLM-271-FR-PROP-DIFFUSION' not in affected_nodes(nodes,edges,{'CLM-271-FR-THM-SPARSE-PINS'})
oldcards=[n for n in map(json.loads,git('show','cd96e41:data/graph/nodes.jsonl').decode().splitlines()) if n['kind']=='connection']
assert len(oldcards)==48 and all(nodes[n['id']]==n for n in oldcards)
report=(root/'reports/F271-finite-range-claims.md').read_text()
for n in newclaims:
 assert n['id'] in report and n['properties']['statement'] in report
 assert all(c in report for c in n['properties']['conditions'])
metrics=json.loads((root/'reports/metrics.json').read_text());assert metrics['candidate_connections']==48 and metrics['externally_checked_cards']==15
assert metrics['partial_reading_families']==64 and metrics['source_decomposition_drafts']==59
savegz(out/'new-scope-impact-checks.json.gz',{'finite_range_claims':30,'selected_proof_interfaces':44,'old48cards_preserved':True,'new_chain_grades_unknown':True,'cross_manuscript_no_formal_inheritance':True,'no_bootstrap_cycle':True,'current_source_label_set_complete':True})

# New correction scopes: source statements and exact old capacity retained.
newcur=json.loads((root/'reports/reproducibility/20261029-F271-correction/curation.json').read_text());assert newcur['new_records']==24 and newcur['new_edges']==97 and newcur['selected_proof_interfaces']==71
corledger=json.loads((root/'data/provenance/readings/F-271-correction-claims-WP129.json').read_text());newcor=[nodes[x['id']] for x in corledger['claims']];assert len(newcor)==23
newids={n['id'] for n in newcor};assert 'CLM-271-CORR-CAPACITY' not in newids
allcor=[n for n in nodes.values() if n['id'].startswith('CLM-271-CORR-')];assert len(allcor)==24
old_capacity=next(json.loads(b) for b in oldn.splitlines() if json.loads(b)['id']=='CLM-271-CORR-CAPACITY');assert nodes[old_capacity['id']]==old_capacity
labels=set()
for path in {x['source']['path'] for x in corledger['claims']}:
 labels.update(x['label'] for x in named_results((root/path).read_text()))
assert labels=={x['label'] for x in corledger['claims']}|{'lem:capacity'}
for c in corledger['claims']:
 p=root/c['source']['path'];assert sha(p.read_bytes())==c['source']['file_sha256'];a,b=c['source']['statement_lines'];statement='\n'.join(p.read_text().splitlines()[a-1:b]);assert '\\label{'+c['label']+'}' in statement
for n in newcor:
 assert n['properties']['credibility']=='C' and not n['properties']['independent_proof_review']
 assert theoretical_grade(nodes,edges,n['id'])=='unknown'
for source in corledger['source_reading_receipts']:assert sha((root/source['path']).read_bytes())==source['file_sha256']
newedges=[e for e in edges if e['id'] in newcur['edge_ids']];mandatory=[e for e in newedges if e['relation'] in {'depends_on','uses','derived_from'}];assert len(mandatory)==94
closures={s:affected_nodes(nodes,edges,{s}) for s in {e['target'] for e in mandatory}}
for e in mandatory:assert e['source'] in closures[e['target']],e
main='CLM-271-CORR-THM-MAIN';snapshot='CLM-271-CORR-PROP-SNAPSHOT';good='CLM-271-CORR-PROP-GOOD';comparison='CLM-271-CORR-PROP-COMPARISON';dual='CLM-271-CORR-PROP-DUALENERGY';early='CLM-271-CORR-LEM-EARLYSOURCEENERGY'
for seed in ['CLM-271-CORR-CAPACITY','CLM-271-CORR-PROP-SCALAR',dual,good,'CLM-271-CORR-LEM-SURFACECOST']:
 assert main in affected_nodes(nodes,edges,{seed})
for seed in [good,comparison,main]:assert snapshot not in affected_nodes(nodes,edges,{seed})
assert early not in affected_nodes(nodes,edges,{dual})
assert 'CLM-271-CORR-LEM-FREEBOUNDS' not in affected_nodes(nodes,edges,{good})
assert 'CLM-271-CORR-LEM-KERNELENERGY' not in affected_nodes(nodes,edges,{good})
for seed in newids:
 affected=affected_nodes(nodes,edges,{seed})
 for protected in ['CLM-271-CORR-CAPACITY','PART-271-DUAL-CAPACITY','APP-271-01','CLM-271-F-THM-MAIN','CLM-271-FR-THM-MAIN']:
  assert protected not in affected,(seed,protected)
report=(root/'reports/F271-correction-claims.md').read_text()
for n in newcor:
 assert n['id'] in report and n['properties']['statement'] in report
 assert all(c in report for c in n['properties']['conditions'])
assert corledger['source_bindings_total_after']==88 and corledger['remaining_October_semantic_statements']==30
assert corledger['new_numerical_targets']==0 and corledger['new_application_checks']==0
savegz(out/'correction-scope-impact-checks.json.gz',{'new_source_claims':23,'this_manuscript_bindings':24,'new_records':24,'new_edges':97,'selected_proof_interfaces':71,'new_mandatory_edges_checked':94,'old_capacity_byte_preserved':True,'old48cards_preserved':True,'all_new_complete_chain_grades_unknown':True,'snapshot_no_final_good_event_or_main_cycle':True,'early_source_does_not_assume_dual_conclusion':True,'generic_capacity_and_candidate_not_invalidated_by_physical_claims':True,'no_cross_manuscript_formal_inheritance':True,'source_binding_total':88,'remaining':30})

archives=[];members=0
for mf in sorted((root/'experiments/runs').glob('*/manifest.json')):
 d=json.loads(mf.read_text());folder=mf.parent
 for path,digest in d['outputs'].items():assert sha((folder/path).read_bytes())==digest,(mf,path)
 for path,meta in d['compressed_payloads'].items():
  raw=gzip.decompress((folder/path).read_bytes());assert sha(raw)==meta['uncompressed_sha256'];json.loads(raw)
 snapshot=json.loads(gzip.decompress((folder/d['source_snapshot']).read_bytes()))
 for path,content in snapshot.items():assert sha(content.encode())==d['inputs'][path],(mf,path)
 members+=len(snapshot);archives.append({'run_id':d['run_id'],'source_members':len(snapshot),'outputs_and_decompressed_hashes_verified':True})
assert len(archives)==18 and members==378,(len(archives),members)
clean=work/'clean';assert not clean.exists();clean.mkdir()
names=sorted(set(filter(None,git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0'))));manifest=[]
for n in names:
 assert n.split('/')[0] not in {'math','.git','.venv','.cache','tmp'}
 src=root/n;assert src.is_file() and not src.is_symlink();b=src.read_bytes();dst=clean/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);dst.chmod(src.stat().st_mode&0o777);assert sha(dst.read_bytes())==sha(b);manifest.append({'path':n,'bytes':len(b),'sha256':sha(b)})
assert not (clean/'math').exists()
with (work/'no-math-core.log').open('wb') as f:p=subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
receipt={'at':datetime.now(timezone.utc).isoformat(),'files':len(manifest),'bytes':sum(i['bytes'] for i in manifest),'official_math_paths':0,'copy_hashes_verified':True,'core_exit_code':p.returncode,'runtime':sys.version,'manifest':manifest};savegz(out/'no-math-clean.json.gz',receipt)
if p.returncode:
 print((work/'no-math-core.log').read_text()[-3000:]);sys.exit(p.returncode)
assert 'Ran 97 tests' in (work/'no-math-core.log').read_text() and '\nOK\n' in (work/'no-math-core.log').read_text();assert 'skipped=' not in (work/'no-math-core.log').read_text()
for i in manifest:assert sha((clean/i['path']).read_bytes())==i['sha256'],i['path']
shutil.rmtree(clean)
quality={k:v for k,v in receipt.items() if k!='manifest'};quality.update(core_tests=97,clean_core_tests=97,skips=0,clean_directory_removed=True,scientific_implementation_unchanged_from='cd96e41',full_JSON_GraphML_objects_equal=True,scientific_archives=archives,source_archive_members=members,prior_complete_dependency_impact_receipt='reports/reproducibility/20261027-F181-history/quality.json.gz',prior_strict_supported_adverse_replays='reports/reproducibility/20261029-F178-admission/closure.json',new_scientific_runs=0,WP129_full_family_credit_added=False,scope='Owner-requested publication of current canonical snapshot;recheck inherited graph/source/dependency/archive contracts and no-math clean copy. No new research or numerical credit.')
# Store helper/log plaintext compressed; verify every archive member before deleting it later.
entries=['qa.py','core.log','no-math-core.log'];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for n in entries:
  b=(work/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for n in entries:assert t.extractfile(n).read()==(work/n).read_bytes()
(out/'helpers-and-logs.tar.gz').write_bytes(z);quality.update(old_impact_cases_rechecked=len(prior['impact_cases']),old_multi_seed_cases_rechecked=len(prior['alternative_route_cases']),new_method_dependency_cases=8,old_canonical_rows_byte_preserved=True,foundation_source_claims=34,foundation_dependency_interfaces=len(new_interfaces),helper_members_verified=len(entries),helper_compressed_sha256=sha(z),helper_decompressed_sha256=sha(raw));(out/'quality.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in quality.items() if k!='scientific_archives'}),flush=True)
