from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).resolve().parent;base='3ea7af2'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
a=old('data/graph/nodes.jsonl').splitlines(keepends=True);b=(r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)
changed={'LIT-047-TRAVERSO','LIT-047-STACKS','ANALYSIS-F-047','CLM-047-PROP-LINEARIZATION'};arch=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-115-before.json.gz').read_bytes()));prior={x['id']:x for x in arch['records']};kept=0
for x,y in zip(a,b):
 n=json.loads(x);z=json.loads(y);assert n['id']==z['id']
 if n['id'] in changed:assert n==prior[n['id']] and z['version']==n['version']+1
 else:assert x==y;kept+=1
assert kept==5262 and len(b)==5275
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl')) and len((r/'data/graph/edges.jsonl').read_bytes().splitlines())-len(old('data/graph/edges.jsonl').splitlines())==14
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')) and name!='reports/families/F-047.md':
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==61 and generated['source_decomposition_drafts']==56
assert generated['candidate_connections']==46 and generated['externally_checked_cards']==14 and generated['effective_leads']==6 and generated['distinct_validation_hypotheses']==14
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
assert nodes['CLM-047-PROP-LINEARIZATION']['properties']['source_claim_grade']=='C' and nodes['CLM-047-PROP-LINEARIZATION']['properties']['dependency_chain_grade']=='unknown'
assert nodes['CLM-047-PROP-LINEARIZATION']['properties']['statement_tex']==prior['CLM-047-PROP-LINEARIZATION']['properties']['statement_tex']
assert nodes['ANALYSIS-F-047']['properties']['formal_status']==prior['ANALYSIS-F-047']['properties']['formal_status'] and not nodes['ANALYSIS-F-047']['properties']['historical_lineage_complete']
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F276-receiver-registration/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
pic='CLM-047-REGULAR-PICARD-INVARIANCE';tr='PART-047-PICARD-TRAVERSO-ROUTE';dv='PART-047-PICARD-DIVISOR-ROUTE';lift='CLM-047-PROP-LINEARIZATION'
for seed,target,positive in [('CLM-047-TRAVERSO-PICARD-STATEMENT',tr,True),('CLM-047-STACKS-0BE9',dv,True),(pic,lift,True),(tr,pic,False),(dv,pic,False),('CLM-047-STACKS-0BE9',lift,False),('CLM-047-STACKS-0AG0','APP-276-01',False)]:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'Explicit alternative routes isolate single-route review; no proof independence or mathematical acceptance inferred'})
or_cases=[]
for seeds,required in [([tr,dv],[pic,lift]),(['CLM-047-TRAVERSO-PICARD-STATEMENT','CLM-047-STACKS-0BE9'],[pic,lift])]:
 affected=impact_report(nodes,edges,set(seeds))['affected'];assert set(required)<=set(affected);or_cases.append({'seeds':seeds,'required_affected':required,'confirmed':True})
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==16 and members==298
ledger=json.loads((r/'data/provenance/readings/F-047-Picard-history.json').read_text());assert ledger['source_bytes']==1119546 and ledger['original_works']==2 and ledger['primary_mathematical_documents_checked']==5 and not ledger['full_historical_lineage_complete']
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_rows_byte_equal':kept,'updated_record_versions':{k:[prior[k]['version'],nodes[k]['version']] for k in sorted(changed)},'new_records':9,'new_explicit_edges':14,'old_explicit_edge_prefix_equal':True,'preserved_science_code_tests_corpus_other_family_reports_and_prior_reading_ledgers':len(preserved),'reading_coverage_byte_equal':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':or_cases,'experiment_archives':archives,'source_archive_members':members,'new_candidates':0,'application_checks_added':0,'new_scientific_runs':0,'selected_original_mathematical_documents':5,'original_primary_works':2,'source_bytes':1119546,'limitations':'Actual selected historical prerequisite statements and source-use premise matching, not recursive proof closure, new source-family coverage, Lean build, human/provider review or application support. No numerical rerun because code/science are unchanged; WP117 exact archived replay remains immutable evidence.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','experiment_archives','generated_metrics']},ensure_ascii=False))
