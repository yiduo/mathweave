from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,json,re
w=Path(__file__).resolve().parent
urls={'Traverso-landing':'https://www.numdam.org/item/ASNSP_1970_3_24_4_585_0/'}
urls.update({x:'https://stacks.math.columbia.edu/tag/'+x for x in ['056S','0AG0','0BE9','00KV']})
class Text(HTMLParser):
 def __init__(self):super().__init__();self.out=[];self.hide=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.hide+=1
  if t in ['p','div','h1','h2','h3','li','br','section']:self.out.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style']:self.hide-=1
 def handle_data(self,s):
  if not self.hide:self.out.append(s)
def fetch(item):
 name,url=item;row={'name':name,'url':url,'requested_at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave primary-source research'}),timeout=25) as resp:
   b=resp.read(2*1024**2+1);assert len(b)<=2*1024**2;row.update(final_url=resp.url,status=resp.status,content_type=resp.headers.get('Content-Type'),http_last_modified=resp.headers.get('Last-Modified'),http_etag=resp.headers.get('ETag'))
  (w/(name+'.html')).write_bytes(b);s=b.decode('utf-8');parser=Text();parser.feed(s);txt='\n'.join(x.strip() for x in ''.join(parser.out).splitlines() if x.strip())+'\n';(w/(name+'.txt')).write_text(txt)
  row.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),text_sha256=hashlib.sha256(txt.encode()).hexdigest(),text_lines=len(txt.splitlines()),temporary_html=str(w/(name+'.html')),temporary_text=str(w/(name+'.txt')))
  if name=='Traverso-landing':row['pdf_metadata']=[m.group(0) for m in re.finditer(r'<meta[^>]+(?:pdf|citation)[^>]*>',s,re.I)];row['pdf_links']=re.findall(r'[^\s\"<>]+\.pdf',s)
 except Exception as e:row['error']=repr(e)
 return row
with ThreadPoolExecutor(max_workers=5) as pool:rows=list(pool.map(fetch,urls.items()))
assert sum(x.get('bytes',0) for x in rows)<=8*1024**2
(w/'acquisition.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'rows':rows},ensure_ascii=False,indent=2)+'\n')
for row in rows:print(json.dumps(row,ensure_ascii=False))
