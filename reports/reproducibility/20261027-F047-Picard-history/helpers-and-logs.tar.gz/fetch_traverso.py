from pathlib import Path
from datetime import datetime,timezone
import json,re,urllib.request,hashlib,subprocess
w=Path(__file__).resolve().parent;d=json.loads((w/'acquisition.json').read_text());landing=next(x for x in d['rows'] if x['name']=='Traverso-landing');url=re.search(r'content="([^"]+)"',next(x for x in landing['pdf_metadata'] if 'citation_pdf_url' in x)).group(1)
row={'url':url,'requested_at':datetime.now(timezone.utc).isoformat()}
try:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave primary-source research'}),timeout=30) as resp:
  b=resp.read(4*1024**2+1);assert len(b)<=4*1024**2 and b.startswith(b'%PDF');row.update(final_url=resp.url,status=resp.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 p=w/'Traverso1970.pdf';p.write_bytes(b);text=w/'Traverso1970.txt';cmd=['/opt/homebrew/bin/pdftotext','-layout',str(p),str(text)];proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row['conversion_exit']=proc.returncode;row['conversion_stderr']=proc.stderr.decode();assert proc.returncode==0
 t=text.read_bytes();row.update(temporary_pdf=str(p),temporary_text=str(text),text_sha256=hashlib.sha256(t).hexdigest(),text_bytes=len(t),text_lines=len(t.splitlines()),page_segments=len(t.decode().split('\f'))-1,conversion_command=cmd)
except Exception as e:row['error']=repr(e)
(w/'Traverso-acquisition.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False))
