from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).resolve().parent;base='011f37b'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
on=old('data/graph/nodes.jsonl');oe=old('data/graph/edges.jsonl');assert (r/'data/graph/nodes.jsonl').read_bytes().startswith(on) and (r/'data/graph/edges.jsonl').read_bytes().startswith(oe);assert len((r/'data/graph/nodes.jsonl').read_bytes().splitlines())-len(on.splitlines())==15
kept=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')):assert (r/name).read_bytes()==old(name),name;kept.append(name)
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
metrics=validate(r);generated=render(r);exported=export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==61 and generated['source_decomposition_drafts']==56
assert generated['candidate_connections']==46 and generated['externally_checked_cards']==13 and generated['effective_leads']==5 and generated['distinct_validation_hypotheses']==13
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F047-cancellation/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected'),v;impacts.append(v)
for a,b in [('LIT-047-SINGULAR-ALGEBRA-API','PART-047-CONSUMER-MAP-CERTIFICATE'),('LIT-047-SAGE-MORPHISM-API','PART-047-CONSUMER-SOURCE-RELATION-GUARD'),('LIT-047-SAGE-MORPHISM-API','PART-047-CONSUMER-TYPED-GRAPH'),('PART-047-CONSUMER-MAP-CERTIFICATE','PROB-047-CONSUMER-INCREMENTAL-WORKLOAD')]:
 assert b in impact_report(nodes,edges,{a})['affected'];impacts.append({'seed':a,'required_affected':b,'confirmed':True})
for a,b in [('LIT-047-SAGE-MORPHISM-API','CLM-047-THM-MAIN'),('LIT-047-SINGULAR-ALGEBRA-API','CLM-047-PROP-STABILIZATION'),('LIT-047-SINGULAR-BIJECTIVE-CALLER','CLM-047-THM-MAIN'),('LIT-020-SAGE-LICENSE','PART-047-CONSUMER-TYPED-GRAPH'),('PART-047-CONSUMER-TYPED-GRAPH','APP-020-01')]:
 assert b not in impact_report(nodes,edges,{a})['affected'];impacts.append({'seed':a,'must_not_propagate_to':b,'confirmed':True,'scope':'Software/code/license context doesnot become mathematicalproof or unrelatedapplication dependency'})
for nid in ['CLM-047-THM-MAIN','CLM-047-PROP-STABILIZATION']:assert nodes[nid]['properties']['source_claim_grade']=='B' and nodes[nid]['properties']['dependency_chain_grade']=='unknown'
ledger=json.loads((r/'data/provenance/demand/F-047-map-consumers.json').read_text());assert ledger['file_count']==3 and ledger['selected_source_lines_read']==1687 and not ledger['actual_local_software_execution'];assert ledger['new_candidates']==ledger['new_initial_checks']==0
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());folder=mp.parent
 for name,digest in m['outputs'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((folder/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((folder/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':folder.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==15 and members==267
replays=[]
for suffix in ['221','325']:
 x=json.loads((w/('replay-'+suffix+'.json')).read_text());assert all(x['deterministic_outputs_match'].values()) and x['replay_resource_envelope_met'] and x['comparison_scope']=='Exact complete JSON payloads; no fields excluded';replays.append(x)
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_records_byte_equal':len(on.splitlines()),'new_records':15,'old_explicit_edges_prefix_equal':True,'preserved_science_code_tests_corpus_family_reports_reading_ledgers':len(kept),'reading_coverage_byte_equal':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'experiment_archives':archives,'source_archive_members':members,'actual_representative_replays':replays,'new_candidates':0,'application_checks_added':0,'scientific_runs_added':0,'source_files':3,'source_lines_actually_read':1687,'source_bytes':159523,'limitations':'Traceability/software checks andoldactualarchivedreplays;notlocalSage/Singular execution,proof validation,human/providerreview ornewapplication support. Replays do not add distinct hypotheses.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','experiment_archives','generated_metrics','actual_representative_replays']},ensure_ascii=False))
