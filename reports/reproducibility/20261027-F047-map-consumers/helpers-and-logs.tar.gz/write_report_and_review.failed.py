from pathlib import Path
from datetime import datetime,timezone
import json,collections
r=Path.cwd();w=Path(__file__).resolve().parent;now=datetime.now(timezone.utc).isoformat();l=json.loads((r/'data/provenance/demand/F-047-map-consumers.json').read_text())
t='''# F047：真实多项式映射证书消费者核查

本报告引用规范节点 `GEN-20261027-113`、`EXPLORE-F-047-CONSUMERS` 及 `data/provenance/demand/F-047-map-consumers.json`。两项目三个固定文件，159523字节、1687行实际选读；只做来源核查，没有安装、执行Sage/Singular或运行新的符号／数值实验。完整族、历史、人审与应用验收均未由此完成。

## 实际来源与所读范围

| 固定来源 | 实际范围 | 输入与输出 |
| --- | --- | --- |
'''
for f in l['source_files']:t+='| ['+f['project']+' '+f['path']+']('+f['url']+')，`'+f['commit']+'` | '+str(f['actual_read_ranges'])+'；'+str(f['actual_lines_read'])+'行 | 给定映射／商环／变量与调用范围见下文；下载不等于全文阅读 |
'
t+='''
同版本Sage／Singular许可复用此前 `LIT-020-SAGE-LICENSE` 与 `LIT-020-SINGULAR-LICENSE` 的实际阅读证据，没有重复下载或增加阅读计数。GitHub连接器读取Sage正文时传输失败，改用同提交第一方raw地址、正常TLS获取；失败保留，不归因于源代码。插件文字经patch落盘多出一个末尾换行，只有恢复原始Git blob SHA完全相等后才登记来源。

## 实际接口结论

Singular `algebra.lib` 对给定映射建立图理想和消元核，并以目标生成元是否属于像代数判断满射。其 `is_bijective` 在同一过程里检查核及满射，不是实际调用两个公开wrapper。源与目标变量数分别取实际环，算法不自行寻找一个未提供映射的全局坐标系统。原始manual调用含多项式与商环实例，已读调用没有F047特定案例；没有把上游测试正文说成本地运行通过。

商环关系与序条件不能略去。Singular的单射过程会把核模源商理想判定；满射说明明确要求留意源商环映射是否良定义，局部／混合序也不能照普通全局多项式语义解释。这是文档中的适用边界，不是本项目发现了一个未经实测的软件漏洞。

Sage的通用源商环映射构造逐个检查cover kernel生成元的像为零。生成元像构造在 `check=True` 时检查像数及domain有效性；不能把一个构造器的 `check=False` 视为所有商环路径都可跳过关系闸门。实际 `_graph_ideal` 要求交换、基环相等、平凡base map；张量模型同时保留两侧关系，重名变量单独改名，要求全局序。逆映射入口先调用单射判断，再寻找每个目标生成元的逆像。所选单射类别实现未全文核查，不宣称全程序正确性；有限域专门支路与一般图方法分开。

## F047能迁移什么，以及什么还不成立

固定柱同构、p=0多项式证书和严格输入／输出类型可以作为未来映射回归语料。已读接口并没有用“加一个变量后同构”直接取消该变量；不能凭F047的标题指控它们会误判原四维对象。复数标量保持的代数同构也不能默认为浮点复数多项式运算的完全相同任务。

旧的源关系检查、图消元、核、生成元逆像及互逆复合证书已覆盖这个给定映射任务。F047可能增加回归实例的结构多样性，但本包没有建立独立增量价值、资源改进或具体错误接受案例。单跑其恒等式不会构成新的应用初检。因此在两项目、三文件时按“旧方法已足够”条件提前停止，不填满三项目、八文件的上限。

## 规范记录、边界与重访

新增15规范记录与20显式边。源接口事实、方法契约、旧基线和增量任务缺口分别关联；不把软件文档当F047主定理的证明输入，不传播成来源B/A。全部5248旧规范行、既有来源账本、科学数据／代码／测试与阅读覆盖保持。

没有新候选、初检、数学声明升级或正式否定。只有真实任务要求未稳定／全局识别且对应证书确有不足，或一个预先冻结的代表性比较能区别新旧方法同输出、同成本时，才重访。全图／散列／传播／导出／归档／核心／干净目录／存储结果以 `reports/reproducibility/20261027-F047-map-consumers/` 最终收据为准。本包之后强制全局复盘041；不例行推送GitHub。
'''
(r/'reports/F047-map-consumer-audit.md').write_text(t)
# Readiness comparison is based on existing canonical card predictions and plans,without target numerical calculations.
cards={x['id']:x['properties'] for x in map(json.loads,(r/'data/graph/nodes.jsonl').read_text().splitlines()) if x['kind']=='connection'}
assert len(cards)==46 and len([x for x in cards.values() if not x.get('run_ids')])==33
fam=[json.loads(x) for x in (r/'data/corpus/families.jsonl').read_text().splitlines()];cov=json.loads((r/'data/graph/reading_coverage.json').read_text());read=set(cov['partially_read_families']);tot=collections.Counter(x['subject'] for x in fam);cnt=collections.Counter(x['subject'] for x in fam if x['id'] in read);analog=collections.Counter(x.get('analogy','missing') for x in cards.values())
review={'at':now,'source_generation':'GEN-20261027-113','family_subject_coverage':[{'subject':s,'read':cnt[s],'total':n} for s,n in tot.items()],'candidate_analogy_counts':dict(analog),'candidate_count':46,'actually_checked_cards':13,'unchecked_cards':33,'effective_leads':5,'adverse_checks':8,'full_family_history_human_provider_pilots':0,'pending_comparison':{i:{k:cards[i].get(k) for k in ['prediction','test_spec','limitations','resources','revisit_when']} for i in ['APP-276-01','APP-094-01','APP-142-01']},'decision':'SelectWP117 existingAPP276 fixed-receiver synthetic audit,freeze executable specification andisolatedauxiliaryreviews beforetargetoutputs. Keep old honestreceiver computation andzero2026increment as allowed null. WP118critical historicalclosure;next coverage selectioncompared afterward.','target_outputs_observed':False,'no_automatic_count_credit':True}
(w/'global-review-evidence.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
retro='''# 全局复盘041：从接口筛查回到可执行的条件检验

2026-10-27；WP114–WP116三项实质工作包。整体第一阶段仍未完成。当前公开d48dd19仍是旧发布边界，本周期研究和复盘只本地保存，不为元数据推送。

## 1. 目标对齐与实际新增

WP114实际读Sage／Singular／SymPy三个固定项目10文件3863行，24规范44边，未满足F020同S完整有理评价核及全路径稳定契约，保留APP02001待定。WP115读F047一当前稿10TeX2281行含172参考文献及README，17具名结果、12契约、60规范100边；仅两个选定结果来源B，15C，全链未知。两部历史原作仅选定范围；Suslin网页片段／局部TLS两次失败和BCW403都未抹去。

WP116两固定项目三文件159523字节、1687行，15规范20边，区分给定映射检查、源关系、双侧商理想、全局序及实际变量数。旧精确检查已覆盖对应任务，提前停止扩搜。三包合计99新增规范164显式边；没有新候选、实际应用初检或科学假设闭环。结果是解除错误迁移的不确定性，不能把15个接口记录当15项应用价值。

必须承认执行偏差：连续“读新稿→找真实消费者→无准入”能保护边界，但若变成所有卡片的统一前置条件，会挤掉原纲领允许的代表性合成检验。真实任务、字段和独立裁判仍需明确；不能在原卡片本来允许合成时额外要求先有硬件或商业用户，也不能倒过来把某条承诺真实消费者的既有假设偷偷降格。

## 2. 覆盖、偏差与剩余差距

372族全部登记，只有61族有阅读／56族当前稿全文草稿；完整族、完整历史谱系和六阶段全部完成仍0。代数复几何从3/36到4/36；组合4/37、微分几何3/29、实复分析2/16仍低，理论计算机12/40不能持续垄断。下一周期同时保留覆盖与历史闭合资源，不能以一个数值闭环替代全量任务。

46/500候选、13/100实际初检、13/10不同可复现假设（5限定支持、8不利观察），150真实分级目标当前0。33候选还未实际初检。候选分布near34／far11／bold1；尝试距离不等于事实错误，远类比和大胆方向保留。实际本周46总体的三条5%抽样准备记录存在，真实审核仍挂起、事实错误率未知；不写0或伪造第二供应商。

## 3. 哪些判断改变，哪些保持

F020的普通Fp核、首项理想、实际分批／回调不能冒充完整Q核与固定全路径事件。F047商环稳定化、环境稳定坐标、纤维为仿射空间、光滑和Zariski局部平凡必须分开；原稿一般规范线丛提升与Lean的非零不变倍数cD后取最高分量不是同一命题。正权E+反例不能推翻只针对非正权的障碍。两项来源B不变，全链仍未知。

Singular文档本身提示商环良定义和序语义；Sage所选路径已有源关系检查、双侧图理想、独立变量块和目标生成元逆像。未发现已读调用在做错误变量取消；这是所选路径范围，不能概括全库没有问题。既有精确图／代换工具在这个任务上允许胜出；不跑F047恒等式演示救回应用数量。

## 4. 实质路线比较与旧方法零假设

| 路线 | 消除的未知与成本 | 决策 |
| --- | --- | --- |
| 扩搜第三个坐标识别软件／更多相近API | 两已读路径已用精确证书；缺少新的目标语义，继续扩搜很可能重复 | 本周期停止；保留条件和方法 |
| 补F047全部历史／形式支持闭包 | 对M2有直接价值，但BCW403与Suslin重复TLS没有新访问条件，不能一直同路重试；24根仍缺 | 留给下一周期一个专门历史包，按关键根／替代原作排序，不声称短期全闭合 |
| 实现APP09401重加权 | 原卡片允许合成，但尚无具体源权重算法／收敛率；minimax松弛不一定是sigma下界约束内基线 | 本周期不跳过算法输入缺口，不临时改弱基线 |
| 实现APP14201有限域幂等元 | 具体全抛物代数、真正所需算子输出与强结构旧基线未准入；不能临时把原真实消费者假设改成任意随机矩阵 | 保留待定，不为数值便利伪造输入 |
| **恢复APP27601已有固定接收机合成审计** | 现有冻结前计划明确允许合成gamma/nu/p、2×2四Kraus与独立经典概率裁判，60秒／64MiB，原预测不要求先有真实硬件 | **选择WP117：先规格和隔离辅助意见，再执行；若不满足原假设／完整字段则不计卡片** |
| 立即再读低覆盖新稿 | 可增加广度，但继续把所有资源放到源码草稿会延迟待检卡片与历史闭合 | 本周期下一包后回到专门历史及低覆盖选择 |

APP27601的零假设是旧单次Holevo公式和诚实的固定X接收机经典互信息已经给出全部可计算差值，2026多次使用主张没有新增数值计算收益。这个零假设可以完全成立。检验只能说明同一个编码的Holevo与特定接收机可达互信息不同，以及错误标签能否被区分；不把固定X说成最优逐次POVM，不说得到硬件收益、有限码或验证了多次可加性。

## 5. 机会成本与明确行动

如果重新分配下一份资源，选一项已具备有限对象、独立计算路径且原本允许合成的待检卡片，优于第三个相近软件或另一个新稿标题。不会降低原有成功阈值、放宽同编码／同接收机比较或把已知差值充作新数学效益。参数和判据必须在目标输出前固定，保留所有端点、不利点与精度失败。

WP117先恢复APP27601的实际自然语言／形式参数约定与旧公式定位，冻结可执行规格、固定理性参数与资源判据，并让隔离怀疑者／辩护者审同包后再产生目标输出。同供应商角色只算辅助，不冒充第二家模型或人。只有完整实际检验闭环符合原卡片计数口径才更新13初检，不能预记14。若该卡片的目标本身仍不充分，说明原因并继续历史包，不改写为更容易通过的问题。

下一周期另留一个关键历史闭合包；其后比较低覆盖领域和F238剩余六稿。配置40%覆盖、30%验证、20%远联想／组合、10%质量及每三包复盘保持不变。不得把本次调整变成只做小型已知公式演示的长期策略。

## 6. 技术与数据回归

WP116全部5248旧规范行／旧边、阅读覆盖、已有科学源码／测试／语料／族报告与来源账本保持。全图8373节点24014关系，新增接口与软件证据不成为F047主定理证明输入；来源B、应用结果和工作流保持分离。完整JSON/GraphML对象、正负依赖传播、外键、来源散列、状态闸门与15归档267源码成员按最终质量收据核验。

本轮实际重放EXP221限定支持和EXP325不利的归档源码，完整raw／summary逐对象相等、无字段排除，均在原资源上限内；不是新增假设或为了匹配当前指纹。核心69和无math干净目录、临时源码清理、自有日志／代码压缩解压散列以最终闭包收据补记为准。两旧消费者许可按同固定提交复用，没有下载大型依赖或改写math。

## 7. 继续、停止与等待

继续WP117原有条件假设的严格合成审计准备；保留WP118关键历史与之后低覆盖选择。停止本周期F047消费者扩搜和所有同一失败网址的无新条件重试。不删除任何待定／不利线索，不作正式否定。真人分级、数学规格、第二供应商与试点仍等待真实资源，用户已要求后补，不再反复询问。整体active_incomplete。
'''
(r/'reports/retrospectives/041-from-interface-screening-to-conditional-tests.md').write_text(retro)
decision='''# 002：合成检验与真实消费者前提按具体假设区分

2026-10-27；全局复盘041。

纲领第八节允许公开基准、数据或明确标为合成的代表性实例。真实工程消费者与硬件不是所有本地初检的统一前置条件；只有具体卡片明确承诺实际调用／请求时，才须先满足该前提。不能把该前提临时删掉以便运行，也不能给本来允许合成的卡片额外添加商业用户要求。

选择现有APP27601的固定X接收机合成审计作为下一包，保留同编码、单位、端点、旧诚实经典概率基线及0.01 bit原阈值，先冻结规格／独立计算路径再运行。旧方法已足够、2026无增量允许成为结论。计算并不验证多次可加性、最优逐次测量、有限码或硬件。

不改变500候选／150真实分级／100实际初检／10不同闭环的总目标，人工闸门、第二供应商缺口、信用等级与三包复盘节奏保持。数值演示若没有对原假设的实际判别，不计完整卡片；禁止把这个选择扩大成已知公式凑数的通用策略。
'''
(r/'docs/decisions/002-conditional-synthetic-validation.md').write_text(decision)
# Update current entry paragraph,keeping historical reports unchanged.
p=r/'README.md';s=p.read_text();a=s.index('最新本地[F047复仿射');b=s.index('\n\n',a);s=s[:a]+'最新本地[F047映射消费者核查](reports/F047-map-consumer-audit.md)选读两固定项目三文件1687行，新增15规范20边；旧精确映射／源关系检查已覆盖对应任务，停止扩搜，无新候选或实验。[复盘041](reports/retrospectives/041-from-interface-screening-to-conditional-tests.md)恢复已有APP27601允许的严格合成接收机审计，先规格／辅助意见后执行；不把实际消费者前提强加给所有卡片，也不删改原本需要真实请求的条件。[F047当前稿草稿](reports/cancellation-F047-reading.md)17结果／12契约、2来源B／15C／全链未知保持。公开d48dd19仍为旧边界，本轮只本地保存。'+s[b:];s=s.replace('8353节点、23975关系；核心研究类型9104条','8373节点、24014关系；核心研究类型9123条');p.write_text(s)
p=r/'README.en.md';s=p.read_text();a=s.index('Local WP115 qualifies');b=s.index('\n\n',a);s=s[:a]+'Local WP116 audits two pinned polynomial-map projects:three files,159,523bytes,1,687read lines;15canonical records/20explicit edges. Existing exact graph/source-relation checks cover the selected task,so no new candidate or experiment is added. [Global review041](reports/retrospectives/041-from-interface-screening-to-conditional-tests.md) selects the existing APP27601 synthetic fixed-receiver audit,with executable preregistration and auxiliary isolated opinions before outputs. Real-consumer prerequisites remain binding where the actual card requires them;they are not added universally to cards already allowing representative synthetic tests. Totals remain61reading/56source drafts,46candidates/13checks;graph8,373nodes/24,014relations. Phase one remains incomplete;verified publicd48dd19 is the older boundary androutinepush isdisabled. See [F047 consumer evidence](reports/F047-map-consumer-audit.md).'+s[b:];p.write_text(s)
with (r/'PROGRESS.en.md').open('a') as out:out.write('\n\n## Local WP116 and global review041\n\nTwo pinned projects/three files/1,687selected lines qualify actual map-certificate paths;15canonical records/20explicit edges,with old source/science andreading coverage preserved. Exact old graph/source-relation checks suffice for the selected task. No newcandidate,initialcheck orscientificrun. Global041 selects the pre-existing APP27601 synthetic receiver-constraint audit,after executable preregistration andisolatedauxiliaryreview. Old honestreceiver probabilities may already supply all computational value;no hardware or2026theorem validation is implied. Next historical/coverage packages remain reserved. Full QA/storage results are separate;routine GitHub push disabled.\n')
print('Source-backed consumer report/global041/decision002 saved;QA closure pending,no targetF276outputs.')
