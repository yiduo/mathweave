from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib
w=Path(__file__).resolve().parent;repo='sagemath/sage';commit='601df58edafe95f68597b9dec61e0a75adca8983';path='src/sage/rings/morphism.pyx';url='https://raw.githubusercontent.com/'+repo+'/'+commit+'/'+path
with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave bounded source audit'}),timeout=35) as r:
 b=r.read(512*1024+1);assert len(b)<=512*1024
p=w/'sage-morphism.pyx';p.write_bytes(b);row={'project':repo,'path':path,'commit':commit,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'github_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'lines':len(b.splitlines()),'temporary_path':str(p),'retrieved_at':datetime.now(timezone.utc).isoformat(),'actual_read_ranges':[],'fallback_reason':'GitHubconnectorfetch_file transport error preserved;normalTLS primary raw URL fallback,not a source-content failure.'};(w/'sage-acquisition.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['actual_read_ranges']},ensure_ascii=False))
