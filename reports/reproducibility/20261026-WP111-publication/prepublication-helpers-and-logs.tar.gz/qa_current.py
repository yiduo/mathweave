from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,os,shutil,subprocess,sys,tarfile
root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP111-publication'
def git(*a): return subprocess.check_output(['git',*a],cwd=root)
assert not git('diff','1a8a2b9','--','data','experiments','src','tests','reports/families','reports/graph')
assert not git('-C','math','status','--porcelain')
assert git('-C','math','rev-parse','HEAD').decode().strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a'
assert 'Ran 69 tests' in (work/'core.log').read_text() and '\nOK\n' in (work/'core.log').read_text()
prior=json.loads((root/'reports/reproducibility/20261026-F300-paving/storage.json').read_text())
arc=root/'reports/reproducibility/20261026-F300-paving/helpers-and-logs.tar.gz'
assert hashlib.sha256(arc.read_bytes()).hexdigest()==prior['helpers_compressed_sha256']
assert hashlib.sha256(gzip.decompress(arc.read_bytes())).hexdigest()==prior['helpers_decompressed_sha256']
j=json.loads((root/'state/reading-progress/WP-112.json').read_text())
assert j['actual_lines_read']==983 and sum(x['actual_lines_read'] for x in j['source_files'])==983
clean=work/'clean';assert not clean.exists();clean.mkdir()
names=sorted(set(filter(None,git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0'))))
manifest=[]
for name in names:
    assert name.split('/')[0] not in {'math','.git','.venv','.cache','tmp'}
    src=root/name;assert src.is_file() and not src.is_symlink()
    dst=clean/name;dst.parent.mkdir(parents=True,exist_ok=True)
    raw=src.read_bytes();dst.write_bytes(raw);dst.chmod(src.stat().st_mode&0o777)
    h=hashlib.sha256(raw).hexdigest();assert hashlib.sha256(dst.read_bytes()).hexdigest()==h
    manifest.append({'path':name,'bytes':len(raw),'sha256':h})
assert not (clean/'math').exists()
with (work/'no-math-core.log').open('wb') as f:
    p=subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
r={'at':datetime.now(timezone.utc).isoformat(),'files':len(names),'bytes':sum(x['bytes'] for x in manifest),'official_math_paths':0,'copy_hashes_verified':True,'core_exit_code':p.returncode,'runtime':sys.version,'manifest':manifest}
raw=json.dumps(r,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
(out/'no-math-clean.json.gz').write_bytes(packed)
if p.returncode:
    print((work/'no-math-core.log').read_text()[-2500:]);sys.exit(p.returncode)
shutil.rmtree(clean)
members=['prepare_current.py','qa_current.py','core.log','no-math-core.log']
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for name in members:
        data=(work/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;t.addfile(info,io.BytesIO(data))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for name in members:assert t.extractfile(name).read()==(work/name).read_bytes()
(out/'prepublication-helpers-and-logs.tar.gz').write_bytes(packed)
quality={k:v for k,v in r.items() if k!='manifest'}
quality.update({'core_tests':69,'local_core_exit_code':0,'clean_directory_removed':True,'science_code_tests_corpus_exports_unchanged_from':'1a8a2b9','prior_WP111_archive_roundtrip_verified':True,'prior_full_graph_impact_archive_evidence':'reports/reproducibility/20261026-F300-paving/quality.json.gz','new_scientific_experiments':0,'incomplete_WP112_actual_lines':983,'helper_members_verified':len(members),'helper_compressed_sha256':hashlib.sha256(packed).hexdigest(),'helper_decompressed_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Publication checks,not new scientific replays,proof review or application validation.'})
(out/'quality.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(quality),flush=True)
