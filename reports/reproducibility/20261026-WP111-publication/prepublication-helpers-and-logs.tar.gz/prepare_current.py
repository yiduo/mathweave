from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile

root=Path('/Users/smzdm/projects/ai_paper')
work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP111-publication'
out.mkdir(exist_ok=True)
now=datetime.now(timezone.utc).isoformat()
def load(p): return json.loads((root/p).read_text())
def save(p,d): (root/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
j=load('state/reading-progress/WP-112.json')
assert j['actual_lines_read']==983 and j['source_files_downloaded']==11
download=json.loads(Path('/private/tmp/ai-paper-WP112/downloads.json').read_text())
for row in download['files']:
    source=Path('/private/tmp/ai-paper-WP112/sources')/row['project']/row['path']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==row['sha256']
assert len(download['files'])==11
# Preserve only our helper code and source metadata, not third-party source bodies.
files=sorted(p for p in Path('/private/tmp/ai-paper-WP112').iterdir() if p.is_file())
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for p in files:
        assert p.suffix in {'.py','.json'}
        raw=p.read_bytes(); info=tarfile.TarInfo(p.name); info.size=len(raw);info.mtime=0
        t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for p in files: assert t.extractfile(p.name).read()==p.read_bytes()
(out/'WP112-incomplete-helpers-and-metadata.tar.gz').write_bytes(packed)
save(str((out/'reading-storage.json').relative_to(root)),{'at':now,'members':len(files),'compressed_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'all_members_verified':True,'source_hashes_verified':11,'third_party_bodies_included':False,'temporary_work_retained_for_incomplete_task':True,'scope':'Incomplete WP112; source bodies retained temporarily to resume, no experiment or application credit.'})

summary='This owner-requested publication batch includes completed WP-111 / GEN108 and an explicitly unfinished [WP-112 reading checkpoint](state/reading-progress/WP-112.json). Both F300 manuscripts are read in full: 22 TeX files / 7,647 lines, 56 source-qualified C-grade bindings and 20 method contracts; complete dependency grades remain unknown. Totals are 59 families actually read, 54 current-source decomposition drafts, 8,091 graph nodes and 23,129 relations. WP-112 pins three software projects and has read 983 selected source/license lines; the other selected bodies remain unqualified. No new application check, numerical experiment, human review or second-provider review is added. The previous verified public snapshot is `453a806`; this batch requires its own push, remote readback and CI observation. See [F300 scope](reports/paving-F300-reading.md), [progress](PROGRESS.en.md) and [publication state](state/publication.json).'
p=root/'README.en.md';s=p.read_text();a=s.index('Current local progress includes WP-111:');b=s.index('\n\nRepository:',a);p.write_text(s[:a]+summary+s[b:])
p=root/'README.md';s=p.read_text();old='公开453a806已含GEN107、复盘039及当时WP111未完成4745行检查点，完整远端树、七文件回读与CI成功已核验；当前F300规范增量本地保存。';assert old in s
s=s.replace(old,'本次用户要求合并发布WP111／GEN108完整F300来源草稿及WP112未完成检查点：三项目固定版本、11文件已获取、983行选定源码／许可实际阅读，其他正文待核。上一公开453a806与其CI只覆盖旧快照；本批推送、回读及CI分别核验。')
intro='\n当前来源拆解见[F300两稿与谱压缩接口](reports/paving-F300-reading.md)：22TeX7647行全文、56来源C级绑定、20方法契约；完整依赖未知，未建立实用有限构造或应用收益。名称采用 **MathWeave（数学织网）**，仓库地址为 [github.com/yiduo/mathweave](https://github.com/yiduo/mathweave)。\n'
anchor='\n最新 [F239对称随机符号矩阵源码草稿]';assert anchor in s;s=s.replace(anchor,intro+anchor,1);p.write_text(s)
p=root/'PROGRESS.en.md';s=p.read_text();a=s.index('Snapshot:');b=s.index('\n\n| Measure',a)
s=s[:a]+'Snapshot: October 26, 2026, curated through WP-111 / GEN108, with unfinished WP-112 selected-source qualification. This explicit owner request prepares one publication batch. Global retrospective039 remains the latest review. The previous verified public `453a806` and its scoped CI cover the older snapshot; this batch requires separate remote verification. **Phase one remains incomplete.**'+s[b:]
a=s.index('Publication boundary:');b=s.index('\n\n',a)
s=s[:a]+'Publication boundary: this batch includes the completed F300 draft and the unfinished WP112 journal. The official `math/` directory, third-party source downloads and bulk local Git history remain excluded. Post-push receipts stay local until the next meaningful batch, avoiding a second push solely for metadata.'+s[b:]
s+='\n\n## WP112: unfinished consumer qualification\n\nThree pinned first-party projects (PETSc, Ginkgo and TeNPy) supply 11 selected source/license files, totaling 202,494 downloaded bytes. Actual reading covers 983 lines: all three licenses, the PETSc Helmholtz caller and selected deflation implementation ranges. The selected Ginkgo and TeNPy code bodies remain unread apart from locators, and their consumer qualification is pending. These provisional notes add no canonical records, candidate, experiment or application-check credit. Resume at the pinned Ginkgo Jacobi API, generation/application and caller, then TeNPy truncation/TEBD and parent error handling. The [journal](state/reading-progress/WP-112.json) records exact ranges, hashes, pins, acquisition failures and limits.\n'
p.write_text(s)
p=load('state/publication.json');assert p['verified_commit']=='453a806aecb454c3581726a8e949e439cd3bdb66'
p['pending_batch']={'requested_at':now,'status':'prepared_not_pushed','scope':'Completed WP111 GEN108 and unfinished WP112983-line source/license journal; latest global039 retained','official_math_excluded':True,'previous_public_commit':p['verified_commit'],'qa_directory':str(out.relative_to(root)),'new_scientific_experiments':0}
p['local_progress_after_verified_snapshot']='WP111 GEN108 complete;WP112 in progress,983 actual source/license lines only. This explicit owner-requested batch is pending push/readback.'
save('state/publication.json',p)
c=load('state/checkpoint.json');c['saved_at']=now
c['publication_work'].update({'status':'preparing_owner_requested_WP111_batch','current_local_research_not_yet_pushed':p['local_progress_after_verified_snapshot'],'prepush_audit':str((out/'final-audit.json.gz').relative_to(root))})
c['recovery_commands'][4]='Owner-requested WP111/unfinishedWP112 batch in preparation;see state/publication.json for actual verified public boundary.'
c['previous_goal_turn_classification']={'classification':'progress','evidence':'Prior research WP111 complete and WP112 actual983-line checkpoint preserved. Current explicit owner publication request takes priority;no additional reading or application credit.'}
save('state/checkpoint.json',c)
text='用户再次要求先把当前进展提交GitHub。沿用易传播的MathWeave（数学织网），含义为把数学成果、历史方法和可检验应用织成证据网络。仓库及origin为https://github.com/yiduo/mathweave，仓库ID1429150108，已完成改名而无需重复建库。本批包含WP111 GEN108以及WP112未完成983行选读检查点；不增加应用／人审／第二供应商信用。官方math、第三方下载正文及批量本地历史排除。检查后一次推送；远端回读和CI另行记录，后验收据本地保存以减少频繁更新。'
for name in ['state/status.md','docs/roadmap.md','docs/publication.md']:
    with (root/name).open('a') as f:f.write('\n\n## 2026-10-26 当前进展合并发布：WP111与WP112检查点\n\n'+text+'\n')
print(json.dumps({'prepared':True,'scope':'WP111 and unfinishedWP112','source_hashes_verified':11,'own_helper_members':len(files),'third_party_bodies_included':False}))
