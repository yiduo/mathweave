from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request

work=Path(__file__).resolve().parent;dest=work/'sources';dest.mkdir(exist_ok=True)
projects={
'petsc':{'repo':'petsc/petsc','commit':'ef2932a3562721ceda7312b5bddd3fabb82cd7fa','branch':'main','paths':['LICENSE','src/ksp/pc/impls/deflation/deflation.c','src/ksp/ksp/tutorials/ex11.c']},
'ginkgo':{'repo':'ginkgo-project/ginkgo','commit':'e008bfdee4fdda56d4defa63443df0ff871e6be7','branch':'develop','paths':['LICENSE','include/ginkgo/core/preconditioner/jacobi.hpp','core/preconditioner/jacobi.cpp','examples/preconditioned-solver/preconditioned-solver.cpp']},
'tenpy':{'repo':'tenpy/tenpy','commit':'8444a0320e0775b3ded0be974d509842fe3ba541','branch':'main','paths':['LICENSE','tenpy/linalg/truncation.py','tenpy/algorithms/tebd.py']}}
manifest={'at':datetime.now(timezone.utc).isoformat(),'work_package':'WP-112','resource_limits':{'projects':3,'source_license_files':12,'new_body_bytes':2*1024*1024},'pins':projects,'files':[],'attempts':[],'downloaded_body_bytes':0,'discovery_failures':[{'channel':'web.open','scope':'Ginkgoexamples andTeNPyalgorithms pinnedcommitdirectorypages','result':'cache miss;not sourceabsence'},{'channel':'GitHubMCPfetch','scope':'Ginkgoexamplesdirectoryfirstcall','result':'transport error'},{'channel':'anonymousAPI','scope':'samefixeddirectory','result':'HTTP403rate limit;authenticatedconnectorretry succeeded'}]}
for project,meta in projects.items():
    for path in meta['paths']:
        url='https://raw.githubusercontent.com/'+meta['repo']+'/'+meta['commit']+'/'+path
        attempt={'project':project,'repo':meta['repo'],'commit':meta['commit'],'path':path,'url':url,'at':datetime.now(timezone.utc).isoformat()}
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave bounded primary source inspection'}),timeout=30) as r:
                remaining=manifest['resource_limits']['new_body_bytes']-manifest['downloaded_body_bytes']
                declared=r.headers.get('Content-Length')
                if declared and int(declared)>remaining:raise RuntimeError('exceeds registered remaining source-body budget')
                raw=r.read(remaining);content_type=r.headers.get('Content-Type')
            manifest['downloaded_body_bytes']+=len(raw)
            text=raw.decode('utf-8');assert '<!DOCTYPE html' not in text[:100] and '<html' not in text[:100]
            target=dest/project/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            row={**attempt,'bytes':len(raw),'lines':len(text.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'content_type':content_type,'temporary_path':str(target),'actual_read_ranges':[],'state':'downloaded_not_yet_read'}
            manifest['files'].append(row);attempt['state']='downloaded';print(json.dumps({k:row[k] for k in ['project','path','bytes','lines','sha256']},ensure_ascii=False),flush=True)
        except Exception as e:
            attempt['state']='failed';attempt['error_type']=type(e).__name__;attempt['error']=str(e)[:300];print(json.dumps(attempt),flush=True)
        manifest['attempts'].append(attempt)
        (work/'downloads.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
assert manifest['downloaded_body_bytes']<=2*1024*1024 and len(manifest['files'])<=12
