from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
work=Path(__file__).resolve().parent;payload=json.loads(Path(sys.argv[1]).read_text());m=json.loads((work/'downloads.json').read_text());jp=Path('state/reading-progress/WP-112.json');j=json.loads(jp.read_text());now=datetime.now(timezone.utc).isoformat()
for item in payload['files']:
    row=next(x for x in m['files'] if x['project']==item['project'] and x['path']==item['path']);raw=Path(row['temporary_path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
    old=next((x for x in j['source_files'] if x['project']==row['project'] and x['path']==row['path']),None)
    ranges=(old or row).get('actual_read_ranges',[])+item['ranges'];covered=set()
    for a,b in ranges:assert 1<=a<=b<=row['lines'];covered.update(range(a,b+1))
    merged=[]
    for line in sorted(covered):
        if merged and merged[-1][1]+1==line:merged[-1][1]=line
        else:merged.append([line,line])
    current={k:v for k,v in row.items() if k not in ['temporary_path','state','actual_read_ranges']};current.update({'actual_read_ranges':merged,'actual_lines_read':len(covered),'full_file_read':len(covered)==row['lines'],'state':'selected_actual_source_read_not_runtime_execution'})
    if old:j['source_files'].remove(old)
    j['source_files'].append(current)
j['pins']=m['pins'];j['new_source_body_bytes']=m['downloaded_body_bytes'];j['source_files_downloaded']=len(m['files']);j['actual_lines_read']=sum(x['actual_lines_read'] for x in j['source_files']);j['updated_at']=now;j.setdefault('batches',[]).append({'at':now,'files':payload['files'],'notes':payload['notes']});j.setdefault('qualified_notes',[]).extend(payload['notes']);j['source_acquisition_failures']=m['discovery_failures'];j['next_action']=payload['next'];jp.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
cp=Path('state/checkpoint.json');c=json.loads(cp.read_text());c['saved_at']=now;c['recovery_commands'][2]=payload['next']
for key in ['active_work_package','next_work_package']:c[key]['source_reading_progress']={'projects_pinned':3,'files_downloaded':len(m['files']),'body_bytes':m['downloaded_body_bytes'],'selected_lines_actually_read':j['actual_lines_read'],'new_application_checks':0};c[key]['next_action']=payload['next']
cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');bp=Path('state/backlog.json');b=json.loads(bp.read_text());task=next(x for x in b['tasks'] if x['id']=='WP-112');task['source_reading_progress']=c['active_work_package']['source_reading_progress'];task['next_action']=payload['next'];b['updated_at']=now;bp.write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'downloaded_files':len(m['files']),'new_body_bytes':m['downloaded_body_bytes'],'actual_selected_lines':j['actual_lines_read'],'application_credit':0}))
