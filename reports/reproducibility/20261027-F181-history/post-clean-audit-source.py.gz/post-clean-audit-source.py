from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess
r=Path.cwd();out=r/'reports/reproducibility/20261027-F181-history';now=datetime.now(timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
c=json.loads(gzip.decompress((out/'clean-check.json.gz').read_bytes()));changed=[]
allowed={'docs/roadmap.md','reports/F181-historical-scope-followup.md','reports/reproducibility/20261027-F181-history/partial-checkpoint.json','reports/retrospectives/045-old-method-sufficiency-and-history-scope.md','state/backlog.json','state/checkpoint.json','state/status.md'}
for x in c['manifest']:
 if sha((r/x['path']).read_bytes())!=x['sha256']:changed.append(x['path'])
assert set(changed)==allowed
storage=json.loads((out/'storage.json').read_text());z=(out/'helpers-and-logs.tar.gz').read_bytes();assert sha(z)==storage['helpers_archive_sha256']
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z))) as t:
 assert set(t.getnames())==set(storage['members'])
 for name,meta in storage['members'].items():assert sha(t.extractfile(name).read())==meta['sha256']
assert not Path(storage['temporary_root_removed']).exists()
cp=r/'state/checkpoint.json';p=json.loads(cp.read_text());p.setdefault('recovery_observation',{})['WP128_final_boundary']={'at':now,'project_process_query':'ps -Ao pid,ppid,etime,command filtered for WP128/project scripts,replay andpreview8768;only queryself matched','running_project_processes':[],'all_quality_handles_terminal':True,'replay_handles_terminal':True,'temporary_root_removed':True,'disk_available_observed':'31GiB;system-wide,not attributed to package','math_commit':subprocess.check_output(['git','-C','math','rev-parse','HEAD'],text=True).strip()};cp.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
assert p['metrics']==json.loads((r/'reports/metrics.json').read_text()) and p['work_packages_since_last_retrospective']==0
b=json.loads((r/'state/backlog.json').read_text());assert next(x for x in b['tasks'] if x['id']=='WP-128')['status']=='complete';assert next(x for x in b['tasks'] if x['id']=='WP-129')==p['active_work_package']
assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],text=True).strip()=='1581d4cbdd69a0faf34b2089614fe2a814316a6a' and not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':now,'post_clean_changed_files':changed,'all_changes_are_declared_closure_or_planning_metadata':True,'scientific_and_canonical_inputs_unchanged_after_clean':True,'final_helper_archive_reopened_all_member_hashes_equal':True,'state_metrics_backlog_next_selection_consistent':True,'last_completed':'WP-128','next':'WP-129','global_retrospective':'045','next_body_read_credit':0,'goal':'active_incomplete','process_handles_terminal':True,'official_math_unchanged':True,'github_write':False,'scope':'Later closure metadata was not claimed to be part of the earlier clean copy;all scientific and canonical inputs identical.'}
(out/'post-clean-metadata-audit.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
source=Path(__file__).read_bytes();packed=gzip.compress(source,mtime=0);assert gzip.decompress(packed)==source;(out/'post-clean-audit-source.py.gz').write_bytes(packed)
print(json.dumps(receipt));Path(__file__).unlink()
