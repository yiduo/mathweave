from pathlib import Path
from datetime import datetime,timezone
import urllib.request,subprocess,json,hashlib
w=Path(__file__).parent;rows=[]
urls={'Krivelevich2019':'https://arxiv.org/pdf/1609.06851v2'}
for key,url in urls.items():
 x={'key':key,'requested_url':url,'at':datetime.now(timezone.utc).isoformat(),'reason':'AuthorPDFnormalTLSremoteclosed;useexactobservedarXivv2primaryversion.'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave source-scope research'}),timeout=30) as f:
   b=f.read(3*1024**2+1);assert len(b)<=3*1024**2 and b.startswith(b'%PDF');x.update(status=f.status,final_url=f.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  p=w/(key+'.pdf');p.write_bytes(b);t=w/(key+'.txt');z=subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(p),str(t)],capture_output=True,text=True);x.update(conversion_exit=z.returncode,conversion_stderr=z.stderr)
  if z.returncode==0:
   b=t.read_bytes();x.update(text_bytes=len(b),text_sha256=hashlib.sha256(b).hexdigest(),text_lines=len(b.decode().splitlines()))
 except Exception as e:x['failure']=repr(e)
 rows.append(x)
(w/'alternative-fetch-receipt.json').write_text(json.dumps({'rows':rows},indent=2)+'\n');print(json.dumps(rows))
