from pathlib import Path
from datetime import datetime,timezone
import json,urllib.request,subprocess,hashlib
w=Path(__file__).parent;cap=3*1024**2;total=0;rows=[]
urls={'Krivelevich2019':'https://www.math.tau.ac.il/~krivelev/long_cycles_expanders.pdf','BKS2012':'https://arxiv.org/pdf/1009.3721v1','KKS2015':'https://people.math.ethz.ch/~sudakovb/cycle-packing-random-graphs.pdf','AABC2025':'https://arxiv.org/pdf/2509.01901v2'}
for key,url in urls.items():
 row={'key':key,'requested_url':url,'at':datetime.now(timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'MathWeave source-scope research'})
  with urllib.request.urlopen(req,timeout=30) as f:
   b=f.read(cap+1);assert len(b)<=cap and total+len(b)<=16*1024**2 and b.startswith(b'%PDF');total+=len(b);row.update(status=f.status,final_url=f.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  p=w/(key+'.pdf');t=w/(key+'.txt');p.write_bytes(b);x=subprocess.run(['/opt/homebrew/bin/pdftotext','-layout',str(p),str(t)],capture_output=True,text=True);row.update(conversion_exit=x.returncode,conversion_stderr=x.stderr)
  if x.returncode==0:
   text=t.read_bytes();row.update(text_bytes=len(text),text_sha256=hashlib.sha256(text).hexdigest(),text_lines=len(text.decode().splitlines()))
 except Exception as e:row['failure']=repr(e)
 rows.append(row);(w/'fetch-receipt.json').write_text(json.dumps({'rows':rows,'total_pdf_bytes':total,'normal_TLS':True,'bodies_for_temporary_text_analysis_only':True},ensure_ascii=False,indent=2)+'\n');print(json.dumps(row),flush=True)
