from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,re,hashlib
w=Path(__file__).parent;rows=[]
for key,url in [('Haxell','https://math.uwaterloo.ca/~pehaxell/'),('Lovasz','https://web.cs.elte.hu/~lovasz/'),('Pyber','https://www.renyi.hu/~pyber/')]:
 x={'key':key,'url':url,'at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave source-scope research'}),timeout=20) as f:
   b=f.read(200001);assert len(b)<=200000;x.update(status=f.status,final_url=f.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest());t=b.decode('utf-8','replace');links=re.findall(r'<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',t,re.I|re.S);x['links']=[{'href':u,'label':re.sub('<[^>]+>','',label).strip()[:160]} for u,label in links if any(k in (u+' '+label).lower() for k in ['publ','paper','hall','cover','gallai'])];(w/(key+'-home.html')).write_bytes(b)
 except Exception as e:x['failure']=repr(e)
 rows.append(x);print(json.dumps(x),flush=True)
(w/'primary-discovery.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')
