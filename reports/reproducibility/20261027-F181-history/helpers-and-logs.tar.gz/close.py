from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil,subprocess,tarfile,io,re,os
r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261027-F181-history';now=datetime.now(timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
q=json.loads(gzip.decompress((w/'quality.json.gz').read_bytes()));c=json.loads(gzip.decompress((w/'clean-check.json.gz').read_bytes()));s=json.loads((w/'curation-summary.json').read_text());m=json.loads((r/'reports/metrics.json').read_text())
assert c['core_exit_code']==0 and not (w/'clean').exists()
for log in ['core.log','clean-core.log']:
 text=(w/log).read_text();assert re.search(r'Ran 95 tests in ',text) and '\nOK\n' in text and 'skipped=' not in text and 'Traceback' not in text
for item in c['manifest']:assert sha((r/item['path']).read_bytes())==item['sha256'],item['path']
assert len(q['impact_cases'])==181 and len(q['alternative_route_cases'])==2 and len(q['scientific_archives'])==18 and q['source_archive_members']==378
assert m['nodes']==8874 and m['edges']==26094 and m['candidate_connections']==47 and m['externally_checked_cards']==15
for p in ['quality.json.gz','clean-check.json.gz']:shutil.copyfile(w/p,out/p)
closure={'at':now,'work_package':'WP-128','generation':'GEN-20261027-125','base_commit':s['base_commit'],'overall_status':'active_incomplete','new_selected_original_scopes':4,'current_selected_original_scopes':8,'historical_root_count':11,'partial_original_domain_scopes':1,'remaining_unqualified_roots':['LIT-181-AH2000','LIT-181-LOVASZ1968','LIT-181-PYBER1985'],'full_original_proof_or_lineage_acceptance':False,'new_records':3,'new_explicit_edges':8,'versioned_old_records':9,'old_rows_byte_preserved':5615,'protected_files':q['protected_files'],'draft_title_corrections_preserved':2,'scientific_code_and_prior_experiments_unchanged':True,'core_tests':95,'clean_core_tests':95,'skipped_tests':0,'single_seed_impact_cases':181,'multi_seed_cases':2,'full_JSON_GraphML_objects_equal':True,'scientific_archives':18,'source_archive_members':378,'strict_replays':q['strict_replays'],'graph_nodes':8874,'graph_edges':26094,'core_citations':9845,'full_canonical_citations':9858,'source_artifacts':2090,'clean_files':c['files'],'clean_bytes':c['bytes'],'clean_copy_all_original_files_still_identical':True,'clean_directory_removed':True,'new_candidates':0,'new_initial_checks':0,'new_distinct_hypotheses':0,'source_grade_promotions':0,'retrospective':'reports/retrospectives/045-old-method-sufficiency-and-history-scope.md','github_push':False,'metadata_after_clean':['Finalclosure/storage/status/checkpoint/backlog/publication metadata','Finalclosure paragraphs in source-scope report andretrospective','Roadmap append'],'scope':'Four selected historical original scopes and static stronger old-cycle criterion;not new mathematics,wholeCn proof,application efficacy,full lineage,human or provider acceptance.'};save(out/'closure.json',closure);save(w/'closure.json',closure)
paragraph=f"WP128与全局045最终闭包（{now}）：新增四原作选段，F181为8/11选定原作；另Lovasz原作仅术语，AH/Pyber正文与Lovasz精确界、递归历史仍缺。旧局部扩张准则已足够且更强，不宣称新数学或完整Cn分解/运行时间。GEN125新增3规范8显式边，9旧记录版本化、5615旧行与{q['protected_files']}保护文件保持；两初版标题纠正留档。完整图8874/26094、9845核心来源、9858全审计/2090来源制品，181单种子2多种子/完整导出，18科学归档378源码，本地95/无math干净95无跳过通过；F149支持与F325不利代表完整raw/summary源码重放、原资源通过。原作临时制品与自有辅助均按本包storage收据核散列压缩/清理。64阅读59草稿、47候选15初检15不同7限定支持8不利、另1诊断保持；完整族/历史/人审等仍0。计数归零，下一WP129四篇F271实际源文预算，正文阅读信用0，不推GitHub。"
for p in ['reports/F181-historical-scope-followup.md',closure['retrospective'],'docs/roadmap.md']:
 with (r/p).open('a') as f:f.write('\n\n'+paragraph+'\n')
status=r/'state/status.md';tail=status.read_text().split('以下为历次工作记录，数字保留为当时快照。',1)[1]
status.write_text(f'''# 当前状态

更新时间：{now}。第一阶段仍未完成。

固定上游1581d4cbdd69a0faf34b2089614fe2a814316a6a，372族/719当前手稿；math只读且未重新部署。规范图8874节点26094关系；64阅读族/59当前稿草稿，47候选/15合格初检/15不同验证（7限定支持8不利），另1诊断。完整族/历史/人审/第二供应商/试点仍0；不能以15项验证数量替代100初检/500候选/150人审。

WP128补F181四部原作选段，当前8/11；Lovasz术语原作可读但精确公式转录缺口，AH/Pyber正文未核实。BKS有向路径、KKS随机高概率、AABC覆盖/分解/2-正则区别入图；旧Krivelevich准则在源扩张接口上更强，保留为历史基线，不计新数学/运行时间/应用收益。

3新规范8显式边、9旧记录版本化；5615旧行和{q['protected_files']}保护文件保持。181单种子2多种子、完整导出与来源、18科学归档378源码、本地95及无math干净95无跳过通过。F149限定支持和F325不利代表完整raw/summary源码重放及原资源通过；没有新数值假设运行。原作临时文件核散列清理，自有辅助/失败/日志压缩回解核验。最终证据reports/reproducibility/20261027-F181-history/closure.json。

全局045完成，实质包计数归零。下一WP129读F271四当前稿，原始清单46TeX/Bib14199行，正文信用0；先核实际模型、量词、极限次序和旧基线，不把有限格模拟当自发磁化或已发现应用。真人和第二供应商待后补，不反复询问。不例行推GitHub；最后核验公开快照仍d48dd19。

以下为历次工作记录，数字保留为当时快照。'''+tail+'\n\n'+paragraph+'\n')
wp=json.loads((r/'state/selection-WP129.json').read_text());bp=r/'state/backlog.json';b=json.loads(bp.read_text());item=next(x for x in b['tasks'] if x['id']=='WP-128');item.update(status='complete',completed_at=now,execution_state='selected_original_scopes_graph_core_clean_replays_storage_closed',new_selected_original_scopes=4,remaining_original_root_gaps=3,new_initial_checks=0,new_candidates=0,evidence=['data/provenance/readings/F-181-history-WP128.json','reports/F181-historical-scope-followup.md',str((out/'closure.json').relative_to(r))],result='8of11selectedoriginals;Lovaszdomainpartial/exactboundgap,AH/Pyberbodiesunread. Oldlongcyclecriterionstronger;no newmath/application credit. 181single2multi/fullobjects18archives378members95core95clean/149+325strictrepresentativespass.',next_action=wp['next_action']);assert not any(x['id']=='WP-129' for x in b['tasks']);b['tasks'].append(wp);b['updated_at']=now;save(bp,b)
cp=r/'state/checkpoint.json';checkpoint=json.loads(cp.read_text());checkpoint.update(saved_at=now,updated_at=now,overall_status='active_incomplete',latest_retrospective=closure['retrospective'],work_packages_since_last_retrospective=0,retrospective_due_after=3,metrics=m,running_research_experiments=[],running_quality_checks=[],active_work_package=wp,next_work_package=wp,last_completed_work_package='WP-128',last_quality_evidence=str((out/'closure.json').relative_to(r)),storage_receipt=str((out/'storage.json').relative_to(r)),current_goal_turn_classification={'previous_turn':'no_progress_status_only','this_turn':'progress','evidence':'Four actual selected originals canonicalized,fullquality/core/clean/replays andglobal045closed','overall_goal':'active_incomplete'})
if 'WP-128' not in checkpoint['completed_work_packages']:checkpoint['completed_work_packages'].append('WP-128')
checkpoint['resume_commands']=['Read goal objective,root charter,docs/roadmap.md,state/status.md,state/checkpoint.json,state/backlog.json andglobal045;check disk andactual handles.','Read state/selection-WP129.json and reports/reproducibility/20261027-F181-history/global-coverage-and-selection.json;four F271 current bodies notyetread.','Use existing Python3.12.14 and Node PATH for scripts/check.py;F076strict replay only verified3.14.8,known3.12failure preserved.','Do not repeat prior F14972case target or denied primary routes as new work;do not push GitHub perpackage.']
checkpoint['must_not_repeat']+=['WP128 selected originals8/11 do not complete F181history:AH/Pyberbody andLovaszexactnumericformula/PDFhash remainunqualified. Do not repeat same403/abstractredirect or infer originalbound from secondary restatement.','WP128 auxiliary preservation check initially assumed every reading_coverage value was a list;actual legacy values are mixed dict/list. Failed helper/log preserved;canonical facts unchanged.']
checkpoint['publication_work']['current_local_research_not_yet_pushed']='WP113throughWP128localonly;F1818of11selectedoriginalscopes pluspartialLovasz/gaps andglobal045. No GitHub write.';save(cp,checkpoint)
# Pin all third-party bytes before removing temporary originals. No full texts are republished.
ledger=json.loads((r/'data/provenance/readings/F-181-history-WP128.json').read_text());third=[]
for x in ledger['rows']:
 for ext,key in [('.pdf','sha256'),('.txt','text_sha256')]:
  p=w/(x['key']+ext);data=p.read_bytes();assert sha(data)==x[key];third.append({'name':p.name,'bytes':len(data),'sha256':sha(data),'removed_after_hash_verification':True})
p=w/'Pyber-home.html';data=p.read_bytes();assert sha(data)=='be3da9334791002bf479b8a226eb9ee53170ac699973a17e2d628017dbf26c52';third.append({'name':p.name,'bytes':len(data),'sha256':sha(data),'removed_after_hash_verification':True})
save(w/'third-party-cleanup-receipt.json',{'at':now,'files':third,'total_bytes':sum(x['bytes'] for x in third),'republication':False})
thirdnames={x['name'] for x in third};members={p.name:p.read_bytes() for p in w.iterdir() if p.is_file() and p.name not in thirdnames};buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as t:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;t.addfile(info,io.BytesIO(data))
raw=buffer.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(z))) as t:
 assert set(t.getnames())==set(members)
 for name,data in members.items():assert sha(t.extractfile(name).read())==sha(data)
(out/'helpers-and-logs.tar.gz').write_bytes(z)
storage={'at':now,'helpers_archive_sha256':sha(z),'archive_bytes':len(z),'uncompressed_tar_bytes':len(raw),'verified_member_count':len(members),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in members.items()},'all_members_roundtrip_verified':True,'third_party_files_hash_verified_before_removal':third,'third_party_bytes_removed':sum(x['bytes'] for x in third),'clean_directory_removed':True,'clean_copy_bytes_removed':c['bytes'],'temporary_root_removed':str(w),'third_party_full_text_republished':False,'numerical_source_archives_verified':18,'source_members_verified':378,'scope':'Third-party original/text files were hashed then removed,not republished. Own helpers,failed drafts,logs and receipts compressed and verified member-by-member. No raw corpus duplication or dependency installation.'};save(out/'storage.json',storage)
save(out/'partial-checkpoint.json',{'at':now,'execution':'closed','closure':'reports/reproducibility/20261027-F181-history/closure.json','next':'state/selection-WP129.json','overall_status':'active_incomplete'})
shutil.rmtree(w);assert not w.exists()
print(json.dumps({'closure':str((out/'closure.json').relative_to(r)),'clean_files':c['files'],'clean_bytes':c['bytes'],'helper_members':len(members),'helper_archive_bytes':len(z),'third_party_bytes_removed':storage['third_party_bytes_removed'],'temporary_root_removed':True,'next':'WP-129','goal':'active_incomplete'}))
