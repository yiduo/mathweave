from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;s=json.loads((w/'curation-summary.json').read_text());base=s['base_commit']
def old(p):return subprocess.check_output(['git','show',base+':'+p])
a={json.loads(x)['id']:x for x in old('data/graph/nodes.jsonl').splitlines(keepends=True)};b={json.loads(x)['id']:x for x in (r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True)};changed=set(s['versioned_old_record_ids'])
assert len(a)==5624 and len(b)==5627 and len(changed)==9
for id,raw in a.items():
 if id not in changed:assert b[id]==raw,id
archive=json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-125-before.json.gz').read_bytes()));assert {x['id']:x for x in archive['records']}=={id:json.loads(a[id]) for id in changed}
for id in changed:
 n=json.loads(b[id]);assert n['version']==json.loads(a[id])['version']+(2 if id in s['draft_title_corrections'] else 1)
 assert n['properties'].get('credibility','unknown')==json.loads(a[id])['properties'].get('credibility','unknown')
 if id.startswith('CLM-'):assert n['properties']['statement_tex']==json.loads(a[id])['properties']['statement_tex']
ea=old('data/graph/edges.jsonl');eb=(r/'data/graph/edges.jsonl').read_bytes();assert eb.startswith(ea) and len(eb[len(ea):].splitlines())==8
ca=old('data/graph/reading_coverage.json');assert gzip.decompress((r/'data/graph/history/GEN-20261027-125-reading-coverage-before.json.gz').read_bytes())==ca
cova=json.loads(ca);covb=json.loads((r/'data/graph/reading_coverage.json').read_text());assert cova['source_decomposition_drafts']==covb['source_decomposition_drafts'] and set(cova['partially_read_families'])==set(covb['partially_read_families'])
for id,notes in cova['partially_read_families'].items():
 assert (covb['partially_read_families'][id][:len(notes)]==notes if id=='F-181' else covb['partially_read_families'][id]==notes)
preserved=[]
for p in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if p.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','reports/cards/','data/provenance/readings/')) and p!='reports/families/F-181.md':assert (r/p).read_bytes()==old(p),p;preserved.append(p)
metrics=validate(r);generated=json.loads((r/'reports/metrics.json').read_text());expected={'partial_reading_families':64,'source_decomposition_drafts':59,'candidate_connections':47,'externally_checked_cards':15,'distinct_validation_hypotheses':15,'effective_leads':7,'diagnostic_executions_not_initial_checks':1}
assert all(generated[k]==v for k,v in expected.items())
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
export(r);nodes,edges=load(r);j=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in j['nodes']}==nodes and j['edges']==edges
ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes())).find('g:graph',ns);xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F149-execution/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
newcases=[('LIT-181-KRIVELEVICH2019','PART-181-OLD-EXPANSION-CRITERION',True),('LIT-181-KRIVELEVICH2019','EXPL-181-HISTORY-SCOPES-WP128',True),('LIT-181-KRIVELEVICH2019','CLM-181-THM-MAIN',False),('LIT-181-KRIVELEVICH2019','CLM-181-LEM-SPLIT-VERTEX-EXPANSION',False),('LIT-181-BKS2012','EXPL-181-HISTORY-SCOPES-WP128',True),('LIT-181-BKS2012','CLM-181-LEM-SPLIT-VERTEX-EXPANSION',False),('LIT-181-AABC2025','EXPL-181-HISTORY-SCOPES-WP128',True),('LIT-181-AABC2025','CLM-181-THM-MAIN',False),('LIT-181-LOVASZ1968','CLM-181-THM-LOVASZ',True),('LIT-181-AH2000','CLM-181-THM-AHARONI-HAXELL',True)]
for seed,target,required in newcases:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==required,(seed,target)
 impacts.append({'seed':seed,'required_affected' if required else 'must_not_propagate_to':target,'confirmed':True,'scope':'Historical comparison versus mandatory selected source input;review routing only'})
ors=[]
for v in previous['alternative_route_cases']:assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'all_hashes':True})
assert len(archives)==18 and members==378
replays={}
for name in ['F149','F325']:
 x=json.loads((w/('replay-'+name+'.json')).read_text());assert all(x['deterministic_outputs_match'].values()) and x['replay_resource_envelope_met'] and x['comparison_scope']=='Exact complete JSON payloads; no fields excluded';replays[name]=x
ledger=json.loads((r/'data/provenance/readings/F-181-history-WP128.json').read_text());analysis=nodes['ANALYSIS-F-181']['properties'];assert len(analysis['historical_verified_keys'])==8 and len(analysis['unread_or_unqualified_original_root_ids'])==3 and not analysis['historical_lineage_complete'] and not analysis['full_family_complete']
assert all(x['selected_scope_qualified'] for x in ledger['rows']) and not ledger['partial_original']['selected_scope_qualified'] and ledger['partial_original']['raw_PDF_sha256'] is None
assert all(not x['original_body_checked'] for x in ledger['unqualified_originals'])
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_preserved':len(a)-len(changed),'versioned_old_records':len(changed),'draft_title_corrections':s['draft_title_corrections'],'new_records':3,'new_edges':8,'protected_files':len(preserved),'scientific_source_code_unchanged':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'scientific_archives':archives,'source_archive_members':members,'strict_replays':replays,'historical_selected_originals':8,'partial_originals':1,'unqualified_roots':3,'new_initial_checks':0,'new_distinct_hypotheses':0,'new_candidates':0,'source_grade_promotions':0,'scope':'Four selected original history scopes and static old-method inclusion;not complete proof,lineage,family,application or human/provider acceptance.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics','strict_replays']},ensure_ascii=False))
