from pathlib import Path
from datetime import datetime, timezone
import copy, gzip, hashlib, json, subprocess

r=Path.cwd(); w=Path(__file__).parent
now=datetime.now(timezone.utc).isoformat(); gen='GEN-20261027-125'
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base.startswith('c9259ab')
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def packed(p,b):
    z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z)
def source(p,loc):return {'path':p,'sha256':sha((r/p).read_bytes()),'commit':None,'locator':loc}
up='math/preprints/A-linear-cycle-and-edge-decomposition-of-every-graph-September-24-2026/build/'
root_receipt='data/provenance/readings/F-181-history-WP128.json'
ranges={'BKS2012':[[1,9],[92,110],[281,346]],'KKS2015':[[34,173]],'AABC2025':[[1,19],[20,186],[437,470]],'Krivelevich2019':[[1,80],[225,278],[324,343]]}
versions={
 'BKS2012':'arXiv1009.3721v1, footer20Sep2010; generated title23Oct2018; cited journal2012. No byte-equivalence to journal asserted.',
 'KKS2015':'Author-hosted published CPC(2015)24:857-872, DOI10.1017/S0963548314000844; online29Dec2014/copyright2014 separately observed.',
 'AABC2025':'arXiv2509.01901v2,7Sep2025; only this version read.',
 'Krivelevich2019':'arXiv1609.06851v2,footer18May2017; generated title5Aug2018; bibliography journal2019. AuthorPDF disconnected; journal/author/arXiv bytes not equated.'}
findings={
 'BKS2012':{'locator':'arXivv1 pp7-8 Claim2.2/Lemma2.3, actual statement and selected full proof; model definitions pp2-3',
  'input':'Directed bipartite graph with equal parts t; every A,B in opposite parts of size k has an arc in each direction.',
  'output':'Directed path of edge length at least2t-4k+3; DFS stack contains at least2t-4k+4 vertices.',
  'scope':'DFS S/T equality and alternating even stack give balanced opposite intersections; no S-to-T arc bounds each by k-1. Claim2.2 supplies one-direction existence from regular bi-density. The lemma needs both directions.',
  'cannot_transfer':'A directed path is not an undirected simple cycle. No general digraph resilience or whole main proof review; not a mandatory proof input to the self-contained F181 lemma.'},
 'KKS2015':{'locator':'Published pp857-859 Theorem1.1,Corollary1.2,definitions and proof outline; main theorem proof not read',
  'input':'G(n,p) with independent edges,p=omega(loglog(n)/n); high probability as n tends to infinity.',
  'output':'Edge partition into odd(G)/2+np/2+o(n) cycles and single edges. The n/4+np/2+o(n) corollary also needs p<1-omega(1/n).',
  'scope':'Odd-degree lower bound and cycle-size bound motivate the count. Euler means all degrees even, connectivity not required; log is natural. Outline separates sparse/intermediate/dense ranges.',
  'cannot_transfer':'No deterministic arbitrary finite graph guarantee,effective n0,or implementation runtime. Do not replace odd(G)/2 by n/4 arbitrarily near p=1.'},
 'AABC2025':{'locator':'arXivv2 pp1-4 definitions,Theorems1.3/1.5/1.7 and selected1.3 proof; pp9-10 Theorem5.1 and selected1.7 proof',
  'input':'Finite simple graphs; source use of1.3 has positive order n and maximum degree<=4;1.7 source uses graphs containing a cycle.',
  'output':'Theorem1.3 f_ce<=n-1 for maxdegree<=4; Theorem1.7 g_ce<=n-2 for a graph that is not a tree. f_ce partitions cycles/edges; g_ce covers and may repeat edges.',
  'scope':'Non-tree includes disconnected forests with at least two components. Here Eulerian means connected and even. Theorem1.5 counts 2-regular parts, each may have many cycle components. Selected1.3 and1.7 proofs read, not accepted or fully recursively audited.',
  'cannot_transfer':'Overlap cover is not edge partition; a 2-regular subgraph need not be one simple cycle. Source positive-order qualification retained. Theorem1.7 invokes Fan and3.1; original Fan and full3.1 proof remain outside this reading.'},
 'Krivelevich2019':{'locator':'arXivv2 p2 Theorem1;pp5-7 Propositions2.1/2.2 and DFS;pp7-8 full selected Theorem1 proof',
  'input':'Integers k>0,t>=2;undirected graph order>k;external neighborhood>=t for EVERY W with k/2<=|W|<=k.',
  'output':'A simple cycle of length at least t+1.',
  'scope':'Choose child subtrees of total size k/2..k;DFS non-tree edges have ancestor endpoints;neighbors lie on one ancestor path,whose farthest neighbor closes a long simple cycle.',
  'cannot_transfer':'External neighborhood convention differs from F181 N(U) before subtracting U. No claim about general cycle decomposition,finite C,fast optimization,or applications sections not read.'}}
success={}
for f in ['fetch-receipt.json','alternative-fetch-receipt.json']:
    for x in json.loads((w/f).read_text())['rows']:
        if x.get('status')==200:success[x['key']]=x
rows=[]
for key in ['BKS2012','KKS2015','AABC2025','Krivelevich2019']:
    x=copy.deepcopy(success[key]);pdf=(w/(key+'.pdf')).read_bytes();txt=(w/(key+'.txt')).read_bytes()
    assert sha(pdf)==x['sha256'] and sha(txt)==x['text_sha256']
    lines=txt.decode().split('\n')
    x.update(version_observation=versions[key],actual_selected_LF_ranges_read=ranges[key],line_number_convention='LF-separated lines as nl -ba; original fetch text_lines uses Python splitlines and also splits form-feeds',LF_line_count=len(lines),selected_scope_qualified=True,full_original_proof_review=False,findings=findings[key],PDF_page_ranges=[{'LF_lines':[a,b],'PDF_pages':[1+''.join(lines[:a-1]).count('\f'),1+''.join(lines[:b]).count('\f')]} for a,b in ranges[key]])
    rows.append(x)
lovasz_url='https://www.researchgate.net/profile/Laszlo-Lovasz/publication/268652766_On_covering_of_graphs/links/5e1465b7299bf10bc3967731/On-covering-of-graphs.pdf'
lovasz={'key':'Lovasz1968','url':lovasz_url,'access':'Author-uploaded primary PDF served as cached web-converted text; prior direct403 not blindly repeated','web_locator':'PDFpage0 lines36-65; readable conventions36-43; theorem numerical formula56 OCR damaged','partial_original_domain_scope_checked':True,'selected_scope_qualified':False,'raw_PDF_sha256':None,'text_sha256':None,'short_quote':'Disjoint means always edge-disjoint and path means simple path.','finding':'Finite undirected graphs without loops/multiple edges; disjoint means edge-disjoint,paths simple. Exact floor(n/2) formula remains unreadable in original conversion; BM/AABC restatements do not repair this original-byte/transcription gap.','full_original_proof_review':False}
attempts={f:json.loads((w/f).read_text()) for f in ['fetch-receipt.json','alternative-fetch-receipt.json','primary-discovery.json','Pyber-publications-receipt.json']}
ah={'key':'AH2000','url':'https://onlinelibrary.wiley.com/doi/pdf/10.1002/1097-0118%28200010%2935%3A2%3C83%3A%3AAID-JGT2%3E3.0.CO%3B2-V','observed_final_kind':'Publisher abstract HTML,not original body','original_body_checked':False,'selected_scope_qualified':False,'gap':'Exact original uniform/rank/indexed hypergraph conditions and proof remain unqualified. Source bounded-rank theorem and BM Theorem6 were read separately; private fresh padding per edge occurrence is a source deduction,not original AH proof review.'}
pyber={'key':'Pyber1985','url':'https://link.springer.com/content/pdf/10.1007/BF02579444.pdf','original_body_checked':False,'selected_scope_qualified':False,'gap':'Publisher body unavailable;author home1102bytes200 led to genuine pub.html,which returned403. No repeated identical denied route. Later original AABC/KKS citations are restatements,not Pyber original review.'}
comparison={'kind':'Static old-method scope inclusion,not a new mathematical discovery or numerical experiment','source_claim_id':'CLM-181-LEM-SPLIT-VERTEX-EXPANSION','old_literature_id':'LIT-181-KRIVELEVICH2019','substitution':['u sufficiently large;alpha=(1/32)/log2(u)^2;0<alpha<=1','k=floor(u/2)>0; t=ceil(alpha*k/2)>=2;u>k','For k/2<=|W|<=k,source expansion gives integer external degree>=alpha|W|>=alpha*k/2, hence>=ceil(alpha*k/2)=t','Old Theorem1 yields cyclelength>=ceil(alpha*k/2)+1;for u>=3,k>=u/3,so bound>alpha*u/6>alpha^2*u/100'], 'conclusion':'The already-cited old criterion is stronger on this selected long-cycle interface. Preserve source literal weaker lemma and sourceC;do not promote wholeCn theorem,constructive cost,or complete proof chain.','dependency_semantics':'Old criterion is historical comparison,not mandatory dependency of the self-contained source DFS/bypass proof.'}
ledger={'at':now,'generation':gen,'work_package':'WP-128','base_commit':base,'upstream_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','scope':'Four additional original selected statement/proof scopes;one partial original convention scope;two original-body gaps. Only converted text analyzed;no source proof acceptance,new application or human/provider credit.','rows':rows,'partial_original':lovasz,'unqualified_originals':[ah,pyber],'attempt_receipts':attempts,'static_old_method_comparison':comparison,'new_selected_original_count':4,'previous_selected_original_count':4,'current_selected_original_count':8,'root_count':11,'remaining_unqualified_root_ids':['LIT-181-AH2000','LIT-181-LOVASZ1968','LIT-181-PYBER1985'],'full_lineage_complete':False,'full_original_proof_review':False,'third_party_republication':False,'downloaded_original_PDF_bytes':sum(x['bytes'] for x in rows),'converted_text_bytes':sum(x['text_bytes'] for x in rows),'per_artifact_cap':3*1024**2,'total_new_download_cap':16*1024**2,'source_use_ranges':[{'path':up+'sections/preliminaries.tex','LF_lines':[1,147]},{'path':up+'sections/splitting.tex','LF_lines':[50,150]},{'path':up+'main.tex','LF_lines':[65,115]}]}
save(r/root_receipt,ledger)
save(r/'data/provenance/research-at-generation-125.json',json.loads((r/'configs/research.json').read_text()))
nodepath=r/'data/graph/nodes.jsonl';rawlines=nodepath.read_bytes().splitlines(keepends=True);nodes={json.loads(b)['id']:json.loads(b) for b in rawlines};before={}
history='data/graph/history/'+gen+'-before.json.gz'
def edit(id):
    n=nodes[id];before[id]=copy.deepcopy(n);n.update(version=n['version']+1,updated_at=now,updated_by_generation_id=gen,prior_version_archive=history)
    n['properties'].update(revision_reason='WP128 actual selected original scopes and explicit gaps;prior source record preserved,no mathematical grade or completion promotion',last_historical_scope_generation=gen)
    n['sources'].append(source(root_receipt,'WP128 selected original scopes,versions,hashes,access failures and exact scope limits'))
    return n
for key in ['BKS2012','KKS2015','AABC2025','Krivelevich2019']:
    n=edit('LIT-181-'+key.upper());x=next(x for x in rows if x['key']==key)
    n['evidence_status']='source_content_checked';n['properties'].update(title={'BKS2012':'Long directed cycles in random digraphs','KKS2015':'Decomposing Random Graphs into Few Cycles and Edges','AABC2025':'Decompositions of graphs into cycles and edges','Krivelevich2019':'Long cycles in locally expanding graphs, with applications'}[key],retrieval_status='original_selected_converted_text_scopes_checked',verified_scope=x['findings'],version_observation=x['version_observation'],original_PDF_sha256=x['sha256'],original_text_sha256=x['text_sha256'],full_original_proof_review=False,dependency_closure_complete=False)
    n['sources'].append({'url':x['final_url'],'sha256':x['sha256'],'content_checked':True,'locator':x['findings']['locator']+';LF ranges'+str(ranges[key]),'source_revision':x['version_observation'],'text_sha256':x['text_sha256'],'checked_at':now,'scope':'Selected converted-text scope only;not full proof/lineage'})
for key,obj,status in [('LOVASZ1968',lovasz,'cached_primary_domain_only_exact_formula_unresolved'),('AH2000',ah,'publisher_abstract_only_author_route403'),('PYBER1985',pyber,'original_body_unavailable_author_list403')]:
    n=edit('LIT-181-'+key);n['properties'].update(retrieval_status=status,verified_scope=obj,full_original_proof_review=False)
    if key=='LOVASZ1968':
        n['evidence_status']='source_content_checked';n['sources'].append({'url':lovasz_url,'content_checked':True,'locator':lovasz['web_locator'],'checked_at':now,'scope':'Primary domain convention only;numeric formula unresolved;PDF/text bytes hash unknown'})
n=edit('CLM-181-LEM-SPLIT-VERTEX-EXPANSION');n['properties']['old_method_scope_comparison']=comparison
n=edit('ANALYSIS-F-181');p=n['properties'];p['historical_verified_keys']+=['BKS2012','KKS2015','AABC2025','Krivelevich2019'];p.update(historical_partial_keys=['Lovasz1968'],unread_or_unqualified_original_root_ids=ledger['remaining_unqualified_root_ids'],historical_scope_followup_receipt=root_receipt,old_method_comparison=comparison,completion_basis='Allcurrent9TeX/Bib2566lines,16namedbindings12contracts;now8of11 selected original scopes plus Lovasz domain-only;three roots and recursive history unqualified. Not full family/history/proof/human/provider completion.')
p['gaps'][1]='WP128 now8of11 selected original scopes;AH original body andPyber original body unavailable;Lovasz original conventions clear but exactbound formula unreadable andPDFhashunknown. All recursive full-proof/history closures remain incomplete.'
p['gaps'].append('WP128 oldKrivelevichTheorem1 already gives stronger cycle bound on the selected local-expansion assumption;this is historical sufficiency,not newCn decomposition/runningtime or wholeproof acceptance. BKS directedpaths,KKS randomscope,AABC cover/partition/2-regularparts cannot be interchanged.')
new=[]
def add(id,kind,props,ss):
    assert id not in nodes;z={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':'source_content_checked','sources':ss,'properties':props};nodes[id]=z;new.append(z)
ls=source(root_receipt,'Four original selected scopes,partial Lovasz conventions and explicit unqualified interfaces;not applications or full lineage')
add(gen,'generation',{'title':'F181 selected original history and old-method scope comparison','provider':'OpenAI','model':'Current user-selected session; exact backend unknown','family_ids':['F-181'],'human_review':None,'independent_second_provider':None,'project_base_commit':base,'new_candidates':0,'new_initial_checks':0,'new_distinct_validation_hypotheses':0,'new_full_original_scopes':4,'mathematical_grade_promotions':0,'credibility':'unknown'},[ls,source('data/provenance/research-at-generation-125.json','Frozen research policy at generation125')])
method='PART-181-OLD-EXPANSION-CRITERION';expl='EXPL-181-HISTORY-SCOPES-WP128'
add(method,'method',{'title':'Old local external-expansion cycle criterion','family_ids':['F-181'],'model_generation_id':gen,'input':findings['Krivelevich2019']['input'],'output':findings['Krivelevich2019']['output'],'conditions':'Exact integers k>0,t>=2;graph order>k;all intermediate subsets k/2..k;external neighbors. Static source substitution recorded in ledger.','cannot_transfer':'No whole decomposition,explicit global threshold or practical runtime;not a new project result.','credibility':'unknown','dependency_closure_complete':False,'old_method_scope_comparison':comparison},[ls])
add(expl,'exploration',{'title':'F181 history scope differences and old-method sufficiency','family_ids':['F-181'],'model_generation_id':gen,'credibility':'unknown','dependency_closure_complete':False,'scope_findings':findings,'partial_original':lovasz,'remaining_unqualified_root_ids':ledger['remaining_unqualified_root_ids'],'old_method_scope_comparison':comparison,'new_candidate':False,'new_initial_check':False,'numerical_execution':False,'full_lineage_complete':False},[ls])
packed(r/history,json.dumps({'at':now,'reason':'WP128 versioned actual original scope observations;preserve prior facts','records':list(before.values())},ensure_ascii=False,indent=2).encode())
nodepath.write_bytes(b''.join((json.dumps(nodes[json.loads(raw)['id']],ensure_ascii=False,sort_keys=True)+'\n').encode() if json.loads(raw)['id'] in before else raw for raw in rawlines)+b''.join((json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n').encode() for n in new))
edgepath=r/'data/graph/edges.jsonl';ebefore=edgepath.read_bytes();edges=[]
def edge(a,rel,b,loc):
    id='E-'+sha((a+'|'+rel+'|'+b).encode())[:16].upper();assert id not in {json.loads(l)['id'] for l in ebefore.splitlines()}
    edges.append({'id':id,'source':a,'relation':rel,'target':b,'version':1,'created_at':now,'evidence_status':'source_content_checked','source_locator':loc,'source_commit':ledger['upstream_commit']})
edge(method,'depends_on','LIT-181-KRIVELEVICH2019','Original Theorem1 selected statement;unknown complete proof chain;no human approval')
edge(expl,'uses',method,'Static substitution and historical-sufficiency comparison;not main proof')
for lit in ['LIT-181-BKS2012','LIT-181-KKS2015','LIT-181-AABC2025','LIT-181-LOVASZ1968']:edge(expl,'derived_from',lit,'Selected original domain/statement limits only;Lovasz numeric formula unresolved')
edge('CLM-181-LEM-SPLIT-VERTEX-EXPANSION','historical_context',method,'Stronger old criterion comparison;not mandatory dependency of self-contained source proof')
edge('ANALYSIS-F-181','historical_context',expl,'WP128 selected original followup;full family/history incomplete')
edgepath.write_bytes(ebefore+b''.join((json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n').encode() for e in edges))
covpath=r/'data/graph/reading_coverage.json';cb=covpath.read_bytes();packed(r/('data/graph/history/'+gen+'-reading-coverage-before.json.gz'),cb);cov=json.loads(cb);cov['partially_read_families']['F-181'].append('WP128:8of11 selected original scopes now checked,pluspartialLovasz conventions;AH/PyberbodiesandLovaszexactbound/recursivehistory remainunqualified. Oldlongcyclecriterion suffices;no newfamily,card,experiment orproofcredit.');cov.update(updated_at=now,update_reason='WP128 selected original history scope followup;coverage/cardinality unchanged',prior_version_archive='data/graph/history/'+gen+'-reading-coverage-before.json.gz');save(covpath,cov)
summary={'at':now,'base_commit':base,'generation':gen,'old_rows':len(rawlines),'new_record_ids':[n['id'] for n in new],'new_explicit_edges':len(edges),'versioned_old_record_ids':list(before),'current_selected_originals':8,'partial_originals':1,'remaining_unqualified_roots':3,'new_candidates':0,'new_initial_checks':0,'mathematical_grade_promotions':0};save(w/'curation-summary.json',summary)
save(w/'partial-checkpoint.json',{'at':now,'package':'WP-128','execution':'canonical curated;quality/core/clean/global045/storage/commit remain','overall_status':'active_incomplete','summary':summary,'temporary_originals':'Four originals and converted text retained until hash-verified cleanup','previous_goal_turn':'no_progress_status_only;next safe action actually executed'})
print(json.dumps(summary))
