from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,urllib.request

work=Path(__file__).resolve().parent
sources=[
 ('BM2024','https://arxiv.org/pdf/2211.07689v2'),
 ('CFS2014','https://people.math.ethz.ch/~sudakovb/cycle-packing.pdf'),
 ('GGKO2021','https://arxiv.org/pdf/1911.05501'),
 ('EGP1966','https://www.renyi.hu/~p_erdos/1966-21.pdf'),
 ('Lovasz1968','https://www.researchgate.net/profile/Laszlo-Lovasz/publication/268652766_On_covering_of_graphs/links/5e1465b7299bf10bc3967731/On-covering-of-graphs.pdf')]

def fetch(item):
 key,url=item;row={'key':key,'requested_url':url,'at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-audit/1.0'}),timeout=20) as response:
   row.update(status=response.status,final_url=response.url,content_type=response.headers.get('Content-Type'));raw=response.read(2*1024*1024+1)
  assert len(raw)<=2*1024*1024 and raw.startswith(b'%PDF'), 'Not a bounded PDF'
  pdf=work/(key+'.pdf');txt=work/(key+'.txt');pdf.write_bytes(raw)
  row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),temporary_pdf=str(pdf))
  cmd=['/opt/homebrew/bin/pdftotext','-layout',str(pdf),str(txt)]
  result=subprocess.run(cmd,capture_output=True,timeout=20)
  row.update(conversion_command=cmd,conversion_exit=result.returncode,conversion_stderr=result.stderr.decode(errors='replace'))
  assert result.returncode==0
  text=txt.read_bytes();row.update(temporary_text=str(txt),text_bytes=len(text),text_sha256=hashlib.sha256(text).hexdigest(),text_lines=len(text.splitlines()),actual_selected_ranges_read=[])
 except Exception as error:row['failure']=repr(error)
 return row

with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,sources))
assert sum(r.get('bytes',0) for r in rows)<=6*1024*1024
out={'at':datetime.now(timezone.utc).isoformat(),'scope':'Primary original statement scopes only; PDF analyzed only through converted text; downloaded bytes bounded and will be hash-verified before cleanup.','rows':rows,'full_proof_review':False,'full_lineage_complete':False,'third_party_republication':False}
(work/'history-fetch.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
