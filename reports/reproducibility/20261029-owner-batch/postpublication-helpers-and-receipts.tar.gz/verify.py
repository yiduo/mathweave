from pathlib import Path
from datetime import datetime,timezone
import base64,gzip,hashlib,json,subprocess,urllib.request,urllib.error
r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-owner-batch';c=json.loads((w/'public-candidate.json').read_text());events=[]
def get(path):
 url='https://api.github.com/repos/yiduo/mathweave'+path;headers={'User-Agent':'MathWeave-publication-check','Accept':'application/vnd.github+json'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as f:return json.load(f)
 except urllib.error.HTTPError as e:
  if e.code!=403:raise
  events.append({'path':path,'anonymous_status':403,'retry':'configured credential helper; secret not logged or saved'})
  raw=subprocess.check_output(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',cwd=r);parts=dict(x.split('=',1) for x in raw.decode().splitlines() if '=' in x);headers['Authorization']='Basic '+base64.b64encode((parts['username']+':'+parts['password']).encode()).decode()
  with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as f:return json.load(f)
def savegz(name,d):
 b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/name).write_bytes(z)
repo=get('');assert repo['private'] is False and repo['default_branch']=='main'
ref=get('/git/ref/heads/main');assert ref['object']['sha']==c['commit']
commit=get('/git/commits/'+c['commit']);assert commit['tree']['sha']==c['tree'] and [p['sha'] for p in commit['parents']]==[c['parent']]
tree=get('/git/trees/'+c['tree']+'?recursive=1');assert not tree.get('truncated')
remote={x['path']:(x['mode'],x['sha'],x.get('size')) for x in tree['tree'] if x['type']=='blob'};local={}
for row in subprocess.check_output(['git','ls-tree','-rlz',c['local_commit']],cwd=r).decode().split('\0'):
 if not row:continue
 meta,path=row.split('\t',1);mode,typ,sha,size=meta.split();assert typ=='blob';local[path]=(mode,sha,int(size))
assert remote==local;assert not any(p=='math' or p.startswith('math/') for p in remote);assert len(remote)==c['files']
verified={'verified_at':datetime.now(timezone.utc).isoformat(),**c,'state':'published_remote_verified','public':True,'remote_tree_equals_local_tree':True,'all_blob_paths_modes_sizes_sha_equal':True,'api_fallbacks':events,'ci':'separate receipt,not implied by push'};savegz('verification.json.gz',verified)
runs=get('/actions/runs?head_sha='+c['commit']+'&per_page=10');observed={'at':datetime.now(timezone.utc).isoformat(),'commit':c['commit'],'runs':[{k:x.get(k) for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at','run_attempt']} for x in runs['workflow_runs']],'scope':'Actual observed run state only; CI does not establish mathematical/application/human acceptance.','api_fallbacks':events};savegz('CI-observation.json.gz',observed);(w/'verification.json').write_text(json.dumps(verified,indent=2)+'\n');(w/'CI-observation.json').write_text(json.dumps(observed,indent=2)+'\n');print(json.dumps({'verified_commit':c['commit'],'tree':c['tree'],'files':len(remote),'math':0,'runs':observed['runs']}))
