from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,tarfile
r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-owner-batch';now=datetime.now(timezone.utc).isoformat();v=json.loads((w/'verification.json').read_text());ci=json.loads((w/'CI-observation.json').read_text())
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=r/'state/publication.json';d=json.loads(p.read_text());prior={k:d[k] for k in ['verified_at','verified_commit','verified_tree','verification_receipt','verification_scope','latest_scoped_ci','latest_ci_receipt','latest_ci_conclusion'] if k in d};d['prior_verifications'].append(prior)
d.update(state='published',public=True,remote_verified=True,verified_at=v['verified_at'],verified_commit=v['commit'],verified_tree=v['tree'],verification_receipt=str((out/'verification.json.gz').relative_to(r)),verification_scope='Owner-requested F271 mapping, finite-range claims, global046 and replay diagnostics batch. Entire3442blob tree equals audited local snapshot; officialmath and bulk localhistory excluded. WP129 and phaseone incomplete.',latest_scoped_ci=ci,latest_ci_receipt=str((out/'CI-observation.json.gz').relative_to(r)),latest_ci_conclusion='in_progress',latest_retrospective='reports/retrospectives/046-proof-scope-and-replay-evidence.md',linux_ci_scope='97 core checks,13 configured strict archive replays, graph export/publication audit and failed replay upload; actual outcome observed separately.',pending_batch=None)
d['latest_progress_packages']=['WP113 through WP128','unfinished WP129 with GEN128 application mapping and GEN129 finite-range claims','global046 and replay evidence diagnostics']
save(p,d)
p=r/'state/checkpoint.json';d=json.loads(p.read_text());d['saved_at']=now;d['publication_work'].update(status='published_verified_ci_in_progress',verified_commit=v['commit'],verified_tree=v['tree'],verification_receipt=str((out/'verification.json.gz').relative_to(r)),latest_scoped_ci=ci,latest_ci_conclusion='in_progress',postpublication_receipts_local_only=True,next_action='Resume WP130 actual constructor/cost admission audit, then mandatory global047. New remote CI is in progress; do not claim it passed. No further push without a meaningful batch or explicit request.')
d['running_quality_checks']=[{'kind':'remote_GitHub_Actions','run_id':ci['runs'][0]['id'],'head_sha':v['commit'],'status':'in_progress','url':ci['runs'][0]['html_url'],'local_process':False}] if ci['runs'] else []
d['current_goal_turn_classification']={'this_turn':'progress','evidence':'Owner-requested exact audited snapshot pushed once and full remote tree readback verified.97 local/clean tests,18archives378source members. CI in progress. No research counts added.','goal':'active_incomplete'}
save(p,d)
p=r/'state/status.md';text=p.read_text();text=text.replace('最后核验公开快照f2aa303及CI失败收据保持；本地CI留证修复与本轮研究未推送。当前无已知活动研究/质量句柄；真人与第二供应商由用户后补，不重复询问。','当前公开快照3a4d5ce已核验，含应用映射、有限程命题和CI留证修复；新CI40842772641仍在运行，旧f2aa303失败收据保留。当前无本地活动研究/质量进程；真人与第二供应商由用户后补，不重复询问。')
text+='\n本批发布核验（'+now+'）：一次推送3a4d5cef39bfc75a15d41e63405a22974683ee08，远端完整tree/path/mode/size/blob与本地审核快照相等，3442文件/97307187字节，math0、无批量本地历史。CI40842772641已启动但仍in_progress，不提前声称通过。后验收据仅本地保存；下一研究仍WP130准入审计，之后强制全局047，再续WP129余53条；整体active_incomplete。\n';p.write_text(text)
# Exact indexed audit is a postpublication receipt, avoiding a self-referential snapshot.
b=(w/'final-audit.json').read_bytes();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/'final-audit.json.gz').write_bytes(z)
entries=sorted(p.name for p in w.iterdir() if p.is_file());buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for n in entries:
  b=(w/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for n in entries:assert t.extractfile(n).read()==(w/n).read_bytes()
(out/'postpublication-helpers-and-receipts.tar.gz').write_bytes(z)
receipt={'at':now,'members':len(entries),'compressed_sha256':hashlib.sha256(z).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'all_members_verified':True,'temporary_directory':str(w),'plaintext_removed_after_verification':True,'postpublication_receipts_local_only':True,'remote_commit':v['commit'],'ci_status':'in_progress','new_numerical_runs':0}
shutil.rmtree(w);save(out/'postpublication-storage.json',receipt);print(json.dumps(receipt))
