from pathlib import Path
from datetime import datetime,timezone
import gzip,io,json,tarfile,hashlib
r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-owner-batch'
q=json.loads((out/'quality.json').read_text());assert q['core_tests']==97 and q['clean_core_tests']==97 and q['skips']==0 and q['clean_directory_removed']
now=datetime.now(timezone.utc).isoformat()
for name in ['state/publication.json','state/checkpoint.json']:
 p=r/name;d=json.loads(p.read_text())
 if name.endswith('publication.json'):d['pending_batch'].update(status='checks_passed_pending_push_readback_ci',quality_receipt=str((out/'quality.json').relative_to(r)))
 else:d['saved_at']=now;d['publication_work'].update(status='checks_passed_pending_push_readback_ci',current_batch_qa=q,prepush_audit=str((out/'final-audit.json.gz').relative_to(r)))
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
with (r/'state/status.md').open('a') as f:f.write('\n本批发布前核验（'+now+'）：97核心及无math干净副本97项均无跳过；完整图JSON/GraphML对象一致，18归档378源码成员与解压散列核验。干净副本逐项核散列后已删除；实际研究代码/输入及规范图保持9428240，沿用该包传播/证明接口和CI119真实支持/不利重放收据。待精确索引审计、一次推送和远端回读；不提前声称CI成功。\n')
entries=['qa.py','finalize_pre.py','core.log','no-math-core.log','qa.log'];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
 for n in entries:
  b=(w/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for n in entries:assert t.extractfile(n).read()==(w/n).read_bytes()
(out/'final-prepublication-helpers-and-logs.tar.gz').write_bytes(z)
print(json.dumps({'core':97,'clean':97,'helper_members':len(entries),'compressed_sha256':hashlib.sha256(z).hexdigest()}))
