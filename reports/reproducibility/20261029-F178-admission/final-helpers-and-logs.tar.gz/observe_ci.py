from pathlib import Path
from datetime import datetime,timezone
import base64,gzip,json,subprocess,urllib.request,urllib.error
r=Path.cwd();p=r/'reports/reproducibility/20261029-CI40842772641';fallback=[]
def get(path):
 headers={'User-Agent':'MathWeave-evidence-check','Accept':'application/vnd.github+json'};u='https://api.github.com/repos/yiduo/mathweave'+path
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers=headers),timeout=30) as f:return json.load(f)
 except urllib.error.HTTPError as e:
  if e.code!=403:raise
  fallback.append({'path':path,'anonymous_status':403,'retry':'configured credential helper; secret not logged or saved'})
  b=subprocess.check_output(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n');d=dict(x.split('=',1) for x in b.decode().splitlines() if '=' in x);headers['Authorization']='Basic '+base64.b64encode((d['username']+':'+d['password']).encode()).decode()
  with urllib.request.urlopen(urllib.request.Request(u,headers=headers),timeout=30) as f:return json.load(f)
x=get('/actions/runs/40842772641');assert x['head_sha']=='3a4d5cef39bfc75a15d41e63405a22974683ee08' and x['status']=='completed' and x['conclusion']=='failure'
d={'at':datetime.now(timezone.utc).isoformat(),'commit':x['head_sha'],'runs':[{k:x.get(k) for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at','run_attempt']}],'scope':'97core plus11successful archived replay steps; EXP119strict raw mismatch/summary match. EXP332/export/finalaudit skipped. Failure upload succeeded; full artifact and payload inspection retained separately. No software/scientific acceptance upgrade.','api_fallbacks':fallback}
b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(p/'CI-observation.json.gz').write_bytes(z);print(json.dumps(d))
