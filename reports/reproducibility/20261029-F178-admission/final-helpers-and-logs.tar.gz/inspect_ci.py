from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,zipfile,tarfile,importlib.util,struct
r=Path.cwd();out=r/'reports/reproducibility/20261029-CI40842772641'
def sha(b):return hashlib.sha256(b).hexdigest()
def savegz(p,d):
 b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;p.write_bytes(z)
raw=(out/'replay-failures.zip').read_bytes();assert sha(raw)=='0a145e4f9af73b55bcc1f7b243d5f76accfe260b8377959841d1282861c2a193';caps=[];actual={}
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 for name in z.namelist():
  if not name.endswith('/receipt.json'):continue
  receipt=json.loads(z.read(name));archive=z.read(name.rsplit('/',1)[0]+'/failure.tar.gz');assert sha(archive)==receipt['archive_sha256']
  with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
   values={n:t.extractfile(n).read() for n in t.getnames()}
  assert set(values)==set(receipt['members'])
  for n,b in values.items():assert sha(b)==receipt['members'][n],n
  caps.append({'capsule':name.rsplit('/',1)[0],'original_run':receipt['original_run'],'members':len(values),'archive_sha256':sha(archive),'all_member_hashes_verified':True})
  if 'EXP-119' in name:actual=values
comp=json.loads(actual['replay-comparison.json']);prefix='experiments/runs/'+comp['replay_run']+'/'
manifest=json.loads(actual[prefix+'manifest.json'])
for n,s in manifest['outputs'].items():assert sha(actual[prefix+n])==s
for n,m in manifest['compressed_payloads'].items():assert sha(gzip.decompress(actual[prefix+n]))==m['uncompressed_sha256']
snapshot=json.loads(gzip.decompress(actual[prefix+manifest['source_snapshot']]))
for n,s in snapshot.items():assert sha(s.encode())==manifest['inputs'][n]
original=r/'experiments/runs'/comp['original_run'];before=json.loads(actual['original-input-hashes-at-failure.json'])
for n,m in before.items():assert sha((original/n).read_bytes())==m['sha256'] and (original/n).stat().st_size==m['bytes']
a=json.loads(gzip.decompress((original/'raw.json.gz').read_bytes()));b=json.loads(gzip.decompress(actual[prefix+'raw.json.gz']))
spec=importlib.util.spec_from_file_location('replay_controller',r/'scripts/replay_run.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);diff=mod.payload_differences(a,b);assert diff['different_positions']==4 and not diff['preview_truncated']
summary=json.loads(gzip.decompress(actual[prefix+'summary.json.gz']));assert summary==json.loads(gzip.decompress((original/'summary.json.gz').read_bytes()))
allowed={'/2/midpoint/combined','/2/midpoint/old_hybrid','/5/midpoint/combined','/5/midpoint/old_hybrid'};assert {x['path'] for x in diff['preview']}==allowed
ulps=[]
for x in diff['preview']:
 v=float.fromhex(x['expected']['hex']);u=float.fromhex(x['actual']['hex']);distance=abs(struct.unpack('>Q',struct.pack('>d',v))[0]-struct.unpack('>Q',struct.pack('>d',u))[0]);assert distance==1;ulps.append({'path':x['path'],'distance_ULP':distance})
observation={'at':datetime.now(timezone.utc).isoformat(),'commit':'3a4d5cef39bfc75a15d41e63405a22974683ee08','workflow_run_id':40842772641,'job_id':123342903587,'observed_job_status':'completed','observed_job_conclusion':'failure','job_url':'https://github.com/yiduo/mathweave/actions/runs/40842772641/job/123342903587','core_step':'success','prior11_replays':'success','EXP119_step':'failure','EXP332_export_audit':'skipped','failure_upload_step':'success','artifact_id':12883243380,'artifact_bytes':len(raw),'artifact_sha256':sha(raw),'capsules':caps,'new_EXP119_payload':{'runtime':comp['runtime'],'platform':comp['platform'],'raw_equal':False,'summary_equal':True,'different_positions':4,'differences':diff,'ULP_distances':ulps,'all_other_raw_fields_equal':True,'frozen_original_files_hash_equal':True,'replay_manifest_payloads_and_source_snapshot_verified':True,'replay_source_members':len(snapshot),'resource_gate':'Not evaluated after deterministic mismatch'},'source_localization':{'path':'src/ai_value/binary_information.py','range':[300,329],'function':'midpoint_check','finding':'Four differences are in float midpoint cross-check results. Function uses math.log,math.atanh and binary floating arithmetic; interval outputs and other raw/summary fields are equal.','not_established':'Exact differing arithmetic/transcendental operation and platform root cause have not been isolated; do not infer all differences come from libm or adjust comparison.'},'scope':'Diagnostic evidence only. No new scientific run/check/hypothesis credit. Historical EXP076 capsule in artifact was already in the checkout; this workflow did not execute EXP076. Strict comparison and historical archive are unchanged.'}
savegz(out/'payload-inspection.json.gz',observation);print(json.dumps({'capsules':caps,'raw_differences':4,'all_four_one_ULP':True,'summary_equal':True,'source_members':len(snapshot),'new_runs':0}))
