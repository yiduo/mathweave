from pathlib import Path
from datetime import datetime, timezone
import json

r = Path.cwd()
now = datetime.now(timezone.utc).isoformat()
def save(p, d):
    (r / p).write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')

p = r / 'README.md'
s = p.read_text().replace('2026年10月27日用户要求的合并发布', '2026年10月29日用户要求的合并发布')
s = s.replace('尚未完成的WP129阅读检查点', '尚未完成的WP129方法和基础稿命题整理')
s = s.replace('8,874节点、26,094关系', '8,936节点、26,265关系')
s = s.replace('命题／方法／跨域关系仍待规范入图，不增加正式阅读族、全文草稿或应用计数。', '已规范整理8个方法接口及九月基础稿34条来源命题；十月三稿84条定位仍待语义整理，历史与跨域探索未完成。不增加完整族、全文草稿或应用计数。见[方法接口](reports/F271-partial-methods.md)和[基础稿命题](reports/F271-foundation-claims.md)。')
s = s.replace('reports/reproducibility/20261027-publication/', 'reports/reproducibility/20261029-publication/')
p.write_text(s)

p = r / 'README.en.md'
s = p.read_text().replace('8,874 nodes and 26,094 relations', '8,936 nodes and 26,265 relations')
s = s.replace('October 27, 2026 owner-requested', 'October 29, 2026 owner-requested')
s = s.replace('Source bindings, methods and application mappings are still pending curation, so this journal adds no canonical coverage or application credit.', 'Eight method interfaces and 34 September foundation statements are now curated with conditions and source locations. The October companions retain 84 lexical result locators pending semantic curation; historical and application mappings remain unfinished. This partial work adds no complete-family, source-draft or application credit. See [method interfaces](reports/F271-partial-methods.md) and [foundation statements](reports/F271-foundation-claims.md).')
p.write_text(s)

p = r / 'PROGRESS.en.md'
s = p.read_text().replace('Snapshot: October 27, 2026.', 'Snapshot: October 29, 2026.')
s = s.replace('WP129 is an unfinished reading and historical-scope checkpoint.', 'WP129 remains unfinished, with eight method interfaces and 34 September foundation statements now curated through generation127.')
s = s.replace('WP129 adds no canonical credit yet', 'WP129 partial curation adds no additional family-count credit')
s = s.replace('8,874 nodes; 26,094 relations', '8,936 nodes; 26,265 relations').replace('9,845 core citation annotations', '9,932 core citation annotations')
s = s.replace('## Evidence added since the previous public snapshot', '## Research evidence and current publication delta')
s = s.replace('- WP113–WP116:', 'The October 27 public snapshot already included WP113–WP128 and the WP129 reading journal. This batch adds the following partial F271 curation and its QA; the earlier results below provide context.\n\n- WP129 partial curation: eight conditional method interfaces and 34 foundation statements, including 39 selected proof-dependency interfaces. Only the selected September endpoint has source grade B; the other 33 statements have source grade C. Every complete dependency grade remains unknown. October results do not inherit September formal coverage. Preserved early audit failures and repaired comparison-edge types are in the [foundation QA](reports/reproducibility/20261029-F271-foundation/). A publication-state rendering mismatch was corrected against the existing verification receipt, without treating it as a new remote observation.\n- WP113–WP116:')
s = s.replace('The latest completed research package has 95 core checks', 'The latest partial foundation curation has 95 core checks')
s = s.replace('[WP128 closure](reports/reproducibility/20261027-F181-history/closure.json) retains the exact scope; [publication QA](reports/reproducibility/20261027-publication/)', '[Foundation closure](reports/reproducibility/20261029-F271-foundation/closure.json) retains the exact scope; representative scientific replays remain in [WP128 closure](reports/reproducibility/20261027-F181-history/closure.json). [Publication QA](reports/reproducibility/20261029-publication/)')
s = s.replace('Complete WP129 source-bound propositions, method contracts, selected historical comparisons and ten-domain/cross-family exploration, then run the required graph and provenance checks before granting canonical credit.', 'Qualify the remaining 84 October statements (finite range 30, lattice correction 24, spherical law 30), with separate model and limit scopes. The next substantive research output triggers global review046, even while WP129 is unfinished. Then reconcile bibliography/history aliases and ten-domain/cross-family exploration before considering whole-family draft credit.')
p.write_text(s)

p = r / 'docs/publication.md'
with p.open('a') as f:
    f.write('\n\n## 2026-10-29 owner-requested partial-curation snapshot\n\nPublish one batch containing the eight F271 method interfaces, 34 September foundation statements and their source/dependency QA, plus the prior publication receipts. WP129 remains in progress: the three October manuscripts retain 84 lexical locators pending semantic qualification, and historical/application mapping remains unfinished. Counts stay at 47 candidates, 15 preliminary checks, 64 reading families and 59 drafts. The graph contains 8,936 nodes and 26,265 relations; graph size is not acceptance. Preserve the existing public main as the sole parent of a new snapshot commit, excluding bulk local history and official math. Verify the exact tree, core and clean checks before the single push; verify remote publication and CI separately. Keep subsequent verification receipts local until the next authorized batch. This publication-maintenance action does not count as another substantive research output or close WP129.\n')

p = 'state/publication.json'
d = json.loads((r / p).read_text())
d['pending_batch'] = {'requested_at': now, 'status': 'preparing_checks_not_pushed', 'source_commit': '9d34ce5', 'scope': 'WP129 partial GEN126 eight methods and GEN127 34 foundation statements; whole family unfinished', 'qa': 'reports/reproducibility/20261029-publication/quality.json', 'official_math_excluded': True, 'bulk_local_history_excluded': True}
d['local_progress_after_verified_snapshot'] = 'GEN126/127 partial F271 curation is local and pending this explicit publication request; previous verified commit and its CI remain separately scoped.'
d['linux_ci_scope'] = '95 core checks plus 13 configured archived replays, graph export and publication audit; no EXP076 strict Linux, optional NumPy, Lean, human/provider or application acceptance'
save(p, d)
p = 'state/checkpoint.json'
c = json.loads((r / p).read_text()); c['saved_at'] = now
c['publication_work'].update(status='preparing_owner_requested_batch', current_local_research_not_yet_pushed='F271 GEN126/127 partial curation; no full-family/application credit', synchronization_status='pending_new_batch', publication_qa='reports/reproducibility/20261029-publication')
c['publication_qa_evidence'] = 'reports/reproducibility/20261029-publication'
c['running_research_experiments'] = []; c['running_quality_checks'] = []
save(p, c)
p = r / 'state/status.md'
s = p.read_text().replace('612e91b（本轮新增方法仅本地）', '612e91b（本轮新增方法及基础稿命题待用户本次授权发布）')
s += '\n\n用户要求“提交一版”（' + now + '）：合并发布GEN126八方法与GEN127基础稿34命题及QA，中英文入口同步8936节点26265关系。当前84条十月定位尚待语义整理，47候选/15初检/64阅读59草稿保持。官方math、第三方全文、批量本地历史排除；检查、单次推送、回读和CI分别取证。此为发布维护，不追加研究工作包计数，下一实质研究产出后仍须全局046。\n'
p.write_text(s)
print('Prepared bilingual publication metadata; scientific records unchanged')
