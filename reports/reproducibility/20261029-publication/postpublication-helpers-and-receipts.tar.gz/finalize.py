from pathlib import Path
from datetime import datetime, timezone
import json,gzip,hashlib,io,tarfile,subprocess,shutil

r=Path.cwd();w=Path(__file__).parent;out=r/'reports/reproducibility/20261029-publication'
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def savegz(p,d):
    raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();z=gzip.compress(raw,mtime=0)
    assert gzip.decompress(z)==raw;p.write_bytes(z)
c=json.loads((w/'public-candidate.json').read_text());v=json.loads((w/'verification.json').read_text());ci=json.loads((w/'CI-observation.json').read_text())
assert v['head_commit']==ci['commit']==c['commit'] and v['full_tree_equal'] and v['public']
assert v['official_math_paths']==0 and len(v['selected_file_reads'])==7
assert all(x['byte_equal'] for x in v['selected_file_reads'])
assert ci['runs'] and all(x['head_sha']==c['commit'] for x in ci['runs'])
success=all(x['status']=='completed' and x['conclusion']=='success' for x in ci['runs'])
terminal=all(x['status']=='completed' for x in ci['runs'])
conclusion='success' if success else ('failure' if terminal else 'in_progress')
now=datetime.now(timezone.utc).isoformat()
for n in ['verification','CI-observation','CI-first-observation','CI-jobs-observation']:
    if (w/(n+'.json')).exists():savegz(out/(n+'.json.gz'),json.loads((w/(n+'.json')).read_text()))
if (w/'CI-failed-job.log').exists():
    rawlog=(w/'CI-failed-job.log').read_bytes();packed=gzip.compress(rawlog,mtime=0)
    assert gzip.decompress(packed)==rawlog;(out/'CI-failed-job.log.gz').write_bytes(packed)
a=json.loads((w/'final-audit.json').read_text());assert a['failure_count']==0
a.update(audited_tree=c['tree'],public_commit=c['commit']);savegz(out/'final-audit.json.gz',a)
p=r/'state/publication.json';d=json.loads(p.read_text())
assert d['verified_commit']==c['parent']
d['prior_verifications'].append({k:d[k] for k in ['verified_at','verified_commit','verified_tree','verification_receipt','verification_scope','latest_scoped_ci','latest_ci_receipt','latest_ci_conclusion'] if k in d})
d.update(state='published',public=True,remote_verified=True,verified_at=v['at'],verified_commit=c['commit'],verified_tree=c['tree'],verification_receipt=str((out/'verification.json.gz').relative_to(r)),verification_scope='WP129 partial GEN126 eight methods and GEN127 34 foundation statements; complete remote tree SHA matches audited local tree and seven selected public files byte-equal through connected GitHub fetch. No official math or bulk local history; research incomplete.',latest_scoped_ci=ci,latest_ci_receipt=str((out/'CI-observation.json.gz').relative_to(r)),latest_ci_conclusion=conclusion,latest_snapshot_files=v['files'],latest_snapshot_bytes=v['total_bytes'],anonymous_public_file_reads=0,selected_public_file_reads=7,public_file_read_access='Connected GitHub fetch of public raw URLs',pending_batch=None,local_progress_after_verified_snapshot='GEN126/127 partial curation is published; only post-push receipts and checkpoint updates stay local. WP129 remains in progress with 84 October statements and historical/application curation pending.',research_phase_one_complete=False)
d['update_policy']['push_this_package']=False;save(p,d)
if not success:
    d['current_public_ci_limitation']=ci.get('failure',{'status':conclusion})
    save(p,d)
p=r/'state/checkpoint.json';s=json.loads(p.read_text());s['saved_at']=now;s['updated_at']=now
s['publication_work'].update(status='published_verified_ci_'+conclusion,synchronization_status='published_verified',latest_public_commit=c['commit'],latest_public_tree=c['tree'],latest_ci=ci['runs'],latest_verification_receipt=str((out/'verification.json.gz').relative_to(r)),latest_ci_receipt=str((out/'CI-observation.json.gz').relative_to(r)),pending_public_commit=None,pending_public_tree=None,active_push_exec_session=None,scientific_local_commit='9d34ce5',local_publication_preparation_commit=c['local_commit'],current_local_research_not_yet_pushed='Only post-push receipts/checkpoint updates; partial GEN126/127 is published. WP129 is unfinished.')
s['running_research_experiments']=[];s['running_quality_checks']=[]
if not success:
    s['publication_work']['followup']={'status':'pending_diagnosis','failure':ci.get('failure'), 'next_action':'Retain failed remote logs. Obtain a failing raw payload through a versioned diagnostic harness before attributing differences; compare last successful environment and current runner. Do not relax exact comparison, change archived data, claim all13 remote replays passed, or repeatedly rerun the same failing job. No second publication push in this batch.'}
s['current_goal_turn_classification']={'this_turn':'progress','evidence':'Owner-requested snapshot '+c['commit']+' published and exact tree hash plus seven file bodies verified; local95/clean95, CI '+conclusion+'. No new research-count credit.','goal':'active_incomplete'}
save(p,s)
p=r/'state/status.md';t=p.read_text();lines=t.splitlines();lines[2]='更新时间：'+now+'。第一阶段仍未完成。';t='\n'.join(lines)+'\n'
t=t.replace('最后已核验公开快照为612e91b（本轮新增方法及基础稿命题待用户本次授权发布）','最后已核验公开快照为'+c['commit'][:7]+'（含本轮方法及基础稿命题；后验收据本地保存）')
t+='\n本批GitHub核验完成（'+now+'）：公开提交'+c['commit']+'，唯一父提交'+c['parent']+'，完整树'+c['tree']+'与本地审计快照一致；'+str(v['files'])+'文件/'+str(v['total_bytes'])+'字节，官方math路径0。7关键文件经GitHub连接器回读逐字节一致。CI '+str(ci['runs'][0]['id'])+'：'+conclusion+'，仅95核心/13配置归档重放/导出/发布审计；不含Lean、人审、第二供应商、EXP076严格Linux或可选NumPy。后验收据仅本地保存，不再推送；WP129与整体目标仍未完成，实质研究输出计数2，下一包后全局046。\n'
if not success:
    t+='远端失败边界：实际核心95及前11归档重放通过，EXP119 raw不一致/summary一致，随后EXP332、导出和发布审计未在远端执行。当前Ubuntu26.04.1/Python3.14.9与之前成功环境不同，但根因未定位，不能仅据环境差异归因浮点。现有重放器未保留失败raw，完整CI日志已压缩保留；后续先建立有界诊断取证，再决定修复，不放宽比较或改旧归档。\n'
p.write_text(t)
assert not subprocess.check_output(['git','diff','9d34ce5','--','data','experiments','src','tests','reports/families','reports/graph'])
assert not subprocess.check_output(['git','-C','math','status','--porcelain'])
assert not (w/'clean').exists()
files=sorted(p for p in w.iterdir() if p.is_file());manifest=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
    for p in files:
        b=p.read_bytes();i=tarfile.TarInfo(p.name);i.size=len(b);i.mtime=0;tar.addfile(i,io.BytesIO(b));manifest.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
    for x in manifest:assert sha(tar.extractfile(x['name']).read())==x['sha256']
(out/'postpublication-helpers-and-receipts.tar.gz').write_bytes(z)
for p in files:p.unlink()
w.rmdir()
save(out/'postpublication-storage.json',{'at':now,'members':manifest,'gzip_bytes':len(z),'compressed_sha256':sha(z),'decompressed_sha256':sha(raw),'roundtrip_members_verified':True,'temporary_directory_removed':not w.exists(),'clean_copy_removed':True,'official_math_copied':False,'postpush_receipts_local_only':True,'public_commit':c['commit'],'CI':conclusion,'scientific_data_and_graph_unchanged':True,'goal':'active_incomplete'})
print(json.dumps({'public_commit':c['commit'],'CI':conclusion,'compressed_members':len(files),'temporary_directory_removed':True,'no_second_push':True}))
