from pathlib import Path
from datetime import datetime, timezone
import json, gzip, tarfile, io, hashlib

r = Path.cwd(); w = Path(__file__).parent
out = r / 'reports/reproducibility/20261029-publication'
now = datetime.now(timezone.utc).isoformat()
q = json.loads((out / 'quality.json').read_text())
assert q['core_exit_code'] == 0 and q['clean_core_tests'] == 95
assert q['clean_directory_removed'] and q['full_JSON_GraphML_objects_equal']
def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p = r / 'state/checkpoint.json'; c = json.loads(p.read_text()); c['saved_at'] = now
c['publication_work'].update(status='checks_passed_pending_exact_audit_push_readback_ci', current_batch_qa=q, scientific_local_commit='9d34ce5', prepush_audit='reports/reproducibility/20261029-publication/final-audit.json.gz')
c['current_goal_turn_classification'] = {'this_turn':'progress', 'evidence':'Explicit owner-requested publication batch of existing partial curation; bilingual entry docs synchronized and software/data QA completed. No new research count or WP closure.', 'goal':'active_incomplete'}
save(p,c)
p = r / 'state/publication.json'; d = json.loads(p.read_text()); d['pending_batch']['status'] = 'checks_passed_pending_exact_audit_push_readback_ci';save(p,d)
with (r/'state/status.md').open('a') as f:
    f.write('\n发布前质量闭包（'+now+'）：本地95核心与无math干净副本95项均无跳过通过；完整JSON/GraphML对象、18科学归档378源码成员核验。规范数据、科学实现及图谱保持9d34ce5，沿用其181旧单种子/2多种子、8方法及39证明接口核验。干净副本'+str(q['files'])+'文件/'+str(q['bytes'])+'字节已逐项核散列并删除。精确索引审计、推送与远端回读/CI分别待执行；不增加研究计数。\n')
entries=['prepare.py','qa.py','final_prepare.py','core.log','no-math-core.log','qa.log']
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for n in entries:
        b=(w/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;t.addfile(i,io.BytesIO(b))
raw=buf.getvalue();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for n in entries: assert t.extractfile(n).read()==(w/n).read_bytes()
(out/'final-prepublication-helpers-and-logs.tar.gz').write_bytes(z)
print(json.dumps({'quality_passed':True,'core':95,'clean':95,'files':q['files'],'bytes':q['bytes'],'helper_members':len(entries),'sha256':hashlib.sha256(z).hexdigest()}))
