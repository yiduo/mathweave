from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,hashlib,json,re,subprocess,sys
sys.path.insert(0,'src')
from ai_value.graph import load,validate
from ai_value.source_results import named_results
r=Path.cwd();w=Path(__file__).parent;now=datetime.now(timezone.utc).isoformat()
G='GEN-20261027-116';F='F-337';UP='1581d4cbdd69a0faf34b2089614fe2a814316a6a';M={'smooth':'P-9808a190babfbe20','CAT0':'P-85565211ca1088a3'}
np=r/'data/graph/nodes.jsonl';ep=r/'data/graph/edges.jsonl';cp=r/'data/graph/reading_coverage.json'
on=np.read_bytes();oe=ep.read_bytes();oc=cp.read_bytes();by={n['id']:n for n in map(json.loads,on.decode().splitlines())}
assert len(by)==5275 and G not in by and 'ANALYSIS-F-337' not in by
allnodes,_=load(r);assert all(x in allnodes for x in [F,*M.values()])
s=json.loads((w/'qualification.json').read_text());j=json.loads((r/'state/reading-progress/WP-119.json').read_text())
hist=json.loads((r/'data/provenance/readings/F-337-history.json').read_text());formal=json.loads((r/'data/provenance/readings/F-337-formal.json').read_text())
assert j['actual_source_lines_read']==7413 and len(j['actual_source_ranges'])==28 and not j['canonical_credit_added']
new=[];edges=[];keys={(e['source'],e['relation'],e['target']) for e in map(json.loads,oe.decode().splitlines())}
def save(p,d):
 p=r/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def src(p,loc):return {'path':p,'locator':loc,'commit':UP if p.startswith('math/') else None,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()}
def add(id,kind,props,sources,status='source_claim'):
 assert id not in by,id
 n={'id':id,'kind':kind,'version':1,'created_at':now,'evidence_status':status,'properties':{'model_generation_id':G,'dependency_closure_complete':False,**props},'sources':sources};by[id]=n;new.append(n);return n
def edge(a,rel,b,loc):
 if (a,rel,b) in keys:return
 keys.add((a,rel,b));edges.append({'id':'E-'+hashlib.sha256((a+'|'+rel+'|'+b).encode()).hexdigest()[:16].upper(),'source':a,'relation':rel,'target':b,'version':1,'created_at':now,'evidence_status':'source_claim','source_commit':UP,'source_locator':loc})
def cid(ms,label):return 'CLM-337-'+('GCH' if ms=='smooth' else 'CAT0')+'-'+re.sub('[^A-Za-z0-9]+','-',label).strip('-').upper()
fp='data/provenance/readings/F-337-formal.json';hp='data/provenance/readings/F-337-history.json';lp='data/provenance/readings/F-337.json'
files=j['actual_source_ranges'];paths={f['path'] for f in files};rows=[];labels={};bysource={};includes=[];biblios={};entries={}
for f in files:
 path=f['path'];t=(r/path).read_text();assert f['complete_file_read'] and hashlib.sha256((r/path).read_bytes()).hexdigest()==f['sha256']
 assert f['ranges']==[[1,len(t.splitlines())]],path
 ms='smooth' if 'Generalized-Cartan' in path else 'CAT0';bysource[path]={}
 build=Path(path.split('/build/')[0]+'/build')
 for m in re.finditer(r'\\(?:input|include)\s*\{([^}]+)\}',t):
  target=str(build/(m[1]+('' if Path(m[1]).suffix else '.tex')));assert target in paths,target;includes.append({'source':path,'target':target,'read':True})
 for v in named_results(t):
  label=v['label'];assert label in s['claims'][ms] and (ms,label) not in labels
  id=cid(ms,label);labels[ms,label]=id;bysource[path][label]=id;title,cond=s['claims'][ms][label]
  rows.append({'id':id,'manuscript':ms,'manuscript_id':M[ms],'label':label,'kind':v['kind'],'path':path,'sha256':f['sha256'],'statement_lines':[t.count('\n',0,v['statement_start'])+1,t.count('\n',0,v['statement_end'])+1],'statement_tex':t[v['statement_start']:v['statement_end']].strip(),'summary':title,'conditions':cond,'source_claim_grade':'B' if ms=='CAT0' and label=='thm:main' else 'C','aliases':v['label_aliases']})
 if path.endswith('.bib'):
  matches=list(re.finditer(r'^@\w+\s*\{([^,]+),',t,re.M));biblios[ms]={}
  for i,m in enumerate(matches):
   key=m[1];entry=t[m.start():matches[i+1].start() if i+1<len(matches) else len(t)].strip()
   biblios[ms][key]='LIT-337-'+re.sub('[^A-Za-z0-9]+','-',key).strip('-').upper();entries.setdefault(key,[]).append({'manuscript_id':M[ms],'path':path,'entry':entry,'lines':[t.count('\n',0,m.start())+1,t.count('\n',0,m.start()+len(entry))+1]})
assert len(rows)==54 and len(labels)==54 and all(not x['aliases'] for x in rows)
assert len(entries)==46 and sum(map(len,biblios.values()))==57
assert sum(len((r/f['path']).read_text().splitlines()) for f in files)==7413
verified={x['key']:x for x in hist['rows']};assert len(verified)==4 and set(verified)<=set(entries)
bmap={key:'LIT-337-'+re.sub('[^A-Za-z0-9]+','-',key).strip('-').upper() for key in entries}
gaps=[
 'Current two manuscripts fully read and54named+1selectedunlabelled result bindings curated; not all historical proof versions, complete family or mathematical proof review.',
 'Only4/46 unique historical roots checked in selected actual original scopes;42 original roots andrecursive proofs remain unqualified.57 bibliography occurrences retained per manuscript,not57 distinct works.',
 'Only second manuscript sharp integral filling main andexistential Euclidean coefficient-optimality substatement have selected local sourceB. Other53 sourceC;all full dependency chains unknown. No local Lean build,Comparator orhuman specification review.',
 'Lexical indices330localfiles2262declarations and112files708declarations are not442mathematicallyread files;zero lexical placeholders/localaxioms doesnot establish proof acceptance orMathlib closure.',
 'No new candidate/card/externalcheck/numericalrun. Scalar C1-through-zero autodiff transfer is retained for separate frozen hypothesis comparison. No training/performance/newalgorithm gain asserted;old correct calculus/branch handling may suffice.',
 'No generic discrete curvature oracle,finite-computation certificate,near-equality stability orprescribed-topology filling algorithm follows. Full chord inequalities needthe hypothetical extremizer andspecific normalized PDEminimizer.',
 'Human grades/specifications,independent second provider andpilots absent;selected OpenAI session exact backend unknown. No routine GitHub push;readonlymath unchanged.'
]
config='data/provenance/research-at-generation-116.json';(r/config).write_bytes((r/'configs/research.json').read_bytes())
upath=next(f['path'] for f in files if f['path'].endswith('/08-classical.tex'));ut=(r/upath).read_text();ustart=ut.index('To see that the coefficient');ulines=[ut.count('\n',0,ustart)+1,len(ut.splitlines())]
unlabel='CLM-337-CAT0-COEFFICIENT-OPTIMAL-EXISTENCE'
ledger={'family_id':F,'work_package':'WP-119','generation_id':G,'at':now,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'upstream_commit':UP,'manuscript_ids':list(M.values()),'read_files':files,'actual_read_ranges':'All28TeX/Bib7413lines:3432smooth and3981CAT0;bothREADMEs previouslyread;noPDFpixels','source_sections':list(bysource),'source_tex_lines':7413,'include_links_checked':includes,'results':rows,'unlabelled_results':[{'id':unlabel,'path':upath,'statement_lines':ulines,'selected_statement':'For every integer n>=2 there exists a nonzero compactly supported integral Euclidean n-cycle for which every compact integral filling has mass at least c_n*M(T)^((n+1)/n).','source_paragraph':ut[ustart:].strip(),'qualification':'Only existential optimality substatement assigned sourceB,not claim all sphere radii formally checked.'}],'methods':s['methods'],'domain_attempts':s['domains'],'cross_family_attempts':s['cross_family'],'historical_references_by_key':bmap,'historical_references_by_manuscript':biblios,'bibliography_entries_by_key':entries,'historical_external_work_count':46,'historical_selected_originals':hp,'unread_or_unqualified_original_root_ids':[bmap[k] for k in entries if k not in verified],'formal_status':fp,'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'new_candidates':0,'new_initial_checks':0,'numeric_or_symbolic_run':False,'gaps':gaps,'third_party_acquired_bytes':hist['bytes'],'third_party_republication':False,'dependencies_installed':False,'github_push':False}
save(lp,ledger);ls=src(lp,'Both current manuscripts complete source scopes;54named+1unlabelled bindings/18methodcontracts,selectedformal/historyboundaries')
for key,es in entries.items():
 props={'title':key,'bibliography_key':key,'bibliography_entries_by_manuscript':es,'retrieval_status':'upstream_bibliography_only','verified_scope':'All sourcebibliography entries actuallyread;originalbody notqualified.','full_original_proof_review':False,'credibility':'unknown'}
 ss=[src(e['path'],'Bibliography '+key+';lines'+str(e['lines'])) for e in es];status='source_claim'
 if key in verified:
  h=verified[key];scope=h['actually_read_selected_text_scope'];props.update(retrieval_status='selected_original_scope_checked',verified_scope=scope['statement'],source_use_match=scope['match'],limitations=scope['limit'],selected_scope_locator=scope['locator'],actual_text_ranges=scope['ranges']);ss.append({'url':h['url'],'sha256':h['sha256'],'source_file_sha256':h['sha256'],'locator':scope['locator'],'content_checked':True,'checked_at':h['requested_at']});status='source_content_checked'
 add(bmap[key],'literature',props,ss,status)
for x in rows:
 props={'title':x['summary'],'statement':x['summary'],'statement_tex':x['statement_tex'],'conditions':[x['conditions']],'family_ids':[F],'manuscript_id':x['manuscript_id'],'source_label':x['label'],'source_statement_lines':x['statement_lines'],'credibility':x['source_claim_grade'],'source_claim_grade':x['source_claim_grade'],'dependency_chain_grade':'unknown','constants_and_constructions':['Exact formulas andconstants retained in statement_tex;contextual hypotheses inconditions;not a numericalimplementation oracceptedproof.']}
 ss=[copy.deepcopy(ls),src(x['path'],x['label']+';lines'+str(x['statement_lines'])+';whole containing fileactuallyread')]
 if x['source_claim_grade']=='B':ss.append(src(fp,'Actual selected sharpfilling signature,Model/Main andComparator wrappers read;not build/specaudit'))
 add(x['id'],'claim',props,ss);edge(x['id'],'member_of',F,'Current source statement');edge(x['id'],'derived_from',x['manuscript_id'],'Fixed current manuscript')
add(unlabel,'claim',{'title':'欧氏积分填充系数的存在式最优性','statement':ledger['unlabelled_results'][0]['selected_statement'],'statement_tex':ut[ustart:].strip(),'conditions':['Only existential nonzero Euclidean cycle,integern>=2,all compact integral fillings;formal endpoint doesnot claim everyR. Whole-source ball paragraph proves broader natural argument;selected B is explicitlylimited.'],'family_ids':[F],'manuscript_id':M['CAT0'],'source_statement_lines':ulines,'credibility':'B','source_claim_grade':'B','dependency_chain_grade':'unknown','constants_and_constructions':['c_n=1/((n+1)*s_n^(1/n));nonzero integer cycle andcompact integral fillings.']},[copy.deepcopy(ls),src(upath,'Unlabelled sharpness paragraph;lines'+str(ulines)),src(fp,'Actual coefficient_optimal Main60-81;existential quantifier scope only')]);edge(unlabel,'member_of',F,'Selected unlabelled source substatement');edge(unlabel,'derived_from',M['CAT0'],'Current source');edge(unlabel,'depends_on',labels['CAT0','lem:top-dimensional-constancy'],'Compact all-filling difference is zero;natural optimality route')
deps={
 'smooth':{'thm:main':['thm:normalized-comparison','lem:smooth-bv-approximation','lem:finite-volume-cutoff'],'thm:equality':['prop:equality-boundary','lem:equality-cutoffs','lem:distance-comparison','lem:balancing'],'cor:model-ball-spectral':['thm:main'],'lem:comparison-maps':['lem:distance-comparison'],'thm:extrinsic-sobolev':['lem:square-estimate','lem:subthreshold-minimizer','lem:balancing'],'lem:square-estimate':['lem:comparison-maps'],'lem:subthreshold-minimizer':['lem:local-sobolev-threshold'],'prop:confined-regularity':['lem:bv-compactness'],'lem:profile-lipschitz':['prop:confined-regularity','lem:bv-flow'],'lem:profile-curvature':['prop:confined-regularity','lem:bv-flow'],'lem:area-growth':['lem:bv-deletion','prop:confined-regularity','lem:bv-flow'],'lem:constant-test':['thm:extrinsic-sobolev','lem:capacity-cutoffs','lem:area-growth'],'prop:profile-ode':['lem:constant-test','lem:profile-curvature','lem:profile-lipschitz'],'thm:normalized-comparison':['prop:profile-ode'],'prop:equality-boundary':['thm:main','lem:equality-graph-regularity'],'lem:equality-cutoffs':['prop:equality-boundary','lem:capacity-cutoffs']},
 'CAT0':{'thm:main':['lem:compact-reduction','prop:base','lem:chord-density','lem:opposite-average'],'cor:cartan-hadamard':['thm:main','lem:top-dimensional-constancy'],'lem:extremizer':['thm:current-background'],'prop:chart-mass':['lem:euclidean-chart-metrics','lem:quadratic-mass'],'lem:euclidean-density':['prop:chart-mass'],'prop:radial':['lem:extremizer','lem:quadratic-mass','prop:chart-mass'],'prop:base':['prop:radial','lem:euclidean-density'],'prop:small-set':['lem:extremizer','thm:current-background'],'lem:intrinsic-coarea':['lem:countable-mass-tests','prop:chart-mass'],'lem:rearranged-energy':['lem:intrinsic-coarea','prop:small-set'],'prop:almost-sobolev':['lem:rearranged-energy','lem:radial-sobolev'],'prop:sobolev-space':['prop:almost-sobolev','prop:chart-mass'],'prop:compact-embedding':['prop:sobolev-space'],'prop:minimizer':['prop:almost-sobolev','prop:compact-embedding'],'lem:powers':['prop:minimizer','prop:sobolev-space'],'lem:composites':['lem:powers','prop:sobolev-space'],'lem:chord-tests':['lem:composites'],'lem:completed-radial':['prop:radial','prop:sobolev-space'],'prop:chord-transform':['lem:chord-tests','lem:completed-radial','prop:minimizer'],'lem:chord-density':['prop:chord-transform','lem:euclidean-density'],'lem:opposite-average':['prop:minimizer','lem:powers']}}
for ms,mapping in deps.items():
 for child,parents in mapping.items():
  for parent in parents:edge(labels[ms,child],'depends_on',labels[ms,parent],'Actual natural manuscript proof input with full contextual qualifiers;not equivalence toformal proof route')
# Induction is typed separately: do not create a same-dimensional main-theorem cycle.
edge(labels['CAT0','prop:small-set'],'lower_dimension_induction',labels['CAT0','thm:main'],'Requires sharp n-1 dimension,not same-dimensional result;base n=2 separatelybound')
required=[('smooth','prop:confined-regularity','GhomiSpruck2022'),('smooth','cor:model-ball-spectral','NobiliViolo2025'),('CAT0','lem:euclidean-chart-metrics','Duda2007'),('CAT0','lem:euclidean-chart-metrics','Kirchheim1994'),('CAT0','thm:current-background','Wenger2005Iso')]
for ms,label,key in required:edge(labels[ms,label],'depends_on',bmap[key],'Selected exact historical interface;unreviewed original proofs keep chainunknown')
for x in rows:
 t=(r/x['path']).read_text();start=t.index('\\label{'+x['label']+'}');nxt=t.find('\\begin{',t.find('\\end{'+x['kind']+'}',start)+1)
 # Historical mentions are context only; manual proof-input list above is authoritative.
 for chunk in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',t):
  for key in chunk.split(','):
   key=key.strip()
   if key in bmap:edge(x['id'],'historical_context',bmap[key],'Bibliographic context in fullyread containing source module;not inference that every cited result is mandatory proofinput')
methodids=[]
for key,title,inp,out,ms,label,limit in s['methods']:
 id='PART-337-'+key;methodids.append(id);x=next(v for v in rows if v['manuscript']==ms and v['label']==label)
 add(id,'method',{'title':title,'input':inp,'output':out,'conditions':x['conditions'],'cannot_transfer':limit,'family_ids':[F],'credibility':'C','dependency_chain_grade':'unknown'},[copy.deepcopy(ls),src(x['path'],label+';conditional transfer contract fromactualsource')]);edge(id,'depends_on',x['id'],'Actual qualified methodsource,not applicationvalidation')
add('PROB-337-DISCRETE-CERTIFICATE','problem',{'title':'连续曲率与质量界到离散证书的桥接缺口','statement':'Need actual CAT0/smoothcurvature,integercurrentmass,boundary/domain anddiscretizationerror certificates beforegeometric application;sharp existence alone doesnot provide algorithms.','family_ids':[F],'credibility':'unknown','prerequisite_status':'not_admitted'},[copy.deepcopy(ls)],'hypothesis')
add('PROB-337-ZERO-COMPOSITE-AD','problem',{'title':'零门控特征的C1复合与实际自动微分一致性','statement':'Audit F(r,z)=z*(1+a*kappa²*r²*z^(2beta))^(-1/(2beta)),beta=1/(n-2),z>=0,extendF=z onz<=0. Full scalar composite C1 atzero even when fractional factor derivative singular. Compare actual AD formulation with independent analytic/highprecision derivative andold correct pre-operation branch;no target outputs orfault/performance claim yet.','family_ids':[F],'credibility':'unknown','prerequisite_status':'promising_separate_specification_required','nonblind_algebraic_prediction':True,'actual_AD_execution':False},[copy.deepcopy(ls)],'hypothesis');edge('PROB-337-ZERO-COMPOSITE-AD','references','PART-337-C1-ZERO-COMPOSITE','Concrete future scalar application interface;fullgeometric assumptions not asserted forML')
expl=add('EXPLORE-F-337','exploration',{'title':'F337十领域与三跨族条件探索','family_ids':[F],'attempts':[{'domain':d,'analogy':a,'assessment':v,'accepted_connection':False} for d,a,v in s['domains']],'cross_family_attempts':s['cross_family'],'new_connection_ids':[],'interpretation':s['reason_no_candidate'],'credibility':'unknown'},[copy.deepcopy(ls)],'hypothesis')
for id in methodids:edge(expl['id'],'uses',id,'Conditional exploration;not externalcheck')
for x in s['cross_family']:assert x['existing_method'] in by;edge(expl['id'],'references',x['existing_method'],'Cross-family comparison only;no joint theorem dependency')
add('ANALYSIS-F-337','family_analysis',{'title':'F337光滑模型等周与CAT0积分填充两稿源码草稿','family_id':F,'family_ids':[F],'manuscript_ids':list(M.values()),'manuscript_source_drafts_complete_ids':list(M.values()),'source_sections':list(bysource),'source_line_count':7413,'result_ids_by_label':{ms+'::'+label:id for (ms,label),id in labels.items()},'result_ids_by_source':bysource,'unlabelled_result_ids':[unlabel],'method_ids':methodids,'formal_statement_comparison':formal['selected_comparison'],'formal_status':{'evidence':fp,'indices':formal['indices'],'local_lean_build':False,'comparator_run':False,'human_spec_review':False,'complete_proof_or_axiom_audit':False},'historical_references_by_key':bmap,'historical_references_by_manuscript':biblios,'historical_verified_keys':list(verified),'source_decomposition_draft_complete':True,'full_family_complete':False,'historical_lineage_complete':False,'gaps':gaps,'credibility':'unknown','completion_basis':'Both28TeX/Bib7413lines,54named+1selectedunlabelledbindings,18contracts;selected formal endpointand4originalscopes.Notfullhistorical/version/proof/human/provider acceptance.'},[copy.deepcopy(ls)],'source_content_checked')
add(G,'generation',{'title':'F337completecurrent source andqualifiedformal/history/transfer scopes','family_ids':[F],'project_base_commit':ledger['base_commit'],'provider':'OpenAI','model':'Current selected session;exactbackendunknown','human_review':None,'independent_second_provider':None,'seed_list_exposed':True,'credibility':'unknown'},[copy.deepcopy(ls),src(config,'Policy snapshot'),src(fp,'Actual selected formal signatures anddefinitions;no build'),src(hp,'Four originalselectedtextscopes;42rootsunreviewed')],'source_content_checked')
cov=json.loads(oc);assert F not in cov['partially_read_families'];archive='data/graph/history/'+G+'-reading-coverage-before.json.gz';z=gzip.compress(oc,mtime=0);assert gzip.decompress(z)==oc;(r/archive).write_bytes(z)
cov['partially_read_families'][F]=['Bothcurrent manuscripts28TeX/Bib7413linesread,54named+1unlabelledselectedbindings/18contracts;notfullfamily/history.','Fourselectedoriginalscopesof46uniqueroots;57bibliographicoccurrences retainedpermanuscript,42rootsandrecursiveproofsunreviewed.','Two selected sourceB/53C,fullchainsunknown;formalstaticindicesnotbuild/proof/specaudit.','Ten domains/three crossfamily attempts;scalarC1zeroAD transfer retainedforseparatespecification,nonewcandidate/check/run.'];cov['source_decomposition_drafts'].append(F);cov.update(updated_at=now,update_reason='WP119actualcompletecurrenttwo-manuscriptsourcequalification;nofullfamily/history/applicationcredit',prior_version_archive=archive)
summary={'generation':G,'base_commit':ledger['base_commit'],'old_records':len(on.splitlines()),'new_records':len(new),'new_explicit_edges':len(edges),'named_bindings':54,'unlabelled_bindings':1,'method_contracts':18,'unique_literature_nodes':46,'bibliography_occurrences':57,'source_B':2,'source_C':53,'new_candidates':0,'new_application_checks':0,'new_scientific_experiments':0,'new_record_ids':[n['id'] for n in new]}
try:
 np.write_bytes(on+''.join(json.dumps(n,ensure_ascii=False,sort_keys=True)+'\n' for n in new).encode());ep.write_bytes(oe+''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges).encode());save('data/graph/reading_coverage.json',cov);summary['initial_graph_validation']=validate(r)
except Exception as e:
 (w/'unaccepted-curation-failure.json').write_text(json.dumps({'error':str(e),'type':type(e).__name__,'summary':summary,'rollback':'nodes/edges/coverage restored;newsource evidence retained'},ensure_ascii=False,indent=2)+'\n');np.write_bytes(on);ep.write_bytes(oe);cp.write_bytes(oc);raise
assert np.read_bytes().startswith(on) and ep.read_bytes().startswith(oe)
(w/'curation-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='new_record_ids'},ensure_ascii=False))
