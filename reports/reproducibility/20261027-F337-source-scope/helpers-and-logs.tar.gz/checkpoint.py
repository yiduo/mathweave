from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,shutil
r=Path.cwd();w=Path(__file__).parent;now=datetime.now(timezone.utc).isoformat();out=r/'reports/reproducibility/20261027-F337-source-scope';out.mkdir(exist_ok=True)
def read(p):return json.loads((r/p).read_text())
def save(p,d):
 p=r/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=json.loads(gzip.decompress((w/'quality.json.gz').read_bytes()));assert len(q['impact_cases'])==115 and len(q['alternative_route_cases'])==2
assert 'Ran 75 tests' in (w/'core.log').read_text() and '\nOK\n' in (w/'core.log').read_text()
rep=json.loads((w/'retro042-adverse-replay.json').read_text());assert all(rep['deterministic_outputs_match'].values()) and rep['replay_resource_envelope_met']
shutil.copyfile(w/'quality.json.gz',out/'quality.json.gz');shutil.copyfile(w/'curation-summary.json',out/'curation.json')
for name in ['core.log','retro042-adverse-replay.json','retro042-adverse-replay.log']:
 b=(w/name).read_bytes();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(out/(name+'.gz')).write_bytes(z)
save(out/'failures.json',{'at':now,'scientific_experiment_failures_added':0,'curation_prewrite_failures':[{'attempt':1,'log':'curation-attempt1.log','reason':'External TeX-distribution glyphtounicode treated as local proof include;no canonical write occurred.'},{'attempt':2,'log':'curation-attempt2.log','reason':'Incorrect optional-load guard assumption;actual glyph-mappings first line directly inputs external TeX glyph table. No canonical write occurred.'}],'final_resolution':'External typesetting dependency explicitly recorded as unread,not manuscript/proof module;no TeX install/compilation or extra reading credit. Third curation accepted.','diagnostic_only_errors':['Temporary index-printing Python unmatched parenthesis,corrected;no state mutation.','Optional legacy method title key absent,corrected to get;no state mutation.','Wrong guessed scripts/replay_experiment.py path missing;actual scripts/replay_run.py used,exact replay passed.'],'Duda_transport':'Web-tool timeout;official directTLS acquisition succeeded,hashed.','failed_paths_to_avoid':['Do not rerun one-shot accepted GEN116 curator.','Do not download glyph support orrepeat scientific experiment to regenerate metrics.']})
# Preserve exact two failed helper versions as well as logs.
current=(w/'curate.py').read_text()
start=current.index("  target=str(build/");end=current.index(" for v in named_results",start)
v1="  target=str(build/(m[1]+('' if Path(m[1]).suffix else '.tex')));assert target in paths,target;includes.append({'source':path,'target':target,'read':True})\n"
v2=current[start:end].replace("assert path.endswith('/glyph-mappings.tex')","assert '\\\\IfFileExists{glyphtounicode.tex}' in t").replace('External TeX PDF textglyph support,not local manuscript/proof module;not downloaded or credited. No typesetting compilation performed.','Optional PDF textglyph support,not manuscript/proof module;not downloaded or credited')
(w/'curate-attempt1.py').write_text(current[:start]+v1+current[end:]);(w/'curate-attempt2.py').write_text(current[:start]+v2+current[end:])
metrics=read('reports/metrics.json');j=read('state/reading-progress/WP-119.json');j.update(status='canonical_source_curated_quality_core_pass_clean_pending',canonical_credit_added=True,canonical_generation='GEN-20261027-116',selected_history_receipt='data/provenance/readings/F-337-history.json',next_action='Run no-math clean check,compress/verify/delete temporary sources andhelpers,closeWP119/global042,thenWP120 actualAD interface andfrozen candidate/specification preparation.',updated_at=now);save('state/reading-progress/WP-119.json',j)
c=read('state/checkpoint.json');task=c['next_work_package'];assert task['id']=='WP-119';task.update(next_action=j['next_action'],execution_progress={'actual_source_lines_read':7413,'total_inventory_lines':7413,'complete_source_files_read':28,'canonical_credit_added':True,'generation':'GEN-20261027-116','scientific_runs':[],'quality_core_passed':True,'clean_pending':True});c.update(updated_at=now,metrics=metrics,active_work_package=task,next_work_package=task,last_quality_evidence=str((out/'quality.json.gz').relative_to(r)));c['previous_goal_turn_classification']={'classification':'progress','evidence':'WP119 full current-source qualification,124newcanonicalrecords/471edges,54named+1unlabelled/18contracts,fullgraph115single+2multi-seedchecks,75core,andactualadversereplay;clean/storageclosurepending.'};save('state/checkpoint.json',c)
b=read('state/backlog.json')
for key,values in b.items():
 if isinstance(values,list):
  for i,x in enumerate(values):
   if isinstance(x,dict) and x.get('id')=='WP-119':values[i]=task
b['updated_at']=now;save('state/backlog.json',b)
status=r/'state/status.md';parts=status.read_text().split('\n\n');assert parts[0]=='# 当前状态';parts[1]='更新时间：'+now+'。总目标继续执行，第一阶段未完成。当前数值以本段、reports/metrics.json和末尾工作包闭包为准；以下历史段落保留当时口径。';parts[3]='规范图谱当前8553节点、24773关系，9399规范来源注释（9389核心）；62族实际阅读、57族当前全文草稿。46候选／14初检／14不同假设，6限定支持、8不利；完整族／历史／真人／第二供应商／试点仍0。WP119完成F337两稿7413行资格入图、54具名+1无标签绑定／18契约，2来源B／53C／全链未知。四历史原作仅选定范围，另42根及递归证明缺口保留。115单种子及2多种子传播、全图导出、16归档298成员和75核心已通过；干净目录与压缩清理待最终收据。复盘042决定下一WP120真实轻量AD接口／候选／冻结规格准备，未产生新目标数值。日常本地保存提交，重要里程碑合并发布，无GitHub写入。';status.write_text('\n\n'.join(parts))
line=f'WP119规范检查点（{now}）：F337两稿28TeX/Bib7413行，54具名+1选定无标签结果、18契约、57书目处／46作品及四原作选段入图。124新增规范471显式边，全部5275旧规范及480科学／测试／语料／历史报告文件保持。62阅读／57当前源草稿，46候选／14初检不增。全图8553节点24773关系／9399规范来源，115单种子+2多种子／16归档298成员／75核心及EXP325完整不利重放通过；无math干净目录与清理待闭包，不宣告包完成。复盘042已写，WP120先真实AD原语／完整候选／规格与辅助意见，目标输出前冻结，正确旧分支可能已足够。'
with status.open('a') as f:f.write('\n\n'+line+'\n')
print('checkpoint saved;clean pending;no targetAD outputs')
