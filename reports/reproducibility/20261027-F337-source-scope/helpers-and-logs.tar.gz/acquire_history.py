from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import urllib.request,json,hashlib,subprocess
w=Path(__file__).resolve().parent
urls={'Duda2007':'https://ems.press/content/serial-article-files/35596','Wenger2005Iso':'https://arxiv.org/pdf/math/0306089v1','GhomiSpruck2022':'https://arxiv.org/pdf/1908.09814v7','NobiliViolo2025':'https://arxiv.org/pdf/2409.14182v2'}
def fetch(item):
 key,url=item;d={'key':key,'url':url,'requested_at':datetime.now(timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MathWeave primary-source scope research'}),timeout=35) as resp:
   b=resp.read(2*1024**2+1);d.update(status=resp.status,final_url=resp.url,content_type=resp.headers.get('Content-Type'));assert len(b)<=2*1024**2 and b.startswith(b'%PDF')
  p=w/(key+'.pdf');p.write_bytes(b);t=w/(key+'.txt');cmd=['/opt/homebrew/bin/pdftotext','-layout',str(p),str(t)];result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert result.returncode==0
  tb=t.read_bytes();d.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),temporary_pdf=str(p),temporary_text=str(t),text_sha256=hashlib.sha256(tb).hexdigest(),text_lines=len(tb.splitlines()),text_bytes=len(tb),conversion_command=cmd,conversion_exit=result.returncode,conversion_stderr=result.stderr.decode())
 except Exception as e:d['error']=repr(e)
 return d
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,urls.items()))
assert sum(x.get('bytes',0) for x in rows)<=8*1024**2
d={'at':datetime.now(timezone.utc).isoformat(),'scope':'Selected primary original statement checks only; full originals and recursive proofs not inferred','rows':rows,'bytes':sum(x.get('bytes',0) for x in rows),'web_transport_failure':'Duda EMS web-tool timeout; directofficial TLS attempted separately,no inference of missing source.'}
(w/'history-acquisition.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
for row in rows:print(json.dumps(row,ensure_ascii=False))
