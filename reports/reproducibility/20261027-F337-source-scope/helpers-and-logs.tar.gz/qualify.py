from pathlib import Path
import json
w=Path(__file__).parent
S='Smooth complete simply connected ambient manifold; Sec<=-b², b=0 or1 when normalized. m=n-1>=3 for hypersurface critical arguments. Full ambient perimeter includes obstacle contact. '
C='Compact CAT(0) Y, AK integral currents with integer multiplicity and disjoint bi-Lipschitz Borel charts. '
E=C+'Hypothetical positive filling-deficit maximizing n-cycle A, rescaled as in 02-currents and 03-radial; mu=mass(A). Not an arbitrary data cloud. '
V=E+'n>2, sharp lower-dimensional filling induction, beta=1/(n-2), p=2n/(n-2), normalized nonnegative critical minimizer v with 0<W=int(v^p)<s_n, Q(v)=nW. '
smooth={
'thm:main':('完整流形上有限体积、有限环境周长集的模型等周比较','n>=2, Sec<=kappa<=0; E may be unbounded; P(E)>=I_sqrt(-kappa)(vol E). No claim of constructive minimization or discrete curvature certification.'),
'thm:equality':('有界正体积等号区域的整域欧氏球刚性','Sec<=0; E bounded, positive finite volume and finite full perimeter. Equality is modulo ambient null sets, with induced metric on the entire occupied region Euclidean. No ambient flatness outside or quantitative near-equality estimate.'),
'cor:model-ball-spectral':('相同体积模型球的Dirichlet p谱下界与扭转上界','Smooth boundaryless ambient n>=2, Sec<=kappa<=0; nonempty smooth relatively compact D; 1<p<infinity. lambda_1,p lower, source-normalized T_p upper; rearrangement and radial Dirichlet membership required. No mesh error or algorithm speed claim.'),
'lem:comparison-maps':('正比较权重与球面映射的微分及Hessian控制',S+'Explicit center p and scale a>0, smooth positive f=e^u and Phi; |dPhi X|<=f|X| and source quadratic-form Hessian upper bound, including joint smoothness after parallel transport.'),
'lem:distance-comparison':('距离平方强凸、指数映射度量支配与对数映射压缩','Sec<=0, complete simply connected smooth M. Hess(d_p²/2)>=g, exp_p pullback metric>=g_p, dlog contraction. Does not compare arbitrary learned dissimilarities.'),
'lem:balancing':('无原子紧支撑概率的有限尺度配平',S+'Probability mu compactly supported in B_D(o), every singleton has zero mass. Exists center p in B_D(o) and finite a>0 with integral Phi=0. Atomic empirical data do not satisfy the statement; Brouwer argument is not a complexity bound.'),
'thm:extrinsic-sobolev':('不必完备超曲面上的锐Sobolev形式界',S+'Locally C11 immersed hypersurface, compact interior Lipschitz tests or H10(U) zero extension. q=2m/(m-2), c=4/(m-2), Ym=m*s_m^(2/m); Q includes signed h through m(h²-b²).'),
'lem:square-estimate':('比较映射下的曲率势与梯度平方分解',S+'Same compact-interior/H10 tests, alpha=(m-2)/2; source f,Phi and outward-normal convention. Both lower bounds and nonnegativity of Q retained; no discretization equality asserted.'),
'lem:local-sobolev-threshold':('局部次临界阈值与L2紧嵌入',S+'Every U relatively compact in regular interior and epsilon>0; finite C_epsilon,U, not uniform algorithmic constant. H10 uses actual closure, no smooth boundary required.'),
'lem:subthreshold-minimizer':('严格低于锐阈值时的极小值达到',S+'Nonempty relatively compact U; constrained Lq norm1 and Y(U)<Ym strictly. Used in contradiction proof, not critical attainment or a solver.'),
'prop:confined-regularity':('围限等周极小集的自由及接触边界正则性',S+'0<v<vol B in fixed geodesic ball. Compact singular set S inside B, Hausdorff dim<=n-8, empty if n<8; regular boundary locally C11, smooth on free part, C11 collar at wall, full perimeter represented by regular area.'),
'lem:profile-lipschitz':('围限完整周长剖面的正性与局部Lipschitz性',S+'Fixed ball and 0<v<vol B; constants may depend on compact volume interval. Do not assert explicit uniform rate at endpoints.'),
'lem:profile-curvature':('可微体积处剖面导数及有符号曲率约束',S+'Differentiability point of confined profile, outward H=m*h and h0=Iprime/m. Iprime>0, free h=h0, wall 0<=h<=h0 a.e.; h²<=h0² follows, not from an unsigned mean curvature substitution.'),
'lem:bv-deletion':('删除小球的BV周长界与例外半径','Complete smooth M, finite volume/perimeter E and 0<r<inj(x). Added cost full sphere area; perimeter on sphere zero except countably many bounded-interval radii.'),
'lem:area-growth':('删除及固定自由补偿片给奇点面积增长',S+'Actual confined minimizing E with 0<v<vol B. Constants depend on E and B; sigma(Sigma∩B_r(x))<=C*r^m for x in singular S. Not a generic mesh density oracle.'),
'lem:capacity-cutoffs':('零容量奇集附近的低能量紧支撑截止','Compact Gamma, closed S; Sigma=Gamma\u2216S boundaryless embedded locally C11 dimension m>=3 and finite area; H^(m-2)(S)=0 and C*r^m area growth. eta_j→1 with vanishing Dirichlet energy; S empty allows1 in all dimensions.'),
'lem:constant-test':('用容量截止合法化完整边界常数检验',S+'Confined profile differentiability volume; m*int(h²-b²)>=Ym*I^((m-2)/m). Noncompact regular locus needs cutoff argument; compact support of Gamma alone does not suffice.'),
'prop:profile-ode':('完整周长剖面的几乎处处微分下界',S+'For a.e. 0<v<vol B, Iprime>=m*sqrt(b²+(s_m/I)^(2/m)). Integrated without presuming a profile endpoint limit.'),
'thm:normalized-comparison':('归一化曲率0或负1的有界集模型比较',S+'n>=4; bounded measurable positive-volume finite-perimeter E. Lower dimensions and general kappa require separate classical inputs and metric scaling.'),
'prop:equality-boundary':('等号类的周长支撑、面积增长与同号CMC','Sec<=0, bounded measurable E, positive volume V and sharp Euclidean perimeter. R=(V/omega_n)^(1/n), H0=(n-1)/R. Statements concern perimeter support and measurable class, not an arbitrary representative topological boundary.'),
'lem:equality-graph-regularity':('弱CMC图方程把C1alpha提升到C11','Smooth Riemannian metric near graph u∈C1alpha_loc, alpha∈(0,1), m>=1; exact weak Euler equation with fixed H0>0 and source L_g,B. Difference quotients/frozen-coefficient oscillation, not assumptions of already bounded second derivatives.'),
'lem:equality-cutoffs':('等号边界上趋于常数的低能量截止','Exact hypotheses of prop:equality-boundary; eta_j∈Lip_c(Sigma),0<=eta<=1,pointwise→1,energy→0; needs singular-set area growth or no singularities.'),
'lem:smooth-bv-approximation':('紧支撑BV集合的严格光滑逼近','Complete connected smooth boundaryless M; E a.e. supported in compact K, finite ambient perimeter; any relatively compact neighborhood U of K. Smooth E_j in U converge in symmetric volume and full perimeter; disconnected E_j allowed.'),
'lem:finite-volume-cutoff':('有界集比较通过coarea截止延伸到无界有限体积集','Complete connected smooth boundaryless M; continuous increasing J>=0,J(0)=0; assumed inequality for all bounded finite-perimeter sets. Retains both finite volume and finite full perimeter on E.'),
'lem:bv-compactness':('共同紧支撑与总变差界的L1紧性','Smooth boundaryless ambient; all u_j vanish outside a fixed compact K, uniformly bounded L1+TV. Subsequence convergence and TV lower semicontinuity; characteristic limits remain characteristic. Not a rate.'),
'lem:bv-flow':('有限周长集在光滑流下的Jacobian与一阶变分','Orientation-preserving smooth diffeomorphism and finite integral RHS; source and target Riemannian adjoints/Jacobians. First variation requires compact perimeter support; common local bounds only fixed finite flow family/support compact.'),
}
cat={
'thm:main':('proper CAT(0)整数循环的锐欧氏系数填充','Proper CAT(0) X; compactly supported integral n-cycle, integer n>=2. Compact integral (n+1)-filling, mass<=c_n*M(T)^((n+1)/n), c_n=1/((n+1)*s_n^(1/n)), s_n=(n+1)*omega_(n+1). Arbitrary integer multiplicity and ambient dimension; no filling topology, algorithm or n=1 extension.'),
'cor:cartan-hadamard':('积分填充结合顶维常性推出光滑域等周界','Cartan-Hadamard manifold d>=3; bounded smooth domain or relatively compact finite-perimeter set. Full ambient perimeter. d=2 needs independent disk inequality; not included by setting n=1.'),
'lem:compact-reduction':('proper闭凸球的非扩张回缩归约','Sharp filling inequality assumed in every compact CAT(0) at fixed cycle dimension; properness makes closed support-containing convex ball compact. Retraction preserves boundary and cannot increase mass.'),
'thm:current-background':('整数流的推前、限制、紧性、图册、积及旧填充输入',C+'k>=1. Borel restrictions may be nonnormal; Lipschitz superlevels integral a.e. Weak compactness requires mass+boundary mass bounds; disjoint signed-integer chart mass summable. Interval product is whole-current. Old K_k,L_k finite with minimizing fillings and weak filling continuity; Euclidean exponent already known.'),
'lem:extremizer':('正填充亏量的假想最大循环',C+'If V(B)-c*M(B)^q0 positive somewhere, positive maximum exists. q0=(n+1)/n. Inequality with arbitrary cycle B follows only for actual maximizing A; no universal point cloud energy principle.'),
'lem:euclidean-chart-metrics':('CAT(0)二点微分产生欧氏图册度量',C+'Almost every density point of bi-Lipschitz chart; positive definite measurable G, N_z(w)^2=w^T G w, J=sqrt(detG). Requires two-moving-point differentiability and CAT(0) parallelogram argument.'),
'lem:quadratic-mass':('二次距离上界控制行列式表示流的质量','Finite-mass d-current with countably many determinant representations, Lipschitz maps, real signed weights and measurable nonnegative quadratic P majorizing squared differential distance; integrable absolute-weight sqrt(detP). This local mass majorant allows real weights; later integer density does not.'),
'prop:chart-mass':('不相交整数图册的精确绝对权质量',C+'Exact Euclidean G from previous lemma, disjoint chart images; mass measure sum pushforward |theta|*sqrt(detG). No cancellation across disjoint images and no assertion each restricted chart is normal.'),
'lem:euclidean-density':('非零整数乘数给欧氏最低密度',C+'Integral k-current; open-ball lower liminf rho^-k mass>=omega_k mass-a.e. Uses |theta|>=1 on nonzero charts; arbitrary real weights invalidate this step.'),
'lem:top-dimensional-constancy':('连通非紧定向流形上紧支撑顶维闭流为零','Connected noncompact oriented Riemannian d-manifold; C integral d-current compact support, boundary0. Used to identify domain filling and round-ball sharpness; noncompactness essential.'),
'prop:radial':('假想极值循环的径向一阶变分界',E+'Every fixed center and nonnegative Lipschitz g; chart inverse metric, |Dr|<=1. Exact determinant is for comparison quadratic form, only an upper majorant of actual deformed mass, not equality of actual metric differential.'),
'prop:base':('紧CAT(0)二维整数循环的基例',C+'Integral two-cycle admits integral3-filling with mass<=M(T)^(3/2)/(6*sqrt(pi)); proof eliminates hypothetical counterexample with inverse-square cutoff. Not n=1 loop statement.'),
'prop:small-set':('低维锐填充归纳给小超水平边界下界',E+'n>2 and sharp n-1 filling induction. Every eta∈(0,1) yields delta∈(0,m/2), independent of u but dependent on setup; integral superlevels only a.e.; P(t)>=(1-eta)*n*omega_n^(1/n)*a(t)^((n-1)/n).'),
'lem:countable-mass-tests':('与流无关的可数标量质量测试族','Any nonempty compact metric Z,k>=1, finite-mass k-current; finite lists of Lipschitz coefficients sum|b|<=1 and1-Lipschitz coordinates. Supremum over countable family equals mass. Does not give finite computable truncation rate.'),
'lem:intrinsic-coarea':('保留内禀梯度和分布奇异部分的coarea界',E+'Real Lipschitz u, actual integral slices a.e. P²<=(-a_acprime)(-e_acprime),P<=Lip(u)*(-a_acprime) a.e. Derivatives are AC densities; atoms and singular continuous parts are permitted.'),
'lem:rearranged-energy':('小支撑分布的等分布欧氏径向能量重排',E+'n>2 and lower-dimensional induction; nonnegative Lipschitz u with mu{u>0}<=delta(eta). All finite positive moments preserved; radial compact Lipschitz ustar, energy<=(1-eta)^-2 E(u). Generalized inverse accounts for atoms/flat regions, no assumption all distribution measures AC.'),
'lem:radial-sobolev':('欧氏径向Lipschitz函数的锐Sobolev常数','n>2,p=2n/(n-2); nonnegative radial nonincreasing compactly supported Lipschitz f. n*s_n^(2/n)||f||p²<=4/(n-2)*DirichletEnergy. Old sharp Sobolev mechanisms, not a new solver.'),
'prop:almost-sobolev':('极值质量空间上的带L2项几乎锐Sobolev界',E+'n>2, sharp n-1 induction; Sstar=n*s_n^(2/n),beta=1/(n-2),p=2n/(n-2). Every epsilon∈(0,Sstar) finite Ceps independent of u, no computed uniform rate.'),
'prop:sobolev-space':('whole-cycle身份闭合图册梯度及Sobolev空间',E+'n>2 and preceding almost-Sobolev input. Quotient functions by mass-a.e.; closed Hilbert chart-covector gradient. Bounded-derivative C1 chain rule, fixed-level gradient0, positive-part continuity, radial nonnegative H tests. Integration by parts on whole cycle before localization, not arbitrary Borel restrictions.'),
'prop:compact-embedding':('加权whole-cycle投影TV给L2紧嵌入',E+'Same n>2 Sobolev setup. H embeds compactly intoL2; chart isolation follows whole-current weighted projections and measure localization. No individual chart normality or quantitative compactness rate.'),
'prop:minimizer':('临界商的归一化非负极小元与弱Euler方程',V+'0<Lambda<Sstar strictly,4beta*int DvDpsi+n*int vpsi=n*int v^(p-1)psi for all psi∈H. Counterexample argument, not arbitrary manifold PDE existence.'),
'lem:powers':('截断与bootstrap给所有有限幂及加权能量',V+'gamma>=1 gives v^gamma∈H∩Lp and actual chain rule; all finite q>0 moments and finite q>=0 weighted energy. Does not imply L∞ or pointwise strict positivity.'),
'lem:composites':('多项式增长C1二变量复合的链法则',V+'r∈H,0<=r<=R and bounded gradient; F jointly C1 on an open neighborhood of strip [0,R]×[0,infinity), F and both derivatives polynomial growth. Fractional v^beta alone is not assumed Sobolev/C1.'),
'lem:chord-tests':('穿过零点的真实C1复合与合法弦检验',V+'a>0,kappa=v(y)^beta for fixed v(y)>0,r=d(y,.),s=kappa*r*v^beta. vw(s),vw(s)² and source g,psi in H. xi explicit through zeros; no assumption s∈H. Scalar F_j extended by z on z<=0 jointlyC1, derivative limits(0,1).'),
'lem:completed-radial':('完成平方后推广到非负H检验的径向界',V+'For every fixed center and nonnegative g∈H, integral(n*g*|Dr|²+r<Dr,Dg>)<=n/4*int r²g. Requires rescaled extremal radial inequality; not unconditional metric-measure claim.'),
'prop:chord-transform':('特定极小元的加权弦变换上界',V+'Every center with v(y)>0,a>=0; J_y(a)<= (1+2aL_y)^(-n/2). nu=v^p mu/W and conformal chords depend on same minimizer; not arbitrary samples or learned weights.'),
'lem:chord-density':('整数切密度给大参数弦变换下界及严格矩上界',V+'nu-a.e. center, liminf a^(n/2)J>=s_n/(2^n W), hence L_y<=2(W/s_n)^(2/n)<2. Uses integral density and selected Lebesgue/approximate continuity properties.'),
'lem:opposite-average':('CAT(0)方差及弱方程给同一弦矩平均下界',V+'Bstar finite positive, I(y) finite continuous, W²<=Bstar*I(y) all y and intL_y dnu>=2. Average distance/value Borel kernel, no joint choice of derivative exceptional sets; contradiction to preceding strict upper only in this setup.'),
}
assert len(smooth)==26 and len(cat)==28
methods=[
('COMPARISON-MAP','光滑比较映射与正权','Hadamard smooth metric,center andpositive scale','sphere-valued Phi plus differential/Hessian controls','smooth','lem:comparison-maps','Needs exact ambient metric/curvature;no empirical curvature oracle'),
('NONATOMIC-BALANCE','无原子配平','compact nonatomic probability in actual Hadamard manifold','center andfinite scale with zero sphere moment','smooth','lem:balancing','Atomic samples and finite-iteration complexity outside statement'),
('SQUARE-SOBOLEV','平方分解到临界Sobolev','locally C11 hypersurface compact-interior tests','sharp Q>=Ym*Lq²','smooth','thm:extrinsic-sobolev','Critical dimension and signed curvature potential retained'),
('BV-REPAIR','删除再固定片修复体积','confined perimeter minimizer','singular-area growth','smooth','lem:area-growth','Not arbitrary reconstructed pointcloud surfaces'),
('CAPACITY-CUTOFF','容量截止合法化常数','finite-area regular locus,zero H^(m-2) singular measure andgrowth','compact tests converge to1 withzeroenergy','smooth','lem:capacity-cutoffs','Requires actual capacity/growth assumptions'),
('PROFILE-INTEGRATE','单调变换积分剖面ODE','positive locallyLipschitz confined profile satisfyingODE','model comparison withoutendpointlimit assumption','smooth','prop:profile-ode','Not an ODE solver error guarantee'),
('BV-EXTEND','严格BV逼近及有限体积截止','bounded comparison andactual ambientBV perimeter','comparison for unboundedfinitevolumeE','smooth','lem:finite-volume-cutoff','Discrete cut perimeter needs separate consistency certificate'),
('EQUALITY-GRAPH','弱图方程正则性提升','C1alpha weakCMC graph in smoothmetric','C11 regularity','smooth','lem:equality-graph-regularity','No noisy near-equality stability or reconstructed derivatives'),
('SPECTRAL-REARRANGE','等周界接径向Dirichlet重排','smooth relativelycompactD,globalmodelprofile,p>1','p-eigenvalue lower/torsion upper','smooth','cor:model-ball-spectral','Exact normalization and membership;no meshcertification'),
('CONVEX-RETRACT','紧凸球回缩','properCAT0 andcompactcycle support','compactworkspace withoutmassgrowth','CAT0','lem:compact-reduction','Properness,integrality andnonexpansive mapmustbeverified'),
('TWO-POINT-METRIC','二点微分恢复欧氏图册','biLipschitzBorelchart intoCAT0','measurablepositiveG andexactmassdensity','CAT0','prop:chart-mass','Mass uses absoluteinteger multiplicity;notarbitrarysignedweights'),
('QUADRATIC-MAJORANT','二次距离上界到质量上界','finite determinant-integralrepresentation andquadraticdistance bound','pushforwardabsoluteweightsqrt(detP) uppermeasure','CAT0','lem:quadratic-mass','Comparisonformdeterminant exactbutactualmapmass generallynot'),
('WHOLE-CYCLE-GRADIENT','全循环身份后局部化','integralcycle andweightedprojections','closedgradient/TVcompactness','CAT0','prop:sobolev-space','Borelchartrestrictions neednotnormal;cannotintegratebyparts independently'),
('ATOMIC-COAREA','含原子分布的能量重排','actualintegralsuperlevels andsmall-support bound','equimeasurable radialfunction andenergycontrol','CAT0','lem:rearranged-energy','Lowerdimensioninduction;notassumeACdistributionorquantilerate'),
('POWER-BOOTSTRAP','有限幂截断bootstrap','actualcriticalminimizer andweakEuler equation','allfinitemoments andweightedenergy','CAT0','lem:powers','No L∞,strictpositivity oruniformfinitecost'),
('C1-ZERO-COMPOSITE','零点处直接复合替代分数幂拆分','n>2,beta=1/(n-2),boundedr,a>0,kappa fixed;scalarF_j=z*w(kappa*r*z^beta)^j','jointC1 extension acrossz=0 withderivatives dz1/dr0','CAT0','lem:chord-tests','Scalarcalculusfragment maytransferindependently;fullHmembership/chordinequalities stillneedextremizerPDE. No numericalADoutputyet'),
('BOREL-CENTER-AVERAGE','对值与距离核平均','nonnegativeBorelrepresentative andfiniteweightedmoments','valid centeraverage withoutjointderivativechoices','CAT0','lem:opposite-average','Specificminimizer requiredforlowerbound;notunconditionalpointcloudvariance'),
('TOP-DIM-CONSTANCY','顶维差流识别填充','connectednoncompactorientedmanifold,compacttopcycle','uniquegivenboundarydomainfilling','CAT0','lem:top-dimensional-constancy','No parameterizedfillingtopology/optimization algorithm'),
]
domains=[
('机器学习自动微分','将穿零C1标量复合直接求导，审计分数幂分解在零门控特征上的梯度','值得另行冻结小型真实AD检验；普通解析微分与正确预操作分支是强旧基线。尚无AD运行、训练收益或实现故障证据。'),
('交通网络','把路网循环边界的填充质量用于运输或围合成本','一般图的距离及一维循环不满足n>=2 CAT0整数流；需二维真实几何和成本同一性。保留条件方向。'),
('材料孔隙','以有限周长孔隙的表面积界约束设计','需完整ambient光滑Hadamard结构、负截曲率和体积计量；三维普通欧氏基线已足够，未知新增益。'),
('生物形态','由近球等周比恢复组织内部几何','本稿是精确等号刚性，没有近等号稳定性；噪声、边界与环境曲率桥接缺失。'),
('语言表示','用加权弦矩检测语义点云几何','经验原子与任意权不满足假想极值循环及Euler方程；不能把严格弦矩上界直接套嵌入。'),
('艺术与网格','用质量最小填充生成面或体','存在性不指定拓扑/参数化，不提供离散优化器与误差率；普通欧氏填充已有旧结果。'),
('金融风险','以CAT0均值或尾分布估计风险','Sturm旧方差与新矛盾中的特定矩分开；交易观测没有积分流/PDE前提，未形成合理新候选。'),
('能源传热','用模型球p谱及扭转界约束响应','可复用连续Dirichlet比较，但实际器件多有边界/非Hadamard几何；需独立曲率证书与离散误差，旧欧氏界须公平比较。'),
('机器人形状空间','紧凸球回缩限制搜索区域','正确CAT0空间及非扩张回缩可迁移；不保证当前机器人配置空间CAT0，也无最短路或填充复杂度。'),
('数据库分位数','允许原子和平台的广义逆重排','统计分位数处理原子已是旧方法；本源内禀能量与整数切片结构没有自然数据库对应，暂保留零增益判断。'),
]
cross=[
{'existing_method':'PART-333-SMALL-VALUE-DERIVATIVE','proposal':'Combine zero/small-value localization with F337 directC1 composite for gradient admission','qualification':'Only shared calculus interface sofar;periodic structured-curvature hypothesis ofF333 doesnotfollowfromF337. Separate scalar audit maynotneed bothfamilies;no combined benefit credit.'},
{'existing_method':'PART-094-CLIP-THEN-PROJECT','proposal':'Clip-before-project and F337 whole-cycle-before-localize as operation-order correctness checks','qualification':'Weighted edge cochains and AKcurrents are different objects;no transferofprojectionbounds. Retain as methodological analogy,not a joint theorem.'},
{'existing_method':'PART-374-MOMENTS','proposal':'Moment normalization with mass-density absolute multiplicity checks','qualification':'Fixed-mass geometric moments require actual measure model. Signed/real weights do notinherit integral density;no new combined candidate.'},
]
out={'claims':{'smooth':smooth,'CAT0':cat},'methods':methods,'domains':domains,'cross_family':cross,'reason_no_candidate':'Geometric target interfaces not admitted. The scalar C1-through-zero AD transfer is a concrete promising direction, retained for global042 comparison and separate frozen plan; it has not yet acquired complete candidate/card/review fields or actual external test.'}
(w/'qualification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('qualified',len(smooth)+len(cat),'methods',len(methods),'domain attempts',len(domains))
