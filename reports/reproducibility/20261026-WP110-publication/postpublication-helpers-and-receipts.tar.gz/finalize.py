from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,shutil,subprocess,tarfile

root=Path('/Users/smzdm/projects/ai_paper');work=Path(__file__).resolve().parent
out=root/'reports/reproducibility/20261026-WP110-publication'
candidate=json.loads((work/'public-candidate.json').read_text())
verification=json.loads(gzip.decompress((work/'verification.json.gz').read_bytes()))
ci=json.loads(gzip.decompress((work/'CI-observation.json.gz').read_bytes()))
assert verification['head_commit']==candidate['commit'] and verification['full_tree_equal']
assert all(x['byte_equal'] for x in verification['anonymous_file_reads'])
assert ci['commit']==candidate['commit']
assert ci['runs'] and all(r['status']=='completed' and r['conclusion']=='success' for r in ci['runs'])
for name in ['verification.json.gz','CI-observation.json.gz']:
    shutil.copyfile(work/name,out/name)
audit=(work/'final-audit.json').read_bytes();packed=gzip.compress(audit,mtime=0)
assert gzip.decompress(packed)==audit
(out/'final-audit.json.gz').write_bytes(packed)
names=['create_public_commit.py','verify.py','finalize.py','final-audit.json','public-candidate.json','verification.json.gz','CI-first-observation.json.gz','CI-observation.json.gz']
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for name in names:
        raw=(work/name).read_bytes(); info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;t.addfile(info,io.BytesIO(raw))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for name in names:assert t.extractfile(name).read()==(work/name).read_bytes()
(out/'postpublication-helpers-and-receipts.tar.gz').write_bytes(packed)
now=datetime.now(timezone.utc).isoformat()
def load(name):return json.loads((root/name).read_text())
def save(name,x):(root/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
p=load('state/publication.json')
old={k:p[k] for k in ['verified_at','verified_commit','verified_tree','verification_receipt','verification_scope','latest_scoped_ci','latest_ci_receipt','latest_ci_conclusion']}
assert old['verified_commit']==candidate['parent']
p['prior_verifications'].append(old)
p.update({'state':'published','public':True,'remote_verified':True,'verified_at':verification['at'],'verified_commit':candidate['commit'],'verified_tree':candidate['tree'],'verification_receipt':str((out/'verification.json.gz').relative_to(root)),'anonymous_api_verification':not bool(verification['api_fallbacks']),'upstream_math_paths':0,'verification_scope':'WP110 canonical GEN107/global039 plus incomplete WP1114745/7647lines;full remote path/mode/size/blob equality and7anonymous byte-equal reads;no officialmath or bulk localhistory','latest_progress_packages':['WP-110'],'latest_retrospective':'reports/retrospectives/039-conditional-transfer-and-coverage-rotation.md','latest_scoped_ci':ci,'latest_ci_receipt':str((out/'CI-observation.json.gz').relative_to(root)),'latest_ci_conclusion':'success','anonymous_public_file_reads':7,'incomplete_reading_journal':'state/reading-progress/WP-111.json','pending_batch':None,'latest_snapshot_files':verification['files'],'latest_snapshot_bytes':verification['total_bytes'],'local_progress_after_verified_snapshot':'No new scientific work after this snapshot;post-push receipts/checkpoint saved locally only. WP111 remains unfinished.','receipt_storage_scope':'Saved and locally committed after public snapshot;not pushed again. The public tree records preparation and previous verification;this subsequent local receipt verifies actual publication and CI.'})
save('state/publication.json',p)
c=load('state/checkpoint.json');c['saved_at']=now
c['release_state']='Public MathWeave '+candidate['commit']+' through WP110/global039 plus unfinished WP1114745/7647lines;exact tree and7anonymous files verified;scoped CI success observed separately.'
c['publication_work'].update({'status':'published_verified_ci_success','latest_public_commit':candidate['commit'],'latest_public_tree':candidate['tree'],'latest_ci':ci['runs'],'latest_verification_receipt':p['verification_receipt'],'latest_ci_receipt':p['latest_ci_receipt'],'synchronization_status':'published_verified','pending_public_commit':None,'pending_public_tree':None,'pending_ci_run':None,'active_push_exec_session':None,'current_local_research_not_yet_pushed':'None after this owner-requested science batch;post-push metadata receipts kept local. WP111 unfinished reading is included,not canonical research completion.','scientific_local_commit':candidate['local_commit'],'receipt_storage_scope':p['receipt_storage_scope']})
c['publication_qa_evidence']=str(out.relative_to(root))
c['running_research_experiments']=[]
c['recovery_observation']['publication_boundary']={'at':now,'running_project_processes':[],'new_scientific_experiments':0,'expensive_experiments_repeated':False,'math_commit':'1581d4cbdd69a0faf34b2089614fe2a814316a6a','math_clean':True,'public_commit':candidate['commit'],'next_actual_read':c['next_work_package']['next_actual_read']}
save('state/checkpoint.json',c)
with (root/'state/status.md').open('a') as f:
    f.write('\n\n发布后实测（'+now+'）：公开MathWeave提交'+candidate['commit']+'，'+str(verification['files'])+'文件／'+str(verification['total_bytes'])+'字节，完整远端树与本地路径、模式、大小、blob逐项相同，七入口匿名回读字节一致，官方math路径0、无批量本地历史。当前配置CI实际completed/success，69核心／13归档重放／导出与发布审计；不代表Lean、人审、第二供应商或研究验收。收据见'+str(out.relative_to(root))+'。后验收据仅本地保存提交，不为此二次推送。整体与WP111仍未完成，下一第二篇polynomials246–681，无运行实验。\n')

# Recheck each archived member before deleting the redundant temporary helpers.
reading=Path('/private/tmp/ai-paper-WP111')
with tarfile.open(out/'WP111-reading-helpers.tar.gz') as t:
    for file in reading.iterdir():
        assert file.is_file() and t.extractfile(file.name).read()==file.read_bytes()
shutil.rmtree(reading)
storage=load(str((out/'reading-storage.json').relative_to(root)))
storage['temporary_plaintext_removed']=True;storage['removed_at']=now
save(str((out/'reading-storage.json').relative_to(root)),storage)
receipt={'at':now,'archive_members_verified':len(names),'archive_bytes':len(packed),'archive_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'temporary_reading_helpers_removed_after_member_verification':True,'publication_temporary_files_removed':False,'next_cleanup':'Verify both helper archives against their remaining temporary originals,then remove publication temporary root. Receipt-only local commit;no second push.'}
save(str((out/'postpublication-storage.json').relative_to(root)),receipt)
print(json.dumps({'public_commit':candidate['commit'],'ci':'success','files':verification['files'],'official_math_paths':0,'receipt_members':len(names),'reading_helpers_removed':True}))
