from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, os, shutil, subprocess, sys, tarfile

root = Path('/Users/smzdm/projects/ai_paper')
work = Path(__file__).resolve().parent
out = root / 'reports/reproducibility/20261026-WP110-publication'
j = json.loads((root / 'state/reading-progress/WP-111.json').read_text())
full = j['actual_source_files_read']
assert len(full) == 15 and sum(x['lines'] for x in full) == 4500
assert j['actual_source_lines_read'] == 4745 and j['source_tex_lines'] == 7647
assert sum(x['lines_read'] for x in j['partially_read_tex_files']) == 245
for x in j['source_files']:
    raw = (root / x['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == x['sha256']
    assert len(raw.decode().splitlines()) == x['lines']
assert not subprocess.check_output(['git','diff','f29d140','--','data/graph','data/corpus','experiments','src','tests','reports/families'],cwd=root)
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],cwd=root)
assert subprocess.check_output(['git','-C','math','rev-parse','HEAD'],cwd=root).decode().strip() == '1581d4cbdd69a0faf34b2089614fe2a814316a6a'
log = (work/'core.log').read_text()
assert 'Ran 69 tests' in log and '\nOK\n' in log

clean = work/'clean'
assert not clean.exists()
clean.mkdir()
paths = sorted(set(filter(None,subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0'))))
manifest = []
for name in paths:
    assert name.split('/')[0] not in {'math','.git','.venv','.cache','tmp'}
    src = root/name
    assert src.is_file() and not src.is_symlink()
    dst = clean/name; dst.parent.mkdir(parents=True,exist_ok=True)
    raw = src.read_bytes(); dst.write_bytes(raw); dst.chmod(src.stat().st_mode & 0o777)
    digest = hashlib.sha256(raw).hexdigest()
    assert hashlib.sha256(dst.read_bytes()).hexdigest() == digest
    manifest.append({'path':name,'bytes':len(raw),'sha256':digest})
assert not (clean/'math').exists()
with (work/'no-math-core.log').open('wb') as f:
    p = subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
r = {'at':datetime.now(timezone.utc).isoformat(),'scope':'Current publication preparation copied byte-for-byte without official math; later closure receipts separately scoped','files':len(manifest),'total_bytes':sum(x['bytes'] for x in manifest),'copy_hashes_verified':True,'official_math_paths':0,'core_exit_code':p.returncode,'manifest':manifest,'runtime':sys.version}
raw = json.dumps(r,ensure_ascii=False,indent=2).encode(); packed = gzip.compress(raw,mtime=0)
assert gzip.decompress(packed) == raw
(out/'no-math-clean.json.gz').write_bytes(packed)
print(json.dumps({k:v for k,v in r.items() if k!='manifest'}),flush=True)
if p.returncode:
    print((work/'no-math-core.log').read_text()[-3000:])
    sys.exit(p.returncode)
shutil.rmtree(clean)
assert 'Ran 69 tests' in (work/'no-math-core.log').read_text()

names = ['prepare.py','qa.py','core.log','no-math-core.log']
buf = io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as t:
    for name in names:
        data=(work/name).read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;t.addfile(info,io.BytesIO(data))
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for name in names:assert t.extractfile(name).read()==(work/name).read_bytes()
(out/'prepublication-helpers-and-logs.tar.gz').write_bytes(packed)
quality={'at':datetime.now(timezone.utc).isoformat(),'core_tests':69,'core_exit_code':0,'no_math_core_exit_code':0,'clean_directory_removed':True,'clean_files':r['files'],'clean_bytes':r['total_bytes'],'copy_hashes_verified':True,'source_inventory_hashes_verified':len(j['source_files']),'reading_lines':4745,'full_file_lines':4500,'partial_lines':245,'canonical_science_and_experiment_code_unchanged_from':'f29d140','new_scientific_experiments':0,'helper_members_verified':len(names),'archive_bytes':len(packed),'archive_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Publication documentation and incomplete-reading recovery. WP110 graph/impact/export and15archive/267member QA plus actual238/325 replays retain their original receipts; no fresh application or Lean/human/provider acceptance.'}
(out/'quality.json').write_text(json.dumps(quality,indent=2)+'\n')
print(json.dumps(quality))
