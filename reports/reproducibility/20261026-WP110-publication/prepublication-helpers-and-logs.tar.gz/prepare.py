from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, subprocess, tarfile

root = Path('/Users/smzdm/projects/ai_paper')
work = Path(__file__).resolve().parent
out = root / 'reports/reproducibility/20261026-WP110-publication'
out.mkdir(exist_ok=True)
now = datetime.now(timezone.utc).isoformat()

def load(name):
    return json.loads((root / name).read_text())

def save(name, value):
    (root / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def gz(name, raw):
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    (root / name).write_bytes(packed)

jpath = 'state/reading-progress/WP-111.json'
gz('state/reading-progress/history/WP111-before-publication-recovery.json.gz', (root / jpath).read_bytes())
j = load(jpath)
assert j['actual_source_lines_read'] == 4500 and j['actual_full_tex_files_read'] == 15
for row in j['source_files']:
    raw = (root / row['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    assert len(raw.decode().splitlines()) == row['lines']
poly = next(x for x in j['source_files'] if 'Quadratic-' in x['path'] and x['path'].endswith('/polynomials.tex'))
assert not poly['actually_read'] and poly['lines'] == 681
poly['actually_read_ranges'] = [[1, 245]]
j['partially_read_tex_files'] = [{'path': poly['path'], 'sha256': poly['sha256'], 'actually_read_ranges': [[1, 245]], 'lines_read': 245, 'fully_read': False}]
j['full_file_lines_read'] = 4500
j['actual_source_lines_read'] = j['actual_body_read_lines'] = 4745
j['updated_at'] = now
j['next_actual_read'] = 'Quadratic manuscript sections/polynomials.tex lines246-681;then invariant493,coloring850,transfer769,completion193,references122,figure39. Total2902lines unread. Formal/history/canonical qualification remains pending for both manuscripts.'
j['publication_recovery_note'] = 'Recovered the additional actual read range1-245 from the immediately preceding source-reading turn;not a new reading or qualification.15 fully read files/4500lines plus245partial=4745/7647. No canonical family,claim,application or review credit.'
save(jpath, j)
progress = {'files_fully_read':15, 'full_file_tex_lines_read':4500, 'partial_file_tex_lines_read':245, 'tex_lines_read':4745, 'selected_total_tex_lines':7647, 'new_full_manuscripts':1, 'canonical_credit_added':False}
b = load('state/backlog.json')
task = next(x for x in b['tasks'] if x['id'] == 'WP-111')
task['execution_progress'] = progress
task['next_actual_read'] = j['next_actual_read']
b['updated_at'] = now
save('state/backlog.json', b)
c = load('state/checkpoint.json')
c['saved_at'] = now
for key in ['next_work_package','active_work_package']:
    c[key]['execution_progress'] = progress
    c[key]['next_actual_read'] = j['next_actual_read']
c['recovery_commands'][2] = j['next_actual_read']
c['publication_work']['status'] = 'preparing_owner_requested_WP110_batch'
c['publication_work']['current_local_research_not_yet_pushed'] = 'WP110 canonical GEN107,global039 and incomplete WP111 4745/7647line checkpoint are being prepared for this explicit owner-requested batch;current verified public commit remains b31ffce until actual remote readback.'
c['publication_work']['prepush_audit'] = 'reports/reproducibility/20261026-WP110-publication/final-audit.json.gz'
c['previous_goal_turn_classification'] = {'classification':'progress', 'evidence':'WP111 source reading advanced to4500full-file lines plus245partial;no canonical credit. Current explicit publication request takes priority over further reading.'}
save('state/checkpoint.json', c)
p = load('state/publication.json')
p['pending_batch'] = {'requested_at':now, 'status':'preparing_not_pushed', 'scope':'WP110 canonical F238 companion decomposition,global039,and incomplete WP1114745/7647line reading checkpoint', 'official_math_excluded':True, 'previous_public_commit':p['verified_commit'], 'qa_directory':str(out.relative_to(root)), 'new_scientific_experiments':0}
p['local_progress_after_verified_snapshot'] = 'WP110 GEN107 and global039 complete;WP11115/22fullfiles pluspartial245lines,4745/7647lines;reading only,canonical F300 qualification pending.'
save('state/publication.json', p)

name = root / 'README.en.md'
s = name.read_text()
start = s.index('Current local curated progress:')
end = s.index('\n\nRepository:', start)
s = s[:start] + 'This owner-requested publication batch includes completed WP-110 and [retrospective 039](reports/retrospectives/039-conditional-transfer-and-coverage-rotation.md), plus an explicitly unfinished [WP-111 reading checkpoint](state/reading-progress/WP-111.json). Curated totals are 58 families actually read, 53 current-source decomposition drafts, 7,955 graph nodes and 22,511 relations. WP-110 adds 132 source-qualified bindings and 30 method contracts from two F238 companions; F238 is 6/12 manuscripts, with 227 bindings and six manuscripts still unread. Two selected formal conclusions retain local B, 130 other new bindings C, and all full dependency chains remain unknown. WP-111 has read 4,745/7,647 source lines (15 complete files plus 245 lines of a partial file), including one complete manuscript; its formal, historical and canonical qualification is pending and adds no curated coverage or application-check credit. The last verified public snapshot is `b31ffce`; the current batch remains pending until actual push and readback. See [F238 scope](reports/F238-frames-fourier-reading.md), [progress](PROGRESS.en.md) and [publication state](state/publication.json).' + s[end:]
name.write_text(s)
name = root / 'README.md'
s = name.read_text().replace('公开b31ffce已含WP109成果与当时WP110未完成日志；本轮GEN107与复盘039仅本地保存。', '此前公开b31ffce含WP109成果与当时WP110未完成日志；本次用户显式要求的合并发布纳入GEN107、复盘039及WP111未完成阅读检查点，实际推送与回读另行核验。')
marker = '\n此前 [F174有理PSD实际调用]'
assert marker in s
s = s.replace(marker, '\n当前WP111转向算子代数F300，两稿共22TeX7647行，已实际读4745行：15个完整文件4500行，另一个文件前245行；其中一篇正文闭包已读完，形式化／历史／规范入图尚未完成，不增加已拆解族、来源命题或应用初检。恢复入口见[阅读检查点](state/reading-progress/WP-111.json)。本次集中发布后，继续维持日常本地提交、重要里程碑合并更新GitHub。\n' + marker, 1)
name.write_text(s)
name = root / 'PROGRESS.en.md'
s = name.read_text()
start = s.index('Snapshot:')
end = s.index('\n\n| Measure', start)
s = s[:start] + 'Snapshot: October 26, 2026, curated through WP-110 and retrospective 039, with an unfinished WP-111 reading checkpoint (4,745/7,647 lines). This explicit owner-requested batch is prepared for one GitHub update. Prior verified public commit `b31ffce` and its successful scoped CI apply to the previous snapshot; the new push and CI require separate observation. Exact evidence is in [publication state](state/publication.json). **Phase one remains incomplete.**' + s[end:]
old = "WP-110 is reading two of F238's eight not-yet-curated companions:"
start = s.index(old)
end = s.index('\n\nThe following paragraphs', start)
s = s[:start] + 'WP-110 subsequently completed those two companions; the current qualification is recorded below. Its earlier unfinished reading counts are superseded by that evidence.' + s[end:]
start = s.index('Publication boundary:')
end = s.index('\n\n\n## WP110', start)
s = s[:start] + 'Publication boundary: the previously verified public [`b31ffce`](https://github.com/yiduo/mathweave/commit/b31ffce90304ca541c6ec4d08cc04c7b3cd38988) contains WP-109 and the earlier unfinished WP-110 journal. Its [scoped CI passed](https://github.com/yiduo/mathweave/actions/runs/40269977360). The owner now explicitly requests one update containing the completed WP-110, retrospective 039, and unfinished WP-111 checkpoint. Post-push verification will be saved locally, avoiding a second routine push solely for receipts. No official `math/` content or bulk local history is included.' + s[end:]
old = 'Mandatory039 compares the remaining six Thorp companions with unread operator-algebra F300;only its READMEs and22-file/7,647-line inventory have been read. No GitHub push.'
assert old in s
s = s.replace(old, '[Retrospective 039](reports/retrospectives/039-conditional-transfer-and-coverage-rotation.md) compares the remaining six Thorp companions with operator-algebra F300 and selects F300 for the next substantive package. These packages are included in the present owner-requested publication batch.')
s += '\n\n## WP111: incomplete source reading\n\nBoth selected F300 manuscripts total 22 TeX files / 7,647 lines. Actual reading covers 15 complete files (4,500 lines) and lines 1–245 of the second polynomial section, totaling 4,745 lines. The first manuscript is fully read; the second has 2,902 unread lines. Formal comparisons, historical originals, canonical decomposition and application mappings remain pending. No curated family, source-binding, candidate or experiment credit is added. The first manuscript distinguishes strong approximation of a nearby operator from the second manuscript’s strong-operator compression of the original operator; neither statement by itself supplies a practical finite algorithm. These are provisional reading notes, not a proof review. Resume at quadratic `sections/polynomials.tex` line 246, as recorded in the [journal](state/reading-progress/WP-111.json).\n'
name.write_text(s)
with (root / 'docs/publication.md').open('a') as f:
    f.write('\n\n## Current owner-requested batch: completed WP110 and unfinished WP111\n\nRetain **MathWeave (数学织网)** and the existing public address [yiduo/mathweave](https://github.com/yiduo/mathweave), whose stable repository ID is 1429150108. The repository and local origin already use this name, so no duplicate repository or local checkout rename is needed. Publish completed WP110 / GEN107 and retrospective039, plus WP111’s incomplete source-reading checkpoint: 15 complete TeX files / 4,500 lines and a further 245-line partial range, totaling 4,745/7,647 lines. No new application check or human/provider review is claimed. Create one reviewed public commit parented by the last public commit, excluding the official math directory and bulk local history. Save post-push verification locally for the next meaningful batch; routine publication remains disabled.\n')
with (root / 'state/status.md').open('a') as f:
    f.write('\n\n## 2026-10-26 用户要求合并发布：WP110及WP111当前检查点\n\n保留MathWeave（数学织网）及https://github.com/yiduo/mathweave，仓库ID1429150108与origin已核对。本次纳入WP110 GEN107、复盘039和WP111未完成阅读：15完整TeX4500行，另第二篇polynomials前245行，共4745/7647行，一篇完整正文已读；两篇形式／历史与规范资格待完成，不增加58阅读／53草稿／45候选／13初检等规范指标。旧515行backlog与4500行恢复检查点已同步，保留旧日志压缩版。下一具体读取为第二篇polynomials246–681，尚余2902行。科学记录与实验未改，整体仍active_incomplete。发布检查与实际推送／远端回读分别记录，不沿用旧CI为新快照背书。官方math不提交；本次一批推送后继续日常本地保存。\n')
with (root / 'docs/roadmap.md').open('a') as f:
    f.write('\n\n当前用户显式发布请求：MathWeave既有名称／地址保持，合并WP110与复盘039及WP111未完成4745/7647行阅读日志；不增加规范覆盖／应用检验，下一读第二篇polynomials246–681。发布结果以state/publication.json实际回读为准，继续保持重要里程碑合并推送。\n')

# Preserve only original helper code and metadata, never copied upstream bodies.
reading_work = Path('/private/tmp/ai-paper-WP111')
names = sorted(p for p in reading_work.iterdir() if p.is_file())
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode='w') as t:
    for pth in names:
        assert pth.suffix in {'.py','.json'}, pth
        raw = pth.read_bytes(); info = tarfile.TarInfo(pth.name); info.size = len(raw); info.mtime = 0
        t.addfile(info, io.BytesIO(raw))
raw = buf.getvalue(); packed = gzip.compress(raw, mtime=0)
assert gzip.decompress(packed) == raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for pth in names:
        assert t.extractfile(pth.name).read() == pth.read_bytes()
(out / 'WP111-reading-helpers.tar.gz').write_bytes(packed)
save(str(out.relative_to(root) / 'reading-storage.json'), {'at':now, 'members':len(names), 'archive_bytes':len(packed), 'compressed_sha256':hashlib.sha256(packed).hexdigest(), 'decompressed_sha256':hashlib.sha256(raw).hexdigest(), 'all_member_hashes_verified':True, 'temporary_plaintext_removed':False, 'scope':'Own helper code and reading metadata only; no upstream source copy or scientific experiment'})
print(json.dumps({'prepared':True,'reading_lines':4745,'full_files':15,'canonical_credit_added':False,'helper_members':len(names),'helper_archive_bytes':len(packed)}))
