from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, urllib.request

root=Path('/Users/smzdm/projects/ai_paper')
work=Path('/private/tmp/ai-paper-20261026-publication')
candidate=json.loads((work/'public-candidate.json').read_text())
paths=['README.md','README.en.md','CHARTER.en.md','PROGRESS.en.md','data/provenance/readings/F-239.json','reports/metrics.json','state/reading-progress/WP-109.json']
observed=[]
for name in paths:
    expected=subprocess.check_output(['git','show',candidate['commit']+':'+name],cwd=root)
    url='https://raw.githubusercontent.com/yiduo/mathweave/'+candidate['commit']+'/'+name
    req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-publication-verification'})
    with urllib.request.urlopen(req,timeout=35) as response:
        actual=response.read()
        assert response.status==200
    assert actual==expected, name
    observed.append({'path':name,'url':url,'status':200,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'matches_exact_commit':True,'authentication':'none'})
receipt={'at':datetime.now(timezone.utc).isoformat(),'commit':candidate['commit'],'public_anonymous_file_reads':observed,'all_equal':True}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode()
packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
(work/'anonymous-file-verification.json.gz').write_bytes(packed)
print(json.dumps({'commit':candidate['commit'],'public_files_verified':len(observed),'bytes':sum(x['bytes'] for x in observed),'all_equal':True}))
