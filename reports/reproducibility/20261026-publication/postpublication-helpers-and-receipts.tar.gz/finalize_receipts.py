from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile

root=Path('/Users/smzdm/projects/ai_paper')
work=Path('/private/tmp/ai-paper-20261026-publication')
out=root/'reports/reproducibility/20261026-publication'
now=datetime.now(timezone.utc).isoformat()
def save(path,d): path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def packed_save(path,data):
    raw=json.dumps(data,ensure_ascii=False,indent=2).encode()
    packed=gzip.compress(raw,mtime=0)
    assert hashlib.sha256(gzip.decompress(packed)).digest()==hashlib.sha256(raw).digest()
    path.write_bytes(packed)

api=json.loads((work/'api-verification.json').read_text())
public_files=json.loads(gzip.decompress((work/'anonymous-file-verification.json.gz').read_bytes()))
candidate=json.loads((work/'public-candidate.json').read_text())
ci=json.loads((work/'ci-observation.json').read_text())
assert public_files['all_equal'] and public_files['commit']==api['commit']==candidate['commit']==ci['head_sha']
assert api['files']==1934 and api['total_bytes']==71820048 and api['upstream_math_paths']==0
api['anonymous_file_verification']=public_files
api['latest_scoped_ci']=ci
api['verified_at']=now
packed_save(out/'publication-verification.json.gz',api)
packed_save(out/'CI-observation.json.gz',ci)
packed_save(out/'prepush-final-audit.json.gz',json.loads((work/'final-audit.json').read_text()))

pub=json.loads((root/'state/publication.json').read_text())
prior={k:pub[k] for k in ['verified_at','verified_commit','verified_tree','verification_receipt','verification_scope','latest_scoped_ci','latest_ci_conclusion'] if k in pub}
prior['latest_ci_receipt']='reports/reproducibility/20261023-mathweave/CI-observation.json.gz'
pub.setdefault('prior_verifications',[]).append(prior)
pub.update({'state':'published','public':True,'remote_verified':True,'verified_at':now,'verified_commit':api['commit'],'verified_tree':api['tree'],'verification_receipt':'reports/reproducibility/20261026-publication/publication-verification.json.gz','verification_scope':api['scope']+';exact full tree SHA matches locally reviewed tree,1934files/math0;seven anonymous public files byte-equal','latest_snapshot_files':1934,'latest_snapshot_bytes':71820048,'upstream_math_paths':0,'anonymous_public_file_reads':True,'latest_scoped_ci':ci,'latest_ci_receipt':'reports/reproducibility/20261026-publication/CI-observation.json.gz','latest_ci_conclusion':ci['conclusion'],'incomplete_reading_journal':'WP109:3fixedprojects/17files394010downloadedbytes/2522actuallyreadlines;conditional mapping auxiliary reviews completed;canonical admission/card/packageQA unfinished;no newcandidate/checkcredit','receipt_storage_scope':'This publication verified;post-push receipts retained locally for next meaningful batch,with no second routine GitHub push.'})
pub['latest_progress_packages']=list(dict.fromkeys(pub['latest_progress_packages']+['WP-108']))
pub['pending_batch'].update({'status':'published_verified','public_commit':api['commit'],'public_tree':api['tree'],'verified_at':now,'ci_status':ci['status'],'ci_conclusion':ci['conclusion']})
save(root/'state/publication.json',pub)

checkpoint=json.loads((root/'state/checkpoint.json').read_text())
checkpoint['saved_at']=now
checkpoint['release_state']='PublicMathWeave '+api['commit'][:7]+' throughWP108,unfinishedWP109journal;1934files/math0,7anonymousbytechecks;CI '+ci['status']+'/'+str(ci['conclusion'])
checkpoint['publication_work'].update({'status':'published_verified_ci_'+str(ci['conclusion'] or ci['status']),'latest_public_commit':api['commit'],'latest_public_tree':api['tree'],'latest_ci':[ci],'latest_ci_receipt':'reports/reproducibility/20261026-publication/CI-observation.json.gz','latest_verification_receipt':'reports/reproducibility/20261026-publication/publication-verification.json.gz','synchronization_status':'published_verified','pending_public_commit':None,'pending_public_tree':None,'active_push_exec_session':None,'scientific_local_commit':candidate['local_commit'],'current_local_research_not_yet_pushed':'Only post-push verification receipts/checkpoint remain local. Scientific snapshot WP108 plus unfinished WP109journal published. WP109canonicalcuration not yet performed.'})
checkpoint['publication_qa_evidence']='reports/reproducibility/20261026-publication'
checkpoint['running_research_experiments']=[]
checkpoint['recovery_observation']={'at':now,'disk_available_observed':'21GiB;system-wide observation,not attributed project savings','running_project_processes':[],'all_current_exec_sessions_completed':True,'WP109_temporary_source_bytes':394010,'clean_publication_directory_removed':True}
checkpoint['previous_goal_turn_classification']={'classification':'progress','evidence':'Owner-requested MathWeave GitHub batch published/verified;WP109remainsinprogress,no scientific count inflation.'}
checkpoint['must_not_repeat'].append('Publication8700f8b verified;no duplicate repo/rename/routine repush. WP10917pinnedfiles already acquired and selected ranges read;resume curation rather than redownload. No scientific experiment was run.')
save(root/'state/checkpoint.json',checkpoint)
with (root/'state/status.md').open('a') as f:
    f.write('\n公开核验（'+now+'）：实际提交'+api['commit']+'，1934文件／71820048字节，远端完整tree与审核树一致，math路径0；7份关键文件匿名逐字节匹配。CI '+str(ci['id'])+'为'+ci['status']+'/'+str(ci['conclusion'])+'，范围为现有69核心、13历史重放、图谱导出与发布审计，不代表数学或应用验收。收据和接续检查点本地保存，避免第二次例行推送。WP109仍in_progress，继续规范整理和卡片准入，不能重跑昂贵实验或重复获取来源。\n')

names=['create_public_commit.py','verify_public_files.py','finalize_receipts.py','public-candidate.json','api-verification.json','ci-observation.json','final-audit.json']
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
    for name in names:
        raw=(work/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0
        tar.addfile(info,io.BytesIO(raw))
raw=stream.getvalue();packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)),mode='r') as tar:
    for name in names: assert tar.extractfile(name).read()==(work/name).read_bytes()
(out/'postpublication-helpers-and-receipts.tar.gz').write_bytes(packed)
save(out/'postpublication-storage.json',{'at':now,'archive_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'compressed_bytes':len(packed),'raw_tar_bytes':len(raw),'member_bytes_verified':len(names),'all_logs_and_helpers_compressed':True,'temporary_third_party_sources_retained_bytes':394010,'reason':'WP109 source acquisition already complete;small pinned temporary copies retained for unfinished curation,never included in public tree.','no_new_scientific_experiment':True,'local_only_until_next_meaningful_batch':True})
print(json.dumps({'public_commit':api['commit'],'ci_status':ci['status'],'ci_conclusion':ci['conclusion'],'postpush_receipts_local':True,'goal_complete':False}))
