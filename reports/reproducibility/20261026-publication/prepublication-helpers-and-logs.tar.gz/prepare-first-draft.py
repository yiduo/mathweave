from pathlib import Path
import json, gzip, hashlib
from datetime import datetime, timezone

root = Path('/Users/smzdm/projects/ai_paper')
temp = Path('/private/tmp/ai-paper-WP109')
now = datetime.now(timezone.utc).isoformat()
def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
def gzsave(path, data):
    raw = json.dumps(data, ensure_ascii=False, indent=2).encode()
    packed = gzip.compress(raw, mtime=0)
    assert hashlib.sha256(gzip.decompress(packed)).digest() == hashlib.sha256(raw).digest()
    path.write_bytes(packed)

acquisition = json.loads((temp/'acquisition.json').read_text())
ranges = {
 'jcmgray/quimb:quimb/tensor/tensor_builder.py': [[1,50],[140,240],[1592,1810],[1844,1930],[5258,5360]],
 'jcmgray/quimb:quimb/gen/rand.py': [[1,205],[245,373],[443,478]],
 'jcmgray/quimb:quimb/tensor/array_ops.py': [[351,372]],
 'jcmgray/quimb:tests/test_tensor/test_tensor_builder.py': [[815,844]],
 'JuliaMath/RandomMatrices.jl:src/GaussianEnsembles.jl': [[1,140]],
 'JuliaMath/RandomMatrices.jl:README.md': [[1,92],[126,141]],
 'reservoirpy/reservoirpy:reservoirpy/mat_gen.py': [[143,330],[466,584],[727,797]],
 'reservoirpy/reservoirpy:reservoirpy/nodes/reservoir.py': [[1,130],[145,270]],
 'reservoirpy/reservoirpy:reservoirpy/observables.py': [[46,124],[484,560]],
 'reservoirpy/reservoirpy:reservoirpy/tests/test_mat_gen.py': [[1,143],[164,217]],
 'reservoirpy/reservoirpy:reservoirpy/nodes/tests/test_reservoir.py': [[1,140]],
}
files=[]
for item in acquisition['files']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
    entry = {k:v for k,v in item.items() if k != 'path'}
    entry['actually_read_ranges'] = [[a,min(b,item['lines'])] for a,b in ranges.get(item['key'],[[1,item['lines']]])]
    entry['actually_read_lines'] = sum(b-a+1 for a,b in entry['actually_read_ranges'])
    entry['reading_scope'] = 'Selected source ranges; downloading a complete file is not complete-file reading'
    files.append(entry)
journal = json.loads((root/'state/reading-progress/WP-109.json').read_text())
journal.update({
 'updated_at':now, 'status':'in_progress_publication_checkpoint',
 'projects':json.loads((temp/'manifest.json').read_text()),
 'actually_read_files':files, 'downloaded_bytes':acquisition['total_downloaded_bytes'],
 'actually_read_lines':sum(f['actually_read_lines'] for f in files),
 'source_files_downloaded':len(files), 'numerical_runs':0,
 'canonical_curation_complete':False, 'candidate_admitted':False,
 'counts_unchanged':{'candidates':44,'preliminary_application_checks':13},
 'provisional_findings':[
  'quimb raw ndim=2 real unshifted unit-scale Rademacher symmetric initializer matches independent upper-triangle signs including random diagonal under the ideal IID generator interpretation. Standard parameters and selected corner tensors only.',
  'The inspected quimb contraction test uses the normal default and requires contraction/permutation invariance, not invertibility. No actual rank-sensitive consumer is established.',
  'Higher-order symmetric tensor flattenings do not inherit the theorem ensemble. Julia GaussianHermite sampling is continuous; inspected ReservoirPy Bernoulli arrays are not mirrored symmetric and recurrent steps do not demand an inverse.',
  'Exact rank screening, numerical SVD/QR, old exponential bounds, and guaranteed-invertible alternative laws remain strong baselines. No finite-D threshold, condition-number, runtime or application benefit follows from the asymptotic theorem.'
 ],
 'auxiliary_reviews':{
  'provider':'OpenAI','exact_backend':'unknown','independent_second_provider':False,'human_review':False,
  'input':'Same frozen neutral candidate packet and selected pinned code; fresh isolated role contexts; neither saw the other output before completion.',
  'defender':{'agent':'/root/f239_defender','status':'completed','recommendation':'retain narrowly conditional candidate pending external qualification','reason':'Concrete implemented ensemble match; hypothetical invertibility consumer and incremental value remain missing.'},
  'skeptic':{'agent':'/root/f239_skeptic','status':'completed','recommendation':'retain narrowly conditional candidate_pending; no application-check credit','reason':'Prediction restates the theorem; actual caller does not establish rank demand. Higher-order flattenings can have duplicate rows.'},
  'classification':'Auxiliary same-provider opinions, not external application evidence or human acceptance.'
 },
 'interruption_reason':'Owner requested current-progress GitHub publication before continuing research.',
 'next_action':'Finish WP109 canonical demand records and conditional-card fields, preserve isolated role evidence, then full graph QA. Do not redownload the 17 hash-pinned files or run a small-matrix frequency check as theorem proof.',
 'temporary_sources':'/private/tmp/ai-paper-WP109/sources; hash-check before use; no external full-code copies included in publication.'
})
save(root/'state/reading-progress/WP-109.json',journal)
packet=json.loads((temp/'candidate-packet.json').read_text())
gzsave(root/'state/reading-progress/history/WP109-neutral-review-packet.json.gz',packet)

pub=json.loads((root/'state/publication.json').read_text())
pub['pending_batch']={'requested_at':now,'status':'prepared_not_pushed','scope':'WP108 canonical source draft and reproducibility receipts; WP109 explicitly unfinished qualification journal only','base_verified_public_commit':pub['verified_commit'],'official_math_excluded':True,'cadence':'Explicit owner publication request; one batch, post-push receipts local until next meaningful batch.'}
save(root/'state/publication.json',pub)
checkpoint=json.loads((root/'state/checkpoint.json').read_text())
checkpoint['saved_at']=now
checkpoint['publication_work']['status']='preparing_explicit_owner_batch'
checkpoint['publication_work']['current_local_research_not_yet_pushed']='WP108 completed canonical records and WP109 unfinished qualification journal; current explicit owner request authorizes one reviewed publication batch.'
checkpoint['publication_work']['synchronization_status']='prepared_not_pushed'
checkpoint['recovery_commands']=[s for s in checkpoint['recovery_commands'] if not s.startswith('CurrentWP108')]
checkpoint['recovery_commands'].append('Read state/publication.json for actual publication receipt; do not infer success from a prepared batch. Resume WP109 curation from its reading-progress journal, with no new acquisition needed.')
save(root/'state/checkpoint.json',checkpoint)

path=root/'PROGRESS.en.md'
text=path.read_text().replace('Snapshot: October 26, 2026, locally curated through WP-108 after retrospective 038. The October 23 public MathWeave snapshot remains a separately verified older state; no routine GitHub push was made for this package.', 'Snapshot: October 26, 2026, curated through WP-108 after retrospective 038, with an explicitly unfinished WP-109 qualification journal. This snapshot is prepared for the owner-requested GitHub batch; exact published commit and CI observations are recorded separately in [publication state](state/publication.json).')
needle='The following paragraphs retain earlier package outcomes in their original time scope.'
text=text.replace(needle,'WP-109 is in progress: three pinned software projects and 17 source/license files totaling 394,010 downloaded bytes were inspected in recorded selected ranges. A real two-index Rademacher initializer matches the source ensemble under explicit restrictions, but the inspected consumer does not establish a need for invertibility. Isolated OpenAI skeptic/defender roles recommend retaining a narrowly conditional mapping; these are auxiliary opinions. Canonical admission, the complete card and package QA remain unfinished, so no candidate or check count is added. See the [reading journal](state/reading-progress/WP-109.json).\n\n'+needle)
path.write_text(text)
path=root/'README.md'
text=path.read_text().replace('下一WP109有界核对真实对称离散矩阵消费者和强旧基线，重要里程碑合并发布，本轮本地保存。','WP109已开始有界核对三个真实软件项目的矩阵分布、消费者和强旧基线；读取范围与未完成项见[日志](state/reading-progress/WP-109.json)，不新增候选或初检计数。本次按用户明确要求合并发布，提交与CI以[发布状态](state/publication.json)实际核验为准。')
path.write_text(text)
with (root/'docs/publication.md').open('a') as f:
 f.write('\n## October 26 owner-requested batch\n\nThe owner requested publication of current progress and an easy-to-share project name. The existing name **MathWeave (数学织网)** is retained: “math” identifies the source material and “weave” describes linking results, historical methods and testable applications. The public repository and local origin already use `https://github.com/yiduo/mathweave`; no duplicate repository or local directory rename is needed. This batch adds WP108 canonical F239 reading and evidence, plus WP109\'s explicitly unfinished selected-source qualification journal. It adds no application-check or human-review credit. The official `math/` tree and bulk local history remain excluded. Post-push verification receipts are retained locally for the next meaningful batch, avoiding a second routine push.\n')
with (root/'state/status.md').open('a') as f:
 f.write('\n\n## 2026-10-26 用户要求集中同步GitHub\n\n沿用MathWeave（数学织网）与已有仓库地址https://github.com/yiduo/mathweave。本批准备公开WP108规范成果及WP109未完成阅读日志，实际推送／远端检查以state/publication.json为准，不继承旧CI。WP109固定三个项目17文件394010字节，明确两索引Rademacher的输入匹配、真实可逆性消费者仍缺；隔离双角色仅辅助自查，卡片准入和规范整理未结束，44候选／13初检计数不变。接续无需重新下载或重跑科学实验；本批不包含第三方完整代码或官方math。\n')
print(json.dumps({'read_files':len(files),'read_lines':journal['actually_read_lines'],'downloaded_bytes':acquisition['total_downloaded_bytes'],'candidate_count':44,'checks':13}))
