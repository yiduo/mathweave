from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile

root=Path('/Users/smzdm/projects/ai_paper')
work=Path('/private/tmp/ai-paper-20261026-publication')
out=root/'reports/reproducibility/20261026-publication'
out.mkdir(parents=True,exist_ok=True)
assert json.loads((work/'staged-audit.json').read_text())['failure_count']==0
no_math=json.loads(gzip.decompress((work/'no-math-clean.json.gz').read_bytes()))
assert no_math['core_exit_code']==0
for name in ['core.log','no-math-core.log']:
    assert 'Ran 69 tests' in (work/name).read_text() and '\nOK\n' in (work/name).read_text()
(work/'prepare-first-draft.py').write_text((work/'prepare.py').read_text().replace('    path.parent.mkdir(parents=True, exist_ok=True)\n',''))
(work/'prepare-first-failure.txt').write_text('Initial prepare.py exited 1 at gzsave(path.write_bytes): FileNotFoundError for state/reading-progress/history/WP109-neutral-review-packet.json.gz. The history parent did not yet exist. Only WP109 journal had been written. Added parent.mkdir(parents=True, exist_ok=True), then reran successfully. No mathematical record, test threshold or application count was changed.\n')
names=['prepare.py','prepare-first-draft.py','prepare-first-failure.txt','clean_check.py','archive_checks.py','core.log','no-math-core.log','staged-audit.json']
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
    for name in names:
        raw=(work/name).read_bytes()
        info=tarfile.TarInfo(name); info.size=len(raw); info.mtime=0
        tar.addfile(info,io.BytesIO(raw))
raw=stream.getvalue();packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)),mode='r') as tar:
    for name in names:
        assert tar.extractfile(name).read()==(work/name).read_bytes()
(out/'prepublication-helpers-and-logs.tar.gz').write_bytes(packed)
(out/'no-math-clean.json.gz').write_bytes((work/'no-math-clean.json.gz').read_bytes())
receipt={'at':datetime.now(timezone.utc).isoformat(),'core_tests':69,'core_exit_code':0,'no_math_exit_code':0,'no_math_copied_files':no_math['files'],'no_math_copied_bytes':no_math['total_bytes'],'no_math_directory_removed':not (work/'clean').exists(),'archive':'reports/reproducibility/20261026-publication/prepublication-helpers-and-logs.tar.gz','archive_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(packed),'decompressed_bytes':len(raw),'member_bytes_verified':len(names),'scope':'Core and clean-directory publication QA; WP108 graph impact/export/archive receipts remain separately scoped. No new scientific experiment or new hypothesis validation. Exact final staged audit and remote commit/CI checked separately.'}
(out/'quality.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
