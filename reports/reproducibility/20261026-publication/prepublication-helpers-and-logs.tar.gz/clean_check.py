from pathlib import Path
import os, subprocess, sys, json, hashlib, shutil, gzip
root=Path('/Users/smzdm/projects/ai_paper')
work=Path('/private/tmp/ai-paper-20261026-publication')
clean=work/'clean'
assert not clean.exists()
clean.mkdir()
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
paths=[p for p in paths if p]
for extra in ['state/reading-progress/WP-109.json','state/reading-progress/history/WP109-neutral-review-packet.json.gz']:
    if extra not in paths: paths.append(extra)
manifest=[]
for name in sorted(paths):
    assert name.split('/')[0] not in {'math','.git','.venv','.cache','tmp'}
    source=root/name
    assert not source.is_symlink()
    target=clean/name
    target.parent.mkdir(parents=True,exist_ok=True)
    data=source.read_bytes()
    target.write_bytes(data)
    target.chmod(source.stat().st_mode & 0o777)
    digest=hashlib.sha256(data).hexdigest()
    assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
    manifest.append({'path':name,'bytes':len(data),'sha256':digest})
assert not (clean/'math').exists()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
with (work/'no-math-core.log').open('wb') as log:
    result=subprocess.run([sys.executable,'scripts/check.py'],cwd=clean,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'scope':'Current selected project snapshot in fresh directory without math, caches, models or installed project dependencies','files':len(manifest),'total_bytes':sum(x['bytes'] for x in manifest),'copy_hashes_verified':True,'upstream_math_paths':0,'core_exit_code':result.returncode,'manifest':manifest,'runtime':sys.version}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode()
packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
(work/'no-math-clean.json.gz').write_bytes(packed)
if result.returncode==0:
    shutil.rmtree(clean)
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'}))
raise SystemExit(result.returncode)
