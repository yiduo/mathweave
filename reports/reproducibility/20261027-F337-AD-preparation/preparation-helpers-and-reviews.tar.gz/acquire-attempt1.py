from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib,zipfile,io,gzip
w=Path(__file__).parent;cap=1048576;total=0;rows=[]
def fetch(url,name):
 global total
 req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-source-audit/0.1'})
 with urllib.request.urlopen(req,timeout=35) as r:
  b=r.read(cap-total+1);assert len(b)<=cap-total,'dependency acquisition byte cap exceeded';total+=len(b);(w/name).write_bytes(b)
  rows.append({'url':url,'status':r.status,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'temporary_path':str(w/name),'at':datetime.now(timezone.utc).isoformat()});return b
meta=fetch('https://pypi.org/pypi/autograd/1.9.1/json','pypi-autograd-1.9.1.json');d=json.loads(meta);assert d['info']['version']=='1.9.1'
f=next(x for x in d['urls'] if x['filename']=='autograd-1.9.1-py3-none-any.whl');assert f['size']<100000
b=fetch(f['url'],f['filename']);assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['digests']['sha256']
selected=['autograd/numpy/numpy_vjps.py','autograd/numpy/numpy_boxes.py','autograd/core.py','autograd/tracer.py','autograd-1.9.1.dist-info/METADATA','autograd-1.9.1.dist-info/licenses/LICENSE.md']
with zipfile.ZipFile(io.BytesIO(b)) as z:
 names=z.namelist();licenses=[x for x in names if 'LICENSE' in x];selected[-1]=licenses[0];members=[]
 for name in selected:
  data=z.read(name);p=w/'selected-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);members.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'lines':len(data.decode().splitlines())})
receipt={'at':datetime.now(timezone.utc).isoformat(),'version':d['info']['version'],'requires_python':d['info']['requires_python'],'requires_dist':d['info']['requires_dist'],'license_expression':d['info'].get('license_expression'),'wheel':{'filename':f['filename'],'url':f['url'],'sha256':f['digests']['sha256'],'bytes':f['size']},'acquisitions':rows,'download_bytes':total,'new_dependency_byte_cap':cap,'selected_source_members':members,'target_numeric_outputs_observed':False,'autograd_imported':False,'installed':False,'full_repository_cloned':False,'official_metadata_url':'https://pypi.org/pypi/autograd/1.9.1/json'}
(w/'acquisition.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['acquisitions','selected_source_members','wheel']},ensure_ascii=False));print('selectedmembers',json.dumps(members))
