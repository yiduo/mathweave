# APP-337-01 isolated pre-target skeptic opinion

Review status: conditional static support for a bounded implementation-consistency calibration; required specification fixes below must precede target execution. This is not application-value acceptance, a proof audit, human review, or an independent second-provider review. The exact selected backend model is unknown. This auxiliary opinion uses the same OpenAI provider.

## Isolation and inspected evidence

I read the complete review packet at `/Users/smzdm/projects/ai_paper/experiments/plans/APP-337-01-review-packet-v1.md` and independently verified its SHA256 as `72b17d7e72a0e808c1d32457916f7f248109acffc937cc7fdfd966cdc57254bd`.

Actual source scopes read:

- `/private/tmp/ai-paper-WP120/selected-source/autograd/numpy/numpy_vjps.py`: lines 12–68, 139–143, 225–230.
- `/private/tmp/ai-paper-WP120/selected-source/autograd/numpy/numpy_boxes.py`: lines 69–73, 117–127.
- `/private/tmp/ai-paper-WP120/selected-source/autograd/core.py`: lines 10–32.
- `/Users/smzdm/projects/ai_paper/math/preprints/Sharp-integral-fillings-in-CAT(0)-spaces-September-23-2026/build/sections/06-chords.tex`: lines 1–145, including the stated hypotheses, source definition, derivative argument, and zero extension at lines 97–123.

I did not import or run Autograd, evaluate any target fixture, run an experiment, contact another reviewer, or alter canonical project files. The packet's wheel/runtime metadata were supplied facts, not independently executed environment findings. Static source inspection makes this review nonblind to the predicted mechanism.

## Algebra and zero extension

Put q=2 beta>0 and p=1/q. On z>0, F=z(1+r^2 z^q)^(-p). Differentiating gives

- partial_z F=(1+r^2 z^q)^(-p-1), because p q=1;
- partial_r F=-2p r z^(1+q)(1+r^2 z^q)^(-p-1).

These agree with the packet. On z<0, the linear extension has partial_z F=1 and partial_r F=0. As z approaches zero from above, F-z=O(z^(1+q)), partial_z F approaches 1, and partial_r F approaches 0, uniformly on bounded r intervals. Thus the join is jointly C1, and the claimed zero derivatives are correct. This argument applies on all real r, although the target domain currently states r>=0.

The source proof explicitly verifies actual two-variable functions and avoids requiring the fractional intermediate to be C1. Its scalar argument supports this fragment. It does not transfer the source's Sobolev, minimizer, geometric, or weighted-inequality conclusions to this synthetic target.

A consequential graph distinction must be explicit: the source writes z*w(kappa*r*z^beta), whereas the target writes the algebraically collapsed z*(1+r*r*z^(2 beta))^(-1/(2 beta)). They are the same real function in scope, but not the same AD graph. In particular, n=4 is a nonsingular-power control for the collapsed target graph; the literal source graph still contains z^(1/2). No result from the collapsed graph can be stated as a backend result for every source-equivalent expression.

## Real-backend semantics

The inspected power base VJP multiplies the incoming cotangent by the exponent and by a shifted base power. It does not universally mask a zero cotangent before evaluating a negative shifted exponent at zero. That gives a coherent static mechanism for undefined intermediate differentiation to contaminate an otherwise differentiable total composite. It is a prediction, not observed output, and not evidence of a backend defect within its smooth primitive contract.

The comparison registrations and ArrayBox methods support scalar Python branching on the current primal value. With the old branch at z<=0, the fractional primitive is never constructed on the join. The branch returns z, whose derivative in z is 1 and whose dependence on r is absent. The inspected core has a zero-cotangent path when the output is disconnected from the differentiated input. The resulting selected branch derivatives coincide with the mathematical derivative at this particular C1 join. This does not authorize a general claim that differentiating arbitrary data-dependent branches is correct.

The where VJP only routes cotangents; it does not establish safe lazy evaluation of both expressions. The proposed code does not use where, and should preserve its actual pre-operation Python branch.

## Fixtures, old baseline, and thresholds

The 192 cases form a coherent exhaustive Cartesian grid for the stated small synthetic family. The n=3 and n=4 controls, the zero values, negative extension, small positive values, and degenerate r=0 cases should all remain. Exactly constructed boundary cases are suitable for a mechanism calibration, not for estimating defect prevalence or application impact. Counts across correlated grid cases are not independent discoveries or significance tests.

The old baseline is strong for the primary consistency question: it already implements the correct join without changing the function away from it. It is also decisive against any claimed incremental numerical value from this comparison. Introducing a weaker epsilon substitute or NaN suppression would weaken the experiment and should not replace this baseline.

The float tolerance is adequate for a deliberately coarse finite/accurate-to-absolute-scale admission check. It is not a relative-accuracy guarantee for tiny values or tiny r derivatives. A zero result for a sufficiently small nonzero derivative could pass this rule. Preserve signed reference values and raw absolute errors, and report relative error where defined; do not interpret a tolerance pass as resolving every tiny sensitivity.

The proposed primary is a conjunction: a predicted naive failure and a completely valid old-baseline pass, with the forward-value and control conditions. Report each conjunct separately. If a judge or resource problem prevents checking a required conjunct, do not promote the overall primary to supported on the strength of the remaining observations.

## High-precision and finite-difference judges

Decimal80/Decimal120 agreement checks precision sensitivity of one analytic formula. It is not an independent formula or a rigorous correctness certificate. The separate high-precision value path and finite differences add useful operational diversity, provided it is genuinely separately implemented and does not call the analytic derivative, reuse its derivative intermediates, or obtain values by integrating the asserted derivative. Common constants, the same interpreted function, and the same provider remain shared failure modes.

The fixed h=10^-100 at precision 180 is not inherently absurd for this bounded grid. At ordinary nonzero z the step is far smaller than the distance to the join; precision 180 leaves substantial decimal headroom even after subtraction and division by h. At z=0 the function is only C1 and a generic O(h^2) centered-difference claim would be wrong. The join error has order h^q. For the specified bounded family, the exact symbolic quotient is [1+(1+r^2 h^q)^(-1/q)]/2 and its deviation from 1 is at most r^2 h^q/(2q). With q>=1/5 and r<=4 this is at most 40 h^(1/5), comfortably below 10^-12 at the proposed h. This is an analytic worst-case bound for the proposed judge, not target numerical output. It provides a reason the join itself need not invalidate the rule.

However, r=0 centered differences evaluate negative r, outside the currently stated target domain. The closed-form function has a natural even extension to all real r, making a centered judge legitimate if that extension is explicitly frozen. Otherwise use and justify a domain-respecting one-sided judge. A centered derivative outside a declared domain cannot be left implicit.

A single step is still not a rigorous interval proof. Freeze an additional predeclared step/precision sensitivity check, or a documented per-regime truncation and rounding justification with an explicit inconclusive policy. An additional step must not be chosen after observing target disagreement. Repeating Decimal precision alone does not test finite-difference step bias.

## Required pre-target specification fixes

1. Define the finite-difference reference on all real r using the same even formula, including the negative-r values required at r=0, or replace the boundary rule with a specified one-sided method. Keep this domain extension separate from claims about the original radial application.
2. Freeze exact executable semantics: Python scalar floating input type, rational-string-to-float conversion, beta/exponent construction, argument differentiation interface, the z<0 versus z<=0 branch predicates, independent calls for both derivative components, and warning/exception capture behavior. The baseline's disconnected-r zero must remain a recorded real-backend result, with any warning retained.
3. State explicitly that the compared naive graph is the algebraically collapsed source-equivalent graph, and that n=4 is a control for that graph. Do not silently substitute a literal w(r*z^beta) graph or infer its results from this one.
4. Freeze Decimal construction from exact rational input strings, exact intended rational exponents, rounding context, zero/negative branches, and the separately written finite-difference value path. The mathematical reference should not inherit rounded binary exponents from the float implementation. Record the interpretation of any such float/reference difference.
5. Freeze the finite-difference sensitivity/justification rule described above and the judge-merging rule. At minimum distinguish reference precision disagreement, finite-difference disagreement, backend nonfinite result, backend exception, control failure, and resource failure. A judge-invalid fixture cannot count as a validated backend failure or baseline pass. A required invalid fixture makes the corresponding universal primary claim inconclusive.
6. Freeze resource measurement semantics before execution: full-process peak RSS and platform units, whether the calculation budget is wall or CPU time, the measured interval for Python allocations, whether tracing overhead counts toward RSS, timeout termination and partial-output handling, and what belongs to setup versus target calculation. Keep import/setup as a separate measurement while retaining full-process RSS. Caps are engineering stop conditions, not evidence of scientific failure. Archive unsuccessful runs and available partial evidence.

These fixes can be made in a new packet/specification version with hashes and a reason; retain v1 rather than rewriting away the review history. Freeze the implementation and executable specification before any target numerical output. No missing second-provider or human opinion needs to be invented to proceed with a limited calibration under the existing gate policy.

## Resources and provenance

The tiny deterministic grid and lack of new datasets or training stack make the proposed limits plausible, but static reading cannot certify the installed runtime, actual memory consumption, or timeout. Do not infer cap feasibility from wheel size. The stated compressed archive and verified decompression hashes are appropriate. Include source scopes/hashes, interpreter and dependency identities, exact code/spec commit, all 192 fixtures and component outputs, warning/exception classifications, measurement methods, and any failed-run partial artifacts. Unknown environment facts must remain unknown until observed. IEEE nonfinite values need explicit string/classification encoding rather than nonstandard JSON numbers.

## Strongest objection and decision boundary

The strongest objection is inferential, not algebraic: the function and graph were chosen after reading the source proof and the backend VJP, and the ordinary correct pre-operation branch is already expected to solve the entire task. A positive run therefore cannot distinguish useful incremental 2026 mathematics from routine established calculus and programming practice. There is no empirical evidence here that anyone needs this feature, that a real workload has the boundary pathology, or that the 2026 source improves cost, reliability, capability, or design relative to the strong old baseline.

The packet already largely states this null honestly. Keep that restriction binding: a positive calibration may document a reproducible source-inspired implementation caution and backend behavior; it cannot count as incremental application value, theorem validation, general ML success, or acceptance of a far-transfer application connection. More grid cases, precision, or agreement between same-provider opinions cannot repair this inferential gap. Establishing application value would require a separately motivated external task and outcome where the strong old method is evaluated fairly and some incremental benefit is actually demonstrated.

My conclusion is conditional support for running only the bounded consistency calibration after the pre-target fixes, with no application-value endorsement. This opinion records reasons and uncertainties; it does not manufacture a consensus approval or rejection.
