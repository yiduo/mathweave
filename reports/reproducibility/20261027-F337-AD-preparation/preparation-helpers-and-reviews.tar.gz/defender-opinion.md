# APP-337-01 independent auxiliary defender opinion

Review stage: pre-target static review. No target values, gradients, benchmark outputs, or fixture computations were produced by this reviewer. Autograd was neither imported nor run. No other reviewer was contacted. This is one isolated same-OpenAI-provider auxiliary opinion; exact backend model identifier is unknown. It is neither human acceptance nor independent second-provider evidence.

## Scope and disposition

I read `experiments/plans/APP-337-01-review-packet-v1.md` and verified its SHA256 as `72b17d7e72a0e808c1d32457916f7f248109acffc937cc7fdfd966cdc57254bd`. I statically inspected the selected Autograd source scopes for power, multiply, comparisons, where, scalar operators and reverse traversal, plus the local tracer's relevant tracing behavior and the selected metadata/license. I inspected F337's `math/preprints/Sharp-integral-fillings-in-CAT(0)-spaces-September-23-2026/build/sections/06-chords.tex`, lines 75–145, concentrating on 103–123. The packet's named source omits the local `preprints/` directory. I did not independently establish that the extracted selected files were generated from the stated wheel or verify the upstream Git revision in this isolated review; those bindings must come from the execution provenance.

Disposition: conditionally support proceeding to a frozen, small actual-backend calibration after the implementation details below are fixed. The mathematical prediction is defensible, the ordinary correct branch is a strong relevant baseline, and the packet already limits its interpretation appropriately. This is not approval of a new scientific application or a demonstrated software defect. No change of the proposed fixture set or tolerances is justified by my static inspection.

## Algebra and source correspondence

Write q=2 beta>0, p=1/q, y=r^2 z^q. For positive z, F=z(1+y)^(-p). Differentiation gives

- F_z=(1+y)^(-p)-p q y(1+y)^(-p-1)=(1+y)^(-p-1).
- F_r=-2p r z^(1+q)(1+y)^(-p-1)=-(r/beta)z^(1+2 beta)(1+y)^(-1/(2 beta)-1).

These agree with the packet. For bounded r, F-z=O(z^(1+q)), F_z tends uniformly to 1, and F_r tends uniformly to 0 as z decreases to zero. Joining to F=z for negative z therefore gives the stated jointly C1 function, with F_z=1 and F_r=0 at the join. This is also valid on all real r because the displayed function is even in r. These are first derivative claims; joint C1 does not confer arbitrary higher smoothness or differentiability on the fractional intermediate itself.

The source defines w(t)=(1+a t^2)^(-(n-2)/2) and F_1=z w(kappa r z^beta). Setting a=kappa=1 and beta=1/(n-2) gives the packet's function exactly. Source lines 113–120 explicitly make the same zero extension and joint C1 argument. The target takes a scalar calculus fragment from the proof. It does not inherit the manuscript's Sobolev admissibility, geometric inequalities, extremizer assumptions, or PDE conclusions.

The chosen computational graph has intermediate z^(2 beta), after algebraic factoring. Thus n=3 and n=4 really are smooth intermediate-power controls for this graph. The original z^beta graph can have a different singular intermediate even at n=4. Results must be attributed to the frozen factored graph, not every algebraically equivalent implementation.

## Actual-backend support and limits

Selected `numpy_vjps.py` lines 139–143 use `g * y * x ** where(y, y - 1, 1.0)` for the power base derivative. For a fixed positive exponent q<1 this still evaluates a negative power at base zero; it does not mask a zero upstream cotangent before that operation. The multiply VJPs at lines 79–83 and reverse traversal at `core.py` lines 25–32 make contamination of a formally vanishing chain-rule term plausible. Zero times a nonfinite intermediate is not repaired merely by the total mathematical composite having a derivative.

This supports the primary prediction without establishing a runtime result. Exact warning/exception/nonfinite behavior still depends on the frozen NumPy scalar types, error policy, and primitive path. The primitive rule is appropriate on its smooth domain; this graph presents it with a nonsmooth intermediate boundary. The packet correctly avoids alleging a library contract violation.

The old branch `if z<=0: return z` is a genuine correct baseline for first derivatives: it prevents construction of the problematic positive-side graph at the join, and its selected branch derivatives equal the derivative of the joint C1 composite there. It requires no analytical derivative injection. It is ordinary established branching and is expected to solve this deliberately boundary-sensitive example. There is consequently no presumed incremental numerical value of the 2026 source.

Python scalar branching is essential. An eager `where` around a previously evaluated fractional expression is not the same baseline and must not be substituted. Both methods must otherwise use identical types, arithmetic order, constants, backend options, and independent calls for the two scalar partials. Do not reuse a failed graph or cached gradient across methods.

For the r derivative on z<=0, returning z makes the output independent of the differentiated argument. The selected `core.py` explicitly provides a zero cotangent for an untraced output, and the local tracer emits an independence warning. Such a warning can be expected even for the correct baseline; record it rather than equating every warning with an incorrect derivative.

## Fixtures, judges, and tolerances

The 6 by 4 by 8 Cartesian product has the proposed 192 fixtures. It includes smooth controls, the zero join, very small positive values, negative extension, and r=0 degeneracy. Deliberate exact zeros are appropriate for implementation admission, with no prevalence inference. The fixture outcomes are highly dependent deterministic checks, not independent hypothesis tests or a statistical sample. The packet's existential primary prediction and full-table retention are appropriate.

The analytic formulas and the separately implemented finite-difference value path give different mathematical checking routes from reverse-mode AD. Decimal80 versus Decimal120 is precision sensitivity, not an independent implementation. Decimal analytic and finite-difference paths still share the same Decimal engine and can share transcription or exponent errors. The final record should describe these as partially independent numerical cross-checks, not three independent judges. Each path should parse the rational inputs and derive q/p from integer n independently; no binary-float beta may be converted into Decimal and no judge may call the AD function or reuse its computed derivatives.

The fixed finite-difference h=10^-100 at precision 180 is supportable for this small grid. At the C1 join the centered z difference is [1+(1+r^2 h^q)^(-1/q)]/2. Its difference from 1 is bounded by r^2 h^q/(2q). With q>=1/5 and r^2<=16, this is at most 4 times 10^-19 for the proposed h, well below the 10^-12 absolute floor. This is an a priori error bound, not a computed target fixture. Away from the join, h is much smaller than the smallest positive z, and 180 decimal digits leave roughly 80 digits after an ordinary subtraction divided by h at values of order one. This supports the chosen rule, while not constituting a rigorous floating-point or interval proof.

The r=0 centered difference evaluates negative r, outside the packet's initial r>=0 wording. Explicitly declare the natural even real-r extension for the finite-difference judge before freezing. This is mathematically legitimate and makes the expected zero partial a valid two-sided check. Alternatively predeclare a boundary derivative convention, but do not change it after observing outputs.

The relative-plus-absolute tolerances are consistent for admission checks. Their absolute floor means very small nonzero r derivatives may not have useful relative-accuracy assurance. Do not claim high relative fidelity in that region. Retain the high-precision reference values and absolute/relative residuals so this limit is inspectable. Precision agreement at 10^-60 is reasonable for Decimal80 versus Decimal120 on this bounded grid but cannot by itself certify a shared analytic error. Any unresolved reference/finite-difference disagreement must gate the associated verdict as inconclusive before scoring either AD implementation.

## Required pre-target clarifications

1. Freeze exact scalar types and conversions; constant formation from n; Python branch predicates; arithmetic expression and order; the separate r/z differentiation closures; and NumPy warning/error settings. Record exceptions by component so one failure does not erase the other component, forward result, or subsequent fixtures. Preserve the exact fixture order and explicit IEEE nonfinite classifications in strict JSON.
2. Declare the real-r even extension used by the centered difference at r=0. Document the a priori join-error bound above or an equivalent justification. Keep the fixed step/precision rule independent of target outcomes.
3. Implement the analytic and finite-difference judges as separate paths, with independent rational parsing and no AD/analytic-derivative reuse in the finite-difference value evaluator. Document their shared Decimal-engine limitation and apply the judge-disagreement gate before any target conclusion.
4. Bind the actual imported Autograd files to the pinned wheel and record Python/NumPy versions and import paths. Selected-source inspection alone does not establish the eventual runtime identity. Freeze the executable specification and code snapshot/commit before producing target outputs.
5. Freeze resource accounting and enforcement: separate import/setup, calculation, and compression intervals; identify whether the 60-second calculation budget includes reference judges; state the tracemalloc window for the 64 MiB Python-allocation cap and platform/unit convention for the 128 MiB full-process RSS cap. Native allocations are not covered by tracemalloc. The RSS cap may fail on a given runtime; that is a preserved resource failure, not permission to silently raise the limit. A watchdog termination needs its own preserved partial-output/error record.
6. Make the archive manifest explicit and capture failed runs too. Verify decompression hashes of the raw outcome records and frozen code/spec snapshot before deleting their uncompressed copies. Preserve wheel/source/runtime hashes and selected-source provenance without copying the read-only upstream mathematical corpus. Include the MIT notice if redistributing substantial backend source. Compress the capsule rather than treating JSON compactness as compression.

These are specification-completeness fixes, not evidence of an observed defect or grounds to tune the target after execution. If already supplied by the registered executable specification, they need only be checked for consistency with this packet.

## Permitted resulting claim

If supported by the complete actual-backend run and reproducibility checks, the defensible claim is that one frozen factorization of an existing jointly C1 scalar function can expose a nonsmooth intermediate to this pinned AD backend at synthetic zero gates, while an ordinary pre-operation branch agrees with bounded numerical references on the frozen grid. The finding would validate a narrow implementation-consistency audit and an expression-level caution. It would establish no customer/network bug, training benefit, activation novelty, new calculus, 2026 numerical advantage, full theory-chain verification, human acceptance, or second-provider independence. An adverse primary result, judge conflict, timeout, memory failure, or reproducibility failure must remain visible under the packet's declared outcome rules.
