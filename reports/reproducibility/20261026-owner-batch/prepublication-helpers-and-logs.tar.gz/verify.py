from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,urllib.request,sys
root=Path('/Users/smzdm/projects/ai_paper');work=Path('/private/tmp/ai-paper-owner-publication-20261026');c=json.loads((work/'public-candidate.json').read_text());base='https://api.github.com/repos/yiduo/mathweave'
def get(url):
 req=urllib.request.Request(url,headers={'User-Agent':'MathWeave-owner-publication-verification','Cache-Control':'no-cache'})
 with urllib.request.urlopen(req,timeout=30) as r:return r.read()
def js(url):return json.loads(get(url))
def gzsave(name,x):
 raw=json.dumps(x,ensure_ascii=False,indent=2).encode();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;(work/name).write_bytes(packed)
if '--ci-only' not in sys.argv:
 repo=js(base);head=js(base+'/git/ref/heads/main');remote=js(base+'/git/commits/'+c['commit']);tree=js(base+'/git/trees/'+c['tree']+'?recursive=1')
 assert repo['private'] is False and repo['id']==1429150108 and head['object']['sha']==c['commit']
 assert remote['tree']['sha']==c['tree'] and [p['sha'] for p in remote['parents']]==[c['parent']]
 assert tree['sha']==c['tree'] and not tree['truncated']
 expected={}
 data=subprocess.check_output(['git','ls-tree','-r','-z','--long',c['commit']],cwd=root)
 for line in data.split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t');mode,kind,sha,size=meta.decode().split();expected[path.decode()]={'mode':mode,'type':kind,'sha':sha,'size':int(size)}
 actual={x['path']:{k:x[k] for k in ['mode','type','sha','size']} for x in tree['tree'] if x['type']=='blob'}
 assert actual==expected and len(actual)==c['files']
 assert not any(p=='math' or p.startswith('math/') for p in actual)
 observed=[]
 for p in ['README.md','README.en.md','CHARTER.en.md','PROGRESS.en.md','reports/metrics.json','reports/cards/APP-239-01.md','state/reading-progress/WP-110.json']:
  want=subprocess.check_output(['git','show',c['commit']+':'+p],cwd=root);got=get('https://raw.githubusercontent.com/yiduo/mathweave/'+c['commit']+'/'+p);assert got==want,p
  observed.append({'path':p,'bytes':len(got),'sha256':hashlib.sha256(got).hexdigest(),'byte_equal':True,'authentication':'none'})
 receipt={'at':datetime.now(timezone.utc).isoformat(),'repository':repo['html_url'],'repository_id':repo['id'],'public':True,'head_commit':c['commit'],'tree':c['tree'],'parent':c['parent'],'full_tree_equal':True,'files':len(actual),'total_bytes':sum(x['size'] for x in actual.values()),'official_math_paths':0,'anonymous_file_reads':observed,'bulk_local_history_included':False,'phase_one_complete':False}
 gzsave('verification.json.gz',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='anonymous_file_reads'}))
runs=js(base+'/actions/runs?head_sha='+c['commit']+'&per_page=10')
selected=[{k:r[k] for k in ['id','name','head_sha','status','conclusion','html_url','created_at','updated_at']} for r in runs['workflow_runs'] if r['head_sha']==c['commit']]
ci={'at':datetime.now(timezone.utc).isoformat(),'commit':c['commit'],'runs':selected,'scope':'69 core checks,13 archived replays,exports and publication audit; no EXP076 strict Linux,optional NumPy,Lean,human/provider or research acceptance'}
gzsave('CI-observation.json.gz',ci);print(json.dumps(ci))
