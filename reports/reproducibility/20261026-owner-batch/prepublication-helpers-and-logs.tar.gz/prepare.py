from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys,tarfile
sys.path.insert(0,'src')
from ai_value.source_results import named_results
root=Path.cwd(); now=datetime.now(timezone.utc).isoformat(); work=Path('/private/tmp/ai-paper-owner-publication-20261026')
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
j=json.loads(Path('state/reading-progress/WP-110.json').read_text())
new=[]
for m in j['manuscripts']:
 for f in m['tex_files']:
  if f['path'].endswith(('/sections/tabloid.tex','/sections/degree-supplement.tex','/sections/tabloid-supplement.tex')):
   raw=Path(f['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==f['sha256']
   assert len(raw.decode().splitlines())==f['lines']
   f['body_actually_read']=True;f['actually_read_ranges']=[[1,f['lines']]]
   if not any(x['path']==f['path'] for x in j['actual_source_files_read']):
    j['actual_source_files_read'].append({'path':f['path'],'sha256':f['sha256'],'lines':f['lines'],'actually_read_ranges':[[1,f['lines']]],'source_result_inventory_only':named_results(raw.decode()),'reading_evidence':'Read in immediately preceding continuation; this checkpoint closes its 1026-line bookkeeping lag, without rereading or canonical promotion.'});new.append(f['path'])
assert len(new)==3
j['actual_source_lines_read']=sum(x['lines'] for x in j['actual_source_files_read']); assert j['actual_source_lines_read']==10014
j['updated_at']=now;j['next_actual_read']='Second manuscript sections/transfer-supplement.tex (229 lines), then references.tex (93 lines);322 lines remain. Historical/formal qualification, canonical bindings, graph QA and retrospective039 remain pending.'
j['reading_batches'].append({'at':now,'files':new,'lines':1026,'status':'previous_continuation_reading_reconciled_not_new_canonical_qualification','notes':['Conditional-product transfer requires actual conditional independence after fixing the environment; uniform half marginals alone do not suffice. Buffer count L>=4000000 and coarse polynomial embedding constants are not practical costs.','Degree-sum supplements give distinct proof routes rather than distinct applications. Signed-tabloid existence and all-positive inverse degree powers remain source claims, not local proof or engineering validation.']})
save('state/reading-progress/WP-110.json',j)
progress={'source_files_fully_read':len(j['actual_source_files_read']),'source_lines_read':10014,'selected_total_tex_lines':10336,'new_manuscripts_fully_read':1,'family_canonical_qualified_manuscripts':'4/12','actual_bodies_read_including_uncurated':'5/12','remaining_selected_lines':322,'qualification_status':'incomplete; no new canonical bindings or application checks'}
b=json.loads(Path('state/backlog.json').read_text())
items=b.get('items',b.get('tasks',[]))
for x in items:
 if x.get('id')=='WP-110':x['execution_progress']=progress
save('state/backlog.json',b)
c=json.loads(Path('state/checkpoint.json').read_text());c['saved_at']=now
for k in ['active_work_package','next_work_package']:
 c[k]['execution_progress']=progress
c['recovery_commands']=[j['next_actual_read'] if 'WP110 journal is authoritative' in x else x for x in c['recovery_commands']]
c['resume_commands']=[x for x in c['resume_commands'] if not ('405' in str(x) or '7123' in str(x))]
c['release_state']='Owner-requested publication batch prepared locally; old verified public commit8700f8b retained until actual push and independent readback.'
c['publication_work']['current_local_research_not_yet_pushed']='This explicit owner-requested batch includes completed WP109 canonical work and incomplete WP110 reading checkpoint10014/10336 lines. Remote synchronization and CI pending.'
c['publication_work']['synchronization_status']='preparing_owner_requested_batch'
c['recovery_observation']['publication_recovery']={'at':now,'base_commit':'6889188','disk_available':'19GiB; system observation','running_project_processes':[],'new_research_experiments':0}
save('state/checkpoint.json',c)
p=json.loads(Path('state/publication.json').read_text());p['pending_batch']={'state':'preparing_not_pushed','requested_by':'project owner, current explicit request','prepared_at':now,'scope':'WP109 canonical progress and unfinished WP110 reading10014/10336 lines; no new application validation','official_math_excluded':True,'name':'MathWeave (数学织网)','repository_url':'https://github.com/yiduo/mathweave','new_commit_ci':'not_observed'}
p['local_progress_after_verified_snapshot']='Completed WP109 and incomplete WP110 journal; pending explicit requested batch. Existing verified snapshot and CI identify only8700f8b.'
save('state/publication.json',p)
p=Path('README.md');s=p.read_text();s=s.replace('公开8700f8b仅含当时未完成阅读日志，当前规范增量本地保存；','本次按用户要求准备合并公开WP109规范成果及WP110未完成阅读日志；')
s=s.replace('本地规范增量尚未推送，公开快照8700f8b仅含当时未完成WP109日志。下一WP110补F238两篇未读伴随稿，当前仅两README和38TeX10336行清单，不能计正文阅读。','本次发布批次纳入WP109规范成果。WP110正在补F238两篇伴随稿，实际读完36/38个TeX文件、10014/10336行，其中一篇正文已读完；历史、形式化和图谱整理尚未完成，规范覆盖仍为4/12，不增加完整族或应用验证。实际远端提交与CI另见发布状态。')
p.write_text(s)
p=Path('README.en.md');s=p.read_text();start=s.index('The verified public snapshot `8700f8b`');end=s.index(' See [progress]',start)
s=s[:start]+'This owner-requested publication batch includes the completed WP-109 canonical conditional candidate and the unfinished WP-110 reading journal. WP-110 has actually read 36 of 38 selected TeX files (10,014 of 10,336 lines); historical/formal qualification and graph curation remain incomplete, so curated F238 coverage remains 4/12. An actual invertibility consumer and finite-D decision value remain unestablished. Exact remote synchronization and CI are recorded separately in [publication state](state/publication.json).'+s[end:];p.write_text(s)
p=Path('PROGRESS.en.md');s=p.read_text();a=s.index('Snapshot:');z=s.index('\n\n| Measure',a);s=s[:a]+'Snapshot: October 26, 2026, curated through WP-109 after retrospective 038, with an explicitly unfinished WP-110 reading checkpoint. This owner-requested batch prepares those current records for publication under MathWeave. Exact verified remote commit and CI observations are recorded separately in [publication state](state/publication.json), which retains the previous verified snapshot until readback. **The overall phase-one goal remains open.** Counts come from [canonical metrics](reports/metrics.json), the [acceptance matrix](reports/acceptance.md), and versioned reading and experiment records.'+s[z:]
s=s.replace("WP-110 next reads two of F238's eight unread companions;only their READMEs and38-file/10,336-line inventory are read so far.","WP-110 is reading two of F238's eight not-yet-curated companions:36/38 TeX files and10,014/10,336 lines have actually been read, including one complete selected body. The remaining322 lines, historical/formal comparison, canonical bindings and quality checks remain pending. Curated F238 coverage stays4/12; source reading alone is not a completed research package.");p.write_text(s)
p=Path('docs/publication.md');p.write_text(p.read_text()+'\n\n## Current explicit owner request: WP109 and unfinished WP110\n\nThe owner again requested current progress on GitHub. Retain **MathWeave (数学织网)** and the existing repository address; no duplicate repository or directory rename is needed. Include completed WP109 canonical records and its conditional APP23901, plus the WP110 reading checkpoint (36/38 files,10014/10336 lines; canonical F238 coverage still4/12). WP110 is not a completed package and adds no application validation. Create one reviewed public commit parented by the previous public branch, excluding bulk local history and official math. Record post-push verification locally for the next meaningful batch to avoid a second routine push.\n')
p=Path('CHANGELOG.md');s=p.read_text();p.write_text(s.replace('# 变更记录\n','# 变更记录\n\n## 2026-10-26 — MathWeave当前进展批次\n\n- 沿用易传播名称MathWeave（数学织网）和GitHub地址yiduo/mathweave，同步本次明确要求的当前成果。\n- 纳入WP109实际消费者限定与APP23901待定候选，45候选／13初检，未增加应用验证。\n- 保存WP110未完成阅读36/38文件、10014/10336行；规范覆盖仍4/12，后续整理与复盘039待完成。\n- 官方math目录、第三方全文、缓存和批量本地Git历史不发布；远端提交、CI与本地准备分别记录。\n',1))
p=Path('state/status.md');p.write_text(p.read_text()+'\n\n## 2026-10-26 用户要求当前进展发布\n\n沿用MathWeave（数学织网）和已有仓库地址yiduo/mathweave，准备一次合并发布已完成WP109及WP110未完成阅读。WP110台账补齐上一续段实际读完的tabloid、degree-supplement和tabloid-supplement共1026行，当前36/38文件10014/10336行，仍余transfer-supplement229与references93。首篇正文已读完，第二篇未读完；历史／形式化／规范绑定／QA和复盘039尚未完成，规范F238仍4/12，无新增实验或初检。当前无运行项目任务，磁盘可用19GiB为系统观察。精确发布与CI待远端核验，不能继承8700f8b的成功状态。\n')
# Reuse only a small inspected clean-copy QA helper; do not copy upstream.
with tarfile.open('reports/reproducibility/20261026-publication/prepublication-helpers-and-logs.tar.gz') as t:
 s=t.extractfile('clean_check.py').read().decode().replace('/private/tmp/ai-paper-20261026-publication',str(work));(work/'clean_check.py').write_text(s)
print(json.dumps({'reading_lines':10014,'read_files':len(j['actual_source_files_read']),'remaining':322,'canonical_F238':'4/12','state':'prepared_not_pushed'}))
