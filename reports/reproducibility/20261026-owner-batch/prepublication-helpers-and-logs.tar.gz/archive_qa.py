from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,tarfile,shutil
root=Path.cwd();work=Path('/private/tmp/ai-paper-owner-publication-20261026');out=root/'reports/reproducibility/20261026-owner-batch';out.mkdir(exist_ok=True)
a=json.loads((work/'staged-audit.json').read_text());assert a['failure_count']==0 and a['upstream_math_paths']==0
clean=json.loads(gzip.decompress((work/'no-math-clean.json.gz').read_bytes()));assert clean['core_exit_code']==0 and not (work/'clean').exists()
for n in ['core.log','no-math-core.log']:
 t=(work/n).read_text();assert 'Ran 69 tests' in t and '\nOK\n' in t and '"canonical_citations": 8404' in t
(work/'preparation-correction.txt').write_text('Draft prose initially said35/38 files. The hash-verified journal counted36 full files (38 total minus2 unread), so all entry prose was corrected to36 before QA/staging. Line count10014, canonical graph, experiments and source thresholds unchanged. Original helper retained as prepare-first.py.\n')
names=['prepare-first.py','prepare.py','preparation-correction.txt','clean_check.py','archive_qa.py','create_public_commit.py','verify.py','core.log','no-math-core.log','staged-audit.json']
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w') as t:
 for n in names:
  raw=(work/n).read_bytes();i=tarfile.TarInfo(n);i.size=len(raw);i.mtime=0;t.addfile(i,io.BytesIO(raw))
raw=b.getvalue();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for n in names:assert t.extractfile(n).read()==(work/n).read_bytes()
(out/'prepublication-helpers-and-logs.tar.gz').write_bytes(packed);shutil.copyfile(work/'no-math-clean.json.gz',out/'no-math-clean.json.gz')
r={'at':datetime.now(timezone.utc).isoformat(),'core_exit_code':0,'core_tests':69,'no_math_core_exit_code':0,'clean_directory_removed':True,'clean_files':clean['files'],'clean_bytes':clean['total_bytes'],'copy_hashes_verified':True,'staged_audit_failures':0,'official_math_paths':0,'archive_sha256':hashlib.sha256(packed).hexdigest(),'decompressed_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(packed),'archive_members_verified':len(names),'scientific_experiments_added':0,'scope':'Publication QA of docs and incomplete reading checkpoint; WP109 graph/export/impact/15-archive receipts remain independently scoped. No new application validation, local Lean build or human/provider review.'}
(out/'quality.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
