from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, re, shutil, tarfile

root = Path.cwd()
work = Path(__file__).resolve().parent
dest = root / 'reports/reproducibility/20261027-F337-AD-execution'
now = datetime.now(timezone.utc).isoformat()

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def copy_gzip(src, target):
    raw = src.read_bytes()
    data = gzip.compress(raw, mtime=0)
    assert gzip.decompress(data) == raw
    target.write_bytes(data)

q = json.loads(gzip.decompress((work / 'quality.json.gz').read_bytes()))
clean = json.loads(gzip.decompress((work / 'clean-check.json.gz').read_bytes()))
assert clean['core_exit_code'] == 0 and clean['copy_hashes_verified'] and not clean['math_included']
assert not (work / 'clean').exists()
for name in ['core.log', 'clean-core.log']:
    log = (work / name).read_text()
    assert re.search(r'Ran 88 tests in ', log) and '\nOK\n' in log and 'skipped=' not in log
assert q['backend_exceptions'] == 16 and q['new_initial_checks'] == 0
assert q['source_archive_members'] == 337 and q['source_inputs_equal_frozen39']
assert len(q['impact_cases']) == 126 and len(q['alternative_route_cases']) == 2
for name in ['quality.json.gz', 'clean-check.json.gz']:
    raw = (work / name).read_bytes()
    assert gzip.decompress(raw)
    (dest / name).write_bytes(raw)
for name in ['core.log', 'clean-core.log', 'quality.log', 'clean-helper.log', 'curation.log']:
    copy_gzip(work / name, dest / (name + '.gz'))
comparison = json.loads((work / 'next-source-comparison.json').read_text())
comparison.update({'selected_family': 'F-181', 'selected_work_package': 'WP-122', 'selected_at': now,
    'reason': 'Combinatorics has only four of 37 families read. Compare finite graph decomposition witnesses and number of pieces with exact edge coverage and total construction cost; linear piece count is not assumed linear-time computation. F188 random-removal finite/asymptotic bridge and F192 Boolean degree interfaces remain alternatives. F181 is not the shortest source.',
    'zero_hypothesis': 'Old cycle/edge decomposition and ordinary witness validation may already suffice; no new application gain follows from the title or a small graph demonstration.'})
save(root / 'state/selection-WP122.json', comparison)

summary = {'at': now, 'work_package': 'WP-121', 'generation': 'GEN-20261027-118',
 'run_id': 'EXP-337-001-b13e1932a05a4c6a',
 'frozen_implementation_commit': 'db5871683b31fdb66225e32e28480e27b015b747',
 'first_target_and_strict_replay_terminal': True, 'full_scientific_payloads_equal': True,
 'scientific_fields_excluded': [], 'runtime_binding_and_original_resources_pass': True,
 'fixtures': 192, 'reference_valid_fixtures': 192, 'backend_exceptions': 16,
 'outcome': 'inconclusive_backend_exception', 'new_initial_check_credit': 0,
 'core_tests': 88, 'clean_core_tests': 88, 'clean_files': clean['files'], 'clean_bytes': clean['bytes'],
 'clean_directory_removed': True, 'single_seed_impact_cases': 126, 'multi_seed_cases': 2,
 'source_archive_members': 337, 'scientific_archives': 17,
 'protected_previous_files': 492, 'old_canonical_rows_preserved': 5403,
 'new_canonical_records': 2, 'versioned_canonical_records': 3, 'new_explicit_edges': 3,
 'numerical_implementation_changed_after_target': False,
 'post_target_implementation_scope': 'Graph projection, diagnostic counting and reporting only; original numerical source snapshot and replay remain frozen.',
 'known_limitations': ['No verified 2026 incremental application gain', 'Observed NumPy native file hashes differ from installed RECORD for 19 files; not a publisher-wheel attestation', 'No human or second-provider approval'],
 'metadata_after_clean': ['Closure receipts', 'WP122 selection metadata', 'status/checkpoint/backlog/publication boundary', 'Diagnostic counting documentation'],
 'github_push': False, 'overall_goal': 'active_incomplete'}
save(dest / 'closure.json', summary)

doc = root / 'docs/data-dictionary.md'
text = doc.read_text()
assert 'diagnostic_run_ids' not in text
doc.write_text(text + '\n`diagnostic_run_ids` 保存实际执行但未满足事前合格初检规则的运行，投影关系为 `diagnostic_execution`。它与合格 `run_ids`、零件 `component_run_ids` 必须互斥，单列统计 `diagnostic_executions_not_initial_checks`。后端异常、裁判或资源闸门未通过不能自动计入初检，也不能删除已有输出；这不把待定诊断当作数学反证。F337 首跑保留 192 项输出和 16 个异常，原判据不变，合格初检仍为 14。\n')

report = root / 'reports/F337-AD-execution.md'
report.write_text('''# F337: first actual AD execution and diagnostic result

WP121 / GEN-20261027-118. The preregistered 192-fixture target and a fresh archived-source replay completed. Complete raw and summary JSON payloads match; no scientific fields were excluded. All 192 reference checks were valid and the original resource gates passed.

Sixteen naive zero-point `dz` evaluations raised `ZeroDivisionError` (`0.0 cannot be raised to a negative power`). The frozen success criterion excluded backend exceptions, so the primary outcome is **inconclusive_backend_exception**, with zero new qualified initial-check or validation credit. We did not change scalar types, grid, tolerances or the criterion after seeing output. Neither this observation nor ordinary correct branching establishes incremental application value from the 2026 result, a library-contract defect, or training improvement.

The canonical record is `data/provenance/readings/F-337-AD-execution.json` plus versioned graph records and APP-337-01. The original numerical implementation is frozen at `db5871683b31fdb66225e32e28480e27b015b747`; all 39 archived input members match its pre-output freeze receipt. Subsequent graph/reporting code represents diagnostic executions separately and does not alter that numerical result.

Calculation took 0.904506416991353 seconds; traced Python peak was 10,782,282 bytes and the terminated CLI worker RSS was 56,246,272 bytes. The 19 NumPy native-file RECORD mismatches remain documented; matching the observed pin is not publisher-wheel authenticity or a fully hermetic native runtime proof.

Full graph/export/source and impact checks passed, including 126 single-seed and two multi-seed cases, 17 scientific archives and 337 archived source members. Both current-tree and fresh no-upstream-copy checks passed 88 tests. The clean copy was removed after success; closure metadata and the counting note were added subsequently. Receipts and compressed helpers are in `reports/reproducibility/20261027-F337-AD-execution/`.

Current counts remain 47 candidates, 14 qualified initial checks, 14 distinct qualified validations, six limited supports and eight adverse observations, with one diagnostic execution listed separately. Human and second-provider reviews remain pending. Phase one is incomplete. This work is local; no GitHub push was made.

Next: WP122 reads the low-coverage F181 cycle-and-edge decomposition source. The current selection used only README and inventory evidence. A linear bound on the number of pieces does not establish linear-time construction. Compare older decomposition methods and complete witness validation before proposing a benchmark. Global retrospective 043 is due after WP122.
''')

backlog = json.loads((root / 'state/backlog.json').read_text())
task = next(t for t in backlog['tasks'] if t['id'] == 'WP-121')
task.update({'status': 'complete', 'completed_at': now, 'execution_state': 'closed_diagnostic_no_initial_credit',
 'next_action': 'Do not rerun frozen EXP337; proceed to WP122 source qualification.',
 'evidence': ['data/provenance/readings/F-337-AD-execution.json', 'reports/F337-AD-execution.md', str((dest / 'closure.json').relative_to(root))],
 'result': '192 valid references,16 backend exceptions; frozen primary inconclusive,zero qualified initial credit. Exact full archived-source replay/runtime/resource pass;126single+2multi/fullobjects/17archives337members/88core/no-mathclean pass. Diagnostic record and unchanged criteria preserved.'})
assert not any(t['id'] == 'WP-122' for t in backlog['tasks'])
next_task = {'id': 'WP-122', 'priority': 1, 'status': 'ready', 'parent_task': 'WP-006',
 'objective': 'Read all current F181 source modules, bind named results and finite witness/cost conditions, compare actual formal scope and primary historical statements, and assess transferable decomposition contracts.',
 'selection_reason': comparison['reason'], 'selection_receipt': 'state/selection-WP122.json',
 'inputs': ['F-181', 'P-aa4a9f7b64d5fc71', 'state/selection-WP122.json'],
 'resource_limit': 'Current 9 TeX/Bib files,2566 lines plus README; selected actual formal and original historical statement scopes. No corpus copy,Lean cache or large install. No numerical target before separately frozen specification.',
 'acceptance': 'Auditable complete current manuscript reading,versioned canonical claims/method contracts/limits,actual selected history/formal comparisons and explicit gaps; distinct applications only if concrete. Full graph/source/impact/export/core/clean/compression for canonical changes. Global043 after this package.',
 'stop_or_redirect': 'Do not infer linear runtime from linear piece count, arbitrary weighted/directed/multigraph coverage from simple graphs,or application speedup from finite known examples. Preserve old-method sufficiency and missing proof/history/human gates.',
 'depends_on': ['WP-121'], 'created_at': now, 'body_reading_credit': 0,
 'github_push': False, 'retrospective_due': 'Global043 mandatory after WP122,third substantive package after042.'}
backlog['tasks'].append(next_task);backlog['updated_at'] = now
save(root / 'state/backlog.json', backlog)
checkpoint = json.loads((root / 'state/checkpoint.json').read_text())
checkpoint['completed_work_packages'].append('WP-121')
checkpoint.update({'saved_at': now, 'updated_at': now, 'overall_status': 'active_incomplete',
 'last_completed_work_package': 'WP-121', 'work_packages_since_last_retrospective': 2,
 'active_work_package': next_task, 'next_work_package': next_task,
 'last_quality_evidence': str((dest / 'quality.json.gz').relative_to(root)),
 'storage_receipt': str((dest / 'storage.json').relative_to(root)),
 'running_research_experiments': [], 'previous_goal_turn_classification': 'progress:verified core88 terminal; prior status response was no research-state advance; current continuation closes diagnostic QA/storage and rotates actual source work.'})
commands = ['Read goal,AGENTS,charter,roadmap,status,checkpoint,backlog and global042; verify disk and current handles before expensive work.',
 'WP121 complete. EXP337 original192fixture diagnostic and exact full archived-source replay terminal,resources/runtime binding passed.16exceptions excluded by frozen prediction; no new initial check. Do not rerun for current graph/reporting fingerprint.',
 'Read reports/F337-AD-execution.md and execution closure/quality/clean/storage receipts. Both core and clean88 passed; diagnostic projection/counts remain disjoint.',
 'Start WP122 F181 complete source9TeX/Bib2566lines; selection-WP122.json is metadata-only before actual reading. Compare finite witness and construction cost; linear pieces does not imply linear time.',
 'After WP122 mandatory global043; retain F238 six unread companions and historical-closure resources. No routine GitHub push/math mutation. Humans and second provider remain deferred,not counted.']
checkpoint['resume_commands'] = commands;checkpoint['recovery_commands'] = commands
checkpoint['recovery_observation']['WP121_final_boundary'] = {'at': now, 'core_tests': 88, 'clean_tests': 88, 'all_quality_handles_terminal': True, 'running_research_experiments': [], 'clean_directory_removed': True, 'diagnostic_initial_credit': 0, 'available_disk_observed': '30GiB system observation before clean copy', 'math_commit': '1581d4cbdd69a0faf34b2089614fe2a814316a6a'}
save(root / 'state/checkpoint.json', checkpoint)
status = root / 'state/status.md';old = status.read_text();head,history = old.split('以下为历次工作记录，数字保留为当时快照。',1)
head = head.replace('88核心／无math干净副本／最终压缩闭包进行中。','88核心与无math干净副本均通过，压缩归档闭包已完成。')
head = re.sub(r'更新时间：[^。]+。', '更新时间：' + now + '。', head, count=1)
paragraph = '\n\nWP121最终闭包（' + now + '）：192参考有效、16后端异常，冻结主预测待定；原始39源码与首次完整重放一致，资源通过，不增加初检。GEN118新增2规范／3边、3旧记录版本化，5403旧行与492保护文件保持。完整8579节点24817关系／9428规范来源（9418核心），126单种子+2多种子、17归档337成员、88核心及无math干净副本' + str(clean['files']) + '文件' + str(clean['bytes']) + '字节通过，副本已删除。全部自有辅助／日志压缩回解逐成员核验后清理；数值实现不变。47候选／14初检／14不同验证／6限定支持／8不利，另1不计初检诊断；62阅读57草稿及完整族历史人审等0保持。复盘042后计数2，WP122转低覆盖F181完整原文，选题仅README／清单、正文0；结束后强制043。不推GitHub，整体active_incomplete。\n'
status.write_text(head + '以下为历次工作记录，数字保留为当时快照。' + history + paragraph)
pub = json.loads((root / 'state/publication.json').read_text())
pub['local_progress_after_verified_snapshot'] = 'WP113GEN110 through WP121GEN118/global042 local only. WP121 actual192fixture/16backendexception diagnostic and strict replay complete; qualified initial checks remain14,candidates47. Public d48dd19 remains older WP112/unfinishedWP113. No routine push.'
save(root / 'state/publication.json', pub)

# Compress all remaining own work files, read every member back, then remove only those verified files.
members = sorted(p for p in work.iterdir() if p.is_file())
manifest = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in members]
archive = dest / 'helpers-and-logs.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in members: tar.add(p, arcname=p.name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert sorted(tar.getnames()) == sorted(m['path'] for m in manifest)
    for m in manifest:
        raw = tar.extractfile(m['path']).read()
        assert len(raw) == m['bytes'] and hashlib.sha256(raw).hexdigest() == m['sha256']
save(dest / 'storage.json', {'at': now, 'archive': str(archive.relative_to(root)), 'archive_bytes': archive.stat().st_size,
 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': manifest,
 'all_members_roundtrip_hash_verified': True, 'plaintext_own_bytes_removed': sum(m['bytes'] for m in manifest),
 'clean_copy_removed_after_success': True, 'tiny_verified_wheel_retained': '/private/tmp/ai-paper-WP120/autograd-1.9.1-py3-none-any.whl',
 'scientific_outputs_and_attempts_retained_compressed': True, 'failure_note': 'An earlier patch verification failed before mutation; corrected patch was applied without changing frozen numerical code. No failed scientific data deleted.'})
for p in members: p.unlink()
work.rmdir()
print(json.dumps(summary, ensure_ascii=False))
