from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;base='f1ec0eb';changed={'APP-337-01','PROB-337-ZERO-COMPOSITE-AD','ANALYSIS-F-337'}
def old(p):return subprocess.check_output(['git','show',base+':'+p])
prior={n['id']:n for n in json.loads(gzip.decompress((r/'data/graph/history/GEN-20261027-118-before.json.gz').read_bytes()))['records']};before=old('data/graph/nodes.jsonl').splitlines(keepends=True);after=(r/'data/graph/nodes.jsonl').read_bytes().splitlines(keepends=True);kept=0
for a,b in zip(before,after):
 x,y=json.loads(a),json.loads(b);assert x['id']==y['id']
 if x['id'] in changed:assert x==prior[x['id']] and y['version']==x['version']+1
 else:assert a==b;kept+=1
assert kept==5403 and len(before)==5406 and len(after)==5408
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
protected=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')) and name not in {'src/ai_value/graph.py','src/ai_value/reporting.py','tests/test_ad_protocol.py','reports/families/F-337.md'}:
  assert (r/name).read_bytes()==old(name),name;protected.append(name)
canonical=validate(r);metrics=render(r);export(r);nodes,edges=load(r)
assert metrics['candidate_connections']==47 and metrics['externally_checked_cards']==14 and metrics['distinct_validation_hypotheses']==14 and metrics['effective_leads']==6
assert metrics['diagnostic_executions_not_initial_checks']==1 and metrics['component_checks']==2
assert metrics['partial_reading_families']==62 and metrics['source_decomposition_drafts']==57
assert all(metrics[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
run='EXP-337-001-b13e1932a05a4c6a';app=nodes['APP-337-01']['properties'];assert app['run_ids']==[] and app['diagnostic_run_ids']==[run] and app['application_result']=='观察' and app['theoretical_grade']=='unknown'
assert any(e['source']=='APP-337-01' and e['relation']=='diagnostic_execution' and e['target']=='RUN-'+run.upper() for e in edges)
assert not any(e['source']=='APP-337-01' and e['relation']=='externally_checked_by' for e in edges)
a=nodes['ANALYSIS-F-337']['properties'];assert a['formal_status']==prior['ANALYSIS-F-337']['properties']['formal_status'] and a['result_ids_by_source']==prior['ANALYSIS-F-337']['properties']['result_ids_by_source']
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {n['id']:n for n in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};graph=xml.find('g:graph',ns);xn={n.attrib['id']:json.loads(next(x.text for x in n.findall('g:data',ns) if x.attrib['key']=='properties')) for n in graph.findall('g:node',ns)};xe=[json.loads(next(x.text for x in e.findall('g:data',ns) if x.attrib['key']=='evidence')) for e in graph.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F337-AD-registration/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 key='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[key] in impact_report(nodes,edges,{v['seed']})['affected'])==(key=='required_affected');impacts.append(v)
for seed,target in [('OBS-337-FIRST-DIAGNOSTIC','CLM-337-SCALAR-C1-JOIN'),('OBS-337-FIRST-DIAGNOSTIC','APP-276-01'),('RUN-'+run.upper(),'CLM-337-GCH-THM-EQUALITY')]:
 assert target not in impact_report(nodes,edges,{seed})['affected'];impacts.append({'seed':seed,'must_not_propagate_to':target,'confirmed':True,'scope':'Diagnosticexecutionisnotmathematicalprooforunrelatedapplicationsupport'})
for v in previous['alternative_route_cases']:assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected'])
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snapshot=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snapshot.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snapshot);archives.append({'run_id':f.name,'source_members':len(snapshot),'all_output_and_roundtrip_source_hashes':True})
assert len(archives)==17 and members==337
ledger=json.loads((r/'data/provenance/readings/F-337-AD-execution.json').read_text());assert ledger['initial_check_credit']==0 and ledger['reference_valid_fixtures']==192 and len(ledger['backend_exceptions'])==16
f=r/'experiments/runs'/run;m=json.loads((f/'manifest.json').read_text());summary=json.loads(gzip.decompress((f/'summary.json.gz').read_bytes()));assert summary['outcome']=='inconclusive_backend_exception' and not summary['meets_prediction'] and summary['old_correct_branch_suffices'] is None
freeze=json.loads((r/'reports/reproducibility/20261027-F337-AD-registration/implementation-freeze.json').read_text());assert m['inputs']==freeze['source_inputs'] and m['resource_envelope_met'] and m['measurement_state']=='parent_child_lifecycle_finalized'
replay=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F337-AD-execution/first-target-replay.json.gz').read_bytes()));assert all(replay['deterministic_outputs_match'].values()) and replay['replay_resource_envelope_met'] and replay['external_runtime_source_binary_binding_matches']
assert '未满足合格初检条件' in (r/'reports/cards/APP-337-01.md').read_text()
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_rows_byte_equal':kept,'versioned_records':{k:[prior[k]['version'],nodes[k]['version']] for k in sorted(changed)},'new_records':2,'new_edges':3,'protected_science_corpus_other_reports_reading_ledgers':len(protected),'reading_coverage_byte_equal':True,'canonical_metrics':canonical,'generated_metrics':metrics,'full_JSON_GraphML_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':previous['alternative_route_cases'],'scientific_archives':archives,'source_archive_members':members,'actual_diagnostic_executions_added':1,'new_initial_checks':0,'new_qualified_validations':0,'source_inputs_equal_frozen39':True,'first_target_and_exact_replay_resources_pass':True,'all192referencegates_valid':True,'backend_exceptions':16,'classification':'Frozenprimaryinconclusive;exceptionsnotrelabeledassuccess. Actualdiagnosticpreservedorthogonallytopreliminarycheckcounts. No scalar-type/grid/tolerance/criteriachange or newtheorem/applicationgain/human/provideracceptance.'};b=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(b,mtime=0);assert gzip.decompress(z)==b;(w/'quality.json.gz').write_bytes(z);print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','scientific_archives','generated_metrics']},ensure_ascii=False))
