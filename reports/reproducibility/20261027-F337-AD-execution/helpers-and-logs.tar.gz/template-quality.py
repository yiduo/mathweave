from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess,sys,xml.etree.ElementTree as ET
sys.path.insert(0,'src')
from ai_value.graph import load,validate,impact_report
from ai_value.reporting import render
from ai_value.knowledge import export
r=Path.cwd();w=Path(__file__).parent;base='f7d3a96'
def old(p):return subprocess.check_output(['git','show',base+':'+p])
s=json.loads((w/'curation-summary.json').read_text());oldrows=old('data/graph/nodes.jsonl');assert (r/'data/graph/nodes.jsonl').read_bytes().startswith(oldrows)
assert len(oldrows.splitlines())==5399 and len((r/'data/graph/nodes.jsonl').read_bytes().splitlines())==5399+s['new_records']
assert (r/'data/graph/edges.jsonl').read_bytes().startswith(old('data/graph/edges.jsonl'))
assert len((r/'data/graph/edges.jsonl').read_bytes().splitlines())-len(old('data/graph/edges.jsonl').splitlines())==s['new_edges']
assert (r/'data/graph/reading_coverage.json').read_bytes()==old('data/graph/reading_coverage.json')
preserved=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines():
 if name.startswith(('src/','tests/','experiments/','data/corpus/','reports/families/','data/provenance/readings/')) and name not in {'src/ai_value/experiments.py','src/ai_value/attempts.py'}:
  assert (r/name).read_bytes()==old(name),name;preserved.append(name)
metrics=validate(r);generated=render(r);export(r);nodes,edges=load(r)
assert generated['partial_reading_families']==62 and generated['source_decomposition_drafts']==57
assert generated['candidate_connections']==47 and generated['externally_checked_cards']==14 and generated['effective_leads']==6 and generated['distinct_validation_hypotheses']==14
assert all(generated[k]==0 for k in ['human_grading_records','pilots','human_spec_reviews','cross_provider_reviews','full_lineages_complete','all_six_stages_complete_families','complete_family_decompositions'])
a=nodes['ANALYSIS-F-337']['properties'];assert len(a['result_ids_by_label'])==54 and len(a['unlabelled_result_ids'])==1 and len(a['method_ids'])==18 and len(a['historical_references_by_key'])==46
refs=list(a['result_ids_by_label'].values())+a['unlabelled_result_ids'];assert sum(nodes[x]['properties']['source_claim_grade']=='B' for x in refs)==2
assert all(nodes[x]['properties']['dependency_chain_grade']=='unknown' for x in refs)
assert nodes['CLM-337-GCH-THM-MAIN']['properties']['source_claim_grade']=='C' and nodes['CLM-337-GCH-THM-EQUALITY']['properties']['source_claim_grade']=='C'
assert nodes['CLM-337-CAT0-THM-MAIN']['properties']['source_claim_grade']=='B'
assert not a['full_family_complete'] and not a['historical_lineage_complete'] and not a['formal_status']['local_lean_build']
assert all(not x['accepted_connection'] for x in nodes['EXPLORE-F-337']['properties']['attempts'])
js=json.loads(gzip.decompress((r/'reports/graph/knowledge.json.gz').read_bytes()));assert {x['id']:x for x in js['nodes']}==nodes and js['edges']==edges
xml=ET.fromstring(gzip.decompress((r/'reports/graph/knowledge.graphml.gz').read_bytes()));ns={'g':'http://graphml.graphdrawing.org/xmlns'};g=xml.find('g:graph',ns)
xn={x.attrib['id']:json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='properties')) for x in g.findall('g:node',ns)};xe=[json.loads(next(d.text for d in x.findall('g:data',ns) if d.attrib['key']=='evidence')) for x in g.findall('g:edge',ns)];assert xn==nodes and xe==edges
previous=json.loads(gzip.decompress((r/'reports/reproducibility/20261027-F337-source-scope/quality.json.gz').read_bytes()));impacts=[]
for v in previous['impact_cases']:
 k='required_affected' if 'required_affected' in v else 'must_not_propagate_to';assert (v[k] in impact_report(nodes,edges,{v['seed']})['affected'])==(k=='required_affected');impacts.append(v)
cases=[
 ('CLM-337-SCALAR-C1-JOIN','APP-337-01',True),
 ('PART-337-SCALAR-BRANCH-CONTRACT','APP-337-01',True),
 ('LIT-337-AUTOGRAD-191','APP-337-01',True),
 ('P-85565211ca1088a3','APP-337-01',True),
 ('CLM-337-CAT0-THM-MAIN','APP-337-01',False),
 ('CLM-337-CAT0-LEM-CHORD-TESTS','APP-337-01',False),
 ('CLM-337-GCH-THM-EQUALITY','APP-337-01',False),
 ('LIT-337-AUTOGRAD-191','APP-276-01',False)]
for seed,target,positive in cases:
 assert (target in impact_report(nodes,edges,{seed})['affected'])==positive,(seed,target)
 impacts.append({'seed':seed,('required_affected' if positive else 'must_not_propagate_to'):target,'confirmed':True,'scope':'F337 separate manuscripts,actual prerequisites andno application-grade inheritance'})
ors=[]
for v in previous['alternative_route_cases']:
 assert set(v['required_affected'])<=set(impact_report(nodes,edges,set(v['seeds']))['affected']);ors.append(v)
archives=[];members=0
for mp in sorted((r/'experiments/runs').glob('*/manifest.json')):
 m=json.loads(mp.read_text());f=mp.parent
 for name,h in m['outputs'].items():assert hashlib.sha256((f/name).read_bytes()).hexdigest()==h
 for name,meta in m.get('compressed_payloads',{}).items():assert hashlib.sha256(gzip.decompress((f/name).read_bytes())).hexdigest()==meta['uncompressed_sha256']
 snap=json.loads(gzip.decompress((f/m['source_snapshot']).read_bytes()))
 for name,body in snap.items():assert hashlib.sha256(body.encode()).hexdigest()==m['inputs'][name]
 members+=len(snap);archives.append({'run_id':f.name,'source_members':len(snap),'output_and_roundtrip_hashes':True})
assert len(archives)==16 and members==298
ledger=json.loads((r/'data/provenance/readings/F-337.json').read_text());assert ledger['source_tex_lines']==7413 and len(ledger['results'])==54 and ledger['third_party_acquired_bytes']==3224589
for f in ledger['read_files']:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
assert not subprocess.check_output(['git','-C','math','status','--porcelain'],text=True).strip()
card=nodes['APP-337-01']['properties'];assert card['run_ids']==[] and card['application_result']=='待定' and card['source_claim_grade']=='C' and card['theoretical_grade']=='unknown'
assert all(not nodes[k]['properties'].get('human',False) for k in ['REVIEW-337-SKEPTIC-PRE-TARGET','REVIEW-337-DEFENDER-PRE-TARGET'])
citation=nodes['LIT-337-AUTOGRAD-191'];assert citation['version']==2 and citation['sources'][-1]['url'].startswith('https://files.pythonhosted.org/')
assert citation['sources'][-1]['sha256']=='b788bae3fa010cbffb4cfb7b8ba2a3f0daa6072a8506da6164c779fe9cf3e05a'
receipt={'at':datetime.now(timezone.utc).isoformat(),'base_commit':base,'old_canonical_rows_byte_equal':5399,'new_records':s['new_records'],'new_explicit_edges':s['new_edges'],'old_explicit_edge_prefix_equal':True,'preserved_science_code_tests_corpus_other_family_reports_and_prior_reading_ledgers':len(preserved),'reading_coverage_byte_equal':True,'canonical_metrics':metrics,'generated_metrics':generated,'full_json_graphml_objects_equal':True,'impact_cases':impacts,'alternative_route_cases':ors,'experiment_archives':archives,'source_archive_members':members,'new_candidates':1,'application_checks_added':0,'new_scientific_runs':0,'retained_F337_primary_original_selected_scopes':4,'retained_F337_source_bytes':3224589,'retained_F337_source_B':2,'retained_F337_source_C':53,'new_scalar_contract_source_grade':'C','new_source_downloads':0,'limitations':'Current two-manuscript source draft andselected original/formal scope only. No full lineage/proof/build/human/provider/application acceptance. NewactualADprotocolandindependentreferenceimplementationprepared,notexecuted;oldarchivepayloadsunchanged. Twelveactualsoftwareerrorcontrolsandnewcore/cleancheckseparatelyrequiredbeforefreeze.'}
raw=json.dumps(receipt,ensure_ascii=False,indent=2).encode();z=gzip.compress(raw,mtime=0);assert gzip.decompress(z)==raw;(w/'quality.json.gz').write_bytes(z)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['impact_cases','alternative_route_cases','experiment_archives','generated_metrics']},ensure_ascii=False))
